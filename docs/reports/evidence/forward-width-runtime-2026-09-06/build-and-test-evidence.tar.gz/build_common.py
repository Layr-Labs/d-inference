"""Canonical owned M5 build/tests; no real-model pilot or serving process."""
from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time,sys
import owner_helper
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'workspace'; ARTIFACT=ROOT/'artifact'; RELEASE=ROOT/'release-build'; TEST_BUILD=ROOT/'native-test-build'
MANIFEST=json.loads((ROOT/'source-manifest.json').read_text())
REPOS={row['name']:SOURCE/row['relative_path'] for row in MANIFEST['repositories']}
ENV={'HOME':str(Path.home()),'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','TMPDIR':'/private/tmp',
     'DEVELOPER_DIR':'/Applications/Xcode.app/Contents/Developer','RADIX_SOURCE_ROOT':str(SOURCE),'RADIX_CANDIDATE_BUILD':'1',
     'MAKEFLAGS':'-j4','METALLIB_CACHE_DIR':str(ROOT/'metallib-cache')}
EXECUTIONS=[]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def identity(path):
 p=Path(path);return {'sha256':sha(p),'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777}
def write(path,value):
 p=Path(path);tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n');tmp.replace(p)
def state(value):
 write(ROOT/'build-status.json',value)
def verify_sources():
 for name,repo in REPOS.items():
  head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
  dirty=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)
  if head!=MANIFEST['source'][name] or dirty:raise ValueError('canonical source drift: '+name+' '+dirty)
  for relative,expected in MANIFEST['files'][name].items():
   if identity(repo/relative)!=expected:raise ValueError('payload drift: '+name+'/'+relative)
 return {'source':MANIFEST['source'],'all_canonical_sources_clean':True}
def command(name,argv,cwd=SOURCE,timeout=3600):
 step=ROOT/'steps'/name;step.mkdir(mode=0o700)
 started=time.time();state({'state':'starting','step':name,'argv':argv,'cwd':str(cwd)})
 def emit(event):
  value=dict(event,step=name,role='build_or_native_test',log=str(step/'provider.log'))
  if event.get('event')=='started':state(dict(value,state='running',argv=argv,cwd=str(cwd),started_unix=started))
  print(json.dumps(value),flush=True)
 previous=Path.cwd()
 try:
  os.chdir(cwd)
  record=owner_helper.run_owner(argv,ENV,step,sys.stdin.buffer,emit,lease_seconds=30,deadline_seconds=timeout)
 finally:
  os.chdir(previous)
  if (step/'provider.log').exists():shutil.copy2(step/'provider.log',ROOT/'logs'/(name+'.log'))
 result=dict(record,step=name,argv=argv,cwd=str(cwd),seconds=time.time()-started)
 EXECUTIONS.append(result);write(ROOT/'executions.json',EXECUTIONS)
 if record['failure'] is not None or record['exit_code']!=0 or not record['group_cleanup_complete'] or record['stop_requested']:
  raise RuntimeError('owned command failed: '+name)
 return ROOT/'logs'/(name+'.log')

def graph_proof(name,scratch,source_roots):
 candidates=[scratch/'release.yaml',scratch/'debug.yaml'];graph=next((p for p in candidates if p.is_file()),None)
 if graph is None:raise ValueError('SwiftPM build graph missing: '+name)
 text=graph.read_text();(ROOT/(name+'-graph.yaml.gz')).write_bytes(gzip.compress(graph.read_bytes(),mtime=0))
 if '/checkouts/mlx-swift/Source/' in text or str(SOURCE/'libs/mlx/') in text:raise ValueError('noncanonical MLX source entered graph')
 paths={}
 for value in re.findall(r'"(/[^"\n]+\.(?:swift|cpp|cc|c|h|hpp|metal|mm|modulemap))"',text):
  p=Path(value)
  if p.is_file() and any(p.resolve().is_relative_to(x.resolve()) for x in source_roots):paths[str(p)]=identity(p)
 for suffix in ['quantized.cpp','ForwardShapeV2.swift','ForwardShapeDispatchV2.swift','EngineLoopV2+ForwardShapes.swift']:
  if not any(p.endswith(suffix) for p in paths):raise ValueError('required source absent from graph: '+suffix)
 write(ROOT/(name+'-source-graph.json'),{'source':MANIFEST['source'],'files':paths,'local_mlx_only':True})
 if (scratch/'workspace-state.json').exists():shutil.copy2(scratch/'workspace-state.json',ROOT/(name+'-workspace-state.json'))
 checkouts={}
 for repo in sorted((scratch/'checkouts').glob('*')):
  if (repo/'.git').exists():checkouts[repo.name]={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'dirty':subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)}
 write(ROOT/(name+'-dependency-checkouts.json'),checkouts)

def purge_owned_resources(roots):
 removed=[]
 for base in roots:
  if not base.exists():continue
  for p in sorted(base.rglob('mlx.metallib')):
   if p.is_file():removed.append(str(p));p.unlink()
  for p in sorted(base.glob('*-apple-macosx/*/*.bundle')):
   if p.is_dir():removed.append(str(p));shutil.rmtree(p)
 return removed

def stage_test_metallib():
 destinations=[TEST_BUILD/'arm64-apple-macosx/debug/mlx.metallib']
 debug=TEST_BUILD/'arm64-apple-macosx/debug'
 for bundle in debug.glob('*PackageTests.xctest'):
  macos=bundle/'Contents/MacOS'
  if macos.is_dir():destinations.append(macos/'mlx.metallib')
 if len(destinations)<2:raise ValueError('native xctest bundle not discovered')
 for p in destinations:shutil.copy2(ARTIFACT/'mlx.metallib',p)
 copies={str(p):identity(p) for p in destinations}
 if any(v['sha256']!=sha(ARTIFACT/'mlx.metallib') for v in copies.values()):raise ValueError('test metallib mismatch')
 write(ROOT/'test-metallib-copies.json',copies)
