#!/usr/bin/env python3
"""Local CPU-only exact sidecar plan proof; no provider/model/GPU execution."""
from pathlib import Path
import hashlib
import http.client
import json
import os
import socket
import subprocess
import tempfile
import time

BASE = Path(__file__).resolve().parent
SIDECAR = Path('/tmp/darkbloom-final-promptsidecar-build1/promptsidecar')
ARTIFACTS = Path('/tmp/darkbloom-release-090/prompt-artifacts').resolve()
EXPECTED = '6a0c4498c6a3d23f85001fe1d1e0b8a502e2397858a586808e792b66e85576ea'
assert hashlib.sha256(SIDECAR.read_bytes()).hexdigest() == EXPECTED
plan = json.loads((BASE/'bundle-plan.json').read_text())
results = {'scope':'Local M3 CPU-only exact pinned Rust rendering/tokenization; no provider/inference or GPU test',
           'binary_sha256':EXPECTED,'expected_request_date_utc':plan['expected_request_date_utc'],
           'status':'running','rows':[]}
with tempfile.TemporaryDirectory(prefix='db-connect-plan-', dir='/private/tmp') as tmp:
    endpoint = str(Path(tmp)/'s.sock')
    with (BASE/'supplemental-tokenizer-plan.log').open('w') as log:
        child = subprocess.Popen([str(SIDECAR),'--socket',endpoint,'--artifact-root',str(ARTIFACTS),
                                  '--max-loaded-contracts','2','--max-tokens','65536',
                                  '--memory-limit-mib','1024','--parent-pid',str(os.getpid())],
                                 stdout=log,stderr=subprocess.STDOUT)
        try:
            for _ in range(100):
                if Path(endpoint).exists(): break
                if child.poll() is not None: raise RuntimeError('sidecar exited during startup')
                time.sleep(.05)
            class UnixHTTP(http.client.HTTPConnection):
                def connect(self):
                    self.sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
                    self.sock.settimeout(30);self.sock.connect(endpoint)
            def post(path, body):
                c=UnixHTTP('localhost',timeout=30)
                c.request('POST',path,json.dumps(body),{'Content-Type':'application/json'})
                response=c.getresponse(); raw=response.read(); c.close()
                if response.status!=200: raise ValueError(str(response.status)+': '+raw.decode())
                return json.loads(raw)
            data=json.loads((BASE/'http-inputs/gemma-qat4-paged-off-b1.json').read_text())
            contract=data['artifact']['prompt_contract_id']
            post('/v1/preload',{'prompt_contract_ids':[contract]})
            cases=[]
            for cap in [32,128]:
                source=BASE/f'inputs/gemma-qat4-paged-off-b1-output{cap}.json'
                body=json.loads(source.read_text())['rows'][0]['request']
                cases.append((f'native-output{cap}',body,True))
            tool_body=data['tools_request'].copy()
            tool_body.update({'model':data['artifact']['model_id'], '_darkbloom_prompt_date':plan['expected_request_date_utc'], 'stream_options':{'include_usage':True}})
            cases.append(('tools-auto512',tool_body,False))
            named=tool_body.copy()
            named['tool_choice']={'type':'function','function':{'name':'record_color'}}
            named['parallel_tool_calls']=False
            cases.append(('tools-named-cpu-normalization-only',named,False))
            for name,body,long_prompt in cases:
                (BASE/'cpu-requests').mkdir(exist_ok=True)
                (BASE/'cpu-requests'/(name+'.json')).write_text(json.dumps(body,indent=2)+'\n')
                answer=post('/v1/plan',{'prompt_contract_id':contract,'scope_id':'qat-supplemental-token-plan-only','endpoint':'chat_completions','body':body})
                (BASE/'cpu-requests'/(name+'-plan.json')).write_text(json.dumps(answer,indent=2)+'\n')
                count=answer['prompt_token_count']
                assert count > (4096 if long_prompt else 0),(name,count)
                results['rows'].append({'case':name,'model_id':data['artifact']['model_id'],'prompt_contract_id':contract,'prompt_tokens':count,'request_sha256':hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':')).encode()).hexdigest(),'max_tokens':body['max_tokens'],'scope':'CPU renderer/normalizer only; no runtime tool or model result'})
            results['status']='passed'
        finally:
            child.terminate()
            try: child.wait(timeout=10)
            except subprocess.TimeoutExpired: child.kill();child.wait()
            (BASE/'supplemental-tokenizer-plan.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
