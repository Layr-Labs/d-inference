from pathlib import Path
import hashlib,json,shutil,subprocess
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/segmented-dispatch-metadata-cache/libs/mlx-swift-lm')
out=Path('/tmp/darkbloom-segment-dispatch-cache-source1');out.mkdir()
base='7d32d43977a5774f223b6892ecfbbaa844047600'
sha=lambda b:hashlib.sha256(b).hexdigest()
files=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=root,text=True).splitlines()
assert len(files)==6
patch=subprocess.check_output(['git','diff','--binary'],cwd=root)
proof={}
for name in sorted(files):
 p=root/name
 old=subprocess.run(['git','show',base+':'+name],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 if old.returncode: patch+=subprocess.run(['git','diff','--no-index','--binary','/dev/null',name],cwd=root,stdout=subprocess.PIPE).stdout
 proof[name]={'before_sha256':sha(old.stdout) if old.returncode==0 else None,'after_sha256':sha(p.read_bytes()),'bytes':p.stat().st_size}
 target=out/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
(out/'native.patch').write_bytes(patch)
(out/'source-proof.json').write_text(json.dumps({'parent_base':'bd8dee80297f0d806b8f5c11bd204460536ca6f6','native_base':base,'worktree':str(root),'files':proof},indent=2)+'\n')
filters=['CBv2PagedSegmentDispatchCacheTests','CBv2PagedSegmentDispatchCacheExecutionTests','CBv2PagedSegmentDispatchCacheEngineTests','CBv2PagedSegmentTests','CBv2PagedRuntimeDTypeTests','CBv2PagedBackendTests','CBv2PagedPrefixBlockCacheTests','CBv2OrdinaryAttentionPacketTests','Qwen35PagedExecutionTests']
(out/'filters.json').write_text(json.dumps(filters,indent=2)+'\n')
(out/'REVIEW.md').write_text('''# Segmented dispatch metadata cache source1

One last plan per PagedLayerCache. Only canonical full row tables carry row serial/tableVersion identity; direct callers and windowed rows bypass. The key covers ordered row identities, table length, visible page/partition counts, writer page/hasWrite, PTOK, page size/group geometry, and exact segment ranges. Dynamic growing token length, write slot, seqinfo, params and group write fence are never cached. KV segment storage is freshly looked up, never retained by cached metadata. Same ordered setRows keeps the plan; changed/empty membership clears it.

Segment ranges are append-only value identity. Removing or recreating backing of an identical range does not change records or value offsets; current storage is fetched each dispatch, and a new row serial prevents page recycling from aliasing a previous request. No new storage-generation token or global dictionary is needed. Rebased checkpoint segments require exactly equal size classes in the existing constructor.

Optional internal Statistics distinguish key lookup time, host/device-metadata preparation time, hits, rebuilds and bypasses. Nil by default: no clock reads. They are available to the existing native profiler/tests without a production environment flag.

Tests: per-token exact fresh host/device record comparison across pages/partitions and >17 bindings; exact Q36 geometry; mixed batch order and partition/hasWrite changes; rollback and Swift array copy-on-write; identityless/window fallback; topology growth and weak storage retirement; row reuse and membership clearing; BF16/FP32 lazy successors across record replacement with native output/history identity; shared-prefix adoption with private tail; actual EngineV2 direct/chained trajectories versus clearing metadata before each normal forward. Existing ordinary packet suite covers coexisting diagnostics, cancellation and typed unwind. Shared partial-frontier KV COW remains deliberately unsupported by the existing backend.

No kernel, partition policy, intermediate dtype, attention arithmetic, sampling, default env, model or remote operation changes. This source freeze precedes compilation; no performance claim.
''')
shutil.copy2('/tmp/freeze-segment-dispatch-source1.py',out/'freeze-source.py')
manifest={'files':{str(p.relative_to(out)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file()}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'root':str(out),'manifest_sha256':sha((out/'manifest.json').read_bytes()),'payloads':len(manifest['files']),'sources':len(files)},indent=2))
