// Copyright © 2025 Apple Inc.

import Foundation

// MARK: - JSON to Sendable Bridge

/// Convert a JSON-deserialized value to `any Sendable`.
///
/// `JSONSerialization` returns `Any`, but all JSON types it produces
/// (String, NSNumber, NSNull, Array, Dictionary) are Sendable.
func asSendable(_ value: Any) -> any Sendable {
    switch value {
    case let s as String: return s
    case let n as NSNumber: return n
    case let a as [Any]: return a.map(asSendable)
    case let d as [String: Any]: return d.mapValues(asSendable)
    case let null as NSNull: return null
    default: return "\(value)"
    }
}

/// Deserialize JSON data, returning a Sendable value.
func deserializeJSON(_ data: Data) -> (any Sendable)? {
    guard let object = try? JSONSerialization.jsonObject(with: data) else { return nil }
    return asSendable(object)
}

/// Normalize an OpenAI tool-call `arguments` payload for chat-template rendering.
///
/// The OpenAI wire format delivers `function.arguments` as a JSON-encoded
/// *string* (e.g. `#"{"command":"ls -la"}"#`). Gemma's `chat_template.jinja`
/// opens its own `{ … }` block around the call and, on the `is string` branch,
/// dumps that string verbatim — producing a malformed double brace
/// `call:run_terminal{{"command":"ls -la"}}`. The model then imitates that
/// shape on the next turn and the output parser shreds it (splitting the inner
/// object at its first `:`), corrupting `function.arguments`.
///
/// Decoding the string into a `[String: any Sendable]` object makes the
/// template take the `is mapping` branch and emit valid `command:<|"|>ls -la<|"|>`
/// pairs instead. Returns the decoded object when `raw` is a JSON object;
/// otherwise returns `raw` unchanged so non-JSON arguments (and JSON
/// non-objects) keep their original shape. This only normalizes the
/// *template-input* shape — the OpenAI request/response contract still carries
/// `arguments` as a `String`.
public func decodeToolCallArguments(_ raw: String) -> any Sendable {
    guard let data = raw.data(using: .utf8),
        let decoded = deserializeJSON(data),
        let object = decoded as? [String: any Sendable]
    else {
        return raw
    }
    return object
}

