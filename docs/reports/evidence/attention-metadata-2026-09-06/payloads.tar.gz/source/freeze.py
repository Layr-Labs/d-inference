#!/usr/bin/env python3
"""Freeze source and CPU wrapper checks; no Swift build or model execution."""
import ast
import datetime
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

WORKTREE = Path('/Users/gaj/Documents/DarkbloomDev/wt/q36-attention-metadata-diagnostic')
NATIVE = WORKTREE/'libs/mlx-swift-lm'
OUT = Path(__file__).resolve().parent
commands = []


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(argv, cwd, label):
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    result = subprocess.run(argv, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    (OUT/(label+'.stdout')).write_text(result.stdout)
    (OUT/(label+'.stderr')).write_text(result.stderr)
    commands.append({'argv': argv, 'cwd': str(cwd), 'started_utc': started,
                     'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                     'exit_code': result.returncode, 'stdout': label+'.stdout', 'stderr': label+'.stderr'})
    (OUT/'commands.json').write_text(json.dumps(commands, indent=2)+'\n')
    assert result.returncode == 0, label
    return result.stdout


def main():
    heads = {}
    paths = {}
    for label, repo, expected in [
        ('parent', WORKTREE, 'dda0b8807dbef8eec53d90a5136cc111ab8c819a'),
        ('native', NATIVE, '5cb848dfdaae04118ecfa901f53fc21a4aa86a06'),
    ]:
        heads[label] = run(['git', 'rev-parse', 'HEAD'], repo, label+'-head').strip()
        assert heads[label] == expected
        untracked = run(['git', 'ls-files', '--others', '--exclude-standard'], repo, label+'-new-files').splitlines()
        if untracked:
            run(['git', 'add', '-N', '--']+untracked, repo, label+'-intent-to-add')
        args = ['git', 'diff', '--no-ext-diff', '--binary']
        if label == 'parent':
            args += ['--', 'scripts/benchmarks']
        patch = run(args, repo, label+'-diff')
        (OUT/(label+'.patch')).write_text(patch)
        run(['git', 'diff', '--check'], repo, label+'-diff-check')
        selected = run(['git', 'diff', '--name-only'], repo, label+'-changed-files').splitlines()
        selected = [name for name in selected if name != 'libs/mlx-swift-lm']
        paths[label] = {}
        for name in selected:
            source = repo/name
            destination = OUT/'source'/label/name
            destination.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, destination)
            baseline = subprocess.run(['git', 'show', expected+':'+name], cwd=repo,
                                      stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            paths[label][name] = {
                'before_sha256': hashlib.sha256(baseline.stdout).hexdigest() if baseline.returncode == 0 else None,
                'after_sha256': sha(source), 'bytes': source.stat().st_size}
    run(['python3', '-B', '-m', 'unittest', '-v', 'test_run_radix_engine'],
        WORKTREE/'scripts/benchmarks', 'python-wrapper-tests')
    for name in ['run_radix_engine.py', 'test_run_radix_engine.py']:
        ast.parse((WORKTREE/'scripts/benchmarks'/name).read_text(), feature_version=(3, 9))
    review = {
        'status': 'Source candidate awaiting root review; Swift build and tests unrun',
        'worktree': str(WORKTREE), 'baseline_heads': heads, 'source_files': paths,
        'python_wrapper_tests': 11, 'python39_parse': 'PASS',
        'native_test_functions_authored': 8, 'benchmark_test_functions_authored': 2,
        'scope': 'Default-nil metadata at the normal cache attention boundary, one request and ordinary B1 MTP-off generated index; all full-attention owners',
        'observations': [
            'Actual original query and incoming K/V dtype, shape, graph-construction strides and scale bits',
            'Actual native contiguous visible K/V or fixed/segmented backing metadata; no gather or copy',
            'Actual contiguous SDPA or fixed/segmented paged dispatch branch, kernel output and outward output dtype',
            'Actual row offsets and compact-to-model layer mapping',
            'Separate graph construction status and normal in-flight confirmed/discarded sample identity',
        ],
        'bounds': 'One selected forward, 1..128 layer records (default64), at most64 segment metadata records per owner; no tensor bytes captured',
        'clear_lifecycle': 'Concrete binding cleared in forward defer; host-only capture attaches to existing step and retires with normal sample confirmation/discard; failed pending forward and shutdown clear ownership',
        'limitations': [
            'Metadata-only: numerical Q/K/V/output packets and independent FP32 reference remain required',
            'Graph-construction strides may change during evaluation; no evaluated-layout claim',
            'No Swift compilation, native or benchmark test execution, real-model runtime, performance result or parity acceptance',
            'No kernel, precision, cache default, routing, model, source contract or production configuration changes',
        ],
    }
    (OUT/'review.json').write_text(json.dumps(review, indent=2)+'\n')
    files = {str(p.relative_to(OUT)): {'sha256': sha(p), 'bytes': p.stat().st_size}
             for p in sorted(OUT.rglob('*')) if p.is_file()}
    (OUT/'manifest.json').write_text(json.dumps({'files': files}, indent=2)+'\n')
    print(json.dumps({'manifest_sha256': sha(OUT/'manifest.json'), 'payload_files': len(files),
                      'parent_source_files': len(paths['parent']), 'native_source_files': len(paths['native']),
                      'review': str(OUT/'review.json')}, indent=2))


if __name__ == '__main__':
    main()
