from pathlib import Path
import hashlib,json,subprocess,sys
OUT=Path(__file__).parent;ROOT=Path('/tmp/darkbloom-connected-http6-results');PACKAGE=Path('/tmp/darkbloom-connected-m5-bundle6-q38')
sys.path.insert(0,'/tmp/darkbloom-connected-http6-execution-prep2')
from common import strict_cell,sha,item,save
CELLS=['qwen38-paged-off-b1','qwen38-paged-ssd-b1']
reports=[];raw=[]
for cell in CELLS:
 folder=ROOT/cell;m=json.loads((folder/'manifest.json').read_text())
 for name,expected in m['files'].items():assert item(folder/name)==expected,name
 launch=json.loads((folder/'launch.json').read_text());report=json.loads((folder/'evidence/report.json').read_text())
 errors=strict_cell(launch,report,cell);assert not errors,(cell,errors)
 reports.append(report);raw.append({'cell':cell,'manifest_sha256':sha(folder/'manifest.json'),'remote_execution':json.loads((folder/'execution.json').read_text()),'postflight':json.loads((folder/'ownership-after.json').read_text()),'launch_status':launch['status'],'launch_exit_code':launch['exit_code'],'owned_group_cleanup':launch['owned_group_cleanup'],'all_ten_cases_passed':True,'strict_errors':errors})
command=[sys.executable,'-B',str(PACKAGE/'compare_connected_cache_http.py'),str(ROOT/CELLS[0]/'evidence/report.json'),str(ROOT/CELLS[1]/'evidence/report.json'),'--output',str(OUT/'strict-pair.json')]
result=subprocess.run(command,text=True,capture_output=True);(OUT/'compare.stdout').write_text(result.stdout);(OUT/'compare.stderr').write_text(result.stderr)
save(OUT/'compare-command.json',{'argv':command,'exit_code':result.returncode,'comparator_sha256':sha(PACKAGE/'compare_connected_cache_http.py')})
comparison=json.loads((OUT/'strict-pair.json').read_text())
rows=[]
for a,b in zip(reports[0]['cases'],reports[1]['cases']):
 record={'name':a['name']}
 for label,row in [('off',a),('ssd',b)]:
  terminals=[e for e in row['wire'] if e['type']=='inference_complete'];assert len(terminals)==1
  terminal=terminals[0]['fields'];profile=terminal['profile'];usage=terminal['usage']
  lookup=[e for e in row['wire'] if e['type']=='prefix_cache_lookup_v2']
  record[label]={'status':row['status'],'first_content_ms':row['http']['first_content_ms'],'total_ms':row['http']['total_ms'],'usage':usage,'terminal_count':len(terminals),
   'lookup_count':len(lookup),'lookup_fields':[e['fields'] for e in lookup],
   'lookup_precedes_terminal':all(row['wire'].index(e)<row['wire'].index(terminals[0]) for e in lookup),
   'accepted_ssd_lookup_delta':row['after']['lifecycle']['ssd_lookups']-row['before']['lifecycle']['ssd_lookups'],
   'accepted_ssd_hit_delta':row['after']['lifecycle']['ssd_hits']-row['before']['lifecycle']['ssd_hits'],
   'cancelled_by_client':row['http']['cancelled_by_client'],'http_done':row['http']['done'],
   'cancel_count':sum(e['type']=='cancel' for e in row['wire']),
   'cancel_profile':{k:v for k,v in profile.items() if k.startswith('cancel_')},'mtp_active':profile['mtp_active']}
 record['first_content_ms_delta_off_minus_ssd']=record['off']['first_content_ms']-record['ssd']['first_content_ms']
 record['first_content_ratio_off_over_ssd']=record['off']['first_content_ms']/record['ssd']['first_content_ms']
 rows.append(record)
cancel=next(row for row in rows if row['name']=='cancel')['ssd']
assert cancel['usage']['cache_outcome']=='hit' and cancel['usage']['cache_tier']=='ssd' and cancel['usage']['cached_tokens']>0 and cancel['usage']['prefill_tokens_saved']>0
assert cancel['lookup_count']==cancel['accepted_ssd_lookup_delta']==cancel['accepted_ssd_hit_delta']==cancel['terminal_count']==cancel['cancel_count']==1
assert cancel['lookup_precedes_terminal'] and cancel['cancelled_by_client'] and not cancel['http_done']
assert cancel['cancel_profile']['cancel_aborted_us']>=cancel['cancel_profile']['cancel_received_us']
save(OUT/'analysis.json',{'status':'STRICT_HTTP_PAIR_PASS' if comparison['passed'] else 'STRICT_HTTP_PAIR_FAIL','comparison':comparison,'raw_cells':raw,'rows':rows,
 'runtime':{'provider_sha256':reports[0]['input']['provider_sha256'],'provider_parent_commit':'98103b39741a48f9d47026be7393362318a2ab0a','native_commit':'dcf39f6b43effaa2b483211c97d7d3a3e7c0269b'},
 'scope':'Single same-binary Qwen3.8 paged B1 normal-MTP HTTP off/SSD pair, all ten original cases; two providers on one M5. Cancel length is transport-dependent under unchanged oracle. No independent-machine, signed/persistent restart, backend parity, all-model rollout, namespace, repetition or release acceptance claim.',
 'timing_scope':'One observation per case; descriptive first-content timings include actual HTTP path. No decode-only or broad performance gain claim. Cold provider/load and durable donation wait are retained in raw evidence.',
 'historical_failure':'HTTP5 remains failed at SSD cancellation with first7passed/1failed/2unrun; no historical overwrite.'})
save(OUT/'manifest.json',{'files':{p.name:item(p) for p in sorted(OUT.iterdir()) if p.is_file()}})
print(json.dumps({'status':comparison,'cancel_ssd':cancel,'analysis_sha256':sha(OUT/'analysis.json')},indent=2));sys.exit(result.returncode)
