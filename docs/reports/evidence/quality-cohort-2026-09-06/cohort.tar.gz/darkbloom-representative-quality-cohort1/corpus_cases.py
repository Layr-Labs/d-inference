"""Deterministic public reference windows; no model outputs inform selection."""
from pathlib import Path
import hashlib
import json
import re

from cohort_common import checked, read_json, require, write_json

ROOT = Path(__file__).resolve().parent
SHORT_CHARS = 2_048
LONG_CHARS = 24_576
REFERENCE_CHARS = 2_048


def rank(seed, domain, identifier):
    return hashlib.sha256((seed + "|" + domain + "|" + str(identifier)).encode()).hexdigest()


def normalized_text(raw, prose=False):
    text = raw.decode("utf-8-sig").replace("\r\n", "\n").replace("\r", "\n")
    if prose:
        start = re.search(r"\*\*\* START OF (?:THE|THIS) PROJECT GUTENBERG EBOOK[^\n]*\*\*\*", text)
        end = re.search(r"\*\*\* END OF (?:THE|THIS) PROJECT GUTENBERG EBOOK[^\n]*\*\*\*", text)
        require(start is not None and end is not None and start.end() < end.start(), "Gutenberg body delimiters missing")
        text = text[start.end():end.start()].strip()
    return text


def window_pair(source, text, seed, domain):
    if domain == "prose":
        anchors = [match.end() for match in re.finditer(r"\n[ \t]*\n", text)]
    else:
        anchors = [match.start() for match in re.finditer(r"(?m)^ {0,8}(?=def |class )", text)]
    anchors = [offset for offset in anchors if LONG_CHARS <= offset <= len(text) - REFERENCE_CHARS]
    require(anchors, "source has no eligible long-context anchor: " + source["id"])
    ordered = sorted(anchors, key=lambda offset: rank(seed, "anchor:" + source["id"], offset))
    for anchor in ordered:
        reference = text[anchor:anchor + REFERENCE_CHARS]
        if reference[:256] not in text[anchor-LONG_CHARS:anchor]:
            break
    else:
        raise ValueError("every deterministic anchor leaks its reference prefix")
    result = []
    for length, size in [("short", SHORT_CHARS), ("long", LONG_CHARS)]:
        start = text.find("\n", anchor-size)
        require(0 <= start < anchor, "missing source line boundary")
        start += 1
        context = text[start:anchor]
        if domain == "code":
            prompt = "Continue this Python source fragment. Return only a fenced Python code block.\n\n```python\n" + context + "\n```"
            answer = "```python\n" + reference + "\n```"
        else:
            prompt = "Continue this narrative excerpt in its style. Return only the continuation.\n\n" + context
            answer = reference.lstrip()
        result.append({"id": domain + "-" + source["id"] + "-" + length,
            "domain": domain, "length": length, "source_id": source["id"],
            "source_revision": source["revision"], "source_sha256": source["sha256"],
            "source_offsets": {"unit": "Unicode code points after LF/BOM and Gutenberg-body normalization",
                               "context_start": start, "reference_start": anchor, "reference_end": anchor + REFERENCE_CHARS},
            "selection": {"eligible_anchors": len(anchors), "rank": ordered.index(anchor), "anchor_sha256_rank": rank(seed, "anchor:" + source["id"], anchor)},
            "context_text": context, "prompt_text": prompt, "reference_text": answer,
            "output_token_cap": 128, "teacher_continuation_cap": 64})
    return result


def reasoning_pairs(source, rows, seed):
    eligible = [index for index, row in enumerate(rows) if 512 <= len(row["answer"]) <= 1_100]
    targets = sorted(eligible, key=lambda index: rank(seed, "gsm8k-target", index))[:2]
    require(len(targets) == 2, "insufficient deterministic reasoning targets")
    target_questions = {rows[index]["question"] for index in targets}
    target_answers = {rows[index]["answer"] for index in targets}
    demos = [index for index, row in enumerate(rows)
             if row["question"] not in target_questions and row["answer"] not in target_answers]
    demos.sort(key=lambda index: rank(seed, "gsm8k-demonstration", index))
    selected, blocks, size = [], [], 0
    for index in demos:
        row = rows[index]
        block = "Worked problem:\n" + row["question"] + "\nSolution:\n" + row["answer"] + "\n\n"
        selected.append(index); blocks.append(block); size += len(block)
        if size >= LONG_CHARS:
            break
    require(size >= LONG_CHARS and size < LONG_CHARS + 8_000, "reasoning demonstration bound differs")
    result = []
    for index in targets:
        row = rows[index]
        require(re.search(r"####\s*[^\n]+\s*$", row["answer"]) is not None, "reasoning answer delimiter missing")
        for length, count in [("short", 2), ("long", len(blocks))]:
            context = "".join(blocks[:count])
            prompt = ("Use the worked examples as context. Solve only the final problem, show your reasoning, "
                      "and end with #### followed by the answer.\n\n" + context +
                      "Final problem:\n" + row["question"])
            result.append({"id": "reasoning-gsm8k-" + str(index) + "-" + length,
                "domain": "reasoning", "length": length, "source_id": source["id"],
                "source_revision": source["revision"], "source_sha256": source["sha256"],
                "selection": {"target_row": index, "eligible_targets": len(eligible), "demonstration_rows": selected[:count],
                              "target_sha256_rank": rank(seed, "gsm8k-target", index), "split": "test"},
                "context_text": context + "Final problem:\n" + row["question"],
                "prompt_text": prompt, "reference_text": row["answer"],
                "reference_final_answer": row["answer"].rsplit("####", 1)[1].strip(),
                "output_token_cap": 256, "teacher_continuation_cap": 64})
    return result


def build(root=ROOT):
    lock = read_json(root / "source-lock.json")
    sources = {row["id"]: row for row in lock["files"]}
    for source in sources.values():
        checked(root, source)
    seed = lock["selection"]["seed"]
    cases = []
    for identifier in ["gutenberg-11", "gutenberg-35"]:
        source = sources[identifier]
        cases += window_pair(source, normalized_text((root/source["path"]).read_bytes(), prose=True), seed, "prose")
    for name in lock["selection"]["selected_code_paths"]:
        source = sources["cpython-" + Path(name).stem]
        cases += window_pair(source, normalized_text((root/source["path"]).read_bytes()), seed, "code")
    source = sources["gsm8k-test"]
    rows = [json.loads(line) for line in (root/source["path"]).read_text().splitlines()]
    require(all(set(row) == {"question", "answer"} and all(isinstance(v, str) for v in row.values()) for row in rows), "GSM8K schema differs")
    cases += reasoning_pairs(source, rows, seed)
    cases.sort(key=lambda case: (case["domain"], case["id"]))
    require(len(cases) == len({case["id"] for case in cases}) == 12, "quality coverage differs")
    require(all(case["reference_text"] not in case["prompt_text"] for case in cases), "reference leaked into prompt")
    return {"schema": 1, "selection_seed": seed, "cases": cases,
            "sample_scope": "12 deterministic coverage cases, not a population quality estimate",
            "training_data_exclusion_claim": False}


if __name__ == "__main__":
    value = build()
    write_json(ROOT / "cases.json", value)
    print(json.dumps([{key: case[key] for key in ["id", "domain", "length", "output_token_cap"]}
                      for case in value["cases"]], indent=2))
