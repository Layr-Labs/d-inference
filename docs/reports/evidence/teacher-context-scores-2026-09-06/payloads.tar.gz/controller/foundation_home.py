import ctypes
import json

foundation = ctypes.CDLL('/System/Library/Frameworks/Foundation.framework/Foundation')
objc = ctypes.CDLL('/usr/lib/libobjc.A.dylib')
foundation.NSHomeDirectory.restype = ctypes.c_void_p
objc.sel_registerName.argtypes = [ctypes.c_char_p]
objc.sel_registerName.restype = ctypes.c_void_p
objc.objc_msgSend.argtypes = [ctypes.c_void_p, ctypes.c_void_p]
objc.objc_msgSend.restype = ctypes.c_char_p
print(json.dumps({'foundation_home': objc.objc_msgSend(
    foundation.NSHomeDirectory(), objc.sel_registerName(b'UTF8String')).decode()}))
