"""Freeze the already captured common input and unbound three-arm execution plan."""
from pathlib import Path
import hashlib
import json
import shutil
import sys

ROOT = Path(__file__).resolve().parent
SOURCE = Path('/Users/gaj/Documents/DarkbloomDev/wt/attention-operator-replay-integrated')
BUILD = Path('/tmp/darkbloom-attention-operator-replay-release-build1')
CAPTURES = Path('/tmp/darkbloom-q36-attention-packet-execution1')
REMOTE = '/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1'
REMOTE_CAPTURE = '/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1/runs/'
INTEGRATION = Path('/tmp/darkbloom-attention-operator-replay-integration1')


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value): path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')
def record(path):
    return {'sha256': sha(path), 'bytes': path.stat().st_size, 'mode': oct(path.stat().st_mode & 0o777)}


def main():
    assert sha(INTEGRATION/'manifest.json') == '85992ccf2116cb774baadac6c1677ca3c115d37ed17e73174482face22dab35c'
    integration = json.loads((INTEGRATION/'manifest.json').read_text())
    for name, digest in integration['files'].items(): assert sha(INTEGRATION/name) == digest, name
    assert sha(BUILD/'preparation-manifest.json') == '97f3d299eebbbca3d9866850a84f0df5caccec04ed6dc6eb5ee03df6bfdeaa01'
    (ROOT/'runner').mkdir()
    source_map = {}
    for module in ('attention_packet', 'attention_replay'):
        for path in sorted((SOURCE/'scripts/benchmarks'/module).glob('*')):
            if not path.is_file(): continue
            relative = path.relative_to(SOURCE/'scripts/benchmarks')
            target = ROOT/'runner'/relative
            target.parent.mkdir(exist_ok=True)
            shutil.copy2(path, target)
            source_map[str(relative)] = {'source': str(path), **record(path)}
            if module == 'attention_replay':
                accepted = INTEGRATION/'files/scripts/benchmarks'/relative
                assert target.read_bytes() == accepted.read_bytes()
    sys.path.insert(0, str(ROOT/'runner'))
    from attention_packet.packet import load_packet
    from attention_replay.transfer import ARMS, prepare
    from compare_captures import require_common_input, compare_output_to_both
    capture_paths = {
        'contiguous': CAPTURES/'qwen36-contiguous-owner0-packet/report.attention-packet/packet.json',
        'paged': CAPTURES/'qwen36-paged-owner0-packet/report.attention-packet/packet.json'}
    expected = {'contiguous': 'cc1e126c7a8f2fe7451174c613ce8170970b241a3bdd924aa4d5805dc075ad2e',
                'paged': '904b08bd45a46abbf8b6c878e190079a80529d78b79de33efa62ddb770c7cc44'}
    packets = {}
    capture_map = {}
    for backend, path in capture_paths.items():
        assert sha(path) == expected[backend]
        packets[backend] = load_packet(path)
        capture_map[backend] = {'path': str(path), 'remote_path': REMOTE_CAPTURE +
            'qwen36-' + backend + '-owner0-packet/report.attention-packet/packet.json',
            'files': {p.name: record(p) for p in sorted(path.parent.iterdir()) if p.is_file()},
            'directory_mode': oct(path.parent.stat().st_mode & 0o777)}
    shared = require_common_input(packets['contiguous'], packets['paged'])
    staged = Path('/tmp/darkbloom-q36-owner0-replay-transfer1')
    _, transfer, digest = prepare(capture_paths['contiguous'], staged)
    shutil.copy2(staged/'input.json', ROOT/'input.json')
    mapping = {name: {'source_file': tensor.descriptor['file'],
                     'destination_file': transfer['tensors'][name]['file'],
                     'source_root': str(capture_paths['contiguous'].parent),
                     'remote_source_root': str(Path(capture_map['contiguous']['remote_path']).parent),
                     **record(staged/transfer['tensors'][name]['file'])}
               for name, tensor in packets['contiguous'].tensors.items()}
    write(ROOT/'source-map.json', source_map)
    write(ROOT/'captures.json', capture_map)
    write(ROOT/'native-buffer-map.json', mapping)
    write(ROOT/'common-input-proof.json', {**shared, 'transfer_sha256': digest,
        'original_output_comparison': compare_output_to_both(packets['contiguous'].tensors['output'].raw,
                                                           packets['contiguous'], packets['paged'])})
    plan = {'schema': 'darkbloom.q36-owner0-operator-replay-plan.v1',
        'status': 'SOURCE_ONLY_PENDING_ROOT_REVIEW', 'runtime_status': 'UNBOUND',
        'remote_root': REMOTE, 'future_artifact_root': str(BUILD/'artifact'),
        'build_preparation_sha256': sha(BUILD/'preparation-manifest.json'),
        'source_integration_sha256': sha(INTEGRATION/'manifest.json'),
        'scope': 'Three genuine operators on one confirmed captured common input; no model load or release gate.',
        'capture_runtime': {'parent': '98103b39741a48f9d47026be7393362318a2ab0a',
                            'native': 'dcf39f6b43effaa2b483211c97d7d3a3e7c0269b'},
        'replay_runtime_expected': {'parent': '0b91fa8d4ed56f03c60ed5f155183bc457d6952b', 'native': '7d32d43977a5774f223b6892ecfbbaa844047600'},
        'input_sha256': digest, 'geometry': transfer['geometry'], 'shared_input': shared,
        'arms': [{'arm': arm, 'argv': [REMOTE+'/runtime/attention-replay', '--input', REMOTE+'/transfer/input.json',
                 '--input-sha256', digest, '--output', REMOTE+'/runs/'+arm, '--arm', arm],
                 'timeout_seconds': 180, 'original_capture_reproduction':
                     {'nativeSDPA': 'contiguous', 'pagedFixed': None, 'pagedSegmented': 'paged'}[arm]}
                for arm in ARMS],
        'lifecycle': ['Fresh root and exact bound source/runtime/buffer modes and hashes before launch.',
            'Sequential separate processes; preserve argv, stdout/stderr, PID, exit, timeout and complete raw output.',
            'Entry requires no owned GPU/helper jobs, GPU <=42 C, load1 <=4, free disk >100 GiB.',
            'Observe postflight idle and temperature separately from model/operator evidence; no hot successor.',
            'Stop on failed/incomplete arm or inconclusive geometry, storage, nonfinite or corresponding capture reproduction.',
            'No model, cache namespace, daemon, configuration, default symlink or key changes.'],
        'analysis': ['Local NumPy 2.4.2 with all BLAS/OpenMP/VecLib threads one; unchanged original-Q FP32 collector.',
            'Every arm versus BOTH captured outputs: exact native mismatch counts, per-head/global FP32 decoded metrics.',
            'Each paged full chronological stored K/V must reproduce supplied bytes exactly.',
            'Retain native/fixed/segmented pairwise comparisons and strict historical model-token FAIL.',
            'No numerical tolerance, performance claim, model-quality pass or migration waiver.'],
        'limitations': ['New reconstructed physical page geometry differs from original model execution.',
            'Exact incoming/full stored input equality is observed; replay cannot prove original historical write lifetime.',
            'nativeSDPA records actual API invocation, not internal MLX kernel-pipeline tracing.',
            'Operator arithmetic reproduction cannot alone establish complete model quality or MTP correctness.']}
    write(ROOT/'plan.json', plan)
    write(ROOT/'preparation.json', {'common_input_verified': True, 'captured_output_mismatch_count': 786,
        'prepare_only_native_buffer_bytes': sum(x['bytes'] for x in mapping.values()),
        'local_transfer_root': str(staged), 'input_sha256': digest, 'runtime_bound': False,
        'remote_calls': 0, 'model_or_operator_invocations': 0})
    print(json.dumps({'input_sha256': digest, 'geometry': transfer['geometry'], 'source_files': len(source_map)}, indent=2))


if __name__ == '__main__': main()
