import argparse
import datetime
import hashlib
import math
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time
import owner_host
from common import ROOT, check_file, digest, file_record, read_json, require, result_inventory, verify_package, write_json, runtime_directory
from results import result_errors, verify_completed

SIGNALS = (signal.SIGTERM, signal.SIGHUP, signal.SIGINT)

def host_identity(binding):
    raw = subprocess.check_output(['ioreg', '-rd1', '-c', 'IOPlatformExpertDevice'], text=True, timeout=10)
    match = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', raw)
    require(match is not None, 'host identity unavailable')
    value = hashlib.sha256((binding['host_identity']['nonce'] + match.group(1)).encode()).hexdigest()
    require(value == binding['host_identity']['sha256'], 'wrong physical host')
    return value

def observation(binding, owned=(), entry=False):
    raw = subprocess.check_output(['ps', '-axo', 'pid=,comm='], text=True, timeout=10)
    commands = {}
    excluded = set(owned) | {os.getpid()}
    for line in raw.splitlines():
        fields = line.strip().split(None, 1)
        if len(fields) == 2 and int(fields[0]) not in excluded:
            commands[int(fields[0])] = fields[1]
    foreign_pids = {pid for pid, name in commands.items() if Path(name).name in
                    ('darkbloom', 'radix-engine', 'attention-replay', 'Runner.Worker', 'benchctl')}
    markers = ('Runner.Worker', 'benchctl measure-job', 'measure-job.sh', 'run_radix_engine.py', 'connected-e2e.test')
    arguments = subprocess.check_output(['ps', '-axo', 'pid=,args='], text=True, timeout=10)
    for line in arguments.splitlines():
        fields = line.strip().split(None, 1)
        if len(fields) == 2 and int(fields[0]) not in excluded and any(marker in fields[1] for marker in markers):
            foreign_pids.add(int(fields[0]))
    foreign = [{'pid': pid, 'command': commands.get(pid, 'exited during observation')} for pid in sorted(foreign_pids)]
    macmon = binding['macmon']
    check_file(Path(macmon['path']), macmon)
    temperature = read_temperature(macmon['path'])
    hardware = subprocess.check_output(['sysctl', '-n', 'hw.model'], text=True, timeout=5).strip()
    memory = int(subprocess.check_output(['sysctl', '-n', 'hw.memsize'], text=True, timeout=5))
    value = {'hardware_model': hardware, 'memory_bytes': memory, 'gpu_temperature_c': temperature,
             'load1': os.getloadavg()[0], 'free_bytes': shutil.disk_usage(Path.home()).free,
             'unexpected_processes': foreign, 'owned_pids': list(owned)}
    require(hardware == binding['hardware_model'] and memory == binding['memory_bytes'], 'hardware tuple differs')
    require(not foreign, 'foreign benchmark or provider process')
    require(math.isfinite(temperature) and 0 <= temperature <= 100, 'invalid temperature')
    if entry:
        require(temperature <= 42 and 0 <= value['load1'] <= 4 and value['free_bytes'] > 100 * (1 << 30), 'host entry is not ready')
    return value

def read_temperature(macmon):
    import json
    raw = subprocess.check_output([macmon, 'pipe', '-s', '1', '-i', '200'], text=True, timeout=10)
    return json.loads(raw.splitlines()[0])['temp']['gpu_temp_avg']

def snapshot(binding, entry):
    deadline = time.monotonic() + binding['limits']['hash_seconds']
    require(datetime.datetime.now(datetime.timezone.utc).date().isoformat() == binding['execution_date_utc'], 'execution UTC date changed')
    canonical = binding['canonical_config']
    config = check_file(Path(canonical['path']), canonical, deadline)
    stat = Path(canonical['path']).stat()
    require((stat.st_ino, stat.st_dev, stat.st_mtime_ns) == (canonical['inode'], canonical['device'], canonical['mtime_ns']), 'canonical config metadata changed')
    runtime_root = runtime_directory(binding)
    actual_runtime = {str(path.relative_to(runtime_root)) for path in runtime_root.rglob('*') if path.is_file() or path.is_symlink()}
    require(actual_runtime == set(binding['runtime']['files']), 'runtime inventory changed')
    runtime = {name: check_file(runtime_root / name, row, deadline) for name, row in binding['runtime']['files'].items()}
    models = {}
    for kind in ['model', 'assistant']:
        model = binding[kind]
        directory = Path(model['directory']).resolve(strict=True)
        actual = {path.name for path in directory.iterdir() if path.is_file() or path.is_symlink()}
        require(actual == set(model['files']), 'model/assistant file inventory differs')
        models[kind] = {name: check_file(owner_host.model_file(directory, name), row, deadline)
                        for name, row in model['files'].items()}
    aggregate = hashlib.sha256(b''.join(bytes.fromhex(models['model'][name]['sha256']) for name in sorted(models['model']))).hexdigest()
    require(aggregate == binding['model']['aggregate_sha256'], 'aggregate model hash differs')
    return {'passed': True, 'host_identity': host_identity(binding), 'canonical_config': config,
            'runtime': runtime, 'model_files': models, 'aggregate_model_sha256': aggregate,
            'observation': observation(binding, entry=entry), 'observed_unix': time.time()}

def run_cell(binding, cell, manifest_sha):
    require(binding.get('state') == 'peer_reviewed', 'root review and hardware handoff required before execution')
    require(str(ROOT) == binding['root'], 'package root differs from bound remote root')
    position = binding['cells'].index(cell)
    for prior in binding['cells'][:position]:
        verify_completed(ROOT / 'runs' / prior['id'], prior, binding, manifest_sha)
    output = owner_host.canonical_owned_root(binding['root'] + '/runs/' + cell['id'], Path.home())
    preflight = snapshot(binding, entry=True)
    output.mkdir(mode=0o700)
    shutil.copy2(ROOT / 'inputs/input.json', output / 'input.json')
    environment = {'HOME': '/Users/gaj', 'PATH': '/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
        'PYTHONDONTWRITEBYTECODE': '1', **binding['profile'],
        'DARKBLOOM_PREFIX_CACHE_TEST_ROOT': str(output / 'prefix-cache'),
        'DARKBLOOM_PREFIX_CACHE_ALLOW_EPHEMERAL': '1', 'DARKBLOOM_PREFIX_CACHE_TEST_PERSISTENT_KEY': '0'}
    write_json(output / 'preflight.json', preflight)
    write_json(output / 'environment.json', environment)
    write_json(output / 'native-argv.json', cell['native_argv'])
    metadata = {'cell': cell['id'], 'manifest_sha256': manifest_sha, 'native_argv': cell['native_argv'],
                'effective_environment': environment, 'model_ready_observed': False, 'failure': None}
    telemetry = None
    ready = False
    started = time.monotonic()
    previous = {sig: signal.getsignal(sig) for sig in SIGNALS}
    def interrupted(signum, frame):
        raise InterruptedError('controller signal ' + str(signum))
    for sig in SIGNALS:
        signal.signal(sig, interrupted)
    def observe(native_pid):
        nonlocal ready
        require(telemetry.poll() is None, 'telemetry exited early')
        log = output / 'provider.log'
        if log.exists():
            require(log.stat().st_size <= 8 << 20, 'native log exceeds readiness bound')
            ready = ready or 'radix-model-ready' in log.read_text(errors='replace')
        require(ready or time.monotonic() - started <= binding['limits']['startup_seconds'], 'model readiness deadline expired')
        value = observation(binding, owned=(native_pid, telemetry.pid))
        value['model_ready'] = ready
        return value
    try:
        with (output / 'telemetry.jsonl').open('xb') as log:
            mask = signal.pthread_sigmask(signal.SIG_BLOCK, SIGNALS)
            try:
                telemetry = subprocess.Popen([binding['macmon']['path'], 'pipe', '-i', '100'], env=environment,
                    stdout=log, stderr=subprocess.DEVNULL, start_new_session=True,
                    preexec_fn=lambda: signal.pthread_sigmask(signal.SIG_SETMASK, mask))
                write_json(output / 'telemetry-live.json', {'pid': telemetry.pid, 'pgid': telemetry.pid})
            finally:
                signal.pthread_sigmask(signal.SIG_SETMASK, mask)
            owner_host.run_owner(cell['native_argv'], environment, output, sys.stdin.buffer, owner_host.send,
                lease_seconds=binding['limits']['lease_seconds'], deadline_seconds=binding['limits']['native_seconds'], observation=observe)
        if (output / 'provider.log').exists():
            ready = ready or 'radix-model-ready' in (output / 'provider.log').read_text(errors='replace')
    except Exception as error:
        metadata['failure'] = type(error).__name__ + ': ' + str(error)
    finally:
        for sig in SIGNALS:
            signal.signal(sig, signal.SIG_IGN)
        cleanup = {'failure': None}
        if telemetry is not None:
            metadata['telemetry_exit_before_cleanup'] = telemetry.poll()
            try:
                owner_host.retire_group(telemetry, cleanup)
            except Exception as error:
                cleanup.update(group_cleanup_complete=False, failure=str(error))
        metadata['telemetry_cleanup'] = cleanup
        metadata['model_ready_observed'] = ready
        if (output / 'provider.log').exists():
            (output / 'provider.log').rename(output / 'engine.log')
        try:
            write_json(output / 'postflight.json', snapshot(binding, entry=False))
        except Exception as error:
            write_json(output / 'postflight.json', {'passed': False, 'error': str(error)})
        write_json(output / 'metadata.json', metadata)
        for sig, handler in previous.items():
            signal.signal(sig, handler)
    try:
        errors = result_errors(output, cell, binding, manifest_sha)
    except Exception as error:
        errors = [{'incomplete_or_invalid_result': type(error).__name__ + ': ' + str(error)}]
    if metadata['failure']:
        errors.append({'owner_failure': metadata['failure']})
    summary = {'cell': cell['id'], 'manifest_sha256': manifest_sha, 'execution_valid': not errors,
               'errors': errors, 'model_validation_scope': 'One current-profile control; pair token equality is separate.'}
    write_json(output / 'summary.json', summary)
    write_json(output / 'manifest.json', {'files': result_inventory(output, binding['limits'])})
    owner_host.send({'event': 'result', **summary})
    return 0 if not errors else 2

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--cell', required=True)
    parser.add_argument('--inventory', action='store_true')
    args = parser.parse_args()
    binding = verify_package(args.manifest_sha256)
    chosen = next((cell for cell in binding['cells'] if cell['id'] == args.cell), None)
    require(chosen is not None, 'unknown cell')
    if args.inventory:
        directory = ROOT / 'runs' / chosen['id']
        if not directory.exists():
            owner_host.send({'exists': False, 'files': {}})
            return 0
        files = result_inventory(directory, binding['limits'])
        if (directory / 'manifest.json').is_file():
            files['manifest.json'] = file_record(directory / 'manifest.json')
        owner_host.send({'exists': True, 'files': files})
        return 0
    return run_cell(binding, chosen, args.manifest_sha256)

if __name__ == '__main__':
    raise SystemExit(main())
