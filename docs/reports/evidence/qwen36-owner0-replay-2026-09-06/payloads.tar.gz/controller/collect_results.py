"""Run the unchanged full collector, then retain exact comparisons to both captures."""
from pathlib import Path
import json
import os
import platform
import sys

from common import PLAN, RESULTS, load_binding, seal, sha, verify_file, write
from run_arm import verify_previous


def main():
    assert len(sys.argv) == 2, 'Pass exact reviewed runtime-binding SHA256'
    binding, plan = load_binding(sys.argv[1])
    for row in plan['arms']: verify_previous(RESULTS/'arms'/row['arm'])
    for key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS'):
        assert os.environ.get(key) == '1', 'Pin local analysis threads before collection'
    local = RESULTS/'analysis'; local.mkdir(exist_ok=False)
    sys.path.insert(0, str(PLAN/'runner')); sys.path.insert(0, str(PLAN))
    import numpy as np
    assert np.__version__ == '2.4.2'
    from attention_packet.files import MAX_TENSOR_BYTES, hashed_file
    from attention_packet.packet import load_packet
    from attention_replay.report import collect
    from attention_replay.transfer import ARMS, DISPATCH
    from compare_captures import require_common_input, compare_output_to_both, native_comparison
    captures = json.loads((PLAN/'captures.json').read_text())
    packets = {key: load_packet(Path(row['path'])) for key, row in captures.items()}
    for row in captures.values():
        for name, identity in row['files'].items(): verify_file(Path(row['path']).parent/name, identity)
    shared = require_common_input(packets['contiguous'], packets['paged'])
    transfer = json.loads((PLAN/'input.json').read_text())
    assert sha(PLAN/'input.json') == plan['input_sha256']
    report = collect(packets['contiguous'], transfer, plan['input_sha256'], RESULTS/'raw')
    write(local/'unchanged-collector.json', report)
    raw = {}
    both = {}
    reasons = list(report['inconclusiveReasons'])
    for arm in ARMS:
        descriptor = report['arms'][arm]['receipt']['tensors']['output']
        raw[arm] = hashed_file(RESULTS/'raw'/arm, descriptor, set(), MAX_TENSOR_BYTES)
        both[arm] = compare_output_to_both(raw[arm], packets['contiguous'], packets['paged'])
        for backend, packet in packets.items():
            if DISPATCH[arm] == packet.record['dispatch'] and not both[arm][backend]['byteIdentity']:
                reasons.append(arm+' does not reproduce original '+backend+' captured output')
    descriptor = packets['contiguous'].tensors['output'].descriptor
    result = {'schema': 'darkbloom.q36-owner0-replay-both-captures.v1',
        'status': 'inconclusive' if reasons else 'analyzed', 'inconclusiveReasons': sorted(set(reasons)),
        'commonInput': shared, 'inputSHA256': plan['input_sha256'],
        'bothCapturedOutputs': both,
        'pairwiseNativeOutputs': {a+'_versus_'+b: native_comparison(raw[a],raw[b],descriptor)
            for a,b in [('pagedFixed','nativeSDPA'),('pagedSegmented','nativeSDPA'),('pagedSegmented','pagedFixed')]},
        'unchangedCollectorSHA256': sha(local/'unchanged-collector.json'),
        'runtime': {'python': platform.python_version(), 'numpy': np.__version__,
                    'interpreter': sys.executable, 'analysisThreads': 1},
        'modelTokenComparison': 'Historical exact-token backend FAIL remains unchanged.',
        'numericalOrModelReleaseGateEvaluated': False,
        'scope': 'Actual isolated operators on the same captured common input. Descriptive numerical/storage interpretation; no complete model quality or performance conclusion.'}
    write(local/'both-captures.json', result)
    seal(local)
    print(json.dumps({'status': result['status'], 'inconclusiveReasons': result['inconclusiveReasons'],
        'bothNativeMismatchCounts': {arm: {backend: entry['mismatchedNativeElements'] for backend, entry in rows.items()}
                                    for arm,rows in both.items()},
        'analysis': str(local)}, indent=2), flush=True)
    raise SystemExit(0 if result['status'] == 'analyzed' else 1)


if __name__ == '__main__': main()
