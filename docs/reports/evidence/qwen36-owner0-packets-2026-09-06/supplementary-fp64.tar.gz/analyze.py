"""Supplementary CPU FP64 check; preserves the existing FP32 reference/gates."""
from pathlib import Path
import hashlib
import json
import os
import platform
import sys

import numpy as np

SOURCE = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated/scripts/benchmarks')
sys.path.insert(0, str(SOURCE))
from attention_packet.packet import load_packet
from attention_packet.reference import attention, compare

ROOT = Path(__file__).parent
CAPTURES = Path('/tmp/darkbloom-q36-attention-packet-execution1')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


packets = {backend: load_packet(CAPTURES / ('qwen36-' + backend + '-owner0-packet')
                               / 'report.attention-packet/packet.json')
           for backend in ('contiguous', 'paged')}
first, second = packets.values()
assert not first.inconclusive_reasons and not second.inconclusive_reasons
assert first.record['scaleBits'] == second.record['scaleBits']
names = ('queries', 'incomingKeys', 'incomingValues', 'storedKeys', 'storedValues')
assert all(first.tensors[n].raw == second.tensors[n].raw for n in names)
assert all(first.tensors[n].descriptor['dtype'] == 'bfloat16' for n in names)
q, k, v = (first.tensors[n].values.astype(np.float64)
           for n in ('queries', 'storedKeys', 'storedValues'))
assert q.shape == (1, 16, 1, 256) and k.shape == v.shape == (1, 2, 5585, 256)
assert first.scale == 0.0625
reference = np.empty(q.shape, dtype=np.float64)
for head in range(q.shape[1]):
    kv_head = head // (q.shape[1] // k.shape[1])
    logits = (k[0, kv_head] @ q[0, head, 0]) * np.float64(first.scale)
    weights = np.exp(logits - logits.max())
    weights /= weights.sum(dtype=np.float64)
    reference[0, head, 0] = weights @ v[0, kv_head]
assert np.all(np.isfinite(reference))
reference32, _ = attention(*(first.tensors[n].values
                            for n in ('queries', 'storedKeys', 'storedValues')), first.scale)
raw = ROOT / 'reference-fp64.bin'
raw.write_bytes(reference.astype('<f8').tobytes())
raw.chmod(0o600)
report = {
    'status': 'descriptive_supplementary_analysis',
    'scope': 'One actual common-input BF16 Qwen36 dense-owner0 capture; no model or release gate.',
    'originalReferencePreserved': 'Existing banked CPU FP32 attention remains unchanged.',
    'runtime': {'python': platform.python_version(), 'numpy': np.__version__,
                'host': platform.platform(), 'interpreter': sys.executable,
                'threads': {n: os.environ.get(n) for n in
                            ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'VECLIB_MAXIMUM_THREADS')}},
    'packetSHA256': {n: p.packet_sha256 for n, p in packets.items()},
    'commonInputNativeSHA256': {n: first.tensors[n].descriptor['sha256'] for n in names},
    'scaleBits': first.record['scaleBits'],
    'reference': {'dtype': 'float64', 'shape': list(reference.shape), 'sha256': sha(raw)},
    'fp32ReferenceVersusFP64': compare(reference32, reference),
    'capturedOutputVersusFP64': {n: compare(p.tensors['output'].values, reference)
                               for n, p in packets.items()},
    'limitations': ['No original-history mirror or isolated native operator replay.',
                    'FP64 is numerical evidence, not exact real arithmetic.',
                    'This does not establish final-logit or model quality across prompts.'],
    'sourceSHA256': {'analyze.py': sha(Path(__file__)), **{
        str(p.relative_to(SOURCE)): sha(p) for p in sorted((SOURCE / 'attention_packet').glob('*.py'))}},
}
(ROOT / 'analysis.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'reference32Versus64': report['fp32ReferenceVersusFP64']['global'],
                  'capturedVersus64': {n: v['global'] for n, v in
                                       report['capturedOutputVersusFP64'].items()}}, indent=2))
