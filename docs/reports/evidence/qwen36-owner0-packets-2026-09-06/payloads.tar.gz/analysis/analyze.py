from pathlib import Path
import hashlib,json,struct
BASE=Path('/tmp/darkbloom-q36-attention-packet-execution1');OUT=Path(__file__).parent
CELLS=['qwen36-contiguous-control','qwen36-paged-control','qwen36-contiguous-owner0-packet','qwen36-paged-owner0-packet']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def trajectories(report):
 result={}
 for key in ['rows','tenant_checks','cancel_donor','recovered']:
  rows=report[key] if isinstance(report[key],list) else [report[key]]
  for i,r in enumerate(rows):result[key+':'+str(i)]={k:r[k] for k in ['prompt_token_ids','token_ids','prompt_tokens','completion_tokens','finish','outcome']}
 return result
reports={};sources={}
for cell in CELLS:
 p=BASE/cell;m=json.loads((p/'manifest.json').read_text());assert json.loads((p/'completion-receipt.json').read_text())['manifest_sha256']==sha(p/'manifest.json')
 for name,row in m['files'].items():
  q=p/name;assert q.stat().st_size==row['bytes'] and sha(q)==row['sha256'] and oct(q.stat().st_mode&0o777)==row['mode']
 summary=json.loads((p/'summary.json').read_text());assert summary['report_integrity_passed'] and summary['exit_code']==0 and summary['errors']==[]
 reports[cell]=json.loads((p/'report.json').read_text());sources[cell]={'manifest_sha256':sha(p/'manifest.json'),'payloads':len(m['files']),'summary':summary}
comparisons={};arms={}
for backend in ['contiguous','paged']:
 control=reports[f'qwen36-{backend}-control'];trace=reports[f'qwen36-{backend}-owner0-packet'];a,b=trajectories(control),trajectories(trace);assert a==b and len(a)==7
 p=BASE/f'qwen36-{backend}-owner0-packet';analysis=json.loads((p/'packet-analysis.json').read_text());packet=json.loads((p/'report.attention-packet/packet.json').read_text());snapshot=trace['attention_metadata']['snapshot']
 logits=trace['logit_diagnostic']['snapshot']['records'][0]
 dtypes=set()
 for rec in snapshot['records']:
  dtypes|={rec[k]['dtype'] for k in ['queries','incomingKeys','incomingValues','output']};dtypes.add(rec['kernelOutputDType']);dtypes|={x['dtype'] for x in rec['storage'].values()}
 assert dtypes=={'bfloat16'}
 comparisons[backend]={'completed_trajectories_exact':list(a),'count':len(a),'control_canceled_tokens':len(control['cancelled']['token_ids']),'capture_canceled_tokens':len(trace['cancelled']['token_ids']),'canceled_tokens_are_own_recovery_prefixes':all(r['cancelled']['token_ids']==r['recovered']['token_ids'][:len(r['cancelled']['token_ids'])] for r in [control,trace])}
 arms[backend]={'packet_sha256':sha(p/'report.attention-packet/packet.json'),'metadata_sha256':sha(p/'report.attention-packet/attention-metadata.json'),'owner_pairs':[[r['storageLayerIndex'],r['modelLayerIndex']] for r in snapshot['records']],'observed_dtypes':sorted(dtypes),'selection':analysis['selection'],'sample':analysis['sample'],'scale':analysis['scale'],'tensor_payload_bytes':packet['capture']['tensorPayloadBytes'],
 'tensor_shapes':{k:v['shape'] for k,v in packet['tensors'].items()},'tensorNonfinite':analysis['tensorNonfinite'],'lastRowConsistency':analysis['lastRowConsistency'],
 'original_fp32_reference':analysis['originalQueryReference']['comparison']['global'],'bf16_rounded_reference':analysis['referenceRoundedToOutputDType']['comparison']['global'],
 'logit_values':[struct.unpack('<f',struct.pack('<I',bits))[0] for bits in logits['valueBits']],'logit_value_bits':logits['valueBits'],'logit_dtype':logits['logitDType'],'candidate_ids':logits['candidateIDs'],'target_token':logits['targetToken'],'narrowed_query_counterfactual':analysis['narrowedQueryCounterfactual']}
a,b=[reports[cell]['rows'][0] for cell in CELLS[:2]];assert a['prompt_token_ids']==b['prompt_token_ids'] and len(a['prompt_token_ids'])==5523
first=next(i for i,(x,y) in enumerate(zip(a['token_ids'],b['token_ids'])) if x!=y);assert first==62
cross=json.loads((BASE/CELLS[3]/'cross-backend-native-bytes.json').read_text());strict=json.loads((BASE/CELLS[1]/'strict-backend-control-comparison.json').read_text());assert not strict['passed']
for name,row in cross['tensors'].items():
 if name!='output':assert row['native_bytes_equal'] and row['mismatched_native_elements']==0,name
assert cross['scale_bits_equal'] and cross['tensors']['output']['mismatched_native_elements']==786
save(OUT/'analysis.json',{'status':'FOUR_INTEGRITY_CELLS_PASS_STRICT_BACKEND_TOKENS_FAIL','sources':sources,'same_backend_trace_comparisons':comparisons,'common_prompt_tokens':5523,'common_prior_output_tokens':62,'first_output_difference':first,'strict_backend_comparison':strict,'arms':arms,'cross_backend_captured_bytes':cross,
 'scope':'One selected native owner0/model3 forward on each of two independently executed same-build model trajectories. Source/runtime/input/lifecycle/trace controls pass; no isolated operator replay, independent full-history mirror, all-layer cause, model accuracy, performance or release gate is established.',
 'source_hypothesis':'Frozen MLX host source selects two-pass vector attention for QL1, GQA16:2, KV5585; standard pass1 writes float partial accumulators as T/bfloat16 before pass2 merges them. This intermediate narrowing is a source-based candidate contributor, not an observed pipeline trace or demonstrated full-model cause.',
 'local_analysis_environment':'Packet captures analyzed with reviewed Python3.14.7/NumPy2.4.2 and OPENBLAS/OMP/VECLIB thread pins1. Initial no-packet contiguous control had no local thread overrides; all remote model environments remain exact.'})
save(OUT/'manifest.json',{'files':{p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.iterdir()) if p.is_file()}});print(json.dumps({'analysis_sha256':sha(OUT/'analysis.json'),'manifest_sha256':sha(OUT/'manifest.json'),'values':{k:v['logit_values'] for k,v in arms.items()}},indent=2))
