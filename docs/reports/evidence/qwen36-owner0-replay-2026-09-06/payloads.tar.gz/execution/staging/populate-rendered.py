import json
C=json.loads('{"remote_root": "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1", "binding_sha256": "a04631ec25459596b98561910463c88e334ed0e059714def34f54cfca57ee4c8", "resources_source": "/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact"}')
from pathlib import Path
import hashlib,json,shutil,stat
root=Path(C['remote_root']);binding=json.loads((root/'runtime-binding.json').read_text())
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()==C['binding_sha256']
assert {p.name for p in (root/'runtime').iterdir()}=={'attention-replay'}
def verify_source(path,row):
 info=path.lstat();assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
 assert info.st_size==row['bytes'] and stat.S_IMODE(info.st_mode)==int(row['mode'],8)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
for name,row in binding['artifacts'].items():
 if name=='attention-replay':verify_source(root/'runtime'/name,row);continue
 source=Path(C['resources_source'])/name;verify_source(source,row)
 target=root/'runtime'/name;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();shutil.copy2(source,target)
mapping=json.loads((root/'plan/native-buffer-map.json').read_text())
assert not list((root/'transfer').iterdir())
for row in mapping.values():
 source=Path(row['remote_source_root'])/row['source_file'];verify_source(source,row)
 target=root/'transfer'/row['destination_file'];shutil.copy2(source,target)
shutil.copy2(root/'plan/input.json',root/'transfer/input.json')
