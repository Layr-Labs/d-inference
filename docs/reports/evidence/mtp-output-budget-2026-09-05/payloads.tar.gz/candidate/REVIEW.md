# MTP output-budget tail bound

Status: implemented in isolated native worktree, source-only validation. This candidate has not been compiled, unit-tested, or run with a model. The normal Q35 adaptive parity gate remains failed. No primary worktree files, default policy, prior raw failures, or frozen reports were changed.

## Change and rationale

A speculative depth-k round feeds the already-confirmed carry followed by k draft inputs, computes k+1 target outputs, and can emit one mandatory target token plus at most k accepted draft-equivalent outputs. If the request has R output slots remaining, only R-1 draft positions can offer useful additional output. In particular, R=1 requires one target evaluation but no speculative draft.

The previous common tail bound allowed k <= R when a valid carry existed, while normal Qwen marginal policy already used k <= R-1. Controller exploration skips marginal policy; fixed-depth requests do not use it. This let a final-slot exploration/fixed round draft and verify a width-two target rectangle despite being allowed to emit only one token. It also permitted a last unused target column at wider tails.

The new pure helper bounds every offered depth by the shortest eligible row's remaining output slots minus one. The common planner calls it after marginal selection and before step-token/KV reservation and synchronized seeding. It therefore covers fixed, exploratory, and ordinary offers without putting request output budgets into the engine-shared cost controller. Existing `tail_depth` telemetry records any resulting clamp. Offers already constrained by hardware, batch or marginal policy can only decrease.

The mandatory slot describes output budget, not ownership of the input carry. A valid carry is a confirmed token not yet fed to the target, and does not eliminate the need to compute the next target token. Removing the carry exception from this arithmetic does not change carry validity, consumption, history transitions, or rollback.

## Scope and invariants

This applies to all common MTP planning, including stateless Gemma and explicit serial verification, on paged and contiguous storage. Any engine with no active drafter remains unaffected. No model-specific branch or new flag was added.

For rows without a valid carry, the existing numeric bound was already max(0,R-1), so that case retains its prior bound. Existing synchronized seeding is unchanged: the next plan recalculates the output bound after a seed emits a token. This candidate does not opportunistically rewrite seed scheduling.

For stateful Qwen, depth zero still uses the existing hidden-returning seed path. The planner retains persistent carry/history, and execution observes a pending verify-produced history transition before the target-only input as before. Stateless paths keep their existing carry invalidation at depth zero. Recurrent bind/capture/commit/rollback, speculative page transactions, assistant finalization, cancellation and request retirement are unchanged. The finalizer continues to cap actual emitted tokens and roll back rejected suffixes; planner savings are not used as a substitute for those correctness checks.

Common width is still bounded by the shortest row, matching finalization's commonEmitted minimum. A nearly finished row can lower the whole rectangle, as existing synchronized semantics already require. Numerical shape changes can affect greedy output; this change does not certify rectangular-versus-serial equivalence or resolve every source of normal adaptive variability.

## Tests and validation handoff

Five new pure policy tests are authored in CBv2MTPOutputBudgetTests.swift:

- A real adaptive controller emits an exploration depth-one offer after its baseline cost observation. The common budget forces zero at R=1, retains one at R=2, and does not consume/reset controller cadence.
- A real fixed-depth-seven controller is bounded at R=1,2,4,8 and a long tail.
- B1/B2/B4 cohorts with one final-slot row all select zero; a three-slot row caps every neighbor at depth two independent of row order.
- Already limited offers, including zero, are never increased by the output budget.
- Empty/exhausted budgets select zero; integer extremes cannot overflow the subtraction.

These tests do not initialize models or tensors. No Swift compilation or test execution was authorized for this lane; do not count them as passed. git diff --check passed. The exact patch was checked and applied against a temporary Git index populated from aafe2069bcdeadef9250530eb511c598649c0355, and every resulting blob hash matched the frozen after snapshot.

The sole validation lane should compile/run the new CBv2MTPOutputBudgetTests and existing CBv2MTPDepthControllerTests / CBv2MTPProbeCadenceTests, then exercise CBv2QwenMTPIntegrationTests, CBv2MTPCaptureVerifyTests, CBv2MTPRoundSmokeTests, CBv2MTPEngineParityTests, CBv2MTPKVStagingTests and CBv2MTPRectangularDegradeTests for actual history, rollback, shared-tail and non-Qwen behavior. Existing tests were not weakened or adjusted speculatively. Any changed expected round counts must be justified by the eliminated useless tail work, not removed wholesale.

Before performance/correctness claims, rebuild the exact serving artifact and repeat the preserved Q35 normal-MTP cache-off/SSD pair with original strict checks. Include maxTokens32 and a longer output budget so token32 is also exercised as an interior position. Verify that final-slot requests no longer launch speculative rounds and that all normal cache/lifecycle gates still hold. The serial diagnostic pair is separate evidence; it cannot replace normal adaptive acceptance.

## If normal parity still differs

At existing finalize fences, capture only selected output positions' actual verification width/column, generated-token index, offered/clamped depth and exploration reason. On the SAME target logits, compare MLX argMax with Qwen top-two IDs and retain their values plus explicit logits for IDs 944 and 19549. Seed sampling and rectangular verification currently use different reducers. The tiny diagnostic packet must be attached to existing evaluation/finalization rather than adding a forced device synchronization; instrumented timings are not performance measurements.

This distinguishes reducer disagreement from changed target logits and establishes actual path provenance. Equal preceding token IDs alone do not establish identical KV/recurrent/hidden floating-point state. If logits differ, a bounded matching-schedule cold/SSD diagnostic or exact-target oracle is still needed to isolate cache effects; neither permits weakening the failed normal-production gate.
