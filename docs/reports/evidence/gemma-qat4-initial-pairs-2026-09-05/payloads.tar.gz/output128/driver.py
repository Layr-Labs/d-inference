from pathlib import Path
import json,hashlib,shlex,subprocess,sys,time
cell=sys.argv[1];bindingpath=Path('/tmp/darkbloom-gemma-qat-binding1/package/binding.json');assert hashlib.sha256(bindingpath.read_bytes()).hexdigest()=='fd5e580268ae1fe564122da0f74a500e43184b421a298087a88f144044c0ecc9';binding=json.loads(bindingpath.read_text());assert cell=='native-kv-observer1' or cell in binding['cells'];observer=cell=='native-kv-observer1';command=binding['native_observer'] if observer else binding['cells'][cell];base=Path('/tmp/darkbloom-gemma-qat-execution1');base.mkdir(exist_ok=True);local=base/cell;local.mkdir(exist_ok=False);remote=binding['remote_root']+'/'+cell if observer else command[command.index('--output')+1];ssh=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99']
preflight=subprocess.run(['python3','/tmp/darkbloom-fleet-smoke-continuation/preflight.py',str(local/'external-preflight.json')],text=True,capture_output=True);(local/'external-preflight.log').write_text(preflight.stdout+preflight.stderr);assert preflight.returncode==0,preflight.stdout+preflight.stderr
check='''from pathlib import Path
import json,hashlib,shutil,datetime
root=Path(ROOT);bp=root/'binding.json';assert hashlib.sha256(bp.read_bytes()).hexdigest()==BINDING_SHA;b=json.loads(bp.read_text());assert not Path(OUTPUT).exists();assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-09-05';free=shutil.disk_usage(root).free;assert free>b['min_free_bytes'];m=json.loads((root/'package-manifest.json').read_text())
for name,item in m['files'].items():
 p=root/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
r={}
for x in [b['binary'],b['wrapper']]+list(b['resources'].values()):
 p=Path(x['path']);sha=hashlib.sha256(p.read_bytes()).hexdigest();assert sha==x['sha256'];r[str(p)]=sha
print(json.dumps({'runtime':r,'free_disk_bytes':free,'scope':'Exact package/runtime precheck; model hashed by native observer or normal wrapper'},indent=2))
'''.replace('ROOT',repr(binding['remote_root'])).replace('BINDING_SHA',repr(hashlib.sha256(bindingpath.read_bytes()).hexdigest())).replace('OUTPUT',repr(remote));r=subprocess.run(ssh+['python3 -B -'],input=check,text=True,capture_output=True);(local/'runtime-precheck.stdout').write_text(r.stdout);(local/'runtime-precheck.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr
(local/'command.json').write_text(json.dumps({'argv':command,'scope':'Target-only native observation; no acceptance claim' if observer else 'Normal-MTP QAT paged SSD pair arm, reviewed exact inputs and candidate build6'},indent=2)+'\n');start=time.monotonic()
with (local/'ssh-run.log').open('x') as log:
 if observer:
  code='''from pathlib import Path
import json,subprocess,time,os,signal
root=Path(OUTPUT);root.mkdir(parents=True,exist_ok=False);command=COMMAND;start=time.monotonic();cleanup=[]
with (root/'native.stdout').open('x') as out,(root/'native.stderr').open('x') as err:
 p=subprocess.Popen(command,stdout=out,stderr=err,start_new_session=True);(root/'launch.json').write_text(json.dumps({'argv':command,'pid':p.pid,'owned_process_group':p.pid,'timeout_seconds':600},indent=2)+'\\n')
 try:rc=p.wait(timeout=600)
 except subprocess.TimeoutExpired:
  for sig,wait in [(signal.SIGINT,10),(signal.SIGTERM,5),(signal.SIGKILL,5)]:
   if p.poll() is not None:break
   os.killpg(p.pid,sig);cleanup.append(int(sig))
   try:p.wait(timeout=wait)
   except subprocess.TimeoutExpired:pass
  rc=p.returncode if p.returncode is not None else 124
(root/'execution.json').write_text(json.dumps({'exit_code':rc,'seconds':time.monotonic()-start,'owned_group_cleanup':cleanup},indent=2)+'\\n');print(json.dumps({'exit_code':rc,'seconds':time.monotonic()-start}));raise SystemExit(rc)
'''.replace('OUTPUT',repr(remote)).replace('COMMAND',repr(command))
  r=subprocess.run(ssh+['python3 -B -'],input=code,text=True,stdout=log,stderr=subprocess.STDOUT)
 else:r=subprocess.run(ssh+[shlex.join(command)],stdout=log,stderr=subprocess.STDOUT)
exit_code=r.returncode;(local/'driver-execution.json').write_text(json.dumps({'exit_code':exit_code,'seconds':time.monotonic()-start},indent=2)+'\n')
code='''from pathlib import Path
import json,hashlib
root=Path(ROOT);files={}
if root.exists():
 for p in sorted(root.iterdir()):
  if p.is_file() and not p.is_symlink():files[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'exists':root.exists(),'files':files},indent=2))
'''.replace('ROOT',repr(remote));r=subprocess.run(ssh+['python3 -B -'],input=code,text=True,capture_output=True);assert r.returncode==0,r.stderr;(local/'remote-inventory.json').write_text(r.stdout);inventory=json.loads(r.stdout)
for name,item in inventory['files'].items():
 assert all(x.isalnum() or x in '.-_' for x in name);p=local/name;r=subprocess.run(['scp','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','gaj@100.124.35.99:'+remote+'/'+name,str(p)],text=True,capture_output=True);assert r.returncode==0,r.stderr;assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
post=subprocess.run(['python3','/tmp/darkbloom-fleet-smoke-continuation/preflight.py',str(local/'external-postflight.json')],text=True,capture_output=True);(local/'external-postflight.log').write_text(post.stdout+post.stderr)
summary={'cell':cell,'exit_code':exit_code,'scope':'Observer diagnostic only' if observer else 'Normal MTP paged arm; pair comparison still required','postflight_exit_code':post.returncode}
if not observer and (local/'report.json').exists():
 sys.path.insert(0,'/tmp/darkbloom-repeated-matrix-plan1/runner');from radix_engine_evidence import report_errors
 report=json.loads((local/'report.json').read_text());errors=report_errors(report);summary.update(passed_report_integrity=not errors,errors=errors,mtp=report.get('mtp'),rows=[{k:r.get(k) for k in ('id','prompt_tokens','completion_tokens','finish','cache_outcome')} for r in report.get('rows',[])])
(local/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');files={str(p.relative_to(local)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(local.rglob('*')) if p.is_file()};(local/'manifest.json').write_text(json.dumps({'scope':summary['scope'],'files':files},indent=2)+'\n');print(json.dumps(summary,indent=2));print('manifest_sha256',hashlib.sha256((local/'manifest.json').read_bytes()).hexdigest());sys.exit(exit_code or (1 if summary.get('errors') else 0))
