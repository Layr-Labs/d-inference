import json
C=json.loads('{"remote": "/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http6-q38", "review_sha": "91a25b23cb7be34e6bc3f35a63a2bc680bfaad96490cde7e4f1c3c5a385b6e35", "archive_sha": "e89ae41a2b21594465b5c31dd036ff9d62d5f5626a1e16afc23c65a95b067a31", "manifest_sha": "82e81db534ea14e80b3f3f2502949b25bc77768e887fdb2755fdab674dddbd0e", "members": 1183, "binding_sha": "401c59e24a3acf88186e03eef9b48c86bbce372fefa6e1c7c9238ef693044b82"}')
from pathlib import Path
import datetime,shutil
root=Path(C['remote'])
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-09-06'
assert shutil.disk_usage(root.parent).free>100*(1<<30)
root.mkdir(exist_ok=False)
