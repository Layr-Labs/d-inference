"""CPU checks of real payloads and existing comparison gates; no model execution."""
from pathlib import Path
import copy
import json
import shutil
import struct
import sys
import tempfile
import unittest

from cohort import command_spec, validate_plan
from cohort_common import digest, identity, local_path, read_json, write_json
from corpus_cases import build
from quality_compare import compare_serving, compare_teacher, serving_identity, teacher_oracle_gate
from quality_inputs import load, load_payload, validate_coverage, validate_plan_tokens
from quality_runtime import runtime_binding

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'vendor'))
from run_radix_engine import arguments as runner_arguments, pin_prompt_date
from compare_radix_engine import mismatch


def bits(value):
    return struct.unpack('!I', struct.pack('!f', value))[0]


class QualityCohortTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cohort = load(ROOT)
        cls.plan = validate_plan(ROOT, cls.cohort)
        cls.record = next(row for row in cls.cohort['records'] if row['model']=='gpt-oss-20b' and row['case_id']=='prose-gutenberg-11-short')
        cls.model = cls.cohort['models'][cls.record['model']]
        cls.case = cls.cohort['cases'][cls.record['case_id']]
        cls.payload = cls.cohort['payloads'][(cls.record['model'], cls.record['case_id'])]

    def copied_payload(self, directory):
        record = copy.deepcopy(self.record)
        for kind in ['teacher', 'serving', 'canonical']:
            source = ROOT/record[kind]['path']; target = directory/record[kind]['path']
            target.parent.mkdir(parents=True, exist_ok=True); shutil.copy2(source, target)
        return record

    def test_actual_coverage_is_six_artifacts_by_twelve_stratified_cases(self):
        self.assertEqual(len(self.cohort['records']), 72)
        self.assertEqual({row['continuation_tokens'] for row in self.cohort['records']}, {64})
        self.assertEqual(min(row['prompt_tokens'] for row in self.cohort['records']), 324)
        self.assertEqual(max(row['prompt_tokens'] for row in self.cohort['records']), 8956)
        self.assertIsNone(self.plan['quality_pass'])

    def test_selection_rebuilds_exactly_without_model_outputs(self):
        self.assertEqual(build(ROOT), read_json(ROOT/'cases.json'))
        targets = {case['selection']['target_row'] for case in self.cohort['cases'].values() if case['domain']=='reasoning'}
        self.assertEqual(targets, {528, 1303})
        self.assertFalse(read_json(ROOT/'source-lock.json')['training_data_exclusion_claim'])

    def test_missing_duplicate_and_wrong_model_coverage_refuse(self):
        models = list(self.cohort['models'].values()); cases = list(self.cohort['cases'].values())
        for records in [self.cohort['records'][:-1], self.cohort['records'][:-1]+[self.cohort['records'][0]]]:
            with self.assertRaises(ValueError): validate_coverage(models, cases, records)
        wrong = copy.deepcopy(models); wrong[0]['aggregate_sha256'] = '0'*64
        with self.assertRaises(ValueError): validate_coverage(wrong, cases, self.cohort['records'])

    def test_reasoning_target_cannot_become_a_demonstration(self):
        cases = copy.deepcopy(list(self.cohort['cases'].values()))
        case = next(case for case in cases if case['domain']=='reasoning')
        case['selection']['demonstration_rows'].append(case['selection']['target_row'])
        with self.assertRaisesRegex(ValueError, 'demonstration'):
            validate_coverage(list(self.cohort['models'].values()), cases, self.cohort['records'])

    def test_mutated_file_fails_before_semantic_comparison(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); record = self.copied_payload(root)
            (root/record['teacher']['path']).write_text('{}')
            with self.assertRaisesRegex(ValueError, 'identity'):
                load_payload(root, record, self.model, self.case, self.cohort['prompt_date'])

    def test_bad_token_ids_and_count_fail_even_with_updated_file_hash(self):
        for bad in [True, -1, self.model['vocabulary_size'], 1.25, 'token']:
            with self.subTest(bad=bad), tempfile.TemporaryDirectory() as temporary:
                root=Path(temporary); record=self.copied_payload(root); path=root/record['teacher']['path']
                value=read_json(path); value['promptTokens'][0]=bad; write_json(path,value); record['teacher'].update(identity(path))
                with self.assertRaises(ValueError): load_payload(root,record,self.model,self.case,self.cohort['prompt_date'])
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary); record=self.copied_payload(root); path=root/record['teacher']['path']
            value=read_json(path); value['continuation'].pop(); write_json(path,value); record['teacher'].update(identity(path))
            with self.assertRaisesRegex(ValueError,'bounds'):load_payload(root,record,self.model,self.case,self.cohort['prompt_date'])

    def test_equal_count_changed_tokens_fail_canonical_block_hash(self):
        canonical=self.payload['canonical']; tokens=list(canonical['prompt_token_ids']); tokens[10] ^= 1
        with self.assertRaisesRegex(ValueError,'block hash'):
            validate_plan_tokens(tokens,canonical['plan'],canonical['prompt_contract_id'],canonical['scope_id'])

    def test_input_cap_date_and_source_attribution_are_strict(self):
        for field,value in [('max_tokens',999),('_darkbloom_prompt_date','2026-09-07')]:
            with self.subTest(field=field), tempfile.TemporaryDirectory() as temporary:
                root=Path(temporary); record=self.copied_payload(root); path=root/record['serving']['path']
                body=read_json(path); body['rows'][0]['request'][field]=value;write_json(path,body);record['serving'].update(identity(path))
                with self.assertRaisesRegex(ValueError,'prompt/date/model/cap'):load_payload(root,record,self.model,self.case,self.cohort['prompt_date'])
        wrong=copy.deepcopy(self.record); wrong['source_sha256']='0'*64
        with self.assertRaisesRegex(ValueError,'attribution'):load_payload(ROOT,wrong,self.model,self.case,self.cohort['prompt_date'])

    def test_existing_date_pinner_preserves_exact_prepared_bytes(self):
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'input.json'
            pin_prompt_date(ROOT/self.record['serving']['path'],path,'2026-09-07')
            self.assertEqual(digest(path),self.record['serving']['sha256'])

    def serving_report(self):
        runtime={'files':{'radix-engine':{'sha256':'a'*64},'mlx.metallib':{'sha256':'b'*64}}}
        report={'schema':3,'forward_shape_telemetry_schema':1,'model':self.model['model_id'],
            'verified_model_hash':self.model['aggregate_sha256'],'input_sha256':self.record['serving']['sha256'],
            'cache_requested':False,'max_concurrent_requests':1,'mtp':'off; no drafter supplied',
            'runtime_identity':{'binary_sha256':'a'*64,'metallib_sha256':'b'*64},
            'rows':[{'id':'long-'+kind,'prompt_token_ids':list(self.payload['teacher']['promptTokens'])} for kind in ['first','repeat']]}
        return report,runtime

    def test_agreement_between_arms_cannot_hide_wrong_corpus_tokens(self):
        report,runtime=self.serving_report();serving_identity(report,self.record,self.model,self.payload,runtime)
        for row in report['rows']:row['prompt_token_ids'][0] ^= 1
        with self.assertRaisesRegex(ValueError,'tokenization'):
            serving_identity(report,self.record,self.model,self.payload,runtime)

    def test_serving_identity_does_not_bypass_existing_report_gates(self):
        report,runtime=self.serving_report()
        binding={'_manifest':runtime,'_binding_sha256':'c'*64,'host_id':'m5',
            'host_identity':{'hardware_model':'CPU-fixture','physical_memory_bytes':1},'serving_profile':self.plan['serving_profile']}
        metadata=[{'status':'completed','exit_code':0,'matrix_binding_sha256':'c'*64,
            'matrix_host':{'id':'m5',**binding['host_identity']},'serving_profile':binding['serving_profile'],
            'binary_sha256':'a'*64,'input_sha256':self.record['serving']['sha256'],'source_input_sha256':self.record['serving']['sha256'],
            'arguments':{'kv_backend':backend,'production_kv_grant':True},'started_unix':index*2,'ended_unix':index*2+1}
            for index,backend in enumerate(['contiguous','paged'])]
        result=compare_serving(self.cohort,self.record['model'],self.record['case_id'],report,copy.deepcopy(report),binding,metadata)
        self.assertFalse(result['comparison']['passed'])
        self.assertIsNone(result['quality_pass'])
        a={'prompt_token_ids':[1],'token_ids':[2],'finish':'length','prompt_tokens':1,'completion_tokens':1}
        self.assertEqual(mismatch(a,dict(a,token_ids=[3])),['token_ids'])
        wrong=copy.deepcopy(metadata);wrong[1]['matrix_host']['id']='m3'
        with self.assertRaisesRegex(ValueError,'host differs'):
            compare_serving(self.cohort,self.record['model'],self.record['case_id'],report,copy.deepcopy(report),binding,wrong)

    def teacher_report(self,snapshot,backend):
        value=self.payload['teacher']; count=len(value['continuation'])
        records=[{'index':i,'contextLength':len(value['promptTokens'])+i,'forcedToken':token,
            'argMaxID':token,'vocabularySize':self.model['vocabulary_size'],'logitDType':'float32',
            'topTwoIDs':[token,(token+1)%self.model['vocabulary_size']], 'argMaxValueBits':bits(0),
            'topTwoValueBits':[bits(0),bits(-1)],'forcedTokenValueBits':bits(0),'logSumExpBits':bits(1),
            'forcedLogProbabilityBits':bits(-1),'nllBits':bits(1),'topTwoMarginBits':bits(1),
            'nanCount':0,'infiniteCount':0} for i,token in enumerate(value['continuation'])]
        diagnostic={'top1':list(value['continuation']),'records':records}
        return {'schema':1,'scope':'ordinary_teacher_forced_scores','status':'observed','inconclusiveReasons':[],
            'input':copy.deepcopy(value),'inputSHA256':self.record['teacher']['sha256'],
            'verifiedModelAggregateSHA256':self.model['aggregate_sha256'],'executableSHA256':'a'*64,'metallibSHA256':'b'*64,
            'modelDirectory':str(snapshot),'resolvedBackend':backend,'cacheMode':'off','mtpEnabled':False,'concurrency':1,
            'gemmaOptimizations':{'prefill_layer18':True,'weighted_r1':True},'kvCapacityBytes':1024,
            'productionGrant':{'slotCount':1,'assistantWeightBytes':0,'ramPrefixAllowanceBytes':0,'grantBytes':1024},
            'diagnostic':diagnostic,'repeatedDiagnostic':copy.deepcopy(diagnostic),'plainTop1':list(value['continuation']),
            'activity':[{'prefillChunks':11,'decodeForwards':count-1} for _ in range(3)],'meanForcedTokenNLL':1.0}

    def test_existing_teacher_controls_and_finite_bits_remain_mandatory(self):
        with tempfile.TemporaryDirectory() as temporary:
            snapshot=Path(temporary); left=self.teacher_report(snapshot,'contiguous');right=self.teacher_report(snapshot,'paged')
            binding={'_manifest':{'files':{'darkbloom':{'sha256':'a'*64},'mlx.metallib':{'sha256':'b'*64}}},
                     'models':{self.record['model']:{'teacher_snapshot':str(snapshot)}}}
            result=compare_teacher(self.cohort,self.record['model'],self.record['case_id'],left,right,binding)
            self.assertIsNone(result['quality_pass']);self.assertTrue(result['comparison']['same_forced_contexts'])
            for field in ['nonfinite','context','activity','repeat']:
                bad=copy.deepcopy(right)
                if field=='nonfinite':
                    bad['diagnostic']['records'][0]['nllBits']=0x7f800000;bad['repeatedDiagnostic']=copy.deepcopy(bad['diagnostic'])
                elif field=='context':
                    bad['diagnostic']['records'][0]['contextLength']+=1;bad['repeatedDiagnostic']=copy.deepcopy(bad['diagnostic'])
                elif field=='activity':bad['activity'][0]['decodeForwards']+=1
                else:bad['repeatedDiagnostic']['top1'][0] ^= 1
                with self.subTest(field=field),self.assertRaises(ValueError):
                    compare_teacher(self.cohort,self.record['model'],self.record['case_id'],left,bad,binding)

    def test_identical_teacher_numbers_never_supply_a_serving_oracle(self):
        with tempfile.TemporaryDirectory() as temporary:
            report=self.teacher_report(Path(temporary),'contiguous')
            row={'prompt_token_ids':report['input']['promptTokens'],'token_ids':report['input']['continuation']}
            gate=teacher_oracle_gate(report,row,observed_serving_prefill_chunks=3)
            self.assertFalse(gate['eligible']);self.assertIn('prefill_chunk_geometry_mismatch',gate['reasons'])
            self.assertFalse(teacher_oracle_gate(report,row,observed_serving_prefill_chunks=11)['eligible'])

    def test_unreviewed_binding_cannot_emit_runtime_commands(self):
        path=ROOT/'binding-template.json'
        with self.assertRaisesRegex(ValueError,'unreviewed'):runtime_binding(path,digest(path))

    def test_path_escape_duplicate_keys_and_nonfinite_json_refuse(self):
        with self.assertRaises(ValueError):local_path(ROOT,'../outside.json')
        with tempfile.TemporaryDirectory() as temporary:
            path=Path(temporary)/'bad.json'
            for text in ['{"value":1,"value":2}','{"value":NaN}']:
                path.write_text(text)
                with self.assertRaises(ValueError):read_json(path)

    def test_teacher_command_reuses_existing_argv_and_owned_fixture(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory=Path(temporary);model_dir=directory/'model';model_dir.mkdir()
            home=directory/'results/teacher-home';snapshot=home/'.cache/huggingface/hub/models--gpt-oss-20b/snapshots/local'
            snapshot.mkdir(parents=True)
            cell=next(row for row in self.plan['cells']['teacher'] if row['stage']=='pilot' and row['backend']=='contiguous')
            binding={'reviewed_cell_ids':[cell['id']],'host_id':'m5','_binding_sha256':'c'*64,
                'runtime_directory':str(directory/'runtime'),'execution_root':str(directory/'results'),
                'models':{cell['model']:{'directory':str(model_dir),'teacher_fixture_home':str(home),'teacher_snapshot':str(snapshot)}}}
            spec=command_spec(ROOT,self.cohort,self.plan,cell,'teacher',binding)
            self.assertEqual(spec['argv'][1:3],['benchmark','--config'])
            self.assertEqual(spec['argv'][-2:],['--teacher-forced-input',str(ROOT/cell['input']['path'])])
            self.assertEqual(spec['environment']['CFFIXED_USER_HOME'],str(home))
            self.assertEqual(spec['teacher_config_copy']['sha256'],digest(ROOT/'config/gpt-oss-20b.toml'))
            self.assertFalse(spec['executed']);self.assertFalse(Path(spec['output_directory']).exists())

    def test_printed_serving_command_uses_existing_parser_and_production_grant(self):
        with tempfile.TemporaryDirectory() as temporary:
            directory=Path(temporary); model_dir=directory/'model';model_dir.mkdir()
            macmon=directory/'macmon';macmon.write_text('CPU fixture only')
            cell=next(row for row in self.plan['cells']['serving'] if row['stage']=='pilot' and row['backend']=='contiguous')
            binding={'reviewed_cell_ids':[cell['id']],'host_id':'m5','_binding_sha256':'c'*64,'runtime_directory':str(directory/'runtime'),
                'execution_root':str(directory/'results'),'models':{cell['model']:{'directory':str(model_dir)}},
                'python_executable':sys.executable,'macmon':{'path':str(macmon),'sha256':digest(macmon)}}
            spec=command_spec(ROOT,self.cohort,self.plan,cell,'serving',binding)
            args=runner_arguments(spec['argv'][3:])
            self.assertTrue(args.production_kv_grant);self.assertEqual(args.concurrency,1)
            self.assertEqual(args.kv_backend,'contiguous');self.assertFalse(spec['executed'])
            self.assertFalse(Path(spec['output_directory']).exists())


if __name__ == '__main__':
    unittest.main()
