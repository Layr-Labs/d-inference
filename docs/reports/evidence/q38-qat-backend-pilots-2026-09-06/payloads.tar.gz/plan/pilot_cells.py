"""Read-only selection/command/collection for seven plan3-derived pilot cells."""
import argparse
import hashlib
import json
import math
from pathlib import Path
import shlex

import matrix_cells as matrix

ROOT = Path(__file__).resolve().parent
QUARTETS = ('qwen38-b1-r1', 'gemma-4-26b-qat-4bit-b1-r1')
ORIGIN_SHA256 = '781532482bdb5ebdbabee4461e574c796e0e2cc04f94513dd81baa23415c7689'


def select(origin, identifiers):
    matrix.require(len(origin['cells']) == 216 and len(origin['pairs']) == 216,
                   'original conceptual matrix topology changed')
    matrix.require(sum(c['support'] == 'supported' for c in origin['cells']) == 189
                   and sum(p['required_comparison'] for p in origin['pairs']) == 162,
                   'original supported/unsupported topology changed')
    expected = [c for c in origin['cells'] if c['quartet'] in QUARTETS and c['support'] == 'supported']
    matrix.require(len(expected) == 7 and identifiers == [c['id'] for c in expected],
                   'pilot selection must be the original ordered supported Q38 quartet and QAT triple')
    matrix.require(all(c['concurrency'] == c['repetition'] == 1 and not c['blockers'] for c in expected),
                   'pilot width/repetition/support changed')
    labels = {c['model'] for c in expected}
    pairs = [p for p in origin['pairs'] if p['quartet'] in QUARTETS]
    matrix.require(sum(p['required_comparison'] for p in pairs) == 6, 'pilot comparisons changed')
    return {'cells': expected, 'models': [m for m in origin['models'] if m['label'] in labels],
            'pairs': pairs, 'prompt_date': origin['prompt_date'], 'output_token_cap': origin['output_token_cap']}


def load_plan():
    matrix.require(matrix.sha256(ROOT / 'origin-plan.json') == ORIGIN_SHA256, 'original plan bytes changed')
    selection = matrix.read(ROOT / 'pilot-selection.json')
    matrix.require(selection['schema'] == 'darkbloom.q38-qat-backend-pilots.v1', 'wrong pilot schema')
    plan = select(matrix.read(ROOT / 'origin-plan.json'), selection['cell_ids'])
    for model in plan['models']:
        matrix.require(matrix.sha256(ROOT / model['input']) == model['input_sha256'], 'original input bytes changed')
        matrix.require(matrix.sha256(ROOT / model['manifest']) == model['manifest_sha256'], 'model manifest changed')
        prepared = (json.dumps(matrix.read(ROOT / model['input']), indent=2, sort_keys=True) + '\n').encode()
        matrix.require(hashlib.sha256(prepared).hexdigest() == model['prepared_input_sha256'], 'prepared input changed')
    return plan


def require_owned_results_root(binding):
    matrix.require(Path(binding['results_root']).resolve() == (ROOT / 'runs').resolve(),
                   'pilot results must use this separate package runs root')


def process_window(metadata):
    start, end = metadata.get('started_unix'), metadata.get('ended_unix')
    matrix.require(all(type(value) in (int, float) and math.isfinite(value) for value in (start, end))
                   and 0 <= start <= end, 'missing or invalid process window')
    return start, end


def collect(plan, binding):
    result = {'scope': 'Seven separate B1 repetition1 pilots; no matrix completion or repeated-performance claim',
              'cells': [], 'comparisons': [], 'process_order_errors': [],
              'matrix_completion_claim': False, 'release_gates_satisfied': False}
    reports, windows, accepted = {}, {}, set()
    for cell in plan['cells']:
        directory = matrix.output_directory(binding, cell)
        try:
            state = matrix.cell_status(binding, cell)
        except (OSError, ValueError, TypeError, AttributeError):
            state = 'retained_failed_or_partial'
        item = {'id': cell['id'], 'origin_order': cell['order'], 'state': state}
        if directory.exists():
            try:
                windows[cell['id']] = process_window(matrix.read(directory / 'metadata.json'))
            except (OSError, ValueError, TypeError, AttributeError) as error:
                result['process_order_errors'].append({'cell': cell['id'], 'error': str(error)})
        if state == 'completed_unvalidated':
            try:
                report = matrix.read(directory / 'report.json')
                meta = matrix.read(directory / 'metadata.json')
                errors = matrix.cell_evidence_errors(plan, binding, cell, report, meta)
                if cell['id'] not in windows:
                    errors.append({'missing_or_invalid_process_window': True})
                item.update(errors=errors, report_sha256=matrix.sha256(directory / 'report.json'),
                            metadata_sha256=matrix.sha256(directory / 'metadata.json'),
                            state='failed_integrity' if errors else 'cell_integrity_pass_comparisons_pending')
                if not errors:
                    accepted.add(cell['id']); reports[cell['id']] = report
            except (OSError, ValueError, KeyError, TypeError, IndexError, AttributeError) as error:
                item.update(state='malformed_evidence', error=str(error))
        result['cells'].append(item)
    ordered = [c['id'] for c in plan['cells'] if c['id'] in windows]
    for before, after in zip(ordered, ordered[1:]):
        if not windows[before][1] <= windows[after][0]:
            result['process_order_errors'].append({'previous': before, 'following': after})
    for pair in plan['pairs']:
        item = dict(pair, passed=False, state='missing_or_failed_cell')
        if not pair['required_comparison']:
            item['state'] = 'unsupported_comparison'
        elif {pair['baseline'], pair['candidate']} <= accepted:
            try:
                item.update(matrix.compare(reports[pair['baseline']], reports[pair['candidate']],
                                           pair['expect_cache_hits'], pair['axis']), state='evaluated')
                if result['process_order_errors']:
                    item['passed'] = False
                    item['errors'].append({'pilot_process_order_or_overlap_failed': True})
            except (OSError, ValueError, KeyError, TypeError, IndexError) as error:
                item.update(state='malformed_comparison', error=str(error))
        result['comparisons'].append(item)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('status', 'command', 'collect'))
    parser.add_argument('--bindings', required=True)
    parser.add_argument('--cell')
    parser.add_argument('--format', choices=('json', 'shell'), default='json')
    args = parser.parse_args()
    plan = load_plan()
    # The exact frozen matrix helper checks reviewed binding, package inventory,
    # runtime/resource hashes, executable mode, date, storage and untouched roots.
    binding = matrix.verified_bindings(args.bindings)
    require_owned_results_root(binding)
    if args.action == 'command':
        matches = [c for c in plan['cells'] if c['id'] == args.cell]
        matrix.require(len(matches) == 1, 'select an exact supported pilot cell')
        argv = matrix.command(plan, binding, matches[0])
        if args.format == 'shell':
            print(shlex.join(argv)); return
        result = {'cell': args.cell, 'bindings_sha256': matrix.sha256(args.bindings),
                  'argv': argv, 'shell': shlex.join(argv)}
    elif args.action == 'status':
        result = [{'id': c['id'], 'state': matrix.cell_status(binding, c)} for c in plan['cells']]
    else:
        result = collect(plan, binding)
    print(json.dumps(result, indent=2, sort_keys=True))


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError) as error:
        raise SystemExit(str(error))
