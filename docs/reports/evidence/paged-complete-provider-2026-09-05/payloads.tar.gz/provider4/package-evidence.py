from pathlib import Path
import difflib,json,re,subprocess,tarfile
script=Path('/tmp/darkbloom-checkpoint-provider-validation4/run.py').read_text();exec(script.split("assert (policy / 'manifest.json').exists()")[0]);assert (out/'source-verified-after.json').exists();verified=verify()
execution=json.loads((out/'execution.json').read_text());groups=json.loads((out/'filters.json').read_text());assert len(execution)==len(groups)+2
ids=[s for s in (out/'identifiers.log').read_text().splitlines() if s.startswith('ProviderCoreTests.')];selected={};summaries={};failures={}
for name,filters in groups.items():
 body=(out/(name+'.log')).read_text();row=next(x for x in execution if x['name']==name)
 if row['exit_code'] or not row['nonzero_and_no_skips']:
  failures[name]=[s for s in body.splitlines() if 'recorded an issue' in s or '✘' in s or ': error:' in s or 'Fatal error' in s or 'failed' in s.lower()];continue
 sw=re.findall(r'Test run with (\d+) tests?',body);swift=int(sw[-1]) if sw else 0;xc=max(map(int,re.findall(r'Executed (\d+) tests?',body)),default=0);extra=sum(int(n)-1 for n in re.findall(r'with (\d+) test cases passed',body));matches=[s for s in ids if any(f in s for f in filters)];assert len(matches)==swift+xc,(name,len(matches),swift+xc)
 assert not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test|recorded an issue|[✘]',body,re.M),name
 selected[name]=sorted(matches);summaries[name]={'functions':swift+xc,'cases':swift+xc+extra,'failures':0,'skips':0}
unique=sorted(set(s for g in selected.values() for s in g));assert len(unique)==sum(v['functions'] for v in summaries.values());direct_functions=len(unique)
direct_cases=sum(v['cases'] for v in summaries.values())
donor=Path('/tmp/darkbloom-checkpoint-provider-validation3')
assert sha(donor/'manifest.json')=='c2e48034a882258e558e3d74d2ad7dd9cb6dfad03104a99ae704ed72f975ae26'
for path,row in json.loads((donor/'manifest.json').read_text())['files'].items():assert sha(donor/path)==row['sha256'],path
donor_sources=json.loads((donor/'provider-source-manifest.json').read_text())['files']
current_sources=json.loads((out/'provider-source-manifest.json').read_text())['files']
assert set(donor_sources)==set(current_sources)
delta=[p for p in current_sources if current_sources[p]!=donor_sources[p]]
assert delta==['provider-swift/Tests/ProviderCoreTests/EngineV2KVBackendGateTests.swift'],delta
donor_verdict=json.loads((donor/'verdict.json').read_text());donor_ids=json.loads((donor/'selected-identifiers.json').read_text())['passed_by_group']
assert len(donor_verdict['by_group'])==13 and 'factory-identity' not in donor_verdict['by_group']
for name,summary in donor_verdict['by_group'].items():
 assert name not in summaries
 summaries[name]=summary
 selected[name]=donor_ids[name]
unique=sorted(set(s for g in selected.values() for s in g));assert len(unique)==sum(v['functions'] for v in summaries.values())
carry={'donor_manifest':str(donor/'manifest.json'),'donor_manifest_sha256':sha(donor/'manifest.json'),'direct_groups':list(groups),'direct_functions':direct_functions,'direct_cases':direct_cases,'carried_groups':list(donor_verdict['by_group']),'carried_functions':donor_verdict['passed_unique_functions'],'carried_cases':donor_verdict['passed_unique_cases'],'only_source_delta':delta,'scope':'Four expectations in two factory tests corrected; full factory97 rerun on candidate4. Remaining13 groups executed on candidate3, unchanged production/dependency/test bytes. These are carried evidence, not candidate4 invocations.'}
(out/'carried-regression-evidence.json').write_text(json.dumps(carry,indent=2)+'\n')
(out/'selected-identifiers.json').write_text(json.dumps({'passed_by_group':selected,'unique_passed_identifiers':unique},indent=2)+'\n')
owned=json.loads((out/'owned-manifest.json').read_text())['files'];base=subprocess.check_output(['git','rev-parse','566d5e549'],cwd=workspace,text=True).strip();patch='';changed={}
with tarfile.open(out/'owned-source.tar.gz','w:gz') as archive:
 for path,h in sorted(owned.items()):
  p=workspace/path;assert sha(p)==h;archive.add(p,arcname=path)
  prior=subprocess.run(['git','show',base+':'+path],cwd=workspace,stdout=subprocess.PIPE,stderr=subprocess.PIPE);before=prior.stdout.decode() if prior.returncode==0 else '';after=p.read_text()
  if before!=after:changed[path]=h;patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+path if prior.returncode==0 else '/dev/null',tofile='b/'+path))
path=out/'provider-after-banked-footprint.patch';path.write_text(patch);numstat=subprocess.check_output(['git','apply','--numstat',str(path)],cwd=workspace,text=True);assert sorted(s.split('\t')[-1] for s in numstat.splitlines())==sorted(changed)
(out/'incremental-owned-manifest.json').write_text(json.dumps({'base':base,'count':len(changed),'files':changed},indent=2)+'\n')
observations={'memory':[],'footprint':[]}
for line in (donor/'real-native-isolated.log').read_text().splitlines():
 if line.startswith(('native-memory ','native-footprint ')):
  values={}
  for part in line.split()[1:]:k,v=part.split('=',1);values[k]=int(v) if v.isdigit() else v
  observations['memory' if line.startswith('native-memory ') else 'footprint'].append(values)
(out/'real-allocator-observations.json').write_text(json.dumps(observations,indent=2)+'\n')
verdict={'status':'pass' if not failures else 'failed','provider_worktree_base':'69a75de82813beaf753fbbb4891c3b3261b63600','canonical_delta_base':base,'native_source':str(native),'native_evidence_sha256':sha(native.parent/'manifest.json'),'policy_evidence':str(policy/'manifest.json'),'policy_evidence_sha256':sha(policy/'manifest.json'),'build_seconds_reported':float(re.findall(r'Build complete! \(([0-9.]+)s\)',(out/'build.log').read_text())[-1]),'passed_unique_functions':len(unique),'passed_unique_cases':sum(v['cases'] for v in summaries.values()),'by_group':summaries,'failure_details':failures,'source_verified':verified,'owned_source_count':len(owned),'incremental_paths':len(changed),'scope':'Provider factory native process binding, shared SSD host/native ownership and historical complete-prefix eligibility against full native union, preserving prior actual allocator, telemetry, load/lifecycle and benchmark regressions.','limits':['Pre-evaluation real-native cap is temporarily constrained at observation boundary then restored before allocation; not continuously bounded whole-model/factory/scratch proof.','OS availability non-binding; coherent actual allocator usage retained in raw observations.','Shared-SSD and real-native suites execute separately to avoid unrelated process allocator interference.','No requested fleet-size model, HTTP path, release default or performance claim from unit integration.','Separate source-only harness/Python and real-model benchmark evidence, if integrated, require their own explicit provenance.']}
lineage_path=Path('/tmp/darkbloom-checkpoint-provider-validation1/partial-manifest.json')
(out/'evidence-lineage.json').write_text(json.dumps({'previous_ready_fixture_failure':{'path':str(donor/'manifest.json'),'sha256':sha(donor/'manifest.json')},'previous_fixture_failure':{'path':'/tmp/darkbloom-checkpoint-provider-validation2/manifest.json','sha256':sha(Path('/tmp/darkbloom-checkpoint-provider-validation2/manifest.json'))},'previous_compile_failure':{'path':str(lineage_path),'sha256':sha(lineage_path)},'native_pass':{'path':str(native.parent/'manifest.json'),'sha256':sha(native.parent/'manifest.json')},'harness_source_and_independent_python_checks':{'path':'/tmp/darkbloom-final-model-harness/freeze2/manifest.json','sha256':sha(Path('/tmp/darkbloom-final-model-harness/freeze2/manifest.json'))}},indent=2)+'\n')
verdict['limits'].append('Parallel source audit found legacy fixed-pool initial sizing can refuse exact Qwen B1 before requests. Separately reviewed segmented initial-grant policy and real-model validation remain mandatory; no inflated benchmark-grant workaround applied.')
verdict['execution_scope']=carry
verdict['limits'].append(carry['scope'])
(out/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n');(out/'environment.txt').write_text(subprocess.check_output(['swift','--version'],text=True,stderr=subprocess.STDOUT)+subprocess.check_output(['sw_vers'],text=True)+subprocess.check_output(['uname','-a'],text=True))
files={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and 'workspace' not in p.relative_to(out).parts and p.name not in ['manifest.json','partial-manifest.json']};(out/'manifest.json').write_text(json.dumps({'scope':verdict['scope'],'files':files},indent=2)+'\n');print(json.dumps({'status':verdict['status'],'functions':len(unique),'cases':verdict['passed_unique_cases'],'failed_groups':list(failures),'payloads':len(files),'manifest_sha256':sha(out/'manifest.json')},indent=2))
