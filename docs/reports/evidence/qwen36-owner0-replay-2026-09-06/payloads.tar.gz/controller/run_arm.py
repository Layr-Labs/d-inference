"""Run one bounded genuine arm, retaining failed output before stopping successors."""
from pathlib import Path
import json
import subprocess
import sys

from common import (BINDING, HOST, OPTIONS, PLAN, RESULTS, file_record, load_binding,
                    remote, seal, sha, verify_file, write)
import remote_sources as snippets


def verify_previous(root):
    summary = json.loads((root/'summary.json').read_text())
    assert summary['status'] == 'PASS', 'Prior failed or incomplete work blocks successor'
    for name, row in json.loads((root/'manifest.json').read_text())['files'].items(): verify_file(root/name, row)
    if (root/'raw-manifest.json').exists():
        for name, row in json.loads((root/'raw-manifest.json').read_text()).items(): verify_file(RESULTS/'raw'/name, row)


def main():
    assert len(sys.argv) == 3, 'Pass one arm and the exact reviewed runtime-binding SHA256'
    binding, plan = load_binding(sys.argv[2])
    chosen = next(row for row in plan['arms'] if row['arm'] == sys.argv[1])
    verify_previous(RESULTS/'staging')
    for row in plan['arms'][:plan['arms'].index(chosen)]: verify_previous(RESULTS/'arms'/row['arm'])
    local = RESULTS/'arms'/chosen['arm']; local.mkdir(parents=True, exist_ok=False)
    raw_root = RESULTS/'raw'; raw_root.mkdir(exist_ok=True)
    configuration = {'remote_root': plan['remote_root'], 'binding_sha256': sha(BINDING),
                     'arm': chosen['arm'], 'argv': chosen['argv']}
    write(local/'command.json', chosen)
    errors = []
    result = None
    try:
        remote(local, 'entry-readiness', snippets.READINESS, {'entry': True})
        result = remote(local, 'execution', snippets.EXECUTE, configuration)
        write(local/'execution.json', result)
        inventory = remote(local, 'inventory', snippets.INVENTORY, configuration)
        write(local/'raw-manifest.json', inventory['files'])
        for name, row in inventory['files'].items():
            target = raw_root/name; target.parent.mkdir(exist_ok=True)
            assert not target.exists(), str(target)
            copy = subprocess.run(['scp', '-p']+OPTIONS+[HOST+':'+plan['remote_root']+'/runs/'+name, str(target)],
                                  text=True, capture_output=True, timeout=240)
            assert copy.returncode == 0, copy.stderr
            verify_file(target, row)
        # Recheck exact runtime and supplied bytes even when the native arm failed.
        remote(local, 'post-identity', snippets.VERIFY+'\nprint(json.dumps({"identity_verified":True}))\n', configuration)
        if result['exit_code'] != 0 or result['failure'] is not None:
            errors.append('Native process failed: ' + json.dumps(result))
        else:
            sys.path.insert(0, str(PLAN/'runner')); sys.path.insert(0, str(PLAN))
            from attention_packet.packet import load_packet
            from validate_arm import validate_arm
            captures = json.loads((PLAN/'captures.json').read_text())
            packets = {key: load_packet(Path(row['path'])) for key, row in captures.items()}
            # Full original descriptors/buffers are pinned independently of their embedded hashes.
            for row in captures.values():
                original = Path(row['path']).parent
                for name, identity in row['files'].items(): verify_file(original/name, identity)
            transfer = json.loads((PLAN/'input.json').read_text())
            analysis = validate_arm(raw_root/chosen['arm'], chosen['arm'], packets['contiguous'], packets['paged'], transfer, plan['input_sha256'])
            write(local/'analysis.json', analysis)
            if analysis['status'] != 'analyzed': errors += analysis['inconclusiveReasons']
    except Exception as error:
        errors.append(type(error).__name__ + ': ' + str(error))
    finally:
        try:
            # Cooling is recorded here; the next arm still requires the original entry thresholds.
            postflight = remote(local, 'postflight', snippets.READINESS, {'entry': False})
            write(local/'postflight.json', postflight)
        except Exception as error: errors.append('Postflight failed: ' + type(error).__name__ + ': ' + str(error))
        write(local/'summary.json', {'arm': chosen['arm'], 'status': 'PASS' if not errors else 'FAIL',
            'errors': errors, 'native_exit_code': None if result is None else result['exit_code'],
            'numerical_or_model_release_gate_evaluated': False})
        seal(local)
    print((local/'summary.json').read_text(), flush=True)
    raise SystemExit(1 if errors else 0)


if __name__ == '__main__': main()
