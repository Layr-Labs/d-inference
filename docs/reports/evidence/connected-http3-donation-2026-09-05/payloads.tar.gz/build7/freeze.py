from pathlib import Path
import gzip,hashlib,json,re
out=Path('/tmp/darkbloom-final-serving-build7');ws=out/'workspace';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
execution=json.loads((out/'execution.json').read_text());assert execution['exit_code']==0
checks=json.loads((out/'compile-and-cli-verdict.json').read_text());assert checks['all_passed'] and checks['checks_passed']==6
known={}
def add(path,digest,group):
 key=str(path.resolve());prior=known.get(key);assert prior is None or prior['sha256']==digest,key;known[key]={'sha256':digest,'group':group}
for name,digest in json.loads((out/'provider-source-manifest.json').read_text())['files'].items():add(ws/name,digest,'provider')
for name,digest in json.loads((out/'native-source-manifest.json').read_text())['files'].items():add(ws/'libs/mlx-swift-lm'/name,digest,'native')
deps=json.loads((out/'dependency-source-manifest.json').read_text())
for key,digest in deps['files'].items():
 alias,name=key.split('/',1);add(Path(deps['repositories'][alias])/name,digest,'dependency')
for name,digest in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():add(Path('/tmp/darkbloom-final-serving-build1/build/checkouts/swift-jinja')/name,digest,'jinja')
text=gzip.decompress((out/'actual-build-graph.yaml.gz').read_bytes()).decode();matches={}
for literal in re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',text):
 path=Path(literal);key=str(path.resolve())
 if key not in known:continue
 row=known[key];assert sha(path)==row['sha256'],literal;matches[literal]={'resolved_frozen_source':key,**row}
assert any('/Sources/darkbloom/' in p for p in matches)
counts={g:sum(x['group']==g for x in matches.values()) for g in ['provider','native','dependency','jinja']}
assert all(counts.values())
(out/'all-owned-graph-source-proof.json').write_text(json.dumps({'scope':'Every graph input under frozen source maps resolves to matching bytes. Graph membership is planned compilation; release command/log establishes executed CLI product.','counts':counts,'files':matches},indent=2)+'\n')
art=json.loads((out/'artifact-manifest.json').read_text())
for name,row in art['files'].items():assert sha(out/'artifact'/name)==row['sha256'],name
baseline=json.loads(Path('/tmp/darkbloom-final-serving-build6/artifact-manifest.json').read_text())
for name,row in baseline['files'].items():assert art['files'][name]==row,name
summary={'status':'PASS','scope':'New release CLI with validated native useful-tail policy. Build6 probe and six resources copied unchanged. No new real-model, HTTP, performance, or rollout result claimed.','execution':execution,'provider_inputs':677,'native_inputs':481,'dependency_inputs':1356,'jinja_inputs':27,'source_commits':{'primary':'9e49059a1806e265fd9ceab420c1b82216a5d785','native':'a932d38cee0beca41ca1a0e71c1e867913a65353'},'canonical_compile_only_package_overlays':2,'cli':art['files']['darkbloom'],'unchanged_build6_probe':art['files']['radix-engine'],'runtime_resources':6,'pure_argument_and_help_checks':6,'source_corrections':0,'preserved_precompile_audit_correction':'preparation-failure.json'}
(out/'verdict.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
for path in sorted(out.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(out)
 if rel.parts[0] in ['workspace','artifact'] or rel==Path('manifest.json'):continue
 files[str(rel)]={'sha256':sha(path),'bytes':path.stat().st_size}
(out/'manifest.json').write_text(json.dumps({'schema':1,'status':'PASS: release CLI and pure guards; connected runtime validation separate','files':files,'runtime_artifacts':art},indent=2)+'\n')
print(json.dumps({'manifest_sha256':sha(out/'manifest.json'),'payloads':len(files),'graph_counts':counts,'verdict':summary},indent=2))
