from pathlib import Path
import hashlib,json,subprocess
out=Path('/tmp/darkbloom-allocator-footprint-foundation4');root=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated');repos={'swift':Path('/tmp/darkbloom-allocator-footprint-foundation3/deps/mlx-swift'),'mlx':Path('/tmp/darkbloom-allocator-footprint-foundation3/deps/mlx-swift/Source/Cmlx/mlx'),'mlx-c':Path('/tmp/darkbloom-allocator-footprint-foundation3/deps/mlx-swift/Source/Cmlx/mlx-c'),'native':out/'native'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
 owned=json.loads((out/'owned-manifest.json').read_text())
 for key,h in owned['files'].items():alias,p=key.split('/',1);assert sha(repos[alias]/p)==h,key
 deps=json.loads((out/'dependency-source-manifest.json').read_text())
 for key,h in deps['files'].items():alias,p=key.split('/',1);assert sha(Path(deps['repositories'][alias])/p)==h,key
 ns=json.loads((out/'native-source-manifest.json').read_text())
 for p,h in ns['files'].items():assert sha(repos['native']/p)==h,p
 ps=json.loads((out/'primary-native-baseline.json').read_text())
 for p,h in ps['files'].items():assert sha(root/'libs/mlx-swift-lm'/p)==h,p
 pd=json.loads((out/'primary-dependency-baseline.json').read_text())
 for key,h in pd['files'].items():alias,p=key.split('/',1);assert sha(Path(pd['repositories'][alias])/p)==h,key
 overlay=json.loads((out/'native-manifest-overlay.json').read_text());assert sha(root/'libs/mlx-swift-lm/Package.swift')==overlay['original_sha256'];assert sha(repos['native']/'Package.swift')==overlay['validation_sha256']
 for r in json.loads((out/'integration.json').read_text())['repositories']:assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=r['path'],text=True).strip()==r['base'],r['repository']
 return {'owned_inputs':len(owned['files']),'candidate_dependency_inputs':len(deps['files']),'candidate_native_inputs_including_manifest':len(ns['files']),'primary_native_inputs':len(ps['files']),'primary_dependency_inputs':len(pd['files']),'no_drift':True}
