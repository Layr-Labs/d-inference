#!/usr/bin/env python3
"""Run one existing connected test cell, only in the sole validation lane."""
import argparse
import datetime
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from temporary_model_alias import assert_idle, digest, verify_snapshot

POLICY_PREFIXES = ('DARKBLOOM_PREFIX_CACHE', 'DARKBLOOM_CBV2_', 'DARKBLOOM_QWEN_',
                   'DARKBLOOM_MTP_', 'DARKBLOOM_ENGINE_V2', 'DARKBLOOM_ACTIVATION_',
                   'DARKBLOOM_MEM_', 'DARKBLOOM_SPEC_DEC_', 'DARKBLOOM_TESTBED_', 'MLX_',
                   'DARKBLOOM_ADAPTIVE_', 'DARKBLOOM_B1_', 'DARKBLOOM_COMPILED_',
                   'DARKBLOOM_GEMMA', 'DARKBLOOM_KV_', 'DARKBLOOM_MLX_',
                   'DARKBLOOM_MAX_', 'DARKBLOOM_PREFILL_', 'DARKBLOOM_VISION_')


def refuse_inherited_policy(environment):
    present = sorted(k for k in environment if k.startswith(POLICY_PREFIXES))
    if present:
        raise ValueError('inherited policy overrides must be absent: ' + ', '.join(present))


def verify_discovery(home, model_id, expected):
    snapshots = Path(home)/'.cache/huggingface/hub'/('models--'+model_id.replace('/', '--'))/'snapshots'
    candidates = [p for p in snapshots.iterdir() if not p.name.startswith('.') and p.is_dir()]
    if not candidates:
        raise ValueError('exact model not discoverable: ' + model_id)
    highest = max(p.stat().st_mtime_ns for p in candidates)
    selected = [p for p in candidates if p.stat().st_mtime_ns == highest]
    if len(selected) != 1 or selected[0].resolve() != Path(expected):
        raise ValueError('production latest-snapshot resolution is not uniquely the pinned artifact')
    return str(selected[0])


def save(path, result):
    temp = path.with_suffix('.tmp')
    temp.write_text(json.dumps(result, indent=2) + '\n')
    temp.replace(path)


def preflight(base, plan, cell, data):
    refuse_inherited_policy(os.environ)
    now = datetime.datetime.now(datetime.timezone.utc).date().isoformat()
    if now != plan['expected_request_date_utc']:
        raise ValueError('request-owned UTC date changed; prepare a newly reviewed paired input bundle')
    assert_idle()
    canonical = Path.home()/'.config/darkbloom/provider.toml'
    if digest(canonical) != plan['canonical_config_sha256']:
        raise ValueError('canonical config differs; no repair or overwrite performed')
    for rel in ['.darkbloom/telemetry-queue.jsonl', '.darkbloom/telemetry-queue.jsonl.tmp']:
        if os.path.lexists(Path.home()/rel):
            raise ValueError('retired startup file present; no host cleanup: ' + rel)
    selected = verify_discovery(Path.home(), data['artifact']['model_id'], cell['model_directory'])
    paths = {data['provider_binary']: data['provider_sha256'],
             str(Path(data['provider_binary']).parent/'mlx.metallib'): data['metallib_sha256'],
             data['sidecar_binary']: data['sidecar_sha256']}
    for path, expected in paths.items():
        if digest(path) != expected:
            raise ValueError('runtime digest differs: ' + path)
    runtime = json.loads((base/'source-inputs'/'payload--transfer-manifest.json').read_text())['files']
    runtime_root = Path(data['provider_binary']).parent.parent
    for name, item in runtime.items():
        if name.startswith('bin/') and name != 'bin/radix-engine' or name.startswith('gemma-assistant/') and 'assistant_path' in data:
            if digest(runtime_root/name) != item['sha256']:
                raise ValueError('colocated runtime/assistant identity mismatch: ' + name)
    codesign = subprocess.run(['/usr/bin/codesign', '-d', '--entitlements', ':-', data['provider_binary']],
                              stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    if codesign.returncode or 'keychain-access-groups' in codesign.stdout:
        raise ValueError('provider must be verifiably unentitled; no persistent signer invocation')
    manifest = json.loads((base/cell['model_manifest']).read_text())
    verify_snapshot(Path(cell['model_directory']), manifest)
    return {'date_utc':now, 'canonical_config_sha256':digest(canonical),
            'selected_snapshot':selected, 'manifest_files_verified':len(manifest['files']),
            'model_aggregate_sha256':manifest['aggregate_sha256'],
            'runtime_sha256':paths, 'policy_environment':{},
            'cache_key_policy':'testbed sets ALLOW_EPHEMERAL=1 plus per-provider TEST_ROOT; persistent override absent',
            'scope':'No provider, sidecar, model, GPU, keychain or daemon launched by preflight'}



def drain_owned_group(pgid, grace_seconds=(5, 5, 5)):
    """Called immediately after wait, before hashing/report IO. Never name-kill.

    The fresh session's PGID is its launched leader PID. While descendants
    retain this group it cannot be reused; stop at the first ESRCH and never
    revisit that retired identifier. No signals go to an already-empty group.
    """
    actions = []
    def exists():
        try:
            os.killpg(pgid, 0)
            return True
        except ProcessLookupError:
            return False
        except PermissionError:
            # Darwin may return EPERM for a just-killed group whose remaining
            # children are init-owned zombies. They hold no live process work;
            # distinguish that from a live group we are forbidden to signal.
            listing = subprocess.check_output(['/bin/ps', '-axo', 'pgid=,stat='], text=True)
            members = [line.split()[1] for line in listing.splitlines()
                       if len(line.split()) == 2 and line.split()[0] == str(pgid)]
            if not members or all(status.startswith('Z') for status in members):
                return False
            raise
    if not exists():
        return actions
    for signum, grace in zip((signal.SIGINT, signal.SIGTERM, signal.SIGKILL), grace_seconds):
        try:
            os.killpg(pgid, signum)
            actions.append(signal.Signals(signum).name)
        except ProcessLookupError:
            return actions
        deadline = time.monotonic() + grace
        while time.monotonic() < deadline:
            if not exists():
                return actions
            time.sleep(.05)
    if exists():
        raise RuntimeError('owned process group did not drain after bounded cleanup')
    return actions


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['preflight','run'])
    p.add_argument('--cell', required=True)
    args = p.parse_args()
    base = Path(__file__).resolve().parent
    plan = json.loads((base/'bundle-plan.json').read_text())
    if str(base) != plan['remote_bundle_root']:
        raise ValueError('bundle must be staged at its exact reviewed remote root')
    cell = next(c for c in plan['cells'] if c['cell'] == args.cell)
    data = json.loads((base/cell['input']).read_text())
    control = base/'runs'/(args.cell+'-'+args.command)
    control.parent.mkdir(exist_ok=True)
    control.mkdir(mode=0o700)  # Never reuse output or old cache state.
    result = {'status':'preparing', 'cell':args.cell, 'started_unix':time.time(),
              'input_sha256':digest(base/cell['input']), 'source_commit':plan['source_commit']}
    record = control/'launch.json'
    save(record, result)
    try:
        result['preflight'] = preflight(base, plan, cell, data)
        if args.command == 'preflight':
            result['status'] = 'preflight_passed_not_run'
        else:
            binary = base/'connected-e2e.test'
            if digest(binary) != plan['go_test_binary_sha256']:
                raise ValueError('Go test executable differs from exact source artifact')
            temp = control/'temporary'; temp.mkdir(mode=0o700)
            evidence = control/'evidence'  # Existing Go test creates this exclusively.
            env = os.environ.copy()
            env.update({'DARKBLOOM_CONNECTED_CACHE_INPUT':str(base/cell['input']),
                        'DARKBLOOM_CONNECTED_CACHE_OUTPUT':str(evidence), 'TMPDIR':str(temp)})
            command = [str(binary), '-test.run', '^TestIntegrationConnectedCacheHTTP$',
                       '-test.v', '-test.timeout', '45m', '-test.parallel', '1']
            result.update(status='running', command=command, evidence_path=str(evidence))
            save(record, result)
            with (control/'connected.log').open('x') as log:
                child = subprocess.Popen(command, env=env, cwd=base, stdout=log, stderr=subprocess.STDOUT,
                                         start_new_session=True)
                pgid = child.pid  # start_new_session makes this exact owned group.
                old_handlers = {}
                interrupted = []
                def forward(signum, frame):
                    interrupted.append((signum, time.monotonic()))
                    try:
                        child.send_signal(signum)  # First allow normal Suite.Stop.
                    except ProcessLookupError:
                        pass
                for signum in [signal.SIGINT, signal.SIGTERM, signal.SIGHUP]:
                    old_handlers[signum] = signal.signal(signum, forward)
                try:
                    while True:
                        try:
                            result['exit_code'] = child.wait(timeout=.25)
                            break
                        except subprocess.TimeoutExpired:
                            if interrupted and time.monotonic()-interrupted[0][1] > 20:
                                result['owned_group_cleanup'] = drain_owned_group(pgid)
                                result['exit_code'] = child.wait(timeout=2)
                                pgid = None
                                break
                    if pgid is not None:
                        # Keep this adjacent to wait: no deferred group check after
                        # postflight hash IO and no revisit after group retirement.
                        result['owned_group_cleanup'] = drain_owned_group(pgid)
                        pgid = None
                finally:
                    for signum, handler in old_handlers.items(): signal.signal(signum, handler)
                    if pgid is not None:
                        result['owned_group_cleanup'] = drain_owned_group(pgid)
                        child.wait(timeout=2)
                if interrupted:
                    result['interrupt_signals'] = [signal.Signals(x[0]).name for x in interrupted]
                    raise RuntimeError('connected run interrupted; retained partial evidence is not a pass')
            # Verify artifacts and host config after actual owned helper unwind.
            result['postflight'] = preflight(base, plan, cell, data)
            report = json.loads((evidence/'report.json').read_text())
            if result['exit_code'] != 0 or report['state'] != 'completed':
                raise ValueError('connected test did not complete; retain all failed/unrun rows')
            dates = {c['request_date_utc'] for c in report['cases'] if c['status'] == 'passed'}
            if dates != {plan['expected_request_date_utc']}:
                raise ValueError('paired request date mismatch')
            result['status'] = 'completed'
    except BaseException as error:
        result.update(status='failed', error=str(error))
        raise
    finally:
        result['ended_unix'] = time.time()
        save(record, result)
        print(record)


if __name__ == '__main__': main()
