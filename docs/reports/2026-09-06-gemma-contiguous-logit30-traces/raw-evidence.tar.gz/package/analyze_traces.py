"""Strict trace/control interpretation; no full target-window or KV-state identity claim."""
from pathlib import Path
import argparse
import json

from common import ROOT, digest, read_json, require, verify_package
from results import verify_completed
from inspect_logit_pair import inspect


def trace_control_checks(report, control, mode):
    result = inspect(report, control, mode)
    for before, after in zip(control['rows'], report['rows']):
        for name in ['prefill_chunks', 'prefill_chunk_tokens_max']:
            require(type(before.get(name)) is int and before[name] > 0
                    and after.get(name) == before[name], 'trace changed main prefill geometry: ' + name)
    result['prefill_geometry_parity'] = True
    result['full_KV_state_identity'] = 'UNOBSERVED'
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--ordinary', type=Path, required=True)
    parser.add_argument('--automatic', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args()
    binding = verify_package(arguments.manifest_sha256, ROOT, local=True)
    result = {'schema': 1, 'status': 'inconclusive', 'cases': {}, 'errors': [],
              'full_KV_state_identity': 'UNOBSERVED',
              'full_rectangular_target_input': 'UNOBSERVED; seed and draftPrefix cover only the selected column prefix',
              'retained_verifier_correctness': 'FAILED: frozen automatic and ordinary controls differ at index 30; diagnostic success does not waive it.'}
    reports = {'off': arguments.ordinary, 'automatic': arguments.automatic}
    for cell in binding['cells']:
        mode = cell['mode'];path = reports[mode]
        try:
            verify_completed(path.parent, cell, binding, arguments.manifest_sha256)
            owner = read_json(path.parent / 'local-process.json')
            require(owner.get('exit_code') == 0 and owner.get('failure') is None
                    and owner.get('group_cleanup_complete') is True, 'local owned execution failed')
            control = ROOT / cell['control_relative'] / 'report.json'
            require(digest(control) == cell['control_report_sha256'], 'frozen trace-off control changed')
            result['cases'][mode] = trace_control_checks(read_json(path), read_json(control), mode)
            result['cases'][mode]['trace_report_sha256'] = digest(path)
            result['cases'][mode]['control_report_sha256'] = digest(control)
        except Exception as error:
            result['errors'].append({'mode': mode, 'error': type(error).__name__ + ': ' + str(error)})
    if not result['errors'] and len(result['cases']) == 2:
        result['status'] = 'valid_bounded_logit_observations'
    with arguments.output.open('x') as output:
        json.dump(result, output, indent=2, allow_nan=False)
        output.write('\n')
    return 0 if not result['errors'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
