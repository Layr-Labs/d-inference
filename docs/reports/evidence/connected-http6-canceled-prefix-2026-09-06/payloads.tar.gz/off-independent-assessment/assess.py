from pathlib import Path
import hashlib,json,sys
BASE=Path('/tmp/darkbloom-connected-http6-results/qwen38-paged-off-b1');OUT=Path(__file__).parent
sys.path.insert(0,'/tmp/darkbloom-connected-http6-execution-prep2')
from common import strict_cell,item,save
manifest=BASE/'manifest.json';assert hashlib.sha256(manifest.read_bytes()).hexdigest()=='3bd499c2ca61a72e2e7faac40572281227533f8bd669d70a2a33ed331d51bc57'
for name,record in json.loads(manifest.read_text())['files'].items():assert item(BASE/name)==record,name
launch=json.loads((BASE/'launch.json').read_text());report=json.loads((BASE/'evidence/report.json').read_text())
errors=strict_cell(launch,report,'qwen38-paged-off-b1');assert not errors,errors
post=json.loads((BASE/'ownership-after.json').read_text());assert not post['processes']
assert json.loads((BASE/'execution.json').read_text())['exit_code']==0
save(OUT/'assessment.json',{'strict_cell_errors':errors,'all_ten_go_cases_passed':True,'remote_go_and_launcher_exit_code':0,'original_controller_exit_code':1,'original_controller_failure':'Post-completion reused entry-readiness helper rejected GPU 47.0074 C >42 C. Raw failure and complete outputs preserved.','postflight':post,'source_manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'scope':'Separate evidence assessment only. Fresh entry readiness required before SSD; no cache-off rerun or original failure overwrite.'})
save(OUT/'manifest.json',{'files':{p.name:item(p) for p in sorted(OUT.iterdir()) if p.is_file()}})
print((OUT/'assessment.json').read_text())
