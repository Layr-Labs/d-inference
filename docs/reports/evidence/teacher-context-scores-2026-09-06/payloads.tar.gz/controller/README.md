# Activated execution6

Root approved activation, exclusive staging and all four sequential teacher cells under review `10eb7fcd0501423832ed6b5681e3117854f384e118bcf2f3d57e3807f04a9653`. The current `binding.json` is `peer_reviewed`, with SHA256 `a7eb36c38980ad771bef6e438040dc12879f26a246c58a297d68912acbab2bc0`. Use the updated `commands.json`. Only the binding review state and associated metadata changed from execution5; all execution, validation, inputs, configs, profile and runtime identities are unchanged. No additional approval round is required. Retain existing results and inspect exact controller receipts after observation loss; never relaunch on an uncertain outcome.

The following execution5 preparation notes are retained as historical context; their pending-approval statements describe the preserved predecessor, not this activated successor.

# Teacher-forced diagnostic controller — fixed 38b source cut

The runtime binding is complete and **awaits root's final binding review before staging**. No M5/SSH, model, GPU, build, dev, dispatch or publication operation occurred in this preparation. The current binding state deliberately remains `awaiting_peer_review`, which the unchanged controller refuses before probes, output creation or runtime launch.

The runtime source cut is parent `38b674d53267018df35338bc4acee176de45c853`, native `a834412931d7dadb8929b2b6b4f3365ccbc5e48b`, Swift `c06149b4f7defa1b958c1e175f6c9a12c86c8a4f`, core `fab0f39f69140393b454c32d6f4bf7a9b32f9dcc` and C `d4328f2d8d54d711d5419e07ab9fa2f07b512a48`. Later test-only pin cuts are excluded. The runtime came from `/tmp/darkbloom-teacher-combined-artifact1/artifact`; all eight actual file hashes/sizes/modes were checked against the reviewed manifest. No runtime bytes were copied or modified.

- Artifact manifest SHA256: `84e5b6d9df7345fa70ddd9b1558dcd9b389ed5a4263dd071eaf4640f31a763b4`.
- Root runtime-review SHA256: `38ad5afdf1ed1571440f0b447386793e9cbf8cd801c99fbdc3ead86ac947e314`.
- CLI SHA256: `e812330b54c144d652acdfd50024f34fac7dcf40f7606f254818132268d5a11e`.
- Radix SHA256: `d999d402fb5c99ab6bf0ddef684cbf8ed08e5b5daa770b37b7f146be16aa06ee`.
- Metallib SHA256: `1c8e612c9c54e8652669c582aad6124438c77f1dce2dc0b1eb50dce1bf083565`.
- Binding candidate SHA256: `6286259d156e6819f56ab939d3bd191016780a1162e4e1b43993b612ea3f2570`.

## Inputs and controls

The exact retained literal token arrays remain byte-identical: Qwen3.6 uses 5,523 prompt tokens plus 83 forced tokens; Gemma QAT4 uses 5,418 plus 61. Both explicit backends use the same input file for each model. `input-provenance.json` retains their source-report identities. Model IDs, aggregate hashes, selected model paths and the original TOML bytes are unchanged.

The four cells remain Qwen contiguous, Qwen paged, Gemma QAT4 contiguous, Gemma QAT4 paged. Every native teacher invocation runs the built-in plain, diagnostic and repeated-diagnostic passes. Existing checks require exact within-backend control agreement, three matching activity records, complete forced-token contexts, finite score bits and exactly continuation-count minus one decode forwards per pass. MTP, assistant weight accounting and both prefix-cache tiers remain excluded by the existing mode/environment/report guards; B1 and the production KV grant remain required.

All seven effective serving flags are unchanged and explicit in `effective-gemma-environment.json`. The original hardware/user/IP checks, <=42 C temperature, load1<=4, >20 GiB free disk, configuration identity, model snapshot/file-link integrity, runtime inventory and owned-process cleanup guards are byte-identical to execution4. `controller.py`, `validation.py`, ownership/readiness/runtime helpers and their operational predicates are unchanged.

`compare_contexts.py` revalidates all four complete cell receipts using the existing guards before describing backend argmax/record differences and forced-score/NLL deltas on those same contexts. Differences are observations, not a new tolerance, validity waiver, quality claim or performance result. It launches no model. A missing or invalid final-cell report refuses comparison.

## Preserved failure and new roots

The original Qwen contiguous PID 44303 failure remains `refused` with exit -5 in `/tmp/darkbloom-teacher-q36-crash-review1`; all 32 frozen payloads were verified unchanged. `prior-qwen-failure.json` records those identities. No previous result directory or completed cell is reused or retried.

Local package: `/tmp/darkbloom-teacher-forced-execution5`. Proposed fresh remote execution root: `/Users/gaj/autoresearch/radix-prefix-cache/090-teacher-forced-ordinary3-recurrent38b`. Proposed runtime root: `/Users/gaj/autoresearch/radix-prefix-cache/090-teacher-forced-ordinary3-recurrent38b/runtime`. Proposed remote manifest: `/Users/gaj/autoresearch/radix-prefix-cache/090-teacher-forced-ordinary3-recurrent38b/runtime-manifest.json`. These are declared new paths, not a claim that M5 has been probed or staged. Ampere/root retain the M5 lane while physical two-host work completes.

## Binding review and later staging

1. Root reviews this source/input delta, CPU receipts, actual runtime identities and the proposed remote paths. `binding-template.json` remains the intentionally unbound construction template; `binding.json` is the complete actual-runtime candidate.
2. After final root binding review and explicit M5 owner handoff, root may mark the exact binding `peer_reviewed`, then recompute its SHA and the package manifest/archive identities. This is the existing review gate, not a request for another user approval flow.
3. Create the proposed execution root exclusively; refuse an existing root. Stage the small controller package and separately copy the eight canonical runtime files plus the exact source manifest as `runtime-manifest.json`, preserving all bound modes. Verify archive/package and runtime identities before the first launch. Do not share or mutate runtime files owned by active two-host/model work.
4. Execute each of the four commands in `commands.json` once, in order, using the SHA of the reviewed binding. The recorded candidate commands currently refuse because the candidate is not approved. Each output directory must be new; failures stop the sequence and preserve evidence. Existing completed cells are never rerun.
5. Only after all four cells validate, run the recorded comparison command. Retain raw reports, control activities, source/runtime/input identities, differences and failure evidence separately from any eventual release gate decision.

`bind_runtime.py` performs only local artifact verification and candidate construction; it cannot approve or launch a run. `--check-plan` and the CPU tests can run without a runtime or host connection. The tests use only small synthetic files and owned Python children, never the actual CLI or models.
