from pathlib import Path
import hashlib,json
O=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,j):(O/n).write_text(json.dumps(j,indent=2)+'\n')
assert not (O/'manifest.json').exists()
assert json.loads((O/'execution.json').read_text())['exit_code']==0
assert all(r['exit_code']==r['expected']for r in json.loads((O/'smokes.json').read_text()))
assert json.loads((O/'measurement-execution.json').read_text())['exit_code']==0
assert json.loads((O/'measurement-summary.json').read_text())['allOutputAndFullHistoryDigestsEqual']
artifacts=json.loads((O/'artifact-manifest.json').read_text())['files']
for name,row in artifacts.items():
 p=O/'artifact'/name
 assert p.is_file()and not p.is_symlink()and p.stat().st_size==row['bytes']and sha(p)==row['sha256']and p.stat().st_mode&0o777==int(row['mode'],8),name
native=Path(json.loads((O/'integration.json').read_text())['validation'])
validation=native/'manifest.json'
for name,row in json.loads(validation.read_text())['files'].items():assert sha(native/name)==row['sha256']
dump('verdict.json',{'status':'PASS_SYNTHETIC_SEGMENT_METADATA_PROFILE','validation_manifest_sha256':sha(validation),'binary_sha256':artifacts['BenchSegmentedDecode']['sha256'],'smokes':len(json.loads((O/'smokes.json').read_text())),'measured_arms':6,'steps_per_arm':64,'resident_owners':10,'all_output_and_full_history_digests_equal':True,'production_math_or_flags_changed':False,'model_runs':False,'performance_scope':'Synthetic attention-only paired attribution with opt-in statistics, not full-model decode or pure GPU kernel duration. Local host and same process/order are explicit; no performance acceptance threshold.'})
files={str(p.relative_to(O)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(O.rglob('*'))if p.is_file()and p.relative_to(O).parts[0]!='artifact'and p.name!='manifest.json'}
dump('manifest.json',{'files':files,'runtime_artifact_manifest':'artifact-manifest.json','status':'PASS_SYNTHETIC_SEGMENT_METADATA_PROFILE'})
print(json.dumps({'manifest_sha256':sha(O/'manifest.json'),'payloads':len(files),'artifacts':len(artifacts)},indent=2))
