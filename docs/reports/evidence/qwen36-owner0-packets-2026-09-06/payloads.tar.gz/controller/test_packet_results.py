import copy
import hashlib
import json
from pathlib import Path
import shutil
import tempfile
import unittest
import sys

SOURCE = Path('/tmp/darkbloom-q36-attention-packet-plan1')
sys.path.insert(0, str(SOURCE/'runner'))
from attention_packet_fixtures import Fixture
from packet_results import inspect_packet, NAMES

class PacketBindingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.base = tempfile.TemporaryDirectory()
        cls.fixture = Fixture(Path(cls.base.name)/'native', q_dtype='bfloat16', kv_dtype='bfloat16',
                              output_dtype='bfloat16', heads=16, kv_heads=2, length=5585, dimension=256)
        for name, descriptor in cls.fixture.descriptors.items():
            (cls.fixture.root/descriptor['file']).rename(cls.fixture.root/NAMES[name])
            descriptor['file'] = NAMES[name]
        cls.fixture.save()

    @classmethod
    def tearDownClass(cls): cls.base.cleanup()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.local = Path(self.temp.name)
        self.fixture = copy.deepcopy(type(self).fixture)
        self.fixture.root = self.local/'report.attention-packet'
        shutil.copytree(type(self).fixture.root, self.fixture.root)
        self.fixture.root.chmod(0o700)
        self.plan = json.loads((SOURCE/'plan.json').read_text())
        self.cell = self.plan['cells'][3]
        self.fixture.document['identity'].update(modelID='fixture', artifactSHA256=self.plan['model_sha256'],
                                                inputSHA256=self.plan['actual_wrapper_input_sha256'])
        tokens = [0]*83; tokens[61:63] = [11346, 6829]
        self.report = {'model':'fixture', 'verified_model_hash':self.plan['model_sha256'],
                       'input_sha256':self.plan['actual_wrapper_input_sha256'], 'resolved_backend':'paged',
                       'rows':[{'token_ids':tokens}], 'logit_diagnostic':{'snapshot':{'records':[
                       {'phase':'chained_decode','seedToken':11346,'targetToken':6829}]}}}
        self.refresh()

    def tearDown(self): self.temp.cleanup()

    def refresh(self):
        self.fixture.save()
        owners = copy.deepcopy(self.fixture.snapshot)
        owners['expectedOwnerCount'] = 10
        owners['records'] = []
        for index in range(10):
            record = copy.deepcopy(self.fixture.record)
            record.update(storageLayerIndex=index,modelLayerIndex=3+4*index)
            owners['records'].append(record)
        self.report['attention_metadata'] = {'snapshot':owners}
        self.report['attention_packet'] = {
            'status':'captured','evaluation_status':'completed',
            'directory':self.plan['remote_root']+'/runs/'+self.cell['id']+'/report.attention-packet',
            'packet_sha256':hashlib.sha256((self.fixture.root/'packet.json').read_bytes()).hexdigest(),
            'tensor_payload_bytes':self.fixture.document['capture']['tensorPayloadBytes'],
            'reserved_bytes':self.plan['byte_budget']['conservativeFP32ReservationBytes'],
            'snapshot':copy.deepcopy(self.fixture.snapshot)}

    def inspect(self): return inspect_packet(self.local,self.cell,self.plan,self.report)
    def refused(self, text): self.assertTrue(any(text in s for s in self.inspect()[0]), self.inspect()[0])

    def test_full_q36_geometry_and_native_bf16_positive(self):
        errors, analysis = self.inspect(); self.assertEqual(errors,[])
        self.assertEqual(analysis['status'],'analyzed')
        self.assertEqual(self.report['attention_packet']['tensor_payload_bytes'],11456512)
        self.assertIsNone(analysis['narrowedQueryCounterfactual'])

    def test_actual_native_contiguous_binding(self):
        self.cell = self.plan['cells'][2]
        self.fixture.document['identity']['backend'] = self.report['resolved_backend'] = 'contiguous'
        self.fixture.record['dispatch'] = 'contiguous_sdpa'; self.refresh()
        self.assertEqual(self.inspect()[0],[])

    def test_report_hash_and_exported_snapshot_are_both_bound(self):
        self.report['attention_packet']['packet_sha256']='0'*64
        self.refused('report packet SHA')
        self.refresh(); self.report['attention_packet']['snapshot']['targetToken']=1
        self.refused('snapshots differ')

    def test_wrong_verified_model_or_actual_input_is_refused(self):
        self.fixture.document['identity']['artifactSHA256']='c'*64; self.refresh()
        self.refused('verified model hash')
        self.fixture.document['identity']['artifactSHA256']=self.plan['model_sha256']
        self.fixture.document['identity']['inputSHA256']='d'*64; self.refresh()
        self.refused('actual input hash')

    def test_wrong_owner_or_trajectory_target_is_refused(self):
        self.fixture.record['modelLayerIndex']=39; self.refresh(); self.refused('modelLayerIndex')
        self.fixture.record['modelLayerIndex']=3; self.fixture.snapshot['targetToken']=1
        self.refresh(); self.refused('seed/target')

    def test_discarded_or_failed_packet_is_inconclusive(self):
        self.fixture.snapshot['sampleOutcome']='discarded'; self.refresh(); self.refused('refused selected forward')
        self.fixture.snapshot['sampleOutcome']='confirmed'; self.fixture.snapshot['forwardSucceeded']=False
        self.refresh(); self.refused('refused selected forward')

    def test_extra_file_symlink_and_unprivate_directory_refuse(self):
        p=self.fixture.root/'unclaimed.bin'; p.write_bytes(b'no'); self.refused('inventory'); p.unlink()
        q=self.fixture.root/'queries.bin'; raw=q.read_bytes(); q.unlink(); outside=self.local/'outside.bin'
        outside.write_bytes(raw); q.symlink_to(outside); self.refused('not regular'); q.unlink(); q.write_bytes(raw)
        self.fixture.root.chmod(0o755); self.refused('private0700')

    def test_corrupt_raw_bytes_and_oversized_declared_budget_refuse(self):
        p=self.fixture.root/'queries.bin'; original=p.read_bytes(); p.write_bytes(bytes([original[0]^1])+original[1:])
        self.refused('packet evidence refused'); p.write_bytes(original)
        self.fixture.document['capture']['tensorPayloadBytes']=33554433
        (self.fixture.root/'packet.json').write_text(json.dumps(self.fixture.document))
        self.report['attention_packet']['packet_sha256']=hashlib.sha256((self.fixture.root/'packet.json').read_bytes()).hexdigest()
        self.refused('packet evidence refused')

    def test_selected_native_tail_mismatch_stays_inconclusive(self):
        p=self.fixture.root/'incoming-keys.bin'; raw=p.read_bytes(); altered=bytes([raw[0]^1])+raw[1:]
        p.write_bytes(altered); self.fixture.descriptors['incomingKeys']['sha256']=hashlib.sha256(altered).hexdigest()
        self.refresh(); self.refused('inconclusive')

    def test_all_owner_or_logit_context_mismatch_refuses(self):
        self.report['attention_metadata']['snapshot']['records'][0]['phase']='decode'
        self.refused('raw/all-owner'); self.refresh()
        self.report['logit_diagnostic']['snapshot']['records'][0]['phase']='decode'; self.refused('raw/logit')

    def test_cross_packet_native_mismatch_keeps_input_identity_separate(self):
        from compare_packets import compare_packet_bytes
        other=self.local/'other';shutil.copytree(self.fixture.root,other)
        same=compare_packet_bytes(other/'packet.json',self.fixture.root/'packet.json')
        self.assertTrue(same['captured_original_Q_stored_KV_bytes_equal'])
        p=self.fixture.root/'queries.bin';raw=p.read_bytes();altered=bytes([raw[0]^1])+raw[1:]
        p.write_bytes(altered);self.fixture.descriptors['queries']['sha256']=hashlib.sha256(altered).hexdigest();self.refresh()
        changed=compare_packet_bytes(other/'packet.json',self.fixture.root/'packet.json')
        self.assertFalse(changed['captured_original_Q_stored_KV_bytes_equal'])
        self.assertEqual(changed['tensors']['queries']['mismatched_native_elements'],1)
        self.assertEqual(changed['tensors']['queries']['first_mismatch_BHTD'],[[0,0,0,0]])
        self.assertFalse(changed['numerical_release_gate_evaluated'])

    def test_large_numeric_error_is_reported_without_invented_gate(self):
        import numpy as np
        raw = (np.full((1,16,1,256),100.0,dtype=np.float32).view(np.uint32)>>16).astype('<u2').tobytes()
        p=self.fixture.root/'output.bin'; p.write_bytes(raw)
        self.fixture.descriptors['output']['sha256']=hashlib.sha256(raw).hexdigest(); self.refresh()
        errors,analysis=self.inspect(); self.assertEqual(errors,[])
        self.assertGreater(analysis['originalQueryReference']['comparison']['global']['linf'],90)
        self.assertNotIn('passed',analysis)

if __name__ == '__main__': unittest.main()
