# Gemma normal-MTP initialization failure

A deterministic fixture-format defect blocks the local assistant before target binding: the directory passed as --assistant-directory contains config.json, model.safetensors, and manifest.json. The production local-artifact inspector accepts only config.json and *.safetensors, so manifest.json makes that directory invalid.

This is not evidence that the QAT assistant is incompatible with the 8-bit target. No model substitution, MTP disablement, guard relaxation, source edit, or GPU/build work was performed by this audit.

## Evidence and exact source path

The failed cell is /tmp/darkbloom-final-fleet-smoke2/results/gemma-4-26b-paged-cache-off-b1-smoke2. Its raw engine log records both exact target hash passes and generic mtpUnavailable; no requests ran. All original-manifest payload hashes were checked; selected raw artifacts are copied in raw/. The exact target aggregate is a4722b6020adb1894c700b45ddcd58bc0e0f033abe7139f86cbbbfe60cba4eb6. The binary recorded by the cell is 601bce0923cfb2e12410073fe193a08a9c73830b5afd74d7f72e2facb49be21c; this audit does not rebuild it.

A fresh read-only SSH inspection is retained with its script, argv, exit status, and stdout. It confirms that the original assistant directory is not a symlink and has exactly three nonempty regular files. Its config digest matches the existing handoff evidence. Target model_type is gemma4, accepted by EngineV2SupportedModels.swift:35-39; the inspection does not prove later loaded-object binding.

Source snapshots and hashes are in sources/ and source-manifest.json. All 11 snapshots match their current git HEAD:

1. EngineV2Factory+BenchmarkAssistant.swift:11-16 invokes the ordinary offline funnel with the supplied local directory and no downloads.
2. SpecDecArtifactFunnel.swift:179-199 accepts the target family, then calls SpecDecStore.inspectLocalArtifact for an explicit local override. A nil inspection produces localArtifactInvalid and never substitutes a catalog artifact.
3. SpecDecStore.swift:226-265 checks the directory and every entry. Lines 252-259 accept config.json or a safetensors suffix; every other name returns nil. The observed manifest.json therefore necessarily fails this predicate regardless of directory iteration order.
4. BenchmarkAssistant.swift:18-19 throws generic mtpUnavailable when the artifact is absent. That erases the useful fallback reason. The older report does not record which of its three generic MTP guards threw, so this audit establishes a deterministic necessary blocker rather than pretending to have captured an unrecorded typed runtime status.
5. Only after preparation succeeds does prepareProductionModel revalidate the artifact, load the assistant, and bind the target. ProductionProviderMTPAssistantLoader requires Gemma4TextModel, loads Gemma4AssistantDraftModel, then constructs Gemma4CBv2MTPDrafter. The latter invokes the model compatibility validator. These guards remain required and unproven for the corrected run.

The same config geometry shows target hidden size 2816, assistant backbone hidden size 2816, matching vocabulary 262144, and matching shared attention dimensions. Those observations do not prove weight loading or all compatibility checks; no conclusion is based solely on the model names or quantization labels.

## Authorized next action

Root accepted this cause and authorized fleet_smoke_continuation to create a NEW owned flat fixture containing only byte-identical config.json and model.safetensors. Preserve the original three-file fixture and manifest outside the new passed directory as provenance. Verify regular-file status, exact two-file membership, and hashes before retrying with fresh output/cache roots and all normal MTP/paged/grant settings unchanged.

Required config SHA-256: 0cd54ff36e53a258532c5c1433bc44b88ba758cfe9b59bb4e6eecfd5453fabcf (2961 bytes).
Required weight SHA-256: 3c4d43863abbbf455ec537c726eff7abeb88bb361e3ab23ff0d2d6006f620f74 (236124704 bytes).
Retained external manifest SHA-256: 8b7c00b7f131345156f5f20fa9c94a895c5340f16d9331bafb9e59628bf45bf2 (859 bytes).

The fleet agent was notified. This audit does not claim the corrected run has happened or passed. The old failed cell remains evidence, and the matching SSD arm requires the corrected normal-MTP load to succeed first.

## Connected bundle and diagnostic handoff

Both frozen connected Gemma inputs still point to the original three-file assistant directory. connected-bundle-handoff.json records exact input paths/hashes and the stale assistant_path. After the corrected standalone Gemma pair passes, prepare a NEW reviewed connected bundle revision pointing at the exact two-file fixture, retaining the assistant manifest outside the local override and updating input/package source hashes. Do not mutate the original frozen 1034-file package or its reports. Root owns this follow-up.

A separate future benchmark-only diagnostic improvement can preserve phase and MTPActivationStatus fallback fields at the three current generic MTP guards (funnel, prepared model, active engine). Default no-op logWarning currently also hides loader/bind detail. The idle-snapshot agent confirmed build5 already compiles a frozen harness delta with provider sources unchanged, so no late provider changes were inserted into that boundary. This diagnostic improvement is not needed to correct the identified fixture defect.
