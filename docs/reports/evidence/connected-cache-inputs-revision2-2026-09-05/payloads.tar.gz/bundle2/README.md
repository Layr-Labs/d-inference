# Connected M5 cache fixture, revision 2

Prepared locally for review; this revision has not been staged or run on M5. Its exact remote root is `/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http2`. The original revision and archive remain unchanged; their manifest, freeze record and historical README are retained in `previous-package/`.

This revision uses coordinator/e2e source from `089d9ade3398b7660b9c0745ea17a8f584d11f9f`. All 988 frozen source/resource files byte-match that banked commit and the before/after build manifests. Relative to revision 1, the only Go/source-resource changes are the three SSE reasoning-reader paths recorded in `go-source-diff.json`: the stream reader, focused tests, and raw replay fixture. The reader reconstructs identical reasoning aliases once, rejects conflicting aliases, and preserves both reasoning fields in the original captured frame. Original failed connected evidence remains failed.

The Go executable is `6e30a1e53cc26ac1bb7953216b6d0af835b8b08a29f1920b2df07999c0e2bc8f` (46,357,378 bytes). Build commands, dependency/test graph, Go environment, executable metadata, exact source hashes and bank proof are under `go-build-evidence/`. Its own helper run passed 12 functions and 18 subtests. Those results are carried from this exact executable; no second build was performed while packaging.

The CLI remains `a81fd9f9ff01fb84f3c236ceaba5fed4fca730b261be1f332b87c38e69cd3cfd`, bound metallib `4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0`, and Rust sidecar `6a0c4498c6a3d23f85001fe1d1e0b8a502e2397858a586808e792b66e85576ea`. The input catalog and artifact identities remain unchanged. These existing runtime files are referenced from `090-final-serving-smoke1/payload` and reverified before/after each owned run; they are not replaced by this package. The fixture copies CLI/resources into its owned evidence root to contain updater writes.

## Corrected assistant and regenerated inputs

Gemma now declares the verified two-file directory `090-final-serving-smoke1/payload/gemma-assistant-local-override1`. The ordinary production local-artifact inspector only accepts config.json and safetensors files; the old three-file directory additionally contained manifest.json and was refused before binding. The new launcher verifies the actual declared directory, exact flat membership, regular non-symlink files, byte sizes and hashes. It no longer verifies an unrelated original assistant directory as if it were the runtime override.

The same original assistant manifest is retained outside that directory, in the catalog input and source-input provenance. `assistant-provenance/` preserves the exact-copy proof, unchanged original source, preflight and post-pair hashes. Config SHA-256 is `0cd54ff36e53a258532c5c1433bc44b88ba758cfe9b59bb4e6eecfd5453fabcf`; weights SHA-256 is `3c4d43863abbbf455ec537c726eff7abeb88bb361e3ab23ff0d2d6006f620f74`. Normal digest revalidation, target compatibility and actual MTP-active checks still run in the provider.

All ten inputs and the plan were freshly regenerated. Gemma's assistant path and each applicable vision asset path changed; artifact identities, catalog, prompt, tools and runtime hashes did not. `inputs-diff.json` records every change. Five off/SSD pairs are identical except cache_mode. Each runs two provider processes and two authenticated API tenants on this single host with configured B1 and sequential cases. This does not establish independent-machine capacity/latency or B2/B4 throughput. Normal MTP remains on for all Qwens/Gemma and off for GPT.

All fifteen Python helper tests passed in this revision. Exact CPU-only planning with the pinned Rust sidecar also passed: Q36=5503, Q35=5503, Q38=5545, GPT=5454 and Gemma=5399 prompt tokens. The shared untruncated prompt has 35,273 characters, SHA-256 `10982a0c99a7e612803ee7b2c8fa62f9ebfcf3de9ae34c2dde25bf8831aee896`. These lengths establish eligible interior boundaries, not actual hits. Requests still must prove actual coordinator receipts, provider saved tokens and SSD read/stage outcomes.

The request-owned UTC date is **2026-09-05**. The generator captures current UTC; it does not change the clock. The launcher refuses any other date, and postflight checks actual request dates. If the date rolls over before execution, regenerate and review another paired bundle plus CPU plans; do not edit frozen inputs or force a production request date.

Tools retain ordinary `tool_choice:auto` with an explicit request for `record_color(color="blue", count=2)`; existing tests check the actual call and arguments. No named-tool enforcement is claimed. Vision uses the original cube-hero PNG only where the exact config declares vision and is required to remain cold. `source-gates.json` preserves the source/feature limitations. HTTP token IDs remain unavailable; raw SSE, content, reasoning, tools, counts and finish are retained. The fixed reader must be tested with real connected traffic; its unit replay is not a real-model pass.

## Sole-lane execution after root review

No staging or remote execution was performed in preparing this package. The fleet owner must receive root's review of the frozen revision before staging it. Extract archive contents into a newly created, absent `090-connected-http2` directory, then run `python3 verify_package.py` there. The archive contains paths relative to that directory. No remote Go, Rust or Swift compilation, PostgreSQL, Docker or production credentials are required. The fixture uses its in-memory test store/mock billing and fresh per-suite tokens/routing keys.

The launcher rechecks the existing canonical provider config hash, unentitled runtime, absent retired startup files, exact target discovery, current date and policy environment. It refuses inherited cache/MTP/MLX/memory policy overrides. Ephemeral cache testing sets both ALLOW_EPHEMERAL and a unique per-provider TEST_ROOT. Resident caching and persistent-key overrides remain absent. This is neither attestation nor persistent-restart proof.

The fleet owner must confirm an idle thermally suitable host and no foreign/ranked model job. Alias journals may already exist from previous connected attempts; inspect existing ownership before proceeding. The helper's `create` is only for absent Q35/Q36 model roots, never for replacing an existing alias or taking another journal's ownership. Existing exact Q38/GPT/Gemma discovery is verified by preflight. For a fresh absent root, the reviewed helper hashes the target, rechecks idle state, creates an exclusive journal/owner marker and a reversible snapshot symlink; it never edits target bytes.

```sh
cd /Users/gaj/autoresearch/radix-prefix-cache/090-connected-http2
mkdir alias-journals
python3 temporary_model_alias.py create --manifest manifests/qwen36.json --target /Users/gaj/autoresearch/radix-prefix-cache/qwen35b/models/qwen3.6-35b-a3b-vl-mtp-mxfp8/73a03825c2226177f3e679210965dba3508cdee8 --journal alias-journals/qwen36.json
python3 temporary_model_alias.py create --manifest manifests/qwen35.json --target /Users/gaj/autoresearch/radix-prefix-cache/qwen35b/models/qwen3.5-35b-a3b/8964653177a21be79662d51e69fe6a2263ffabb3 --journal alias-journals/qwen35.json
```

Run one reviewed model pair at a time. Each cell creates a fresh output/cache root and refuses reuse. The standalone preflight runs no model; `run` repeats it before executing the existing integration test and rehashes runtime/target/config after owned child retirement.

```sh
python3 run_connected_fixture.py preflight --cell qwen36-paged-off-b1
python3 run_connected_fixture.py run --cell qwen36-paged-off-b1
python3 run_connected_fixture.py run --cell qwen36-paged-ssd-b1
python3 compare_connected_cache_http.py runs/qwen36-paged-off-b1-run/evidence/report.json runs/qwen36-paged-ssd-b1-run/evidence/report.json --output runs/qwen36-paired-comparison.json
```

Replace qwen36 with qwen35, qwen38, gpt-oss-20b or gemma-4-26b for the remaining prepared pairs. A failure remains failed, and later unexecuted cells remain unrun. Retain raw reports, launch records and correlation evidence. The script drains only its fresh owned process group, including descendants after abnormal Go exit; it never globally kills by process name. Interruptions and timeouts cannot become passing cells. The helper cleanup regression tests cover unrelated-group survival.

After relevant requests and all owned children stop, retire only aliases owned by the corresponding exact journals. Cleanup verifies markers/symlinks/contents, refuses foreign changes, and uses unlink/rmdir without recursive deletion. Journals remain as evidence. Do not remove unrelated cache namespaces or installed configuration.

```sh
python3 temporary_model_alias.py cleanup --journal alias-journals/qwen36.json
python3 temporary_model_alias.py cleanup --journal alias-journals/qwen35.json
```

Prepared fixture checks do not resolve the normal Q35 adaptive parity failure, lifecycle admission gates, B2/B4 performance, independent-machine routing or restart durability. Those release gates remain separate. All ten connected cells in this new revision remain unrun at freeze.
