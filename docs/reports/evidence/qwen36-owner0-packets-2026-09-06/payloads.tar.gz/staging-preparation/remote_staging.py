CREATE='''from pathlib import Path
import datetime,shutil
root=Path(C['remote'])
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-09-06'
assert shutil.disk_usage(root.parent).free>100*(1<<30)
root.mkdir(exist_ok=False)
'''
EXTRACT='''from pathlib import Path
import hashlib,json,stat,tarfile
root=Path(C['remote'])
assert hashlib.sha256((root/'binding-root-review.json').read_bytes()).hexdigest()==C['review_sha']
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()==C['binding_sha']
archive=root/'plan-package.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==C['archive_sha']
with tarfile.open(archive) as tar:
 members=tar.getmembers()
 assert len(members)==30 and len({m.name for m in members})==30
 for member in members:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  assert not (root/member.name).exists()
 tar.extractall(root)
assert hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()==C['manifest_sha']
manifest=json.loads((root/'manifest.json').read_text())
for name,item in manifest['files'].items():
 p=root/name;assert stat.S_ISREG(p.lstat().st_mode) and p.stat().st_size==item['bytes']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],name
(root/'runtime').mkdir(exist_ok=False)
print(json.dumps({'verified_plan_files':len(manifest['files']),'remote_root':str(root),'manifest_sha256':C['manifest_sha'],'inference_launched':False},indent=2))
'''
RUNTIME='''from pathlib import Path
import hashlib,json,os,shutil,stat
root=Path(C['remote']);binding_path=root/'runtime-binding.json'
assert hashlib.sha256(binding_path.read_bytes()).hexdigest()==C['binding_sha']
binding=json.loads(binding_path.read_text());target=root/'runtime';source=Path(C['resources_copy_source'])
def verify(p,item):
 info=p.lstat();assert stat.S_ISREG(info.st_mode) and not p.is_symlink()
 assert info.st_size==item['bytes'] and stat.S_IMODE(info.st_mode)==int(item['mode'],8),str(p)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],str(p)
assert {p.name for p in target.iterdir()}=={'radix-engine'}
verify(target/'radix-engine',binding['artifacts']['radix-engine'])
for name,item in binding['artifacts'].items():
 if name!='radix-engine':verify(source/name,item)
for name,item in binding['artifacts'].items():
 if name!='radix-engine':
  destination=target/name;destination.parent.mkdir(parents=True,exist_ok=True)
  assert not destination.exists();shutil.copy2(source/name,destination)
for name,item in binding['artifacts'].items():verify(target/name,item)
assert {str(p.relative_to(target)) for p in target.rglob('*') if p.is_file()}==set(binding['artifacts'])
assert os.access(target/'radix-engine',os.X_OK)
result={'status':'RUNTIME_VERIFIED','binding_sha256':C['binding_sha'],'files':binding['artifacts'],'runtime_root':str(target),'inference_launched':False}
(root/'runtime-transfer-receipt.json').write_text(json.dumps(result,indent=2)+'\\n')
print(json.dumps(result,indent=2))
'''
