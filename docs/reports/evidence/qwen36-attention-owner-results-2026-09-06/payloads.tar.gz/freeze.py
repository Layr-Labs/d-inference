from pathlib import Path
import gzip,hashlib,io,json,shutil,tarfile

OUT=Path('/tmp/darkbloom-q36-attention-owner-identity-two-cell-freeze1')
OUT.mkdir(exist_ok=False)
PAYLOAD=OUT/'payloads';PAYLOAD.mkdir()
entries=[]

def put(name,path):
    assert path.is_file() and not path.is_symlink(),path
    data=path.read_bytes()
    assert path.suffix in ('.json','.jsonl','.py','.md','.log','.stdout','.stderr','.txt'),path
    data.decode()
    dest=PAYLOAD/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    entries.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'original_path':str(path)})

def directory(group,root,manifest_name='manifest.json'):
    manifest=json.loads((root/manifest_name).read_text())
    rows=manifest['files']
    if isinstance(rows,list):rows={r['path']:r for r in rows}
    for name,row in rows.items():
        p=root/name
        assert p.stat().st_size==row['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==row['sha256'],p
        if 'mode' in row:assert p.stat().st_mode&0o777==int(row['mode'],8),p
        # Transfer package is duplicate plan bytes; preserve its inventory/receipt/hash,
        # without nesting a second archive inside this one.
        if name.endswith('.tar.gz'):continue
        put(group+'/'+name,p)
    put(group+'/'+manifest_name,root/manifest_name)

directory('corrected-plan',Path('/tmp/darkbloom-q36-attention-owner-identity-plan1'))
for group,suffix in [('staging','staging1'),('runtime-transfer','runtime-transfer1'),('remote-helper-tests','helper-validation1')]:
    directory(group,Path('/tmp/darkbloom-q36-attention-owner-identity-'+suffix))
new=Path('/tmp/darkbloom-q36-attention-owner-identity-execution1')
directory('corrected-execution-preparation',new,'preparation-manifest.json')
for p in sorted(new.iterdir()):
    if p.is_dir():directory('corrected-two-cell/'+p.name,p)
for name in ('compare_completed.py','two-cell-comparison.json','qwen36-contiguous-cache-off-mtp-off-trace-off-live-owned1.json'):
    put('corrected-two-cell/'+name,new/name)
for name in ('runtime-binding1.json','root-release-review.json','final-postflight1.json'):
    put('corrected-context/'+name,Path('/tmp/darkbloom-q36-attention-owner-identity-'+name))

old=Path('/tmp/darkbloom-q36-attention-metadata-execution1')
for p in sorted(old.iterdir()):
    if p.is_dir():directory('original-four-cell/'+p.name,p)
    elif p.is_file():put('original-four-cell/'+p.name,p)
for name in ('runtime-binding1.json','root-trace-review1.json','root-paged-trace-review1.json','four-cell1-postflight.json'):
    put('original-context/'+name,Path('/tmp/darkbloom-q36-attention-metadata-'+name))
put('freeze.py',Path(__file__))
assert len({r['path'] for r in entries})==len(entries)
archive=OUT/'payloads.tar.gz'
with archive.open('wb') as f:
    with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for row in sorted(entries,key=lambda r:r['path']):
                data=(PAYLOAD/row['path']).read_bytes();item=tarfile.TarInfo(row['path'])
                item.size=len(data);item.mode=0o644;item.mtime=0
                tar.addfile(item,io.BytesIO(data))
manifest={'status':'CORRECTED_TWO_CELL_METADATA_PASS_ORIGINAL_FOUR_CELL_FAILURE_RETAINED',
          'scope':'Two same-build corrected contiguous trace controls. Original paged and incomplete contiguous evidence remains a separate earlier-build four-cell group. No numerical or performance acceptance.',
          'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},
          'payload_count':len(entries),'payload_bytes':sum(r['bytes'] for r in entries),
          'files':sorted(entries,key=lambda r:r['path']),
          'excluded':'No binary, metallib, weight, key or cache payload. Runtime artifact identity only; staging archive preserved by hash and expanded source files.'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'payload_count':len(entries),'manifest_sha256':hashlib.sha256((OUT/'manifest.json').read_bytes()).hexdigest(),'archive':manifest['archive']},indent=2))
