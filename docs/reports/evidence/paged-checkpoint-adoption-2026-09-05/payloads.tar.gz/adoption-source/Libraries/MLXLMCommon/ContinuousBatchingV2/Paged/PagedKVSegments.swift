import Foundation
import MLX

/// Stable address ranges, independent of a pool's current byte grant. Retired
/// ranges are reused by size class; live pages never move when the grant grows.
struct PagedKVSegmentLayout: Sendable {
    static let defaultTargetBytes = 64 << 20

    let pageBytes: Int
    let maximumUsablePages: Int
    let maximumAddressPages: Int
    private(set) var ranges: [Range<Int>] = []
    private var segmentForPage: [Int32] = []

    init(pageBytes: Int, targetBytes: Int, maximumBufferBytes: Int,
         maximumAddressPages: Int = Int(Int32.max)) throws {
        guard pageBytes > 0, targetBytes > 0, maximumBufferBytes > 0,
              maximumAddressPages >= 2, maximumAddressPages <= Int(Int32.max) else {
            throw CBv2KVError.backendIneligible(reason: "invalid paged segment geometry")
        }
        let physical = min(targetBytes, maximumBufferBytes) / pageBytes
        guard physical >= 2 else {
            throw CBv2KVError.backendIneligible(
                reason: "paged segment must fit a poison page and a usable page")
        }
        self.pageBytes = pageBytes
        self.maximumAddressPages = maximumAddressPages
        self.maximumUsablePages = Self.sizeClass(atMost: physical - 1)
    }

    /// Eager geometry used by diagnostics. Runtime pools start empty instead.
    init(pageCount: Int, pageBytes: Int, targetBytes: Int, maximumBufferBytes: Int) throws {
        try self.init(pageBytes: pageBytes, targetBytes: targetBytes,
                      maximumBufferBytes: maximumBufferBytes)
        guard pageCount >= 2 else {
            throw CBv2KVError.backendIneligible(reason: "invalid paged segment page count")
        }
        var remaining = pageCount
        while remaining >= 2 {
            let usable = Self.sizeClass(atMost: min(maximumUsablePages, remaining - 1))
            try appendRange(usablePages: usable)
            remaining -= usable + 1
        }
    }

    var pageCount: Int { segmentForPage.count }
    var segmentCount: Int { ranges.count }
    var usablePageCount: Int { pageCount - segmentCount }
    var physicalBytes: Int { pageCount * pageBytes }

    /// Exact eager capacity arithmetic without building a grant-sized map.
    func usablePages(fittingPhysicalPages pages: Int) -> Int {
        guard pages >= 2 else { return 0 }
        let whole = pages / (maximumUsablePages + 1)
        var usable = whole * maximumUsablePages
        var remainder = pages % (maximumUsablePages + 1)
        while remainder >= 2 {
            let count = Self.sizeClass(atMost: remainder - 1)
            usable += count
            remainder -= count + 1
        }
        return usable
    }

    /// Exact bytes for a new batch of size-class segments, without building a
    /// page-address map. Each full class and each binary remainder class owns
    /// one poison page. Used by submit/deadline probes before any allocation.
    func physicalBytes(addingUsablePages usable: Int) -> Int? {
        guard usable >= 0 else { return nil }
        let segments = usable / maximumUsablePages
            + (usable % maximumUsablePages).nonzeroBitCount
        let (pages, pageOverflow) = usable.addingReportingOverflow(segments)
        let (bytes, byteOverflow) = pages.multipliedReportingOverflow(by: pageBytes)
        guard !pageOverflow, !byteOverflow, pages <= maximumAddressPages else { return nil }
        return bytes
    }

    func range(_ index: Int) -> Range<Int> { ranges[index] }
    func segmentIndex(page: Int32) -> Int {
        precondition(page >= 0 && Int(page) < pageCount)
        return Int(segmentForPage[Int(page)])
    }
    func localPage(_ page: Int32) -> Int {
        Int(page) - ranges[segmentIndex(page: page)].lowerBound
    }
    func isUsable(_ page: Int32) -> Bool {
        page >= 0 && Int(page) < pageCount && localPage(page) != 0
    }

    /// Prepare exact additional usable demand without mutating the live map.
    /// Reusing the same size class bounds historical address growth by peak
    /// concurrent demand per class, rather than the number of requests served.
    func adding(usablePages: Int, excluding committed: Set<Int>) throws
        -> (layout: PagedKVSegmentLayout, segmentIDs: [Int])
    {
        precondition(usablePages >= 0)
        var result = self
        var reusable: [Int: [Int]] = [:]
        for index in ranges.indices.reversed() where !committed.contains(index) {
            reusable[ranges[index].count - 1, default: []].append(index)
        }
        var needed = usablePages
        var selected: [Int] = []
        while needed > 0 {
            let usable = Self.sizeClass(atMost: min(maximumUsablePages, needed))
            let index: Int
            if let available = reusable[usable]?.popLast() {
                index = available
            } else {
                index = result.segmentCount
                try result.appendRange(usablePages: usable)
            }
            selected.append(index)
            needed -= usable
        }
        return (result, selected)
    }

    private mutating func appendRange(usablePages: Int) throws {
        let (count, overflow) = pageCount.addingReportingOverflow(usablePages + 1)
        let (_, byteOverflow) = count.multipliedReportingOverflow(by: pageBytes)
        guard !overflow, !byteOverflow, count <= maximumAddressPages else {
            throw CBv2KVError.backendIneligible(reason: "paged range exceeds checked page-ID limit")
        }
        let start = pageCount
        let index = Int32(ranges.count)
        segmentForPage.append(contentsOf: repeatElement(index, count: usablePages + 1))
        ranges.append(start ..< count)
    }

    private static func sizeClass(atMost value: Int) -> Int {
        precondition(value > 0)
        return 1 << (Int.bitWidth - 1 - value.leadingZeroBitCount)
    }
}

/// One stable, evaluated native buffer. The first local page in both regions
/// is poison. Kernels receive this array as an input and order in-place writes
/// with the owning group's fence; they never create a second writable alias.
final class PagedKVSegment {
    let index: Int
    let pages: Range<Int>
    let storage: MLXArray
    let valueOffset: Int
    let byteCount: Int

    /// Ownership metadata changes; native storage and byte offsets do not.
    /// Both ranges use the same size class, so this creates no KV copy.
    init(rebasing source: PagedKVSegment, index: Int, layout: PagedKVSegmentLayout) {
        precondition(source.pages.count == layout.range(index).count)
        self.index = index
        self.pages = layout.range(index)
        self.storage = source.storage
        self.valueOffset = source.valueOffset
        self.byteCount = source.byteCount
    }

    init(index: Int, layout: PagedKVSegmentLayout, key: PagedKVGroupKey,
         pageSize: Int, dtype: DType, evaluate: (MLXArray) throws -> Void) throws {
        self.index = index
        let pages = layout.range(index)
        self.pages = pages
        self.valueOffset = pages.count * key.kvHeads * pageSize * key.headDim
        self.byteCount = pages.count * layout.pageBytes
        self.storage = try withError {
            let array = MLXArray.zeros(
                [2, pages.count, key.kvHeads, pageSize, key.headDim], dtype: dtype)
            try evaluate(array)
            return array
        }
    }
}
