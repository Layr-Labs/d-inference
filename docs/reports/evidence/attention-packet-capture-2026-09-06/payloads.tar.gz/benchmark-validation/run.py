from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time
out=Path(__file__).resolve().parent;native_validation=Path('/tmp/darkbloom-attention-packet-native-validation1')
info=json.loads((out/'integration.json').read_text());ws=Path(info['workspace']);scratch=Path(info['scratch']);package=out/'radix-engine'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy();env.update(info['environment'])
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
native_status=json.loads((native_validation/'run-status.json').read_text())
assert native_status=={'failed':[],'all_filters_run':True},native_status
for row in json.loads((native_validation/'execution.json').read_text()):assert row['exit_code']==0 and row['nonzero_no_skips'],row['name']
for name in ['native-source-manifest.json','dependency-source-manifest.json','jinja-source-manifest.json']:
 assert sha(native_validation/name)==sha(out/name),name
shutil.copy2(native_validation/'run-status.json',out/'native-run-status.json')
shutil.copy2(native_validation/'execution.json',out/'native-execution.json')
def verify():
 harness=json.loads((out/'harness-source-manifest.json').read_text())
 for name,digest in harness['files'].items():assert sha(out/name)==digest,name
 provider=json.loads((out/'provider-source-manifest.json').read_text())
 for name,digest in provider['files'].items():assert sha(ws/name)==digest,name
 native=json.loads((out/'native-source-manifest.json').read_text())
 for name,digest in native['files'].items():assert sha(ws/'libs/mlx-swift-lm'/name)==digest,name
 deps=json.loads((out/'dependency-source-manifest.json').read_text())
 for key,digest in deps['files'].items():
  alias,name=key.split('/',1);assert sha(Path(deps['repositories'][alias])/name)==digest,key
 jinja=json.loads((out/'jinja-source-manifest.json').read_text())
 for name,digest in jinja['files'].items():assert sha(scratch/'checkouts/swift-jinja'/name)==digest,name
 return {'harness':len(harness['files']),'provider':len(provider['files']),'native':len(native['files']),'dependency':len(deps['files']),'jinja':len(jinja['files']),'no_drift':True}
def graph(label):
 for name in ['debug.yaml','workspace-state.json']:
  path=scratch/name
  if path.exists():(out/(label+'-'+name+('.gz' if name.endswith('yaml') else ''))).write_bytes(gzip.compress(path.read_bytes(),mtime=0) if name.endswith('yaml') else path.read_bytes())
results=[]
def run(name,command,test=False):
 started=time.monotonic()
 with (out/(name+'.log')).open('x') as log:p=subprocess.run(command,cwd=package,env=env,stdout=log,stderr=subprocess.STDOUT)
 body=(out/(name+'.log')).read_text();nonzero=bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test',body));skips=bool(re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',body,re.M))
 row={'name':name,'command':command,'cwd':str(package),'exit_code':p.returncode,'seconds':time.monotonic()-started,'nonzero_no_skips':not test or nonzero and not skips};results.append(row);write('execution.json',results);print(json.dumps(row),flush=True)
 if not test and p.returncode:
  graph('failed-build');write('source-verified-after-failure.json',verify());raise SystemExit(p.returncode)
write('source-verified-before.json',verify());write('compile-environment.json',info['environment']);graph('before')
run('build',['swift','build','--scratch-path',str(scratch),'--build-tests','--jobs','4','--disable-automatic-resolution']);graph('actual-build');write('source-verified-postcompile.json',verify())
body=(scratch/'debug.yaml').read_text();paths=sorted(set(re.findall(r'"(/[^"\n]+)"',body)));proof=[]
changed=json.loads((out/'native-source-manifest.json').read_text())['candidate_changes']
owned=[ws/'libs/mlx-swift-lm'/name for name in changed if name.startswith('Libraries/')]
harness=json.loads((out/'harness-source-manifest.json').read_text())
owned += [out/name.removeprefix('scripts/benchmarks/') for name in harness['parent_candidate_changes'] if name.endswith('.swift')]
for path in owned:
 actual=next((p for p in paths if p.endswith('/'+path.name) and Path(p).resolve()==path.resolve()),None);assert actual,str(path);proof.append({'actual_path':actual,'resolved_path':str(path.resolve()),'sha256':sha(path)})
assert '/checkouts/mlx-swift/Source/' not in body
write('actual-compiler-source-proof.json',{'paths':proof,'remote_mlx_source_excluded':True,'scope':'Declared build graph source references; this does not assert every graph path is linked into the selected test product.'})
debug=scratch/'arm64-apple-macosx/debug';bundle=debug/'RadixEngineBenchmarkPackageTests.xctest/Contents/MacOS';binary=bundle/'RadixEngineBenchmarkPackageTests'
lib=Path('/tmp/darkbloom-final-serving-build8/artifact/mlx.metallib');assert sha(lib)=='4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0'
for target in [debug/'mlx.metallib',bundle/'mlx.metallib']:shutil.copy2(lib,target);assert sha(target)==sha(lib)
write('test-binary.json',{'path':str(binary),'sha256':sha(binary),'bytes':binary.stat().st_size,'metallib_sha256':sha(lib)})
run('identifiers',['swift','test','list','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution'])
filters=json.loads((out/'filters.json').read_text())
for name in filters:run(name,['swift','test','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution','--filter',name],test=True)
graph('actual-after');write('source-verified-after.json',verify());assert sha(binary)==json.loads((out/'test-binary.json').read_text())['sha256']
failed=[row['name'] for row in results if row['exit_code'] or not row['nonzero_no_skips']]
write('run-status.json',{'failed':failed,'all_filters_run':len(results)==len(filters)+2});print('FAILED FILTERS='+str(failed),flush=True);raise SystemExit(bool(failed))
