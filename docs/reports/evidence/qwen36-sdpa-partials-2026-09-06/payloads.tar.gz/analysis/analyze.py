from pathlib import Path
import hashlib,json,struct,sys
import numpy as np

ROOT=Path(__file__).resolve().parent
CANDIDATE=Path('/private/tmp/darkbloom-qwen-sdpa-partials1')
sys.path.insert(0,str(CANDIDATE))
import inspect_pair
sys.path.insert(0,'/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated/scripts/benchmarks')
from attention_packet.native import decode,rounded
from attention_packet.reference import attention,statistics

document=json.loads((CANDIDATE/'input/input.json').read_text())
assert hashlib.sha256((CANDIDATE/'input/input.json').read_bytes()).hexdigest()==inspect_pair.INPUT_SHA256
arrays={}
for name in ['queries','storedKeys','storedValues']:
 descriptor=document['tensors'][name];raw=(CANDIDATE/'input'/descriptor['file']).read_bytes()
 assert hashlib.sha256(raw).hexdigest()==descriptor['sha256']
 arrays[name]=decode(raw,descriptor['dtype'],descriptor['shape'])
values={};traces={};raw_values={}
for arm in ['baseline','variant']:
 step=ROOT/'raw/runs'/arm
 traces[arm],raw_values[arm]=inspect_pair.read_arm(step/'output',step/'stderr',arm=='variant',0)
 values[arm]=decode(raw_values[arm],'bfloat16',[1,16,1,256])
captures={name:(CANDIDATE/'captures'/(name+'.bin')).read_bytes() for name in ['contiguous','paged']}
pair=inspect_pair.compare(traces['baseline'],raw_values['baseline'],traces['variant'],raw_values['variant'],captures)
values['paged_capture']=decode(captures['paged'],'bfloat16',[1,16,1,256])
scale=struct.unpack('<f',struct.pack('<I',document['scaleBits']))[0]
reference,stages=attention(arrays['queries'],arrays['storedKeys'],arrays['storedValues'],scale)
assert all(not any(row[kind].values()) for row in stages for kind in ['logits','weights'])
comparison={name:{'fp32_reference':statistics(value,reference),
                  'fp32_rounded_bf16':statistics(value,rounded(reference,'bfloat16'))} for name,value in values.items()}
different=np.flatnonzero(np.frombuffer(raw_values['variant'],dtype='<u2')!=np.frombuffer(captures['paged'],dtype='<u2')).tolist()
details=[]
for index in different:
 details.append({'flat_index':index,'query_head':index//256,'channel':index%256,
  'variant':float(values['variant'].reshape(-1)[index]),'paged_capture':float(values['paged_capture'].reshape(-1)[index]),
  'baseline':float(values['baseline'].reshape(-1)[index]),'fp32_reference':float(reference.reshape(-1)[index])})
result={'pair':pair,'numpy_version':np.__version__,'interpreter':sys.executable,
 'reference_source_sha256':hashlib.sha256(Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated/scripts/benchmarks/attention_packet/reference.py').read_bytes()).hexdigest(),
 'comparison':comparison,'remaining_variant_vs_paged':details,
 'scope':'One actual sealed Q36 B1/D256 operator; no whole-model/token/quality/performance acceptance'}
with (ROOT/'analysis.json').open('x') as output:json.dump(result,output,indent=2,sort_keys=True,allow_nan=False);output.write('\n')
print(json.dumps({'pair':pair,'errors':{name:{key:{metric:data[metric] for metric in ['linf','rmse']} for key,data in item.items()} for name,item in comparison.items()},'remaining':details},indent=2))
