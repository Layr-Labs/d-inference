import Foundation

/// An explicitly owned key hierarchy for standalone persistent-cache tests.
/// This selects names; the executable still needs real Keychain authorization.
/// It does not change ProviderLoop's separate attestation identity.
@_spi(Benchmarking)
public struct SSDPersistentTestKeyNamespace: Sendable, Equatable {
    public let identifier: UUID
    public let accessGroup: String

    public enum Failure: Error, Equatable, Sendable {
        case invalidAccessGroup
        case persistentModeRequired
        case isolatedRootRequired
        case unsafeIsolatedRoot
    }

    public init(identifier: UUID, accessGroup: String) throws {
        let components = accessGroup.split(separator: ".", omittingEmptySubsequences: false)
        guard accessGroup.utf8.count <= 255, components.count >= 2,
            components.allSatisfy({ !$0.isEmpty }),
            accessGroup.utf8.allSatisfy({
                (48...57).contains($0) || (65...90).contains($0)
                    || (97...122).contains($0) || $0 == 45 || $0 == 46
            })
        else { throw Failure.invalidAccessGroup }
        self.identifier = identifier
        self.accessGroup = accessGroup
    }

    private var stem: String { "io.darkbloom.test.ssd.\(identifier.uuidString.lowercased())" }

    public var enclaveLabel: String { "\(stem).enclave" }
    public var wrappedKEKService: String { "\(stem).kek" }
    public var wrappedKEKAccount: String { "cache-\(identifier.uuidString.lowercased())" }

    /// Call before root creation and again immediately before key loading.
    /// The existing ALLOW_EPHEMERAL flag opts into TEST_ROOT, but this mode
    /// never permits an ephemeral fallback.
    public func validate(environment: [String: String], requirePersistentKey: Bool = true) throws {
        guard requirePersistentKey,
            environment["DARKBLOOM_PREFIX_CACHE_TEST_PERSISTENT_KEY"] == "1"
        else { throw Failure.persistentModeRequired }
        guard SSDPrefixCacheFactory.ephemeralAllowed(environment: environment),
            let rawRoot = environment[SSDPrefixCacheFactory.testRootEnvironmentKey]?
                .trimmingCharacters(in: .whitespacesAndNewlines),
            !rawRoot.isEmpty
        else { throw Failure.isolatedRootRequired }
        guard rawRoot.hasPrefix("/"), !rawRoot.utf8.contains(0) else {
            throw Failure.unsafeIsolatedRoot
        }
        let root = URL(fileURLWithPath: rawRoot, isDirectory: true)
            .standardizedFileURL.resolvingSymlinksInPath().path.lowercased()
        let normal = SSDPrefixCacheFactory.cacheRootDirectory(environment: [:])
        let legacy = normal.deletingLastPathComponent().appendingPathComponent("kv", isDirectory: true)
        guard root != "/", [normal, legacy].allSatisfy({ protected in
            // Conservatively reject spelling aliases on case-insensitive volumes.
            let path = protected.standardizedFileURL.resolvingSymlinksInPath().path.lowercased()
            return root != path && !root.hasPrefix(path + "/") && !path.hasPrefix(root + "/")
        }) else { throw Failure.unsafeIsolatedRoot }
    }
}
