from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys
import time

SOURCE = Path('/tmp/darkbloom-q36-attention-metadata-plan1')
OUT = Path('/tmp/darkbloom-q36-attention-metadata-execution1')
BINDING = Path('/tmp/darkbloom-q36-attention-metadata-runtime-binding1.json')
OPTIONS = ['-i', '/Users/gaj/.ssh/darkbloom_testbox', '-o', 'IdentitiesOnly=yes',
           '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15']
HOST = 'gaj@100.124.35.99'
SSH = ['ssh'] + OPTIONS + [HOST]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def remote(local, name, code):
    result = subprocess.run(SSH + ['python3 -B -'], input=code, text=True, capture_output=True)
    (local / (name + '.stdout')).write_text(result.stdout)
    (local / (name + '.stderr')).write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)


def main():
    sys.dont_write_bytecode = True
    assert sha(SOURCE / 'manifest.json') == '5b8d5c6d665ce10bd3664ccc5eb14892285bf24e5cc9c028d67d146d35104d77'
    assert sha(BINDING) == 'b5aa04cbfd4c6acfd6dec4c38b722f95dc6b9bb2de1e9d3720ff133868a656af'
    plan = json.loads((SOURCE / 'plan.json').read_text())
    binding = json.loads(BINDING.read_text())
    assert sha(Path(binding['review'])) == binding['review_sha256']
    chosen = next(cell for cell in plan['cells'] if cell['id'] == sys.argv[1])
    command = chosen['argv']
    local = OUT / chosen['id']
    local.mkdir(exist_ok=False)
    (local / 'command.json').write_text(json.dumps(chosen, indent=2) + '\n')
    check = subprocess.run(['python3', '-B', '/tmp/darkbloom-fleet-smoke-continuation/preflight.py',
                            str(local / 'ownership-before.json')], text=True, capture_output=True)
    (local / 'ownership-before.log').write_text(check.stdout + check.stderr)
    assert check.returncode == 0, check.stdout + check.stderr
    output = command[command.index('--output') + 1]
    code = '''from pathlib import Path
import datetime,hashlib,json,shutil
root=Path(ROOT);assert not Path(OUTPUT).exists()
date=datetime.datetime.now(datetime.timezone.utc).date().isoformat();assert date=='2026-09-06'
assert hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()=='5b8d5c6d665ce10bd3664ccc5eb14892285bf24e5cc9c028d67d146d35104d77'
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()=='b5aa04cbfd4c6acfd6dec4c38b722f95dc6b9bb2de1e9d3720ff133868a656af'
binding=json.loads((root/'runtime-binding.json').read_text())
assert hashlib.sha256((root/'runtime-root-review.json').read_bytes()).hexdigest()==binding['review_sha256']
inventory=json.loads((root/'manifest.json').read_text())['files']
for name,item in inventory.items():
 p=root/name;assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
runtime={}
for name,item in binding['artifacts'].items():
 p=root/'runtime'/name;assert p.stat().st_size==item['bytes'] and p.stat().st_mode&0o777==int(item['mode'],8)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'];runtime[name]=item
plan=json.loads((root/'plan.json').read_text());selected=next(c for c in plan['cells'] if c['id']==CELL)
assert selected['argv']==ARGV
free=shutil.disk_usage(root).free;assert free>plan['execution_guards']['min_free_bytes']
print(json.dumps({'utc_date':date,'free_bytes':free,'runtime':runtime,'cell':CELL,'fresh_output_root':True},indent=2))
'''.replace('ROOT', repr(plan['remote_root'])).replace('OUTPUT', repr(output)).replace('CELL', repr(chosen['id'])).replace('ARGV', repr(command))
    remote(local, 'runtime-precheck', code)
    started = time.monotonic()
    with (local / 'ssh-run.log').open('x') as log:
        run = subprocess.run(SSH + [shlex.join(command)], stdout=log, stderr=subprocess.STDOUT)
    (local / 'execution.json').write_text(json.dumps({'exit_code':run.returncode,'seconds':time.monotonic()-started,'scope':plan['scope']},indent=2)+'\n')
    inventory = remote(local, 'remote-inventory', '''from pathlib import Path
import hashlib,json
root=Path(OUTPUT);files={}
if root.exists():
 for p in sorted(root.iterdir()):
  if p.is_file() and not p.is_symlink():files[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'root':str(root),'files':files},indent=2))
'''.replace('OUTPUT', repr(output)))
    for name, item in inventory['files'].items():
        assert name and all(c.isalnum() or c in '.-_' for c in name)
        result = subprocess.run(['scp'] + OPTIONS + [HOST + ':' + output + '/' + name,str(local/name)],text=True,capture_output=True)
        assert result.returncode == 0, result.stderr
        assert (local/name).stat().st_size == item['bytes'] and sha(local/name) == item['sha256']
    summary = {'cell':chosen['id'],'exit_code':run.returncode,'trace':chosen['trace'],
               'scope':'Diagnostic only; no performance or numerical acceptance waiver'}
    errors = []
    if (local/'report.json').exists():
        sys.path.insert(0,str(SOURCE/'runner'))
        from radix_engine_evidence import report_errors
        report=json.loads((local/'report.json').read_text())
        errors=report_errors(report)
        metadata=report.get('attention_metadata')
        if chosen['trace']:
            if not isinstance(metadata,dict) or metadata.get('status')!='captured':
                errors.append('selected metadata forward was not captured')
        elif metadata is not None:
            errors.append('uninstrumented control unexpectedly emitted attention metadata')
        summary.update(report_integrity_passed=not errors,errors=errors,
                       attention_metadata_status=(metadata or {}).get('status'),
                       logit_diagnostic_status=(report.get('logit_diagnostic') or {}).get('status'))
    else:
        errors=['report missing'];summary['errors']=errors
    (local/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    files={str(p.relative_to(local)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(local.rglob('*')) if p.is_file()}
    (local/'manifest.json').write_text(json.dumps({'scope':summary['scope'],'files':files},indent=2,sort_keys=True)+'\n')
    print(json.dumps({**summary,'manifest_sha256':sha(local/'manifest.json')},indent=2),flush=True)
    raise SystemExit(run.returncode or (1 if errors else 0))


if __name__ == '__main__':
    main()
