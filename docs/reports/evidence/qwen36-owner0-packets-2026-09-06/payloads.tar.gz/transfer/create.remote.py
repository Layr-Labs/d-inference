import json
C=json.loads('{"remote": "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1", "archive_sha": "f9824eba3447507da1670a7ca9c8c4243b14f25dbb789cbdb4fe8bd19cc4ac16", "manifest_sha": "21467d42b7e710d8303cb2690f79edb16d793241b919fa303d6acea888660fce", "review_sha": "bcef01db59932780e017de10bc6e3ed132f1a80fe6dbc6fd89659ef50cfce4cd", "binding_sha": "48cea7e3daa6fb0676ccc069891eb93170885d7ae85dc6540a155d4454df2cdc", "resources_copy_source": "/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact"}')
from pathlib import Path
import datetime,shutil
root=Path(C['remote'])
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-09-06'
assert shutil.disk_usage(root.parent).free>100*(1<<30)
root.mkdir(exist_ok=False)
