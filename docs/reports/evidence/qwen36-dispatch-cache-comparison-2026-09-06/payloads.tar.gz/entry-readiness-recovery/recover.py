from pathlib import Path
import hashlib,json,shutil,subprocess
ROOT=Path(__file__).resolve().parent
OLD=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-execution1/qwen36-paged-mtp-off-candidate-rep3')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
expected={'command.json','expected-native-command.json','ownership-before.json','ownership-before.log'}
assert {p.name for p in OLD.iterdir()}==expected
original=json.loads((OLD/'ownership-before.json').read_text());assert original['processes']==[] and original['gpu_temp_c']>42
assert 'Entry temperature above 42 C'in(OLD/'ownership-before.log').read_text()
fresh=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-cooled-readiness1.json');f=json.loads(fresh.read_text())
assert not f['processes'] and f['gpu_temp_c']<=42 and f['load'][0]<=4 and f['free_disk_bytes']>100*1024**3
code="from pathlib import Path\nimport json\np=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-q36-paged-plan-cache-comparison1/runs/qwen36-paged-mtp-off-candidate-rep3')\nassert not p.exists()\nprint(json.dumps({'remote_output_absent':True,'root':str(p)}))\n"
compile(code,'<remote-output-absence>','exec')
args=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99','python3 -B -']
r=subprocess.run(args,input=code,text=True,capture_output=True,timeout=30)
(ROOT/'remote-absence.stdout').write_text(r.stdout);(ROOT/'remote-absence.stderr').write_text(r.stderr);assert r.returncode==0
(ROOT/'remote-absence.py').write_text(code)
shutil.copy2(fresh,ROOT/'cooled-readiness.json')
OLD.rename(ROOT/'failed-attempt')
(ROOT/'receipt.json').write_text(json.dumps({'status':'Preserved original entry refusal; cooled original guard passes and remote cell absent. Exact driver/argv may resume this unlaunched cell.','failed_entry':original,'fresh_entry':f,'remote_check':json.loads(r.stdout),'no_completed_cell_repeated':True},indent=2)+'\n')
files={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)}for p in sorted(ROOT.rglob('*'))if p.is_file()}
(ROOT/'manifest.json').write_text(json.dumps({'files':files},indent=2)+'\n');print(sha(ROOT/'manifest.json'))
