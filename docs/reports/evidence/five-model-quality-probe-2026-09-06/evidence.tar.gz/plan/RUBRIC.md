# Serving quality review, frozen before model output

Evaluate the actual generated response to the frozen request. Responses do not need identical tokens, prose, or source-code spelling across backends. A model process/integrity PASS is never a task-quality PASS. The separate existing numerical/trajectory/SSD/concurrency tests retain their recorded results.

Use three explicit outcomes: PASS, FAIL, INCONCLUSIVE. PASS requires relevant continuation or a correct completed answer without a substantive error. FAIL identifies the violated requirement and quotes the relevant response span. INCONCLUSIVE covers unresolved completion, ambiguous correctness, missing evidence or a token-cap cutoff that prevents judgment. Record the actual finish reason and token cap for every response, including otherwise coherent partial continuations. No failed/inconclusive case disappears into an average score.

## Reasoning: both short and long variants

- GSM8K528: final answer **172**. Ophelia has20 sofas and22 chairs; Jenna has66 chairs and64 sofas; total20+22+66+64=172. The response must solve the final problem and end with `#### 172`. Algebraically equivalent reasoning is accepted. Wrong relations or arithmetic are substantive errors even when the final integer happens to match.
- GSM8K1303: final answer **4 weeks**. The initial backlog is6×14=84 holes; net daily removal is9−6=3;84/3=28 days=4 weeks. End with `#### 4` (a unit suffix is acceptable). This is the locked GSM8K convention. A well-explained alternative about within-day completion must be recorded as an ambiguity for review rather than silently counted correct under this fixed expected-answer rule.
- Only the final problem is graded; worked examples are context. Numeric final-answer extraction is a useful automatic observation, but correct extraction alone does not verify the requested explanation. A capped unfinished response is not a completed-answer PASS.

## Prose: both short and long variants

- Alice/Gutenberg11: continue the scene with Alice, the Gryphon and the Mock Turtle discussing the puzzling poem/dance. Preserve the narrative viewpoint, whimsical dialogue and established character roles. Respond with a continuation, not commentary or a summary. The historical next line concerns the first dancing position, but reproducing that line or its exact plot is not required.
- Time Machine/Gutenberg35: continue the first-person narrator's reflections at night in the future, following the chapter transition “A Sudden Shock.” Maintain the setting/viewpoint and a plausible transition from the narrator's overconfident explanation. The source proceeds through moonlight toward discovery of the missing machine, but the frozen prompt does not require verbatim recall or immediate discovery within128 tokens.
- Assess continuity, relevance, intelligibility and substantive contradictions. Novel coherent continuation is acceptable. Unrelated text, meta-instructions, serious viewpoint/setting contradictions or runaway repetition fail. A sentence cut by the cap is explicitly marked; judge observed continuation quality separately from whether the requested continuation was completed.

## Code: both short and long variants

- Return a fenced Python continuation of the supplied CPython fragment. Judge meaningful continuation, indentation/scope continuity and substantive semantic errors. Do not require a complete module or an exact reproduction of CPython.
- Fractions: the fragment ends after `__int__` inside Fraction. A continuation should preserve rational/integer semantics and the positive-denominator representation. The historical continuation adds `__trunc__`, `__floor__`, `__ceil__`, then rounding. If these operations appear, truncation must be toward zero (−7/3→−2), floor toward negative infinity (−7/3→−3), ceiling toward positive infinity (7/3→3 and−7/3→−2); exact integers stay unchanged. Equivalent implementations or other coherent Fraction methods can be valid. Floating conversion that loses exact large-integer semantics, sign mistakes or undefined state are substantive errors.
- Functools: the fragment ends inside `singledispatch`, after dispatch/type helpers. A continuation should use the existing registry/cache/helper scope coherently. The historical next method is `register(cls, func=None)`, supporting direct and decorator registration; a type-only call returns a decorator and registration invalidates dispatch cache. A relevant partial method can be assessed as continuation. Do not invent a requirement to finish the whole decorator within128 tokens. Wrong scope, invalid registration semantics, unrelated code or an assertion that a stub is complete are substantive errors.
- Parseable complete definitions can be inspected statically against these semantics. Do not execute arbitrary generated code as part of this collector. Incomplete syntax at a recorded length cutoff is distinguished from a malformed completed answer. Cap-limited unresolved task completion remains INCONCLUSIVE even if the observed prefix is locally plausible.

## Review record

Keep per-cell/per-row response hash, input/canonical identities, model artifact, backend/MTP/runtime binding, finish/cap, domain observations, outcome, reviewer and reason. Prefer reviewing continuation text before revealing model/backend labels. Repeated output is still retained; matching first/repeat tokens is an independent same-backend integrity gate, not two independent quality samples.

There are six underlying targets with short/long variants, not12 independent problems. This is a small domain/context release check, not an official GSM8K score or a statistical quality estimate. Teacher likelihood and its64-token reference span are not used. Full licenses/source notices and deterministic original selection are preserved in this package.
