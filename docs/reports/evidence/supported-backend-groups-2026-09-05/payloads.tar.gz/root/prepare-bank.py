import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

root = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
destination = root / 'docs/reports/evidence/supported-backend-groups-2026-09-05'
assert not destination.exists()
payloads = {}
for group in ['q35-normal-quartet1', 'gpt-supported-group1', 'gemma8-supported-group1']:
    directory = Path('/tmp/darkbloom-' + group + '-freeze')
    manifest = json.loads((directory / 'manifest.json').read_text())
    for name, spec in manifest['files'].items():
        raw = (directory / name).read_bytes()
        assert len(raw) == spec['bytes']
        assert hashlib.sha256(raw).hexdigest() == spec['sha256']
        payloads[group + '/' + name] = raw
    payloads[group + '/manifest.json'] = (directory / 'manifest.json').read_bytes()
payloads['root/review.json'] = Path('/tmp/darkbloom-three-backend-groups-root-review.json').read_bytes()
payloads['root/prepare-bank.py'] = Path(__file__).read_bytes()
destination.mkdir(parents=True)
archive = destination / 'payloads.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, raw in sorted(payloads.items()):
                assert raw[:4] not in [b'\x7fELF', b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf']
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                tar.addfile(entry, io.BytesIO(raw))
entries = {name: {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
           for name, raw in sorted(payloads.items())}
manifest = {
    'schema': 1,
    'scope': 'Initial B1 Qwen3.5 quartet and GPT/Gemma8 supported three-cell groups; Qwen backend regression remains failed, historical unsupported cells remain unrun',
    'files': entries,
    'payload_count': len(entries),
    'payload_bytes': sum(len(raw) for raw in payloads.values()),
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archive_bytes': archive.stat().st_size,
    'excluded': 'Compiled runtime and model weights; identities remain recorded',
}
(destination / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(entries)
    for member in tar:
        raw = tar.extractfile(member).read()
        assert len(raw) == entries[member.name]['bytes']
        assert hashlib.sha256(raw).hexdigest() == entries[member.name]['sha256']
summary = {key: value for key, value in manifest.items() if key != 'files'}
summary['manifest_sha256'] = hashlib.sha256((destination / 'manifest.json').read_bytes()).hexdigest()
Path('/tmp/darkbloom-three-backend-groups-bank-review.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
