from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time
out=Path('/tmp/darkbloom-final-serving-build5');base=Path('/tmp/darkbloom-production-grant-harness-validation1');ws=out/'workspace';scratch=Path('/tmp/darkbloom-final-serving-build1/build')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
info=json.loads((out/'integration.json').read_text());env=os.environ.copy();env.update(info['environment'])
ns={};exec((base/'run.py').read_text().split("assert (policy / 'manifest.json').exists()")[0],ns)
def write(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
def verify():
 prior=ns['verify']();provider=json.loads((out/'provider-source-manifest.json').read_text())
 for name,expected in provider['files'].items():assert sha(ws/name)==expected,name
 for name in provider['deleted_files']:assert not (ws/name).exists(),name
 inputs=json.loads((out/'compile-source-manifest.json').read_text())['files']
 for name,row in inputs.items():assert sha(out/name)==row['sha256'],name
 for name,h in json.loads((base/'jinja-source-manifest.json').read_text())['files'].items():assert sha(scratch/'checkouts/swift-jinja'/name)==h,name
 return {'baseline_unchanged':prior,'diagnostic_provider_inputs':len(provider['files']),'only_provider_delta':provider['delta'],'standalone_package_inputs':len(inputs),'actual_jinja_inputs_verified':27}
def proof(label):
 graph=scratch/'release.yaml';body=graph.read_text();(out/(label+'-graph.yaml.gz')).write_bytes(gzip.compress(graph.read_bytes(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/(label+'-package-state.json'))
 expected=[ws/'provider-swift/Sources/ProviderCore/Inference/EngineV2Factory+BenchmarkSession.swift',ws/'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVSegments.swift',ws/'libs/mlx-swift/Source/MLX/AllocationFootprint.swift',ws/'libs/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp',out/'radix-engine/Sources/radix-engine/BenchmarkIdleObservation.swift',out/'radix-engine/Sources/radix-engine/BenchmarkGeneration.swift']
 if label=='tests':expected.append(out/'radix-engine/Tests/RadixEngineBenchmarkTests/BenchmarkIdleObservationTests.swift')
 rows=[]
 for path in expected:
  aliases=[str(path),str(path.resolve()),str(path).replace('/tmp/','/private/tmp/',1),str(path.resolve()).replace('/private/tmp/','/tmp/',1)]
  actual=next((Path(p) for p in aliases if p in body),None);assert actual is not None,str(path)
  assert actual.resolve()==path.resolve();rows.append({'actual_compile_path':str(actual),'resolved_frozen_source':str(path.resolve()),'sha256':sha(path)})
 assert '/checkouts/mlx-swift/Source/' not in body
 assert '/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated/provider-swift/Sources/' not in body
 write(label+'-actual-source-proof.json',{'paths':rows,'remote_mlx_compile_source_absent':True,'mutable_primary_compile_source_absent':True,'jinja_inputs_verified':27})
results=[]
def run(label,command,test=False):
 write(label+'-source-verified-before.json',verify());start=time.monotonic()
 with (out/(label+'.log')).open('w') as log:p=subprocess.run(command,cwd=out/'radix-engine',env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':label,'command':command,'cwd':str(out/'radix-engine'),'seconds':time.monotonic()-start,'exit_code':p.returncode};results.append(row);write('execution.json',results);print(json.dumps(row),flush=True)
 write(label+'-source-verified-after.json',verify())
 if (scratch/'release.yaml').exists():proof(label)
 if p.returncode:raise SystemExit(p.returncode)
 if test:
  body=(out/(label+'.log')).read_text();matches=re.findall(r'Test run with (\d+) tests? passed',body);assert matches and int(matches[-1])==8,matches
  assert not re.search(r'(?:Test|Suite) .+ skipped|with [1-9][0-9]* tests? skipped',body)
  write('test-verdict.json',{'test_functions':8,'executed_cases':8,'passed':True,'skipped':0,'failed':0,'log_sha256':sha(out/(label+'.log'))})
common=['-c','release','--scratch-path',str(scratch),'--jobs','4','--disable-automatic-resolution']
run('tests',['swift','test',*common,'--filter','BenchmarkIdleObservationTests'],test=True)
run('release',['swift','build',*common,'--product','radix-engine'])
artifact=out/'artifact';artifact.mkdir();shutil.copy2(scratch/'arm64-apple-macosx/release/radix-engine',artifact/'radix-engine')
prior_artifact=Path('/tmp/darkbloom-final-serving-build3/artifact');prior_manifest=json.loads(Path('/tmp/darkbloom-final-serving-build3/artifact-manifest.json').read_text())
for name,row in prior_manifest['files'].items():
 assert sha(prior_artifact/name)==row['sha256'],name
 if name in ['darkbloom','radix-engine']:continue
 target=artifact/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(prior_artifact/name,target)
files={str(p.relative_to(artifact)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(artifact.rglob('*')) if p.is_file()}
write('artifact-manifest.json',{'scope':'New coherent-idle standalone probe plus exact inherited runtime resources. Both paired arms must use this binary. No CLI rebuild or real-model result claimed.','files':files,'unchanged_cli':prior_manifest['files']['darkbloom']})
(out/'radix-engine-dylibs.txt').write_text(subprocess.check_output(['otool','-L',str(artifact/'radix-engine')],text=True))
write('source-verified-final.json',verify());print('IDLE TESTS AND STANDALONE RELEASE PASS '+files['radix-engine']['sha256'],flush=True)
