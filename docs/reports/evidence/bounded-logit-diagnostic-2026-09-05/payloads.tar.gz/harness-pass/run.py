from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time

out=Path('/tmp/darkbloom-q36-diagnostic-harness-validation1')
parent=Path('/tmp/darkbloom-receipt-diagnostic-provider-validation1')
info=json.loads((out/'integration.json').read_text());ws=Path(info['provider_candidate_workspace']);scratch=Path(info['scratch'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
env=os.environ.copy();env.update(info['environment'])
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
def verify():
 harness=json.loads((out/'compile-source-manifest.json').read_text())
 for name,row in harness['files'].items():assert sha(out/name)==row['sha256'],name
 provider=json.loads((parent/'candidate/provider-source-manifest.json').read_text())
 for name,digest in provider['files'].items():assert sha(ws/name)==digest,name
 for name in provider.get('deleted_files',[]):assert not (ws/name).exists(),name
 for manifest in ['native-source-manifest.json','ancillary-package-manifest.json']:
  for name,digest in json.loads((parent/manifest).read_text())['files'].items():assert sha(ws/'libs/mlx-swift-lm'/name)==digest,name
 deps=json.loads((parent/'dependency-source-manifest.json').read_text())
 for key,digest in deps['files'].items():
  alias,name=key.split('/',1);assert sha(Path(deps['repositories'][alias])/name)==digest,key
 for name,digest in json.loads((parent/'jinja-source-manifest.json').read_text())['files'].items():assert sha(scratch/'checkouts/swift-jinja'/name)==digest,name
 return {'harness':len(harness['files']),'provider':len(provider['files']),'native':484,'ancillary_native':405,'dependencies':1356,'jinja':27,'no_drift':True}
assert json.loads((parent/'candidate/verdict.json').read_text())['status']=='PASS'
results=[]
def run(name,command,test=False):
 started=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(command,cwd=out/'radix-engine',env=env,stdout=log,stderr=subprocess.STDOUT)
 body=(out/(name+'.log')).read_text();nonzero=bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test',body));skips=bool(re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',body,re.M))
 row={'name':name,'command':command,'cwd':str(out/'radix-engine'),'exit_code':p.returncode,'seconds':time.monotonic()-started,'nonzero_no_skips':not test or nonzero and not skips};results.append(row);write('execution.json',results);print(json.dumps(row),flush=True)
 write('source-verified-current.json',verify())
 for file in ['debug.yaml','workspace-state.json']:
  path=scratch/file
  if path.exists():(out/('actual-'+file+('.gz' if file.endswith('yaml') else ''))).write_bytes(gzip.compress(path.read_bytes(),mtime=0) if file.endswith('yaml') else path.read_bytes())
 assert p.returncode==0 and row['nonzero_no_skips'],name
write('source-verified-before.json',verify());write('compile-environment.json',info['environment'])
run('build',['swift','build','--scratch-path',str(scratch),'--build-tests','--jobs','4','--disable-automatic-resolution'])
text=(scratch/'debug.yaml').read_text();proof=[]
actual_paths=sorted(set(re.findall(r'"(/[^"\n]+)"',text)))
for path in [out/'radix-engine/Sources/radix-engine/BenchmarkLogitDiagnostic.swift',out/'radix-engine/Sources/radix-engine/BenchmarkOptions.swift',out/'radix-engine/Tests/RadixEngineBenchmarkTests/BenchmarkLogitDiagnosticOptionsTests.swift',ws/'provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge+Submission.swift',ws/'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/CBv2LogitDiagnostic.swift']:
 actual=next((p for p in actual_paths if p.endswith('/'+path.name) and Path(p).resolve()==path.resolve()),None);assert actual,str(path);proof.append({'actual_path':actual,'resolved_path':str(path.resolve()),'sha256':sha(path)})
assert '/checkouts/mlx-swift/Source/' not in text
write('actual-compiler-source-proof.json',{'paths':proof,'remote_mlx_source_excluded':True})
debug=scratch/'arm64-apple-macosx/debug';bundle=debug/'RadixEngineBenchmarkPackageTests.xctest/Contents/MacOS';binary=bundle/'RadixEngineBenchmarkPackageTests'
lib=Path('/tmp/darkbloom-final-serving-build7/artifact/mlx.metallib');assert sha(lib)=='4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0'
for target in [debug/'mlx.metallib',bundle/'mlx.metallib']:shutil.copy2(lib,target);assert sha(target)==sha(lib)
write('test-binary.json',{'path':str(binary),'sha256':sha(binary),'bytes':binary.stat().st_size,'metallib_sha256':sha(lib)})
for name in ['BenchmarkLogitDiagnosticOptionsTests','BenchmarkIdleObservationTests']:
 run(name,['swift','test','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution','--filter',name],test=True)
write('source-verified-after.json',verify());write('verdict.json',{'status':'PASS','diagnostic_option_tests':3,'idle_observation_tests':8,'provider_receipt_tests':'separate prior candidate PASS','real_models_run':False});print('HARNESS11 TESTS PASS',flush=True)
