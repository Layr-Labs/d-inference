from pathlib import Path
import json,os,re,subprocess,time
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated');out=Path('/tmp/darkbloom-process-memory-ledger-validation1')
env=os.environ.copy();env['MLX_METALLIB_PATH']=str(root/'provider-swift/.build/arm64-apple-macosx/debug/mlx.metallib')
commands=[('build',['swift','build','--package-path','provider-swift','--build-tests','--jobs','4','--disable-automatic-resolution']),('identifiers',['swift','test','list','--skip-build','--package-path','provider-swift','--disable-automatic-resolution']),('ledger',['swift','test','--skip-build','--package-path','provider-swift','--disable-automatic-resolution','--filter','processLedger'])]
results=[]
for name,command in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(out/(name+'.log')).read_text();valid=True
 if name=='ledger':valid=bool(re.search(r'Test run with 18 tests',text)) and not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',text,re.M)
 entry={'name':name,'command':command,'exit_code':result.returncode,'seconds':time.monotonic()-start,'expected_count_and_no_skips':valid}
 results.append(entry);(out/'execution.json').write_text(json.dumps({'cwd':str(root),'environment':{'MLX_METALLIB_PATH':env['MLX_METALLIB_PATH']},'results':results},indent=2)+'\n')
 print(json.dumps({k:v for k,v in entry.items() if k!='command'}),flush=True)
 if result.returncode or not valid:raise SystemExit(result.returncode or 1)
