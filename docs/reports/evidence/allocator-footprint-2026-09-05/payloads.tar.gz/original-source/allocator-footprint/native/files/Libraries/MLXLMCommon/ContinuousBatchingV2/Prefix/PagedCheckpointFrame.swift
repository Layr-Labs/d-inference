import Foundation
import MLX

/// Private import owner, assembled after the final authenticated tensor byte.
/// The enclosing codec must move its arrays into this object, retaining no
/// writable source aliases. This mechanical frame is not cache eligibility.
final class CBv2PagedCheckpointFrame: @unchecked Sendable {
    private let lock = NSLock()
    private var owner: CBv2PagedCheckpointOwner?

    init(storage: CBv2PagedCheckpointStorage, auxiliary: [MLXArray],
         lease: CBv2CheckpointStageLease) throws {
        var bytes = 0
        for array in auxiliary {
            let (next, overflow) = bytes.addingReportingOverflow(array.nbytes)
            guard !overflow else { throw CBv2CompleteCheckpointError.invalidManifest }
            bytes = next
        }
        guard storage.plan.nativeBytes == lease.targetBytes, bytes == lease.auxiliaryBytes,
            storage.allocatedBytes <= storage.plan.nativeBytes
        else { throw CBv2CompleteCheckpointError.incompatibleCheckpoint }
        try lease.settleTargetAfterEvaluation(actualBytes: storage.allocatedBytes)
        owner = CBv2PagedCheckpointOwner(storage: storage, auxiliary: auxiliary, lease: lease)
    }

    /// Empty the public closeable owner before engine work. A concurrent close
    /// can win or lose this move, but cannot refund arrays being adopted.
    func consume() throws -> CBv2PagedCheckpointOwner {
        try lock.withLock {
            guard let owner else { throw CBv2CompleteCheckpointError.closed }
            self.owner = nil
            return owner
        }
    }

    func close() {
        let owner = lock.withLock {
            let value = self.owner
            self.owner = nil
            return value
        }
        owner?.close()
    }

    deinit { close() }
}

/// Single engine-queue owner after consume. Its scratch reservation survives
/// the destination transfer until close; native/process charge is not doubled.
final class CBv2PagedCheckpointOwner {
    let storage: CBv2PagedCheckpointStorage
    var auxiliary: [MLXArray]
    let lease: CBv2CheckpointStageLease

    init(storage: CBv2PagedCheckpointStorage, auxiliary: [MLXArray], lease: CBv2CheckpointStageLease) {
        self.storage = storage
        self.auxiliary = auxiliary
        self.lease = lease
    }

    func close() {
        storage.close()
        auxiliary.removeAll()
        lease.closeAfterDroppingOwners()
    }

    deinit { close() }
}

/// Resources installed in ordinary pool ownership. The engine integration can
/// move them into its active state; this mechanical slice keeps an explicit
/// retirement boundary for rollback tests and never refunds before aliases.
final class CBv2PagedCheckpointAdoption {
    private(set) var rows: [PagedSequenceKV]
    private(set) var auxiliary: [MLXArray]
    private var releaseAdmission: (() -> Void)?

    init(rows: [PagedSequenceKV], auxiliary: [MLXArray], releaseAdmission: @escaping () -> Void) {
        self.rows = rows
        self.auxiliary = auxiliary
        self.releaseAdmission = releaseAdmission
    }

    func release() {
        for row in rows { row.releaseStorage() }
        rows.removeAll()
        auxiliary.removeAll()
        let release = releaseAdmission
        releaseAdmission = nil
        release?()
    }

    deinit { release() }
}
