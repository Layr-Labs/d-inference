import json
import subprocess
import sys

cell=sys.argv[1]
assert cell in ('qwen38-paged-off-b1','qwen38-paged-ssd-b1','qwen36-paged-off-b1','qwen36-paged-ssd-b1','qwen35-paged-off-b1','qwen35-paged-ssd-b1','gpt-oss-20b-paged-off-b1','gpt-oss-20b-paged-ssd-b1','gemma-4-26b-paged-off-b1','gemma-4-26b-paged-ssd-b1','gemma-qat4-paged-off-b1','gemma-qat4-paged-ssd-b1')
code="""from pathlib import Path
import json,subprocess,time
root=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http5/runs')/(CELL+'-run')
result={'unix_time':time.time(),'cell':CELL}
if (root/'launch.json').exists():
 x=json.loads((root/'launch.json').read_text());result['launch']={k:x.get(k) for k in ['status','started_unix','ended_unix','exit_code','error','owned_group_cleanup']}
if (root/'evidence/report.json').exists():
 x=json.loads((root/'evidence/report.json').read_text());result['report']={'state':x.get('state'),'cases':[{k:c.get(k) for k in ['name','status','error']} for c in x.get('cases',[])]}
handles=[]
for row in subprocess.check_output(['ps','-axo','pid=,ppid=,pgid=,args='],text=True).splitlines():
 parts=row.strip().split(None,3)
 if len(parts)!=4:continue
 if '090-connected-http5/run_connected_fixture.py' in parts[3]:role='fixture_launcher'
 elif '090-connected-http5/connected-e2e.test' in parts[3]:role='owned_go_leader'
 else:continue
 handles.append({'pid':int(parts[0]),'ppid':int(parts[1]),'pgid':int(parts[2]),'role':role})
result['owned_handles']=handles
print(json.dumps(result,indent=2))
""".replace('CELL',repr(cell))
result=subprocess.run(['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99','python3 -B -'],input=code,text=True,capture_output=True)
print(result.stdout)
if result.returncode:raise RuntimeError(result.stderr)
