from pathlib import Path
import json,hashlib,gzip,tarfile,io
bank=Path('/tmp/darkbloom-allocator-footprint-bank');bank.mkdir(exist_ok=True);files={};excluded=[]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def add(source,path,expected=None):
 source=Path(source);sha=digest(source)
 if expected:assert sha==expected,(source,sha,expected)
 assert path not in files
 files[path]={'path':path,'source':str(source),'bytes':source.stat().st_size,'sha256':sha}
roots=[]
for n in range(1,7):
 root=Path('/tmp/darkbloom-allocator-footprint-foundation'+str(n));name='manifest.json' if n==6 else 'partial-manifest.json';m=json.loads((root/name).read_text());prefix='foundation'+str(n)
 add(root/name,prefix+'/'+name)
 for p,meta in m['files'].items():add(root/p,prefix+'/'+p,meta if isinstance(meta,str) else meta['sha256'])
 roots.append({'path':prefix+'/'+name,'source':str(root/name),'sha256':digest(root/name),'role':'final accepted' if n==6 else 'preserved failed/superseded attempt'})
root=Path('/tmp/darkbloom-footprint-ownership-diagnostic1');m=json.loads((root/'manifest.json').read_text());add(root/'manifest.json','ownership-diagnostic/manifest.json')
for p,sha in m['files'].items():
 if p=='diagnostic':
  assert digest(root/p)==sha;excluded.append({'source':str(root/p),'sha256':sha,'reason':'compiled diagnostic executable; build products excluded'});continue
 add(root/p,'ownership-diagnostic/'+p,sha)
for p,sha in m['linked_unchanged_inputs'].items():
 if p.endswith('.a'):excluded.append({'source':p,'sha256':sha,'reason':'linked static build product; identity retained in diagnostic manifest'})
 else:add(p,'ownership-diagnostic/linked-inputs/array.h',sha)
roots.append({'path':'ownership-diagnostic/manifest.json','source':str(root/'manifest.json'),'sha256':digest(root/'manifest.json'),'role':'external diagnostic; timing not model evidence'})
root=Path('/tmp/darkbloom-allocator-footprint/freeze1');m=json.loads((root/'manifest.json').read_text());add(root/'manifest.json','original-source/allocator-footprint/manifest.json')
for repo in m['repositories']:
 prefix='original-source/allocator-footprint/'+repo['name'];add(repo['patch'],prefix+'/source.patch',repo['patch_sha256'])
 for f in repo['files']:
  p=f['path'];source=root/repo['name']/'files'/p
  if not source.exists():source=Path(repo['worktree'])/p
  add(source,prefix+'/files/'+p,f['sha256'])
overlay=Path(m['native_overlay']);add(overlay,'original-source/native-process-memory/manifest.json')
roots.append({'path':'original-source/allocator-footprint/manifest.json','source':str(root/'manifest.json'),'sha256':digest(root/'manifest.json'),'role':'original reviewed source freeze; corrections preserved separately'})
add('/tmp/darkbloom-allocator-footprint-final-commits.json','bank/final-commits.json')
add('/tmp/darkbloom-allocator-footprint-root-bank-verification.json','bank/root-bank-verification.json')
add(__file__,'bank/package.py')
for path,f in files.items():
 assert not any(part in ['.build','build-metal','build-cpu'] for part in Path(path).parts)
 assert not path.endswith(('.a','.dylib','.o','.safetensors','.metallib','.gguf'))
 if path.endswith('owned-source.tar.gz'):
  with tarfile.open(f['source'],'r:gz') as t:
   for member in t.getmembers():assert not member.name.endswith(('.o','.a','.dylib','.metallib','.safetensors','.gguf'))
archive=bank/'payloads.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for path,f in sorted(files.items()):
  data=Path(f['source']).read_bytes();info=tarfile.TarInfo(path);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
manifest={'schema':1,'scope':'Allocator-owned per-buffer bounds, non-evaluating backing metadata and native paged charge/coverage settlement; final native foundation6 with unchanged Swift/CPU/Metal carry-forward and complete failure lineage.','parent_base':'69a75de82813beaf753fbbb4891c3b3261b63600','native_base':'990475e3ae6f93615bebe0fc36e352aa601ea4a5','banked_commits':json.loads(Path('/tmp/darkbloom-allocator-footprint-final-commits.json').read_text()),'accepted_validation_manifest':'foundation6/manifest.json','accepted_validation_sha256':digest(Path('/tmp/darkbloom-allocator-footprint-foundation6/manifest.json')),'native_filters':29,'native_functions':322,'native_cases':404,'native_failures':0,'native_skips':0,'swift_functions':4,'swift_cases':4,'swift_evidence':'foundation3','cpp_cases_per_backend':3,'cpp_backends':['CPU','Metal'],'cpp_evidence':'foundation1','owned_source_files':35,'evidence_roots':roots,'excluded_build_products':excluded,'limits':['CUDA source unexecuted.','Policy12 detached footprint API not applied or validated.','Real provider coherent allocator plus shared C/M integration, complete SSD codec union and fleet model performance remain pending.','Per-buffer bounds do not cover arbitrary graph inputs, scratch or whole-model allocations.','Diagnostic timing is not end-to-end overhead evidence.'],'archive':{'path':'payloads.tar.gz','sha256':digest(archive),'bytes':archive.stat().st_size},'entries':list(sorted(files.values(),key=lambda f:f['path']))}
assert manifest['accepted_validation_sha256']=='1028f760d648cae2161f81b0a1be7c9250bca9e39ba7ce44f91dbaac00d5dc4e'
(bank/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('entries',len(files),'archive_bytes',archive.stat().st_size,'manifest_sha',digest(bank/'manifest.json'),'archive_sha',digest(archive))
