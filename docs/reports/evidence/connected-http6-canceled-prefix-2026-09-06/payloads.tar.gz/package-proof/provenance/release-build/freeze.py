import json, stat
from build_proof import OUT, INFO, sha, write, verify, executable

assert not (OUT/'manifest.json').exists(), 'Final evidence freeze is immutable.'
verify()
execution = json.loads((OUT/'execution.json').read_text())
assert [r['product'] for r in execution] == ['radix-engine', 'darkbloom']
assert all(r['exit_code'] == 0 for r in execution)
smoke = json.loads((OUT/'smoke-verdict.json').read_text())
assert smoke['all_passed'] and smoke['checks_passed'] == 21 and not smoke['real_models_run']
artifacts = json.loads((OUT/'artifact-manifest.json').read_text())
assert len(artifacts['files']) == 8
for name, row in artifacts['files'].items():
    p = OUT/'artifact'/name
    assert sha(p) == row['sha256'] and p.stat().st_size == row['bytes']
    assert oct(stat.S_IMODE(p.stat().st_mode)) == row['mode']
    if name in INFO['products']: executable(p)
for product in INFO['products']:
    for stage in ['before', 'after']:
        assert json.loads((OUT/(product+'-source-verified-'+stage+'.json')).read_text())['no_drift']
write('verdict.json', {
    'status': 'PASS_COMMITTED_PACKET_AND_CANCELLATION_DUAL_RELEASE_BUILD_WITH_PARSE_SMOKES',
    'parent_commit': INFO['parent_commit'], 'native_commit': INFO['native_commit'],
    'release_products_built': 2, 'build_seconds': {r['product']: r['seconds'] for r in execution},
    'binaries': {p: json.loads((OUT/(p+'-binary.json')).read_text()) for p in INFO['products']},
    'runtime_resources': 6, 'runtime_resources_byte_identical_to_build8': True,
    'smoke_checks': 21, 'native_tests': '77 functions/162 cases, packet native validation1',
    'benchmark_tests': '18 functions, packet benchmark validation1 (provider384)',
    'cancellation_tests': '76 executions/73 distinct, native5cb/provider5b candidate; banked source6',
    'exact_combined_union_real_model_tests': False,
    'namespace_included': False, 'default_settings_changed': False,
    'limitations': 'Separate test evidence plus this exact-union optimized build and parse smokes. No real-model HTTP/packet, common-input operator replay, long-history proof, numerical acceptance, latency win or release readiness is claimed.',
    'next': 'Root artifact review and explicit binding to HTTP6 and actual Q36 packet plans before any M5 operation.',
})
exclude = {'workspace', 'native', 'radix-engine', '__pycache__'}
files = {str(p.relative_to(OUT)): {'sha256': sha(p), 'bytes': p.stat().st_size,
         'mode': oct(stat.S_IMODE(p.stat().st_mode))} for p in sorted(OUT.rglob('*'))
         if p.is_file() and p.relative_to(OUT).parts[0] not in exclude and p.name != 'manifest.json'}
write('manifest.json', {'schema': 1, 'status': 'FROZEN_DUAL_RELEASE_BUILD_AND_PARSE_SMOKES', 'files': files})
print(json.dumps({'manifest': str(OUT/'manifest.json'), 'sha256': sha(OUT/'manifest.json'),
                  'payloads': len(files), 'binaries': json.loads((OUT/'verdict.json').read_text())['binaries']}, indent=2))
