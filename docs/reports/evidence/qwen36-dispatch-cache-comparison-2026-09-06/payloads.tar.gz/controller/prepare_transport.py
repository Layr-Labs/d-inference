from pathlib import Path
import hashlib,json,difflib
OUT=Path(__file__).resolve().parent
SOURCE=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-plan1')
REMOTE='/Users/gaj/autoresearch/radix-prefix-cache/090-q36-paged-plan-cache-comparison1'
STAGE=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-staging1');STAGE.mkdir(exist_ok=True)
TRANSFER=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-transfer1');TRANSFER.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
old=Path('/tmp/darkbloom-qat-mtp-off-staging1/stage.py');t=old.read_text()
for a,b in [('/tmp/darkbloom-qat-mtp-off-staging1',str(STAGE)),('/tmp/darkbloom-qat-mtp-off-plan1',str(SOURCE)),('/Users/gaj/autoresearch/radix-prefix-cache/090-qat-mtp-off1',REMOTE),('cff10f1a674c260d9a5a76ca0667d0697ae8f8050a42fb22734d5c217e2aa29d',sha(SOURCE/'manifest.json')),('SOURCE_ONLY_PENDING_ROOT_REVIEW','SOURCE_ONLY_CANDIDATE_UNBOUND')]:
 assert a in t,a;t=t.replace(a,b)
compile(t,'stage.py','exec');(STAGE/'stage.py').write_text(t)
(OUT/'stage-delta.patch').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),t.splitlines(True),fromfile=str(old),tofile=str(STAGE/'stage.py'))))
old=Path('/tmp/darkbloom-qat-mtp-off-runtime-transfer1/transfer.py');t=old.read_text()
for a,b in [('/tmp/darkbloom-qat-mtp-off-runtime-transfer1',str(TRANSFER)),('/tmp/darkbloom-qat-mtp-off-staging1',str(STAGE)),('/Users/gaj/autoresearch/radix-prefix-cache/090-qat-mtp-off1',REMOTE),('cff10f1a674c260d9a5a76ca0667d0697ae8f8050a42fb22734d5c217e2aa29d',sha(SOURCE/'manifest.json')),('SOURCE_ONLY_PENDING_ROOT_REVIEW','SOURCE_ONLY_CANDIDATE_UNBOUND')]:
 assert a in t,a;t=t.replace(a,b)
t=t.replace("assert binding['remote_root'] == ROOT and binding['remote_artifact_root'] == ROOT + '/runtime'", "assert binding['remote_root'] == ROOT")
start=t.index("    files = {name:")
end=t.index("    build8 =",start)
t=t[:start]+'''    files = {variant + '/' + name: {**row, 'mode': int(row['mode'],8)}
             for variant,details in binding['variants'].items() for name,row in details['artifacts'].items()}
    assert len(files)==14 and set(binding['variants'])=={'baseline','candidate'}
    probes={}
    for variant,details in binding['variants'].items():
        for name,row in details['artifacts'].items():
            path=Path(details['local_artifact_root'])/name
            assert path.is_file() and not path.is_symlink()
            assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes']
            assert path.stat().st_mode&0o777==int(row['mode'],8)
        probes[variant]=Path(details['local_artifact_root'])/'radix-engine'
'''+t[end:]
start=t.index("    assert set(files) -")
end=t.index("    shutil.copy2(args.binding",start)
t=t[:start]+'''    for variant,details in binding['variants'].items():
        assert set(details['artifacts'])-{'radix-engine'}==set(resources)
        for name,row in resources.items():
            assert row['sha256']==files[variant+'/'+name]['sha256'] and row['bytes']==files[variant+'/'+name]['bytes']
'''+t[end:]
t=t.replace("if name=='radix-engine':continue", "if name.endswith('/radix-engine'):continue")
t=t.replace("Path(BUILD8)/name", "Path(BUILD8)/name.split('/',1)[1]")
t=t.replace("    send('scp-probe', probe, ROOT + '/runtime/radix-engine')", "    for variant,probe in probes.items():\n        send('scp-probe-'+variant, probe, ROOT + '/runtime/'+variant+'/radix-engine')")
compile(t,'transfer.py','exec');(TRANSFER/'transfer.py').write_text(t)
(OUT/'transfer-delta.patch').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),t.splitlines(True),fromfile=str(old),tofile=str(TRANSFER/'transfer.py'))))
print('transport preparation ready')
