from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import tarfile

work = Path('/Users/gaj/Documents/DarkbloomDev/wt/prefix-receipt-pump-milestone')
out = work / 'docs/reports/evidence/prefix-receipt-pump-ownership-2026-09-05'
out.mkdir(parents=True, exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
payloads, origins, originals = {}, {}, {}
for label, path, expected in [
    ('provider-validation', '/tmp/darkbloom-receipt-diagnostic-provider-validation1',
     '78c24dfaf5aa2ae5c5e0692bf136f2610a8946062f008d0d61c11ffcfe61c4a6'),
    ('receipt-source', '/tmp/darkbloom-prefix-receipt-pump-ownership2',
     '771c8d366fe67e7ff67b9b57e2af0c0c6a4479f7767e6e2283d0f3eec4ff6758'),
    ('native-diagnostic-provenance', '/tmp/darkbloom-q36-logit-diagnostic-validation3',
     '5b2e3d6136498a5964f725ccebefcc42d7eb7d8d349164a26bdf7a27bb735ffd')]:
    root = Path(path)
    manifest = (root / 'manifest.json').read_bytes()
    assert sha(manifest) == expected
    entries = json.loads(manifest)['files']
    originals[label] = {'source': path, 'manifest_sha256': expected,
                        'payloads_verified': len(entries)}
    for rel, record in entries.items():
        data = (root / rel).read_bytes()
        assert sha(data) == record['sha256'] and len(data) == record['bytes'], rel
        name = label + '/' + rel
        payloads[name] = data
        origins[name] = str(root / rel)
    payloads[label + '/manifest.json'] = manifest
    origins[label + '/manifest.json'] = str(root / 'manifest.json')

paths = ['provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge+Submission.swift',
         'provider-swift/Tests/ProviderCoreTests/EngineV2BridgeTests.swift']
source_proof = []
for rel in paths:
    data = (work / rel).read_bytes()
    assert data == payloads['receipt-source/after/' + rel]
    assert data == payloads['provider-validation/candidate/changed-source/' + rel]
    source_proof.append({'path': rel, 'sha256': sha(data),
                         'matches_reviewed_freeze_and_executed_candidate': True})
assert payloads['provider-validation/native-source-manifest.json'] == payloads[
    'native-diagnostic-provenance/native-source-manifest.json']
payloads['archive-builder.py'] = Path(__file__).read_bytes()
origins['archive-builder.py'] = __file__
preparation = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'base': '53e45fc1460a5420ee397d130968137b2edf3f68',
               'source_proof': source_proof,
               'native_source_manifests_byte_equal': True,
               'diagnostics_configured_in_provider_tests': False,
               'compiled_binaries_included': False,
               'new_Swift_or_GPU_or_remote_execution': False,
               'scope': 'Archive preparation; native diagnostic source retained as validation provenance, not part of the provider patch.'}
payloads['archive-preparation.json'] = (json.dumps(preparation, indent=2) + '\n').encode()
origins['archive-preparation.json'] = 'generated from exact reviewed and executed source comparisons'
archive = out / 'payloads.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(payloads.items()):
                item = tarfile.TarInfo(name)
                item.mode = 0o644
                item.size = len(data)
                tar.addfile(item, io.BytesIO(data))
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(payloads)
    assert {item.name for item in tar} == set(payloads)
    for item in tar:
        assert item.isfile() and tar.extractfile(item).read() == payloads[item.name]
manifest = {'scope': 'Provider receipt-pump ownership regression: reproduced baseline failure, candidate88 unique functions/92 executions PASS. Native diagnostic union retained as provenance, diagnostics nil. Real HTTP rerun pending.',
            'source_commit': '53e45fc1460a5420ee397d130968137b2edf3f68',
            'originals': originals, 'source_proof': source_proof,
            'archive': {'path': archive.name, 'bytes': archive.stat().st_size,
                        'sha256': sha(archive.read_bytes())},
            'payload_count': len(payloads), 'payload_bytes': sum(map(len, payloads.values())),
            'files': {name: {'source': origins[name], 'bytes': len(data), 'sha256': sha(data)}
                      for name, data in sorted(payloads.items())}}
path = out / 'manifest.json'
path.write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'manifest_sha256': sha(path.read_bytes()), 'archive': manifest['archive'],
                  'payload_count': manifest['payload_count'], 'payload_bytes': manifest['payload_bytes']}, indent=2))
