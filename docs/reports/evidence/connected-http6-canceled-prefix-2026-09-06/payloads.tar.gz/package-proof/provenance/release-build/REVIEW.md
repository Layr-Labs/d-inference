This preparation archives parent `98103b39741a48f9d47026be7393362318a2ab0a` and native `dcf39f6b43effaa2b483211c97d7d3a3e7c0269b` exactly. It prepares two optimized products, `radix-engine` then `darkbloom`, in one exclusive local Swift lane. Namespace source is excluded. No compile has started.

`source-union.json` binds 686 canonical provider inputs, 906 native inputs and 18 harness inputs. Native and harness exactly match packet validation canonical manifests. The eight provider differences from that benchmark validation are precisely the five production and three test files from banked cancellation source6. The cancellation archive is independently checked member-by-member and its final reviewed test identities/scope retained. Cancellation tests used native5cb; packet benchmark tests used provider384. Their separate passes do not claim combined runtime validation.

Only the provider/native Package.swift local MLX resolution overlays and pinned Package.resolved copies affect the compile inputs. Dependency/Jinja/availability-API manifests rehash 1,356/27/5 pinned files. No dependencies or shared build scratch are modified during preparation. Python 3.14 is required for safe tar extraction: the initial Python3.9 attempt stopped before extracting any source; its exception is retained in preparation-attempt1.json.

After root review and explicit Swift handoff:

```
/opt/homebrew/bin/python3 -B run.py /tmp/ROOT_REVIEW.json
/opt/homebrew/bin/python3 -B smoke.py
/opt/homebrew/bin/python3 -B freeze.py
```

`run.py` refuses a reused execution/artifact root, rehashes prepared inputs before each product and after compilation, preserves the actual graph/package state separately for each product, and checks successful compilation before accepting any scratch artifact. The declared graph proof establishes frozen source membership, not that every graph reference links into the selected product. Pinned availability implementations must occur in that graph. Remote MLX checkout/worktree sources are refused. Two regular 0755 executables and six exact build8 runtime resources are copied with `copy2` and rechecked. The first product's graph is retained before the second product can replace the shared graph.

`smoke.py` runs 21 bounded argument checks: six valid default/packet/all-diagnostic combinations reach the empty-input guard for both backends; thirteen invalid combinations refuse earlier; CLI `--version`/`--help` exit before subcommand execution. The model path deliberately does not exist. No runtime-smoke, model load, key, server, daemon or remote job is run. These are argument and artifact checks only.

`freeze.py` freezes raw build logs, source proofs, binary/mode/resource identities, parse logs and the exact committed union. Source preparation does not enable diagnostics by default or mark a model/backend acceptable. M5 and HTTP execution require their separate reviewed plans and lane ownership.
