from pathlib import Path
import collections
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

root = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
validation = Path('/tmp/darkbloom-footprint-provider-validation1')
checks = Path('/tmp/darkbloom-footprint-provider-root-validation1')
digest = lambda data: hashlib.sha256(data).hexdigest()
integration = json.loads(Path('/tmp/darkbloom-footprint-provider-root-integration.json').read_text())
go_counts = collections.Counter()
for line in (checks / 'go-focused-race.jsonl').read_text().splitlines():
    event = json.loads(line)
    if 'Test' in event and event['Action'] in ('pass', 'fail', 'skip'):
        go_counts[('subtest_' if '/' in event['Test'] else 'function_') + event['Action']] += 1
assert go_counts['function_pass'] == 6 and not go_counts['function_fail'] and not go_counts['function_skip']
ts = json.loads((checks / 'ts-focused.log').read_text())
assert ts['success'] and ts['numFailedTests'] == 0 and ts['numPendingTests'] == 0
assert json.loads((checks / 'go-command.json').read_text())['exit_code'] == 0
assert all(item['exit_code'] == 0 for item in json.loads((checks / 'ts-commands.json').read_text()))
summary = {'go': dict(go_counts), 'ts_tests': ts['numPassedTests'], 'ts_files': len(ts['testResults']), 'touched_eslint': 'pass'}
(checks / 'results.json').write_text(json.dumps(summary, indent=2) + '\n')

payloads = {}
manifest = json.loads((validation / 'manifest.json').read_text())
for relative, item in manifest['files'].items():
    data = (validation / relative).read_bytes()
    assert digest(data) == item['sha256'] and len(data) == item['bytes']
    payloads['provider/' + relative] = data
payloads['provider/manifest.json'] = (validation / 'manifest.json').read_bytes()
for path in sorted(checks.iterdir()):
    if path.is_file():
        payloads['root-validation/' + path.name] = path.read_bytes()
for label, path in {
    'telemetry': Path('/tmp/darkbloom-paged-footprint-telemetry/freeze2'),
    'lookup': Path('/tmp/darkbloom-ssd-candidate-lookup/freeze2'),
    'oracle': Path('/tmp/darkbloom-footprint-provider-oracle'),
}.items():
    for name in ['manifest.json', 'source.patch']:
        payloads['source/' + label + '/' + name] = (path / name).read_bytes()
payloads['bank/integration.json'] = Path('/tmp/darkbloom-footprint-provider-root-integration.json').read_bytes()
payloads['bank/package.py'] = Path(__file__).read_bytes()
for relative, sha in integration['files'].items():
    data = (root / relative).read_bytes()
    assert digest(data) == sha
    payloads['bank/owned-source/' + relative] = data
evidence = root / 'docs/reports/evidence/provider-footprint-2026-09-05'
evidence.mkdir(parents=True, exist_ok=True)
archive = evidence / 'payloads.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for name, data in sorted(payloads.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                tar.addfile(entry, io.BytesIO(data))
bank_manifest = {
    'schema': 1,
    'scope': 'Actual allocator/provider ownership proof, paged footprint wire observations, and metadata-only SSD candidate lookup.',
    'parent_base': integration['parent_base'],
    'source': integration,
    'provider_validation': json.loads((validation / 'verdict.json').read_text()),
    'root_validation': summary,
    'dependency_evidence': '../allocator-policy-2026-09-05/manifest.json',
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes())},
    'entries': [{'path': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(payloads.items())],
}
manifest_path = evidence / 'manifest.json'
manifest_path.write_text(json.dumps(bank_manifest, indent=2) + '\n')
with tarfile.open(archive, 'r:gz') as tar:
    assert {entry.name for entry in tar.getmembers()} == set(payloads)
    for name, data in payloads.items():
        assert tar.extractfile(name).read() == data

for patch in ['/tmp/darkbloom-paged-footprint-telemetry/docs.patch', '/tmp/darkbloom-ssd-candidate-lookup/docs.patch']:
    subprocess.run(['git', 'apply', '--check', patch], cwd=root, check=True)
    subprocess.run(['git', 'apply', patch], cwd=root, check=True)
canonical = ['docs/reference/protocol-messages.md', 'docs/architecture/telemetry.md',
             'docs/reference/telemetry-schema.md', 'docs/reference/telemetry-inventory.md',
             'docs/architecture/prefix-cache.md']
for relative in canonical:
    path = root / relative
    path.write_text(path.read_text().replace('commit `69a75de82`', 'commit `055a76364`', 1))
manifest_hash = digest(manifest_path.read_bytes())
archive_hash = bank_manifest['archive']['sha256']
report = root / 'docs/reports/2026-09-05-provider-footprint.md'
report.write_text(f'''# Provider allocator accounting and SSD candidate lookup

> Last updated: 2026-09-05 · commit `055a76364`

Provider tests now verify native allocation promises and backing coverage against
the real coherent MLX allocator. Optional telemetry distinguishes retained
allocator padding from unused reservation allowance. Complete SSD lookup checks
only the request's prefix candidates, eliminating its scan of unrelated entries.

## Observed allocation lifecycle

The isolated fixture reserves three independent buffer bounds before its first
evaluation, then inspects their actual allocator sizes. C is reserved memory,
M is backing already covered by that reservation, and U is active plus cached
allocator memory; process admission projects U + (C − M).

| Boundary | Observed bytes |
|---|---|
| Before first buffer evaluation | C = 163,837; M = 0; U = 6 |
| Evaluated segments | C = M = 81,920; U = 81,926 |
| Unused preparation allowance returned | 81,917 |
| Raw alias after native charge/coverage retirement | 24,576 logical bytes retain 32,768 allocated bytes; U = 32,772 |
| Final alias dropped and allocator cache cleared | U = 4; another owner can reuse the released 32,768 bytes |

A competing 4,096-byte promise fits exactly at both the pre-evaluation and
materialized boundaries; one additional byte is refused. The pre-evaluation cap
is deliberately restored before allocation. This proves boundary accounting,
not a continuously constrained serving factory, whole-graph scratch envelope or
OS-pressure behavior. The OS availability constraint is non-binding in this test.

## Changes and checks

`allocator_padding_bytes` reports nonusable retained bytes;
`last_allocation_allowance_bytes` reports the last released preparation allowance.
Neither is an additive total or a new admission authority. The same canonical
wire fixture is checked by Swift, Go and TypeScript, including optional omission.

`SSDBlockIndex.freshFileBytes` reads size and TTL under one lock. The complete
checkpoint store probes deepest-first without building a set of every expired
entry. Probes do not extend TTL; authenticated use and existing file/epoch checks
still control reuse. The lookup tests cover expiry boundaries, clock extremes,
touch, replacement, eviction and unrelated entries. No lookup timing was measured.

| Validation | Result |
|---|---|
| Swift provider | 68 functions / 68 cases pass, zero skip/failure; build 141.46 seconds |
| Go protocol, registry and API | Six focused functions pass with the race detector |
| TypeScript | {summary['ts_tests']} tests across {summary['ts_files']} files pass; touched-file ESLint passes |
| Source identity | 8 exact provider/fixture files, 664 provider inputs, 455 native inputs, 1,356 dependency inputs and 27 Jinja inputs verified |

The provider selection includes the prior 49 process-memory cases, two paged
footprint cases, 15 SSD cases and two real-allocator cases. Test groups execute
in separate processes. The final 16-file source union preserves the earlier
process-memory TypeScript fields; focused Go and TypeScript checks were rerun
after integration. Whole-project TypeScript and the full provider test suite
were not run in this milestone.

## Evidence and limits

The [manifest](evidence/provider-footprint-2026-09-05/manifest.json)
(SHA-256 `{manifest_hash}`) records {len(payloads)} verified
payloads. The [archive](evidence/provider-footprint-2026-09-05/payloads.tar.gz)
has SHA-256 `{archive_hash}`. The accepted provider
validation manifest is
`bfb58c3337fda3ffd7fc84c48cfab6b50caac48cd2b1d352424d3a0a95055967`.
Build products and model weights are excluded.

The complete Qwen/GPT-OSS/Gemma checkpoint union, production factory binding,
normal-MTP model runs, concurrent capacity, HTTP and signed-key restart remain
separate release gates. No model speedup, cache default or rollout is claimed.
Current field meanings are in the [protocol reference](../reference/protocol-messages.md#slotspaged_storage);
lookup flow is in [prefix caching](../architecture/prefix-cache.md).
''')
index = root / 'docs/reports/README.md'
text = index.read_text().replace('commit `2dcec3574`', 'commit `055a76364`', 1)
anchor = '- [Detached allocator sizing policy]'
assert anchor in text
text = text.replace(anchor, '- [Provider allocator accounting and SSD lookup](2026-09-05-provider-footprint.md) — real backing lifetime, coherent capacity boundaries, optional footprint telemetry and candidate-only metadata probes.\n' + anchor, 1)
index.write_text(text)
changelog = root / 'CHANGELOG.md'
text = changelog.read_text()
anchor = '## Unreleased — paged attention foundation\n'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '\n- Expose native allocator padding and released reservation allowance in provider telemetry; avoid scanning unrelated SSD checkpoints on prefix lookup. Verify real allocator ownership and exact capacity refusal.\n', 1)
changelog.write_text(text)
print(json.dumps({'manifest_sha256': manifest_hash, 'archive_sha256': archive_hash, 'payloads': len(payloads), 'archive_bytes': archive.stat().st_size, 'checks': summary}, indent=2))
