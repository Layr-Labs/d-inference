from pathlib import Path
import json,os,re,subprocess,time
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
out=Path('/tmp/darkbloom-090-paged-telemetry-provider4')
env=os.environ.copy();env['MLX_METALLIB_PATH']=str(root/'provider-swift/.build/arm64-apple-macosx/debug/mlx.metallib')
filters='|'.join(json.loads((out/'filters.json').read_text()))
command=['swift','test','--skip-build','--filter',filters,'--package-path','provider-swift','--disable-automatic-resolution']
start=time.monotonic()
with (out/'focused-direct.log').open('w') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
text=(out/'focused-direct.log').read_text()
zero=not re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test',text)
skips=bool(re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',text,re.M))
verdict={'command':command,'cwd':str(root),'exit_code':result.returncode,'seconds':time.monotonic()-start,'zero_tests':zero,'skips':skips,'reason':'Direct invocation preserves nonzero and no-skip tripwires; helper mktemp path exceeds filesystem filename limit for 55-alternative filter.'}
(out/'focused-direct-execution.json').write_text(json.dumps(verdict,indent=2)+'\n')
print(json.dumps({k:v for k,v in verdict.items() if k!='command'}))
raise SystemExit(result.returncode or int(zero or skips))
