from pathlib import Path
import hashlib,json,shutil,subprocess
out=Path('/tmp/darkbloom-final-serving-build7');old=Path('/tmp/darkbloom-final-serving-build6');ws=out/'workspace'
repo=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated');primary='9e49059a1806e265fd9ceab420c1b82216a5d785';native_commit='a932d38cee0beca41ca1a0e71c1e867913a65353'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
assert sha(old/'manifest.json')=='802f51029f30a4e7d7fcdc3dc898aac83bb0edb55939dd88468ab81a6baf8817'
previous=json.loads((old/'manifest.json').read_text())
for name,row in previous['files'].items():assert sha(old/name)==row['sha256'],name
ws.mkdir();shutil.copytree(old/'workspace/provider-swift',ws/'provider-swift');(ws/'libs').mkdir()
for name in ('mlx-swift','mlx-swift-lm'):(ws/'libs'/name).symlink_to((old/'workspace/libs'/name).resolve(),target_is_directory=True)
for name in ('provider-source-manifest.json','native-source-manifest.json','dependency-source-manifest.json','jinja-source-manifest.json'):
 shutil.copy2(old/name,out/name)

def committed_hashes(repo,commit,paths):
 payload=''.join(commit+':'+p+'\n' for p in paths).encode()
 data=subprocess.check_output(['git','cat-file','--batch'],input=payload,cwd=repo);cursor=0;result={}
 for path in paths:
  end=data.index(b'\n',cursor);header=data[cursor:end].decode().split();assert len(header)==3 and header[1]=='blob',(path,header)
  count=int(header[2]);start=end+1;value=data[start:start+count];cursor=start+count+1
  result[path]=hashlib.sha256(value).hexdigest()
 return result
proof=[];overlays=[]
for label,manifest_name,source,gitrepo,commit in [('provider','provider-source-manifest.json',ws,repo,primary),('native','native-source-manifest.json',ws/'libs/mlx-swift-lm',repo/'libs/mlx-swift-lm',native_commit)]:
 manifest=json.loads((out/manifest_name).read_text());committed=committed_hashes(gitrepo,commit,list(manifest['files']))
 for name,digest in manifest['files'].items():
  assert sha(source/name)==digest,name
  if digest!=committed[name]:
   assert name in ('provider-swift/Package.swift','Package.swift'),(label,name,digest,committed[name])
   before=subprocess.check_output(['git','show',commit+':'+name],cwd=gitrepo,text=True)
   after=(source/name).read_text();old_decl='.package(path: "../libs/mlx-swift")' if label=='provider' else '.package(path: "../mlx-swift")'
   new_decl='.package(path: "/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift")'
   assert before.count(old_decl)==1 and before.replace(old_decl,new_decl)==after,(label,'unexpected compile overlay')
   overlays.append({'repository':label,'path':name,'before_sha256':committed[name],'compile_sha256':digest,'only_replacement':{'before':old_decl,'after':new_decl}})
 proof.append({'repository':label,'commit':commit,'files':len(committed),'all_source_matches_except_documented_package_overlay':True})
write('canonical-source-correspondence.json',{'proof':proof,'compile_only_overlays':overlays,'scope':'Frozen build6 inputs equal requested banked primary/native sources; no mutable primary compilation.'})
write('integration.json',{'baseline_manifest':str(old/'manifest.json'),'baseline_manifest_sha256':sha(old/'manifest.json'),'primary_commit':primary,'native_commit':native_commit,'source_workspace':str(ws),'native_source':str((ws/'libs/mlx-swift-lm').resolve()),'swift_source':str((ws/'libs/mlx-swift').resolve()),'scratch':'/tmp/darkbloom-final-serving-build1/build','environment':{},'scope':'Release CLI only from exact build6 provider/native/deps. Probe build6 remains frozen and is carried, not rebuilt. No model or production execution.'})
write('package-resolution-inputs.json',{'files':{str(p):{'sha256':sha(p),'bytes':p.stat().st_size} for p in [ws/'provider-swift/Package.resolved',ws/'libs/mlx-swift-lm/Package.resolved']}})
print(json.dumps({'prepared':str(out),'canonical_proof':proof,'overlays':len(overlays)},indent=2))
