"""CPU-only checks against actual Swift listing and planted unsafe lookalikes."""
from pathlib import Path
import re
import unittest
from test_selection import IN_MEMORY_FUNCTIONS, selected_identifiers, exact_filter, canonical_identifiers

class TestSelectionTests(unittest.TestCase):
    def test_actual_listing_selects_only_four_reviewed_free_functions(self):
        listing = (Path(__file__).parent / 'provider-identifiers-original.log').read_text()
        selected = []
        for name in sorted(IN_MEMORY_FUNCTIONS):
            result = selected_identifiers(listing, name, 'provider')
            self.assertEqual(result, ['ProviderCoreTests.' + name + '()'])
            selected += result
        self.assertEqual(len(selected), 4)
        pattern = exact_filter(selected)
        self.assertEqual([line for line in listing.splitlines() if re.search(pattern, line)], selected_identifiers(
            listing, 'kekConcurrentFirstUseAdoptsSingleKEK', 'provider') + selected_identifiers(
            listing, 'kekLoadOrCreateGeneratesOnFirstCall', 'provider') + selected_identifiers(
            listing, 'kekPersistsAcrossActorInstances', 'provider') + selected_identifiers(
            listing, 'saveIfAbsentDoesNotOverwriteExisting', 'provider'))

    def test_actual_suites_preserve_nine_and_six_functions(self):
        listing = (Path(__file__).parent / 'provider-identifiers-original.log').read_text()
        for name, count in [('SSDPersistentTestKeyNamespaceTests', 9), ('SSDPrefixCacheModeTests', 6)]:
            result = selected_identifiers(listing, name, 'provider')
            self.assertEqual(len(result), count)
            self.assertEqual([line for line in listing.splitlines() if re.search(exact_filter(result), line)], result)

    def test_wrong_module_prefix_suffix_and_real_key_functions_never_select(self):
        name = 'kekLoadOrCreateGeneratesOnFirstCall'
        correct = 'ProviderCoreTests.' + name + '()'
        planted = [correct, 'ForeignTests.' + name + '()', 'ProviderCoreTests.prefix' + name + '()',
                   'ProviderCoreTests.' + name + 'ViaSecureEnclave()', 'ProviderCoreTests.' + name + '(group:)',
                   'ProviderCoreTests.kekRoundtripsViaSecureEnclave()', 'ProviderCoreTests.kekRoundtripsViaKeychainStorage()',
                   'ProviderCoreTests.OtherSuite/' + name + '()', 'warning: ' + correct]
        result = selected_identifiers('\n'.join(planted), name, 'provider')
        self.assertEqual(result, [correct])
        self.assertEqual([line for line in planted if re.search(exact_filter(result), line)], [correct])

    def test_real_key_and_cross_phase_selectors_are_refused(self):
        for name, phase in [('kekRoundtripsViaSecureEnclave', 'provider'), ('kekRoundtripsViaKeychainStorage', 'provider'),
                            ('kekLoadOrCreateGeneratesOnFirstCall', 'benchmark'), ('BenchmarkIdleObservationTests', 'provider')]:
            with self.assertRaises(ValueError): selected_identifiers('', name, phase)

    def test_parameterized_benchmark_suite_and_escaped_exact_filter(self):
        correct = 'RadixEngineBenchmarkTests.BenchmarkPersistentTestKeysTests/refusesInvalid(input:)'
        planted = [correct, correct.replace('BenchmarkPersistentTestKeysTests/', 'BenchmarkPersistentTestKeysTestsLegacy/'),
                   correct.replace('RadixEngineBenchmarkTests.', 'ForeignTests.'), correct + 'Trailing',
                   correct.replace('Tests.', 'TestsX', 1)]
        result = selected_identifiers('\n'.join(planted), 'BenchmarkPersistentTestKeysTests', 'benchmark')
        self.assertEqual(result, [correct])
        self.assertEqual([line for line in planted if re.search(exact_filter(result), line)], [correct])

    def test_zero_and_duplicate_selections_are_not_executable(self):
        for identifiers in ([], ['ProviderCoreTests.one()', 'ProviderCoreTests.one()']):
            with self.assertRaises(ValueError): exact_filter(identifiers)
        listing = 'ProviderCoreTests.kekLoadOrCreateGeneratesOnFirstCall()\n' * 2
        self.assertEqual(len(selected_identifiers(listing, 'kekLoadOrCreateGeneratesOnFirstCall', 'provider')), 2)

    def test_full_actual_runtime_listing_selects_same_nineteen(self):
        root = Path(__file__).parent
        listing = (root / 'provider-identifiers-original.log').read_text()
        runtime = (root / 'canonical-identifiers.log').read_text()
        selected = []
        for name in ['SSDPersistentTestKeyNamespaceTests', 'SSDPrefixCacheModeTests', *sorted(IN_MEMORY_FUNCTIONS)]:
            display = selected_identifiers(listing, name, 'provider')
            canonical = canonical_identifiers(display, runtime)
            pattern = exact_filter(display + canonical)
            self.assertEqual([line for line in listing.splitlines() if re.search(pattern, line)], display)
            self.assertEqual([line for line in runtime.splitlines() if re.search(pattern, line)], canonical)
            selected.extend(canonical)
        self.assertEqual(len(selected), 19)
        self.assertFalse(any('ViaKeychain' in x or 'ViaSecureEnclave' in x for x in selected))

    def test_original_anchored_display_filter_reproduces_zero_runtime_matches(self):
        root = Path(__file__).parent
        display = selected_identifiers((root / 'provider-identifiers-original.log').read_text(),
                                       'SSDPersistentTestKeyNamespaceTests', 'provider')
        self.assertEqual([x for x in (root / 'canonical-identifiers.log').read_text().splitlines()
                          if re.search(exact_filter(display), x)], [])

    def test_runtime_source_identity_is_exact_and_cannot_expand_to_lookalikes(self):
        display = 'ProviderCoreTests.kekLoadOrCreateGeneratesOnFirstCall()'
        actual = display + '/KVCacheKEKTests.swift:27:2'
        planted = [actual, actual + 'garbage', actual.replace(':27:', ':28:'),
                   actual.replace('Tests.', 'TestsX', 1), actual.replace('()', 'ViaSecureEnclave()'),
                   actual.replace('()', '(other:)'), 'prefix' + actual,
                   actual.replace('Tests.', 'Tests.OtherSuite/', 1)]
        pattern = exact_filter([display, actual])
        self.assertEqual([x for x in planted if re.search(pattern, x)], [actual])
        for suffix in ['/../Secrets.swift:1:1', '/A.swift:0:1', '/A.swift:1:0', '/A.swift:1:1/trailing']:
            with self.assertRaises(ValueError): canonical_identifiers([display], display + suffix)

    def test_missing_ambiguous_and_duplicate_runtime_ids_fail_closed(self):
        display = 'ProviderCoreTests.kekLoadOrCreateGeneratesOnFirstCall()'
        actual = display + '/KVCacheKEKTests.swift:27:2'
        for listing in ['', actual + '\n' + actual, actual + '\n' + actual.replace(':27:', ':28:')]:
            with self.assertRaises(ValueError): canonical_identifiers([display], listing)
        with self.assertRaises(ValueError): canonical_identifiers([display, display], actual)

if __name__ == '__main__':
    unittest.main()


class PacketSelectorTests(unittest.TestCase):
    def test_packet_suite_allowlist_is_exact_and_source_bound(self):
        for suite in ('BenchmarkAttentionPacketOptionsTests', 'BenchmarkAttentionPacketExportTests'):
            identifier = 'RadixEngineBenchmarkTests.' + suite + '/selected()'
            runtime = identifier + '/Packet.swift:12:5'
            planted = [identifier, identifier.replace(suite, suite + 'Legacy'),
                       identifier.replace('RadixEngineBenchmarkTests.', 'ForeignTests.'), identifier + 'Trailing']
            self.assertEqual(selected_identifiers('\n'.join(planted), suite, 'benchmark'), [identifier])
            self.assertEqual(canonical_identifiers([identifier], runtime), [runtime])
            pattern = exact_filter([identifier, runtime])
            self.assertEqual([s for s in planted + [runtime] if re.search(pattern, s)], [identifier, runtime])
