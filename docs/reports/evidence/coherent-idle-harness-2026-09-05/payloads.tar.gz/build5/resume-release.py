from pathlib import Path
import hashlib,json,re,shutil
out=Path('/tmp/darkbloom-final-serving-build5')
original=out/'run.py';ns={};exec(original.read_text().split("common=['-c'")[0],ns)
results=json.loads((out/'execution.json').read_text());assert len(results)==1 and results[0]['exit_code']==0
shutil.copy2(out/'execution.json',out/'tests-execution-original.json')
(out/'wrapper-failure.txt').write_text('The original wrapper exited 1 after the successful Swift test command (exit 0, 328.7900259587914 seconds). Its summary regex expected "Test run with 8 tests passed" but Swift Testing 1902 reported "Test run with 8 tests in 1 suite passed". The original source, log, graph, source verifications and command record are retained. No compiler or test failure occurred, and no source was changed. This addendum verifies each exact declared test name and resumes only the release build.\n\nTraceback (most recent call last):\n  File "/tmp/darkbloom-final-serving-build5/run.py", line 41, in <module>\n    run(\'tests\',[\'swift\',\'test\',*common,\'--filter\',\'BenchmarkIdleObservationTests\'],test=True)\n  File "/tmp/darkbloom-final-serving-build5/run.py", line 37, in run\n    assert matches and int(matches[-1])==8,matches\nAssertionError: []\n')
body=(out/'tests.log').read_text();test=out/'radix-engine/Tests/RadixEngineBenchmarkTests/BenchmarkIdleObservationTests.swift'
declared=re.findall(r'@Test func (\w+)\(',test.read_text());passed=re.findall(r'✔ Test (\w+)\(\) passed',body)
summary=re.findall(r'Test run with (\d+) tests?(?: in (\d+) suites?)? passed',body)
assert len(declared)==len(passed)==8 and set(declared)==set(passed),(declared,passed)
assert summary and int(summary[-1][0])==8,summary
assert not re.search(r'✔ Test .+ skipped|✘ Test |recorded an issue|with [1-9][0-9]* tests? skipped',body)
ns['write']('test-verdict.json',{'test_functions':8,'executed_cases':8,'passed':True,'skipped':0,'failed':0,'exact_passed_functions':sorted(passed),'log_sha256':ns['sha'](out/'tests.log'),'parser_addendum':'Accept current Swift Testing suite count and cross-check every named pass against declared source; no rerun.'})
binary=Path('/tmp/darkbloom-final-serving-build1/build/arm64-apple-macosx/release/RadixEngineBenchmarkPackageTests.xctest/Contents/MacOS/RadixEngineBenchmarkPackageTests')
ns['write']('test-binary.json',{'path':str(binary),'sha256':ns['sha'](binary),'bytes':binary.stat().st_size})
ns['results']=results
command=['swift','build','-c','release','--scratch-path','/tmp/darkbloom-final-serving-build1/build','--jobs','4','--disable-automatic-resolution','--product','radix-engine']
ns['run']('release',command)
exec(original.read_text().split("artifact=out/'artifact';")[1].join(["artifact=out/'artifact';", ""]),ns)
