from pathlib import Path
import argparse
import json
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'package'))
from common import digest, read_json, require, verify_package, write_json
from control_validation import trajectories
from compare_radix_engine import mismatch
from results import verify_completed

def comparison(left, right):
    rows = []
    for (label, before), (other, after) in zip(trajectories(left), trajectories(right)):
        differences = mismatch(before, after)
        if label != other or before.get('prompt_render_date') != after.get('prompt_render_date'):
            differences.append('trajectory_identity')
        index = next((index for index, (old, new) in enumerate(zip(before['token_ids'], after['token_ids'])) if old != new), None)
        if index is None and len(before['token_ids']) != len(after['token_ids']):
            index = min(len(before['token_ids']), len(after['token_ids']))
        rows.append({'label': label, 'exact': not differences, 'differences': differences,
            'first_difference_index': index, 'before_ids': before['token_ids'], 'after_ids': after['token_ids'],
            'before_finish': before['finish'], 'after_finish': after['finish']})
    require(len(rows) == 7, 'seven complete trajectories required')
    return {'exact_all_seven': all(row['exact'] for row in rows), 'rows': rows}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest-sha256', required=True)
    args = parser.parse_args()
    binding = verify_package(args.manifest_sha256, ROOT / 'package')
    baseline_root = Path(binding['baseline']['root'])
    baseline_manifest = baseline_root / 'execution-results-manifest.json'
    require(digest(baseline_manifest) == binding['baseline']['results_manifest_sha256'], 'baseline result freeze differs')
    for name, row in read_json(baseline_manifest)['files'].items():
        path = baseline_root / name
        require(path.stat().st_size == row['bytes'] and digest(path) == row['sha256'], 'baseline evidence drift: ' + name)
    baseline_binding = read_json(baseline_root / 'package/binding.json')
    current = {}
    before_after = []
    for cell in binding['cells']:
        directory = ROOT / 'results' / cell['id']
        verify_completed(directory, cell, binding, args.manifest_sha256)
        original = next(value for value in baseline_binding['cells'] if value['id'] == cell['id'])
        original_directory = baseline_root / 'results' / original['id']
        verify_completed(original_directory, original, baseline_binding, binding['baseline']['package_manifest_sha256'])
        report = read_json(directory / 'report.json')
        current[(cell['backend'], cell['mode'], cell['projection'])] = report
        before_after.append({'cell': cell['id'], 'interpretation': 'Descriptive across arithmetic revisions; equality is not required.',
            **comparison(read_json(original_directory / 'report.json'), report)})
    pairs = [((backend, 'off', False), (backend, mode, False)) for backend in ['contiguous','paged'] for mode in ['automatic','serial_target']]
    pairs += [(('contiguous', mode, False), ('paged', mode, False)) for mode in ['off','automatic','serial_target']]
    corrected = [{'left': left[:2], 'right': right[:2], **comparison(current[left], current[right])} for left, right in pairs]
    projection = current[('paged','automatic',True)]['gemma_projection']
    result = {'execution_integrity_valid': True, 'corrected_comparisons': corrected, 'before_after': before_after,
        'projection_versus_control': comparison(current[('paged','automatic',False)], current[('paged','automatic',True)]),
        'projection': projection, 'performance_conclusion': None,
        'baseline_failures_preserved': True, 'source': binding['runtime']['source'], 'profile': binding['profile']}
    write_json(ROOT / 'corrected-complete-comparison.json', result)
    return 0 if all(pair['exact_all_seven'] for pair in corrected) else 2

if __name__ == '__main__': raise SystemExit(main())
