import Foundation
import CoreFoundation
import Jinja
extension JSONValue {
    fileprivate var sendableValue: any Sendable {
        switch self {
        case .null:
            return JSONNull()
        case .bool(let value):
            return value
        case .int(let value):
            return value
        case .double(let value):
            return value
        case .string(let value):
            return value
        case .array(let values):
            return values.map(\.sendableValue)
        case .object(let object):
            return object.mapValues(\.sendableValue)
        }
    }
}

private struct JSONNull: Sendable, Hashable {}


struct Row: Codable { let id: String; let path: String; let inputJSON: String; let bridgedType: String; let jinjaType: String?; let output: String?; let error: String? }
func describe(_ v: Value) -> String {
 switch v {
 case .int(let x): return "int(\(x))"
 case .double(let x): return "double(\(x),bits:\(String(x.bitPattern,radix:16)))"
 case .boolean(let x): return "bool(\(x))"
 case .string(let x): return "string(\(x))"
 case .array(let xs): return "array["+xs.map(describe).joined(separator:",")+"]"
 case .object(let xs): return "object{"+xs.map { $0.key+":"+describe($0.value) }.joined(separator:",")+"}"
 case .null: return "null"
 case .undefined: return "undefined"
 default: return "other"
 }
}
func bridgeDescription(_ value: Any) -> String {
 if let a=value as? [String:Any] { return "object{"+a.keys.sorted().map { $0+":"+bridgeDescription(a[$0]!) }.joined(separator:",")+"}" }
 if let a=value as? [Any] { return "array["+a.map(bridgeDescription).joined(separator:",")+"]" }
 if let n=value as? NSNumber { return "\(type(of:value))(objc:\(String(cString:n.objCType)),cfbool:\(CFGetTypeID(n)==CFBooleanGetTypeID()),value:\(n))" }
 return "\(type(of:value))(\(value))"
}
let numbers=["9223372036854775807","9223372036854775808","18446744073709551615","-9223372036854775808","-9223372036854775809","-0","0","1","1.0","-0.0","1e15","1e16","9007199254740993","1e-7","true","false"]
var inputs=numbers.enumerated().map { ("number_\($0.offset)","{\"v\":\($0.element)}") }
inputs += [("nested",#"{"a":true,"b":false,"c":[true,false,0,1,-0.0,1.0],"n":{"x":false}}"#),("array",#"[true,false,-0.0,1.0]"#),("scalar", "1.0"),("string",#""hello""#),("null","null"),("blank"," ")]
let template=try Template("{{ value | tojson }}")
var rows:[Row]=[]
for (id,raw) in inputs { for path in ["JSONValue/sendableValue","JSONSerialization/Value(any:)","decodeToolCallArguments/Value(any:)"] {
 var type="not decoded"
 do {
 let any:Any
 switch path {
 case "JSONValue/sendableValue": let v=try JSONDecoder().decode(JSONValue.self,from:Data(raw.utf8)); type=String(describing:v); any=v.sendableValue
 case "JSONSerialization/Value(any:)": any=try JSONSerialization.jsonObject(with:Data(raw.utf8),options:[.fragmentsAllowed]); type=bridgeDescription(any)
 default: any=decodeToolCallArguments(raw); type=bridgeDescription(any)
 }
 let value=try Value(any:any)
 rows.append(Row(id:id,path:path,inputJSON:raw,bridgedType:type,jinjaType:describe(value),output:try template.render(["value":value]),error:nil))
 } catch { rows.append(Row(id:id,path:path,inputJSON:raw,bridgedType:type,jinjaType:nil,output:nil,error:String(describing:error))) }
} }
let e=JSONEncoder();e.outputFormatting=[.sortedKeys,.prettyPrinted]
print(String(decoding:try e.encode(rows),as:UTF8.self))
