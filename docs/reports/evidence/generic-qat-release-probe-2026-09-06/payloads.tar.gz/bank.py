from pathlib import Path
import gzip, hashlib, io, json, tarfile

out = Path(__file__).resolve().parent
build = Path('/tmp/darkbloom-generic-qat-release-probe1')
worktree = Path('/Users/gaj/Documents/DarkbloomDev/wt/logit-diagnostic-generic-reducer')
destination = worktree/'docs/reports/evidence/generic-qat-release-probe-2026-09-06'
sha = lambda data: hashlib.sha256(data).hexdigest()
manifest_raw = (build/'manifest.json').read_bytes()
assert sha(manifest_raw) == '61672b2d984cfa5a26fe5febdd3b957122d3899e00394312c249a49482a65eba'
manifest = json.loads(manifest_raw)
payloads = {'bank.py': Path(__file__).read_bytes(), 'build/manifest.json': manifest_raw}
excluded = {}
for name, row in manifest['files'].items():
    path = build/name; data = path.read_bytes()
    assert sha(data) == row['sha256'] and len(data) == row['bytes']
    assert oct(path.stat().st_mode & 0o777) == row['mode']
    if name.startswith('artifact/'):
        excluded[name] = row
    else:
        payloads['build/'+name] = data
assert len(excluded) == 7
payloads['excluded-runtime-files.json'] = (json.dumps({
    'reason': 'Executable and six runtime resources are excluded from the repository archive. Their exact hashes/sizes/modes remain in the original build manifest and artifact proofs.',
    'files': excluded,
}, indent=2)+'\n').encode()
for name, digest in [
    ('darkbloom-generic-qat-release-probe-root-review1.json', 'f368054076f07cfe6f22e1f50f0848cade024a2e615ca5b16878f37dba41ba06'),
    ('darkbloom-generic-qat-release-probe-root-final-review1.json', '8c4a47d7510e5489c59c0218a447cbe1cb481a32c6c85d43ab95ebeba0d81eb2'),
]:
    data = (Path('/tmp')/name).read_bytes(); assert sha(data) == digest
    payloads['root-reviews/'+name] = data
plan = Path('/tmp/darkbloom-qat-actual-logits-plan2')
execution = Path('/tmp/darkbloom-qat-actual-logits-execution3')
for label, root, names in [
    ('qat-plan', plan, ['manifest.json', 'plan.json', 'source-correspondence.json']),
    ('qat-controller', execution, ['preparation-manifest.json', 'preparation-summary.json', 'runtime-binding.json',
                                 'run_cell.py', 'driver-delta.patch', 'successor-driver-tests.log', 'test_successor_driver.py']),
]:
    for name in names: payloads[label+'/'+name] = (root/name).read_bytes()
files = {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in sorted(payloads.items())}
buffer = io.BytesIO()
with tarfile.open(fileobj=buffer, mode='w') as packed:
    for name, data in sorted(payloads.items()):
        entry = tarfile.TarInfo(name); entry.mode = 0o644; entry.mtime = 0; entry.size = len(data)
        packed.addfile(entry, io.BytesIO(data))
archive = gzip.compress(buffer.getvalue(), mtime=0)
destination.mkdir(parents=True)
(destination/'payloads.tar.gz').write_bytes(archive)
record = {
    'scope': 'Exact committed optimized probe, parser smokes and source-only QAT retry handoff; no model outcome, numerical/performance acceptance or release activation.',
    'parent_commit': '6790dea1c7044ca336cd6383aac7e6d27afb7359',
    'native_commit': 'b01e1af06902c82e22227bf923447cc71c47b148',
    'original_build_manifest_sha256': sha(manifest_raw),
    'files': files, 'payload_count': len(files), 'payload_bytes': sum(row['bytes'] for row in files.values()),
    'excluded_runtime_files': excluded,
    'archive': {'path': 'payloads.tar.gz', 'bytes': len(archive), 'sha256': sha(archive)},
    'included_subset_note': 'Original build and QAT manifests are retained provenance. Only this manifest describes the complete archive; the seven runtime files and unchanged QAT packet inputs/helpers are not copied here.',
}
(destination/'manifest.json').write_text(json.dumps(record, indent=2)+'\n')
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as packed:
    assert set(packed.getnames()) == set(files)
    for name, row in files.items():
        data = packed.extractfile(name).read()
        assert sha(data) == row['sha256'] and len(data) == row['bytes']
print(json.dumps({'manifest_sha256': sha((destination/'manifest.json').read_bytes()),
                  'archive': record['archive'], 'payload_count': len(files), 'payload_bytes': record['payload_bytes']}, indent=2))
