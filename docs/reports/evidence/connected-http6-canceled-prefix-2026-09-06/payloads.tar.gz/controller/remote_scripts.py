CREATE='''from pathlib import Path
import datetime,shutil
root=Path(C['remote'])
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-09-06'
assert shutil.disk_usage(root.parent).free>100*(1<<30)
root.mkdir(exist_ok=False)
'''
EXTRACT='''from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,tarfile
root=Path(C['remote'])
assert hashlib.sha256((root/'approved-root-review.json').read_bytes()).hexdigest()==C['review_sha']
archive=root/'transfer.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==C['archive_sha']
with tarfile.open(archive) as tar:
 members=tar.getmembers()
 assert len(members)==C['members'] and len({m.name for m in members})==C['members']
 for member in members:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  assert not (root/member.name).exists()
 tar.extractall(root)
assert hashlib.sha256((root/'package-manifest.json').read_bytes()).hexdigest()==C['manifest_sha']
sys.path.insert(0,str(root))
from verify_package import verify_package
verified=verify_package(root)
(root/'runtime').mkdir(exist_ok=False)
print(json.dumps({'package':verified,'remote_root':str(root),'manifest_sha256':C['manifest_sha'],'inference_launched':False},indent=2))
'''
RUNTIME='''from pathlib import Path
import hashlib,json,os,shutil,stat
root=Path(C['remote']);binding_path=root/'runtime-binding.json'
assert hashlib.sha256(binding_path.read_bytes()).hexdigest()==C['binding_sha']
binding=json.loads(binding_path.read_text());target=root/'runtime';source=Path(binding['resources_copy_source'])
def verify(p,item):
 info=p.lstat();assert stat.S_ISREG(info.st_mode) and not p.is_symlink()
 assert info.st_size==item['bytes'] and stat.S_IMODE(info.st_mode)==int(item['mode'],8),str(p)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],str(p)
assert {p.name for p in target.iterdir()}=={'darkbloom'}
verify(target/'darkbloom',binding['files']['darkbloom'])
for name,item in binding['files'].items():
 if name!='darkbloom':verify(source/name,item)
for name,item in binding['files'].items():
 if name!='darkbloom':
  destination=target/name;destination.parent.mkdir(parents=True,exist_ok=True)
  assert not destination.exists();shutil.copy2(source/name,destination)
for name,item in binding['files'].items():verify(target/name,item)
assert {str(p.relative_to(target)) for p in target.rglob('*') if p.is_file()}==set(binding['files'])
assert os.access(target/'darkbloom',os.X_OK)
result={'status':'RUNTIME_VERIFIED','binding_sha256':C['binding_sha'],'files':binding['files'],'runtime_root':str(target),'inference_launched':False}
(root/'runtime-transfer-receipt.json').write_text(json.dumps(result,indent=2)+'\\n')
print(json.dumps(result,indent=2))
'''
CHECK='''from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,sys
root=Path(C['remote'])
assert hashlib.sha256((root/'approved-root-review.json').read_bytes()).hexdigest()==C['review_sha']
assert hashlib.sha256((root/'package-manifest.json').read_bytes()).hexdigest()==C['manifest_sha']
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()==C['binding_sha']
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-09-06'
assert shutil.disk_usage(root).free>100*(1<<30)
assert not Path(C['output']).exists()
sys.path.insert(0,str(root))
from verify_package import verify_package
package=verify_package(root)
binding=json.loads((root/'runtime-binding.json').read_text())
for name,item in binding['files'].items():
 p=root/'runtime'/name;info=p.lstat()
 assert stat.S_ISREG(info.st_mode) and not p.is_symlink() and info.st_size==item['bytes']
 assert stat.S_IMODE(info.st_mode)==int(item['mode'],8) and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],name
assert os.access(root/'runtime/darkbloom',os.X_OK)
print(json.dumps({'package':package,'date_utc':'2026-09-06','review_sha256':C['review_sha'],'fresh_output':C['output'],'free_disk_bytes':shutil.disk_usage(root).free},indent=2))
'''
INVENTORY='''from pathlib import Path
import hashlib,json
root=Path(C['output'])
launch=json.loads((root/'launch.json').read_text())
assert launch['status'] in ('completed','failed'), 'Remote cell may still be live; inspect its existing handle'
files={}
for name in ['launch.json','connected.log','evidence/report.json']:
 p=root/name
 if p.is_file():files[name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'root':str(root),'launch_status':launch['status'],'files':files},indent=2))
'''
