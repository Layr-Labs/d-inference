# Coordinator signed cache cost review

Source base: 69a75de82813beaf753fbbb4891c3b3261b63600. Parent subsequently advanced to 2dcec357414cf59ec3347febb9f5ee655d89aae7 without coordinator source changes. This isolated change does not alter rollout defaults, model/provider execution, admission authority, receipt identity or cancellation policy.

## Finding and implementation

Before this change, a valid hint with stage time greater than its age-weighted saved prefill was discarded. The provider still attempted that endpoint, so routing omitted its extra first-token blocking cost. A single signed calculation now prices `delta = -min(1, saved/coldPrefill) * pricedPrefill`, where `saved = weight * min(savedTokens,promptTokens)/rate*1000 - stage`. Positive savings retain the existing discount limits; negative savings add excess restore cost to ThisReqMs. Both use the same prefill multiplier and count stage once. Other service terms and the ordinary full-N/TTFT gates remain unchanged. Candidate selection uses exact adjusted cost for either sign; no-hint and fully capped positive-benefit pools retain their existing load spreading.

Example covered by the actual Prepare/Lookup/Ready/Reserve path: a 4096-token checkpoint on a 5000 TPS provider with a 900 ms restore adds 80.8 ms. For a 4352-token prompt, the provider's prefill-related cost becomes 951.2 ms rather than the cold 870.4 ms; a 4800 TPS cold peer costs 906.667 ms, so it wins. These are deterministic scheduler estimates, not network or model measurements. Tests also cover useful-hit wins, queue/decode/backlog overrides, complete-N capacity, unchanged normal TTFT gates, necessary expensive-only service, and a changed provider rate between scan and commit.

## Provider execution audit

Read-only source at the same parent base:

- provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge+Submission.swift: an eligible complete-checkpoint store is awaited before engine submit. The request gate checks scope/cache-enabled state, media and backend availability; it does not compare SSD latency to expected prefill latency.
- provider-swift/Sources/ProviderCore/KVCacheSSD/SSDHybridCheckpointStore+Read.swift: candidate walks hashes deepest-first, filters expiry, minimum token length, read bytes and configured maximum estimated stage time, then selects the first valid endpoint. It authenticates and stages that endpoint; there is no implicit cold bypass on negative net prefill savings.
- provider-swift/Sources/ProviderCore/KVCacheSSD/SSDPrefixCachePolicy.swift: default maximum stage estimate is 1000 ms. The integration test's 900 ms stage fits this policy. A min-effective-token threshold is not a per-provider measured benefit calculation.

Unpublished checkpoints, eviction, stream admission or actual IO may still differ from receipt evidence. These estimates remain advisory; no provider endpoint-selection command or latency claim was introduced.

## Telemetry boundary

RoutingDecision.CacheTier and signed CacheEstimatedTTFTSavedMs distinguish a chosen expensive hit from a no-hint request. Debug routing_decision includes cache_estimated_ttft_saved_ms as a numeric field, with the existing validated tier. Excess cost stays in ThisReqMs so the existing persisted cost sum remains complete; no wire, database or metric-label schema changes.

PendingRequest.CacheSelectionSelected and its savings fields remain positive-credit-only. Consequently api/exact_cache_telemetry.go's exact_cache_estimated_ttft_saved_ms histogram retains its existing positive-benefit meaning, not signed net performance. Canonical architecture docs state this explicitly. Provider actual lookup/stage usage telemetry is unchanged.

## Separate Prepare/configuration finding (not changed here)

PrepareCacheAttempt in coordinator/registry/cache_receipts.go holds no registry lock when invoking PreparePrefixCacheV2Attempt. The latter repeatedly reads r.cacheRouting in its Lock/store/len/enforce/Unlock block. ConfigureCacheRouting replaces that pointer under r.mu; concurrent reconfiguration can therefore mix tracker locks and maps. Preparing an already-created plan has no mode/generation validation before exposing its remote scope. Root assigned a separate generation-bound Prepare/cleanup worktree after this milestone. No live configuration changes were performed.

## Verification scope

Only Go CPU tests and microbenchmarks ran. No Swift/Metal/model builds, GPU execution, network latency measurements, default flips, primary edits, commits or deployment. Raw evidence includes initial fixture mistakes and corrected exact-final-fixture baseline failures; successful candidate evidence is named separately. Root source review accepted the production math and docs before freeze. The final manifest records exact sources, patches and evidence hashes.

## Bounded microbenchmark results

Five 200 ms samples per revision, Go 1.25.0 on the same Apple M3 Max. This shared workstation was not reserved for a latency experiment; baseline holder-index samples overlapped the tail of the API suite. Medians are diagnostic observations only. Pricing stays allocation-free. The 350-candidate selector's cold-pool median increased by 209 ns (about 18% of this sub-microsecond-to-microsecond helper); cached-pool median increased by 68.3 ns. The hint index code is unchanged and retains identical allocation counts; no routing speedup or seconds saved is claimed.

| Benchmark | Baseline ns/op | Candidate ns/op | Candidate allocs/op |
|---|---:|---:|---:|
| BenchmarkCacheServiceCost/useful_hit-14 | 50.670 | 48.660 | 0 |
| BenchmarkCacheServiceCost/expensive_stage-14 | 46.630 | 48.620 | 0 |
| BenchmarkCacheServiceCost/stale_hint-14 | 40.920 | 39.240 | 0 |
| BenchmarkSelectRoutingCandidate/providers=1/cache=false-14 | 4.620 | 4.437 | 0 |
| BenchmarkSelectRoutingCandidate/providers=1/cache=true-14 | 4.621 | 4.414 | 0 |
| BenchmarkSelectRoutingCandidate/providers=32/cache=false-14 | 106.800 | 98.810 | 0 |
| BenchmarkSelectRoutingCandidate/providers=32/cache=true-14 | 67.840 | 73.230 | 0 |
| BenchmarkSelectRoutingCandidate/providers=350/cache=false-14 | 1134.000 | 1343.000 | 0 |
| BenchmarkSelectRoutingCandidate/providers=350/cache=true-14 | 895.500 | 963.800 | 0 |
| BenchmarkCacheHolderIndex/providers=16/boundaries=64/holders=4/content_index-14 | 42320.000 | 41745.000 | 1166 |
| BenchmarkCacheHolderIndex/providers=128/boundaries=64/holders=4/content_index-14 | 44005.000 | 42866.000 | 1166 |
| BenchmarkCacheHolderIndex/providers=512/boundaries=64/holders=4/content_index-14 | 50979.000 | 47929.000 | 1166 |
