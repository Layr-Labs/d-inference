# One-owner raw attention packet: source review

This uncompiled candidate adds one bounded native tensor packet to the existing
ordinary decode path. It is based on banked parent384c321aa/nativee972340; the
owner-identity fix is inherited, not duplicated in the patch. Fifteen native and
seven benchmark/wrapper files change. No provider production file changes.

## Binding, evaluation and lifetime

The packet selects request/output and one dense storage owner independently of
metadata and logit selections. It binds the concrete cache object through the
approved owner identity helper, preserving original contiguous model indices.
Forward defer clears the packet binding without touching the metadata binding.
Unsupported MTP, batch/width, full-history, shared-KV, sink/softcap/span geometry
or byte budgets refuse explicitly.

The selected cache retains original transformed Q, incoming K/V, post-update
native stored K/V, and actual returned output. Conservative FP32 reservation is
checked before retention or paged gather; native payloads are capped at 32 MiB.
Paged capture uses the existing ordinary gather and its published read back-edge.

The six original handles join that same step's existing asyncEval targets.
Attaching the packet to the returned step disables its chained successor before
the launch decision, including when the selected step is itself a chained decode.
Normal sample confirmation and step-cost accounting precede host materialization.
Before any asData call, the pinned nonblocking Cmlx availability query must report
every original handle available. A pending graph is refused, not evaluated by the
diagnostic. Native packed copies survive; MLX handles are released on retirement,
discard, failed forward, drain and shutdown.

## Host export and proof scope

The benchmark writes the agreed `darkbloom.attention-packet.v1` schema with a hashed
raw one-owner metadata snapshot, six hashed native buffers, actual loaded model
aggregate hash and the hash of the same bytes used to parse benchmark inputs.
The descriptor is written last into a fresh private directory. The CLI/probe
executable identity stays in separate run evidence. Trace timing is diagnostic
overhead and is not performance evidence.

This source adds no same-input native backend replay or independent full-history
mirror. The offline analyzer is already banked separately. Within-arm reference,
cross-backend input equality, storage history and operator replay remain distinct
proofs; no release accuracy or parity claim follows from this capture source.

## Validation staged, not yet run in Swift

- Native D256/QH16/KVH2 raw roundtrips for three backends and FP16/BF16/FP32;
  original wider Q, partial partitions beyond 4096, budget/geometry refusal.
- Gather read fencing against an adversarial overwrite and actual recycled pages;
  discarded/unconfirmed/failed handles drain; an unfenced graph cannot materialize.
- Actual engine controls for direct/chained, original noncontiguous owner indices,
  BF16 bytes, preserved ordinary/recurrent forward counts and generated tokens.
  The next actual model forward observes whether raw handles retired, rather
  than relying only on a manually constructed step's flag.
- Actual selected cancellation and typed post-forward unwind; simultaneous and
  independent metadata/logit/packet configurations; bindings and shutdown cleanup.
- Benchmark option and native-byte export/identity/budget/refusal tests.

Fourteen Python wrapper tests pass with retained raw output. Source diff checks
and application checks against current primary pass. Swift tests, optimized packet
build and actual-model capture remain unrun pending source review and lane handoff.

The availability query, native byte copy and asyncEval completion implementation
are copied and hashed from the same pinned dependency source used by the validated
owner-fix build. They are evidence, not edits to that dependency.
