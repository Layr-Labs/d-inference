# Receipt lifetime validation

The original successful-submit defer removes the complete-store ready receipt before the engine reaches terminal. The new real-engine gated-forward negative control reproduced readyReceipts.count 0 (expected 1), then the missing durable callback. Exact original provider source and candidate tests are preserved separately.

The reviewed six-line provider ownership fix passed both new tests and all 14 requested regression filters: 88 distinct test functions, 92 executions because four OuterPrefixCacheReceiptTests were selected twice by overlapping filters. No tests were weakened or skipped. Native diagnostics were present but unconfigured (nil). Tiny local model fixtures only; no downloaded models or network.

The successful baseline build was followed by a runner-only source-path assertion failure caused by the compiler naming native inputs through the workspace symlink. Original run.py, successful build, and runner-provenance-correction.json remain. run-resume.py resolves actual graph paths and reused the already successful baseline binary, then ran the negative control and candidate build/tests. All source hashes and complete owned compiler graph mappings are retained for each variant. No implementation correction occurred.

This validates receipt ownership lifecycle, cancellation, encrypted-store publication and the existing requested regressions. Real HTTP publication, numerical backend parity and release rollout remain separate gates.
