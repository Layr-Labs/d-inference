#!/usr/bin/env python3
"""Verify the capsule and recompute strict token comparisons without model execution."""
from pathlib import Path
import hashlib,json,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'capsule-manifest.json').read_text())
for name,wanted in manifest['files'].items():
 path=root/name
 assert path.is_file() and not path.is_symlink() and path.stat().st_size==wanted['bytes'],name
 assert hashlib.sha256(path.read_bytes()).hexdigest()==wanted['sha256'],name
 assert path.suffix not in {'.safetensors','.metallib','.dylib','.key','.pem'},name
 assert 'prefix-cache' not in Path(name).parts,name
original=json.loads((root/'raw/pilot-evidence-manifest.json').read_text())
for name,wanted in manifest['raw_source_files'].items():
 assert original['files'][name]['sha256']==wanted['sha256']
 assert hashlib.sha256((root/'raw'/name).read_bytes()).hexdigest()==wanted['sha256']
frozen=json.loads((root/'frozen-plan-manifest.json').read_text())
for path in (root/'frozen-evaluator').glob('*.py'):
 assert hashlib.sha256(path.read_bytes()).hexdigest()==frozen['files']['runner/'+path.name]['sha256']
source=json.loads((root/'raw/source-manifest.json').read_text())
audit=json.loads((root/'source-audit.json').read_text())
for name,wanted in audit['files'].items():
 repo,relative=name.split('/',1)
 assert wanted['sha256']==source['files'][repo][relative]['sha256']
 assert hashlib.sha256((root/'audit-sources'/name).read_bytes()).hexdigest()==wanted['sha256']
sys.path.insert(0,str(root/'frozen-evaluator'))
from compare_radix_engine import compare
binding=json.loads((root/'raw/m5.runtime-binding2.json').read_text());ids=binding['reviewed_cell_ids']
reports=[json.loads((root/'raw/results'/name/'report.json').read_text()) for name in ids]
assert compare(reports[0],reports[1],False,'backend')['passed']
cache=compare(reports[1],reports[2],True,'cache');assert not cache['passed']
assert cache['errors']==[{'id':'long-repeat-b0','differences':['token_ids']}]
rows=[row for report in reports for row in report['rows']]
assert len(rows)==12 and all(row['prompt_token_ids']==rows[0]['prompt_token_ids'] for row in rows)
vectors={tuple(row['token_ids']) for row in rows};assert len(vectors)==2
b1=reports[0]['rows'][1]['token_ids']
assert all(report['rows'][1]['token_ids']==b1 and report['rows'][3]['token_ids']==b1 for report in reports)
assert reports[2]['rows'][2]['token_ids']==b1
print(json.dumps({'files_verified':len(manifest['files']),'raw_files_verified':len(manifest['raw_source_files']),
 'backend_comparison_passed':True,'cache_comparison_passed':False,'full_trajectories':2,
 'cached_repeat_b0_equals_all_b1':True,'restore_byte_equality':'UNPROVEN','model_execution':False},indent=2))
