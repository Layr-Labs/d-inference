from pathlib import Path
import hashlib,json,shutil
out=Path('/tmp/darkbloom-q36-attention-kernel-validation1');base=Path('/tmp/darkbloom-q35-mtp-useful-tail-validation1');source=Path('/tmp/darkbloom-q36-attention-kernel-geometry1');native=out/'native';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
for root,expected in [(base,'073c7d90589ba2425b3b98d9960a0fc8daafd3915ee461ea2251e86473e389cd'),(source,'0df3bafae2c2f3b0dfdbde1ec774467e26523f36027349ccb8ef1fff3f373c18')]:
 assert sha(root/'manifest.json')==expected
 for p,row in json.loads((root/'manifest.json').read_text())['files'].items():assert sha(root/p)==row['sha256'],str(root/p)
manifest=json.loads((base/'native-source-manifest.json').read_text())
for p,d in manifest['files'].items():assert sha(base/'native'/p)==d,p
shutil.copytree(base/'native',native);change=json.loads((source/'source-check.json').read_text());name=change['path'];assert sha(native/name)==change['before_sha256'];shutil.copy2(source/'after.swift',native/name);manifest['files'][name]=change['after_sha256'];write('native-source-manifest.json',manifest)
ancillary={str(p.relative_to(native)):sha(p) for p in sorted(native.rglob('*')) if p.is_file() and str(p.relative_to(native)) not in manifest['files']};write('ancillary-package-manifest.json',{'scope':'Complete frozen baseline canonical package inputs beyond original481 owned source manifest; no diagnostic overlays.','files':ancillary})
for name in ['dependency-source-manifest.json','jinja-source-manifest.json']:shutil.copy2(base/name,out/name)
for name in ['source-check.json','candidate.patch','AUDIT.md']:shutil.copy2(source/name,out/name)
write('integration.json',{'base_validation_manifest':str(base/'manifest.json'),'base_sha256':sha(base/'manifest.json'),'source_freeze_manifest':str(source/'manifest.json'),'source_sha256':sha(source/'manifest.json'),'root_review':'/tmp/darkbloom-q36-attention-kernel-root-review.json','root_review_sha256':sha(Path('/tmp/darkbloom-q36-attention-kernel-root-review.json')),'native_source_base':'a932d38cee0beca41ca1a0e71c1e867913a65353','scratch':'/tmp/darkbloom-allocator-footprint-foundation1/build-swift','native_inputs':len(manifest['files']),'ancillary_inputs':len(ancillary),'production_source_changed':False,'diagnostic_patch_included':False,'prerequisite':'Build8 both release products finish first; no parallel local lane.'})
print('Geometry source-only preparation complete:',len(manifest['files']),len(ancillary))
