# Source3: bind both hosts to the same complete runtime

The explicit-host input now requires both RuntimeFiles maps to contain exactly
the same paths, SHA-256, byte sizes and modes, in addition to the existing global
executable/metallib hash pins. This includes pagedattention.metal and every other
selected bundle resource, so the hosts cannot silently run different kernels.

One binding function and its regression test change. Planted differing bundle
hash/size/mode and missing-bundle cases refuse before local model reads. The
changed function's race-enabled Go test and all its subtests pass. The exact
source1 broader Go/race results and source2 Python18 results are carried; no
unchanged Python tests, real providers, models, remote, Swift/GPU, keys, signing
or production operations were rerun. Source1 and source2 remain immutable.
