import json
C=json.loads('{"remote": "/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http6-q38", "output": "/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http6-q38/runs/qwen38-paged-ssd-b1-run", "review_sha": "91a25b23cb7be34e6bc3f35a63a2bc680bfaad96490cde7e4f1c3c5a385b6e35", "manifest_sha": "82e81db534ea14e80b3f3f2502949b25bc77768e887fdb2755fdab674dddbd0e", "binding_sha": "401c59e24a3acf88186e03eef9b48c86bbce372fefa6e1c7c9238ef693044b82"}')
from pathlib import Path
import datetime,hashlib,json,os,shutil,stat,sys
root=Path(C['remote'])
assert hashlib.sha256((root/'approved-root-review.json').read_bytes()).hexdigest()==C['review_sha']
assert hashlib.sha256((root/'package-manifest.json').read_bytes()).hexdigest()==C['manifest_sha']
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()==C['binding_sha']
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-09-06'
assert shutil.disk_usage(root).free>100*(1<<30)
assert not Path(C['output']).exists()
sys.path.insert(0,str(root))
from verify_package import verify_package
package=verify_package(root)
binding=json.loads((root/'runtime-binding.json').read_text())
for name,item in binding['files'].items():
 p=root/'runtime'/name;info=p.lstat()
 assert stat.S_ISREG(info.st_mode) and not p.is_symlink() and info.st_size==item['bytes']
 assert stat.S_IMODE(info.st_mode)==int(item['mode'],8) and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],name
assert os.access(root/'runtime/darkbloom',os.X_OK)
print(json.dumps({'package':package,'date_utc':'2026-09-06','review_sha256':C['review_sha'],'fresh_output':C['output'],'free_disk_bytes':shutil.disk_usage(root).free},indent=2))
