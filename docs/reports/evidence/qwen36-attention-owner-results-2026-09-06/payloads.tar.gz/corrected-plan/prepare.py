from pathlib import Path
import copy
import hashlib
import json
import shutil
import sys

OUT = Path('/tmp/darkbloom-q36-attention-owner-identity-plan1')
PRIOR = Path('/tmp/darkbloom-q36-attention-metadata-plan1')
REMOTE = '/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-owner-identity1'
SOURCE = Path('/tmp/darkbloom-q36-attention-owner-identity-source1')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def copy_file(source, name):
    target = OUT / name
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    assert sha(target) == sha(source)


def main():
    sys.dont_write_bytecode = True
    assert sha(PRIOR / 'manifest.json') == '5b8d5c6d665ce10bd3664ccc5eb14892285bf24e5cc9c028d67d146d35104d77'
    assert sha(SOURCE / 'manifest.json') == 'd7d8d892e076df4bc90d6ffbc346d22108ba7a04463bb5a4036938b642506743'
    previous_inventory = json.loads((PRIOR / 'manifest.json').read_text())['files']
    for name, item in previous_inventory.items():
        path = PRIOR / name
        assert sha(path) == item['sha256'] and path.stat().st_size == item['bytes'], name
    OUT.mkdir(exist_ok=False)
    copied = []
    for name in previous_inventory:
        if name.startswith(('inputs/', 'date-proof/', 'runner/')) or name == 'model-manifest.json':
            copy_file(PRIOR / name, name)
            copied.append(name)
    for source, name in [
        (PRIOR / 'plan.json', 'provenance/original-plan.json'),
        (PRIOR / 'manifest.json', 'provenance/original-plan-manifest.json'),
        (Path('/tmp/darkbloom-q36-attention-metadata-execution1/four-cell-review.json'), 'provenance/original-four-cell-review.json'),
        (SOURCE / 'manifest.json', 'source-manifest.json'),
        (Path('/tmp/darkbloom-q36-attention-owner-identity-root-source-review.json'), 'source-review.json'),
        (Path('/tmp/darkbloom-q36-attention-owner-identity-root-release-union-review.json'), 'source-union-review.json'),
        (Path('/tmp/darkbloom-q36-attention-owner-identity-release-probe1/integration.json'), 'source-union-preparation.json'),
    ]:
        copy_file(source, name)
    old = json.loads((PRIOR / 'plan.json').read_text())
    union = json.loads((OUT / 'source-union-review.json').read_text())
    sys.path.insert(0, str(OUT / 'runner'))
    import run_radix_engine as wrapper
    cells = []
    for original in old['cells']:
        if original['backend'] != 'contiguous':
            continue
        cell = copy.deepcopy(original)
        for key in ['argv', 'native_argv']:
            cell[key] = [arg.replace(old['remote_root'], REMOTE) for arg in cell[key]]
        index = next(i for i, arg in enumerate(cell['argv']) if arg.endswith('/run_radix_engine.py'))
        args = wrapper.arguments(cell['argv'][index + 1:])
        assert args.cache == args.mtp == 'off' and args.concurrency == 1
        assert args.cache_mode == 'ssd' and args.key_mode == 'ephemeral' and args.production_kv_grant
        assert args.kv_backend == 'contiguous'
        assert args.attention_metadata_position == (62 if cell['trace'] else None)
        assert wrapper.probe_command(args, Path(args.output) / 'report.json') == cell['native_argv']
        assert [arg.replace(REMOTE, old['remote_root']) for arg in cell['argv']] == original['argv']
        cells.append(cell)
    assert len(cells) == 2 and [c['trace'] for c in cells] == [False, True]
    left, right = list(cells[0]['argv']), list(cells[1]['argv'][:-6])
    left[left.index('--output') + 1] = right[right.index('--output') + 1] = 'OUTPUT'
    assert left == right
    guards = copy.deepcopy(old['execution_guards'])
    guards.pop('stop_after_four_cells')
    guards.update(stop_after_two_cells=True, stop_after_failed_or_partial_cell=True,
                  m5_lane_requires_explicit_handoff_after_pilots=True)
    plan = dict(old)
    plan.update(
        schema=2, state='source_and_argv_checked_runtime_unbound',
        scope='Corrected contiguous attention-owner metadata rerun only. Two same-build trace controls; diagnostic only, no numerical or performance acceptance.',
        remote_root=REMOTE, parent_source=union['parent_base'],
        native_base='847e32076abd1c7f2b28660b7deed902f5dec692',
        reviewed_native_commit=union['native_commit'],
        source_overlay_manifest_sha256=sha(OUT / 'source-manifest.json'),
        source_union_review_sha256=sha(OUT / 'source-union-review.json'),
        runtime_binding=None,
        runtime_requirement='New validated optimized owner-corrected probe and six exact build8 resources; separate root-reviewed actual artifact hashes and modes required before staging or execution.',
        cells=cells, execution_guards=guards,
        original_evidence_policy='Original four-cell attempt remains failed on contiguous owner capture. Original paged results remain original-build evidence; this pair does not form a mixed-build quartet.',
        comparisons=[
            'Run unchanged strict per-cell report integrity; require contiguous backend, no fallback, cache-off, MTP-off, B1, production grant, exact model/input/runtime/date binding, and no unexpected diagnostic in control.',
            'Compare same-build trace-off/on prompt IDs and every generated ID/finish/count for both main rows, all tenant rows, donor and recovery. Each canceled output must match its own recovery prefix; do not require timing-dependent cancel counts equal.',
            'Require first main prompt5523, confirmed ordinary output index62, matching seed11346 and actual selected target/logit IDs; no teacher forcing or MTP draft.',
            'Require metadata captured with one selected successful forward, no refusals and exactly ten unique dense owners0..9 mapped to model layers3,7,...39. Require B1/L1, chained_decode, offset5584→5585.',
            'Reconcile metadata request/output/seed/target/phase with its actual generated IDs and logit record, preserving original Q, native KV, kernel output and outward output dtypes separately.',
            'Record historical contiguous ID comparison as a cross-build diagnostic only. Never combine old paged rows with this pair for new same-build backend acceptance.',
            'No accuracy, hidden/KV/recurrent-state equivalence or performance claim. Original strict cross-backend failure remains open; full numeric packet and independent reference still required.',
        ],
        cpu_validation=dict(parsed_commands=2, all_selected_arguments_equal_to_original_except_new_root=True,
                            input_bytes_unchanged=True, only_trace_flags_and_output_path_differ=True,
                            expected_prefix_plan_unchanged=True, complete_prompt_ID_equality_requires_runtime=True,
                            runtime_unbound=True, model_launched=False))
    write('plan.json', plan)
    write('source-correspondence.json', dict(original_manifest_sha256=sha(PRIOR / 'manifest.json'),
          copied_payloads={name: previous_inventory[name] for name in copied},
          exact_input_sha256=sha(OUT / 'inputs/qwen36.json'), commands_equal_except_new_root=True,
          selected_original_cells=[cell['id'] for cell in cells], remote_calls_made=False))
    (OUT / 'REVIEW.md').write_text(
        'Two contiguous Qwen3.6 controls use the corrected owner-identity probe: trace off, then trace on. '
        'All input/model/date/backend/cache/MTP/concurrency and native arguments match the prior plan, except the fresh root. '
        'The probe hash is unbound until the optimized build is reviewed. No model or remote call is authorized by this package.\n\n'
        'Retain the failed original contiguous capture and the original-build paged results. This pair is not a replacement mixed-build quartet. '
        'Require all ten attention owners, exact same-build completed trajectories, and authoritative selected-forward/logit identity. '
        'This diagnostic provides no numerical accuracy or performance waiver.\n')
    copy_file(Path(__file__), 'prepare.py')
    files = {str(p.relative_to(OUT)): {'bytes': p.stat().st_size, 'sha256': sha(p),
             'mode': oct(p.stat().st_mode & 0o777)} for p in sorted(OUT.rglob('*')) if p.is_file()}
    write('manifest.json', dict(state=plan['state'], files=files))
    print(json.dumps(dict(root=str(OUT), payloads=len(files), manifest_sha256=sha(OUT / 'manifest.json'),
                          runtime_binding=None, model_launched=False, remote_calls_made=False), indent=2))


if __name__ == '__main__':
    main()
