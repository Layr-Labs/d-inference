This is a source integration preview only. It is uncompiled, unrun, unaccepted, and uncommitted. Primary and every frozen source worktree are unchanged.

Base: native 990475e3ae6f93615bebe0fc36e352aa601ea4a5. The union contains 58 paths (41 library, 17 test). Package.swift, build products, dependency checkouts, provider files, and unrelated working changes are excluded. No model/default rollout switch is performed here.

Input order and lineage:
1. Foundation4 native15 snapshot from its exact owned-manifest.json, cumulative over native990. This includes original footprint sizing/settlement plus the fresh-segment captured-stream completion fence and error priority.
2. Foundation5's sole native test change in CBv2PagedCheckpointAdoptionTests: evaluate the throwing buffer getter before the Testing macro. Foundation validation remains independently in progress; later fixture fixes are not implied by this snapshot.
3. Codec17, metadata14, direct-export4 freeze2, and initial IO capability2.
4. Auxiliary21 freeze2 and fresh auxiliary fence5. Auxiliary physical sizing depends on the separately reviewed allocator policy12 dependency follow-up; this native patch does not include or substitute dependency source.
5. Historical29 freeze2, including full-source refusal for window/ring storage.
6. Historical freeze3's exact three-file delta: PagedSegmentTransfers, HistoricalWindowCapture, and HistoricalWindowCheckpointTests. The historical owner captures its concrete stream before construction and retains it across task-local scope exit, with custom-stream retirement tests.
7. Test-only macro1 and macro2 follow-ups, preserving assertions while evaluating throwing getters before Testing macros.

Every input manifest is archived in inputs/ with the original manifest hash and source path recorded in assembly.json. Every intermediate path merge is recorded there. Unrelated allocator dependency/build overlays were not copied.

Explicit source resolutions (only two):
- CompleteCheckpointCapture retains historical optional `codec.recurrentSpec?.layers ?? []` and the auxiliary physical `captureBytes` pricing after shape validation. The old logical descriptor-pricing loop is removed. Historical launch/commit/failure retirement code remains intact.
- CompleteCheckpointTransfer selects auxiliary tensors using historical `codec.targetTensorCount` while retaining the fresh batch's captured allocationStream and ErrorBox success/catch fence. IO usesProcessMemoryOwner metadata and actual staged.nativeDestinationBytes remain intact.

Clean overlapping integrations were also audited: EngineV2 retains allocator-aware cold recurrent/MTP sizing plus optional historical codec selection; ImportPlan keeps canonical owning tensor count and window geometry plus per-buffer bounds/scalar scratch; PagedCheckpointFrame keeps its combined actual target+aux settlement and active move; foundation fixture corrections and new segment error-priority tests survive the auxiliary test edits. All old settleTargetAfterEvaluation calls are gone. Runtime dtype fault retirement remains inherited from native990 and the historical launch failure paths.

Test-only integration corrections:
- macro1 moved three buffer getter calls outside Testing macros in CBv2AuxiliaryFootprintTests.
- macro2 moved the detached-adoption getter outside #require and separated the fresh-view #require from #expect; assertions unchanged. Its exact two-file incremental manifest is recorded as an input.

Source checks: all 58 worktree hashes match this snapshot; actual modified/untracked path set equals the 58 declared paths; patch parsed path set equals that set; patch applies to saved native990 before-images; git diff whitespace check passes; Package.swift equals native990. These are integrity checks, not compilation, behavioral validation, or performance evidence.

Remaining validation obligations: reviewed allocator policy12 must be combined with the corrected allocator dependency foundation; the sole lane must compile the merged native union and run its suites before any acceptance or milestone commit. Foundation5's test run may identify additional rounding-fixture corrections, which must be incorporated with explicit lineage. Existing real-model/fleet rollout gates, alias ownership, cancellation, historical boundaries, mixed-slot/tight-cap capacity, and latency tests remain required. Conservative C-only MTP history bounds can materially reduce capacity; no persistent auxiliary M credit or speedup is claimed.
