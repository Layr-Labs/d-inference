"""Minimal two-control successor: same reviewed QAT probe/input, MTP off."""
from pathlib import Path
import copy
import difflib
import hashlib
import json
import shutil

ROOT=Path(__file__).resolve().parent
OLD=Path('/tmp/darkbloom-qat-actual-logits-plan2')
EXEC=Path('/tmp/darkbloom-qat-mtp-off-execution1')
OLD_EXEC=Path('/tmp/darkbloom-qat-actual-logits-execution3')
BINDING=Path('/tmp/darkbloom-qat-mtp-off-runtime-binding1.json')
REMOTE='/Users/gaj/autoresearch/radix-prefix-cache/090-qat-mtp-off1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def cp(path,relative):
    target=ROOT/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)


def main():
    old=json.loads((OLD/'plan.json').read_text())
    for path in (OLD/'runner').iterdir():
        if path.is_file():cp(path,'runner/'+path.name)
    for name in ['inputs/gemma-qat4.json','assistant-files.json','assistant-inventory.json','model-manifest.json']:
        cp(OLD/name,name)
    cp(OLD/'manifest.json','provenance/original-normal-mtp-plan-manifest.json')
    old_binding=json.loads(Path('/tmp/darkbloom-qat-actual-logits-runtime-binding2.json').read_text())
    cp(Path(old_binding['review']),'provenance/reviewed-runtime.json')
    def move(value):
        if isinstance(value,str):
            if value.startswith(old['remote_root']+'/'):
                return (REMOTE+value[len(old['remote_root']):]).replace('mtp-on-trace-off','mtp-off-trace-off')
            return value
        if isinstance(value,list):return [move(v)for v in value]
        if isinstance(value,dict):return {k:move(v)for k,v in value.items()}
        return value
    cells=[]
    for before in old['cells']:
        if before['trace']:continue
        cell=move(before);cell['id']=before['id'].replace('mtp-on','mtp-off')
        cell['argv'][cell['argv'].index('--mtp')+1]='off'
        for key in ['expected_observed_native_argv','native_argv_preview']:
            cell[key]=['mtp-off'if v=='mtp-on'else v for v in cell[key]]
        cells.append(cell)
    plan={'state':'SOURCE_ONLY_PENDING_ROOT_REVIEW','remote_root':REMOTE,'cells':cells,
        'scope':'Two same-build QAT cache-off/B1/normal-grant MTP-off backend controls, no diagnostics. Determine whether full-token divergence persists outside verification; normal-MTP failure remains separate.',
        'input_sha256':old['input_sha256'],'expected_model_sha256':old['expected_model_sha256'],
        'prompt_tokens':old['prompt_tokens'],'output_cap':old['output_cap'],
        'gates':['Unchanged report integrity, exact runtime/model/input/argv/date and requested/resolved backend with no fallback.',
            'MTP is explicitly off; no logit/attention diagnostics; cache remains off/ephemeral/SSD mode/production grant/B1.',
            'Keep both main repeats, tenant, donor and cancellation recovery validity; cancelled output remains own recovery prefix.',
            'Compare exact whole backend prompt/output IDs, counts and terminal outcomes. Preserve failed comparison if any.',
            'Do not require normal-MTP output prefix or verification context to match these MTP-off controls.'],
        'lifecycle':'Unchanged reviewed serial wrapper and entry/identity/assistant/storage guards, immutable owned roots, original model inputs and 128 output cap.'}
    write(ROOT/'plan.json',plan)
    files={str(p.relative_to(ROOT)):{'sha256':sha(p),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777)}for p in sorted(ROOT.rglob('*'))if p.is_file()}
    write(ROOT/'manifest.json',{'scope':plan['scope'],'files':files})
    binding=copy.deepcopy(old_binding)
    binding.update(remote_root=REMOTE,remote_artifact_root=REMOTE+'/runtime',plan_manifest_sha256=sha(ROOT/'manifest.json'),scope=plan['scope'])
    binding['commands']=[{'cell':c['id'],'wrapper_argv':c['argv'],'expected_observed_native_argv':c['expected_observed_native_argv']}for c in cells]
    write(BINDING,binding)
    strict=(OLD_EXEC/'strict_results.py').read_text()
    strict=strict.replace("report['mtp'] == 'on; production configured assistant'", "report['mtp'] == 'off'")
    strict=strict.replace("        require(rows[0]['token_ids'][:7] == plan['selected_context']['historical_prior_ids'],\n                'selected prior output context changed from the target diagnosis')\n", "        require(cell['trace'] is False, 'MTP-off control must not request diagnostics')\n")
    strict=strict.replace("rows[0]['prompt_token_ids'] == other_report['rows'][0]['prompt_token_ids']\n                    and rows[0]['token_ids'][:7] == other_report['rows'][0]['token_ids'][:7]", "rows[0]['prompt_token_ids'] == other_report['rows'][0]['prompt_token_ids']")
    (EXEC/'strict_results.py').write_text(strict)
    (EXEC/'strict-delta.patch').write_text(''.join(difflib.unified_diff((OLD_EXEC/'strict_results.py').read_text().splitlines(True),strict.splitlines(True),fromfile='normal-MTP strict_results.py',tofile='MTP-off strict_results.py')))
    shutil.copy2(OLD_EXEC/'preflight.py',EXEC/'preflight.py')
    driver=(OLD_EXEC/'run_cell.py').read_text()
    changes={str(OLD):str(ROOT),str(OLD_EXEC):str(EXEC),'/tmp/darkbloom-qat-actual-logits-runtime-binding2.json':str(BINDING),
        sha(OLD/'manifest.json'):sha(ROOT/'manifest.json'),sha(Path('/tmp/darkbloom-qat-actual-logits-runtime-binding2.json')):sha(BINDING),
        sha(OLD_EXEC/'strict_results.py'):sha(EXEC/'strict_results.py'),
        "len(plan['cells']) == 4 and [c['backend'] for c in plan['cells']] == ['contiguous', 'contiguous', 'paged', 'paged']":"len(plan['cells']) == 2 and [c['backend'] for c in plan['cells']] == ['contiguous', 'paged']",
        'Four same-build QAT logit controls with normal MTP; earlier build8 failure remains separate. No performance or numerical acceptance waiver':plan['scope']}
    for before,after in changes.items():driver=driver.replace(before,after)
    needle="        metadata=report.get('attention_metadata')"
    extra="""        if chosen['backend'] == 'paged':
            from compare_radix_engine import compare
            control=json.loads((OUT/plan['cells'][0]['id']/'report.json').read_text())
            (local/'strict-backend-comparison.json').write_text(json.dumps(compare(control,report,axis='backend'),indent=2)+'\\n')
"""
    assert needle in driver;driver=driver.replace(needle,extra+needle)
    compile(driver,str(EXEC/'run_cell.py'),'exec');(EXEC/'run_cell.py').write_text(driver)
    (EXEC/'driver-delta.patch').write_text(''.join(difflib.unified_diff((OLD_EXEC/'run_cell.py').read_text().splitlines(True),driver.splitlines(True),fromfile='normal-MTP run_cell.py',tofile='MTP-off run_cell.py')))
    shutil.copy2(BINDING,EXEC/'runtime-binding.json')
    print(json.dumps({'plan_manifest_sha256':sha(ROOT/'manifest.json'),'plan_payloads':len(files),'binding_sha256':sha(BINDING),'strict_sha256':sha(EXEC/'strict_results.py'),'cells':2},indent=2))


if __name__=='__main__':main()
