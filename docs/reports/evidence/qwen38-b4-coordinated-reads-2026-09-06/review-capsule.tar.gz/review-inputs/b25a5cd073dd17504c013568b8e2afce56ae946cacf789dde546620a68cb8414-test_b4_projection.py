import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import qwen_plan as scoped
from test_qwen_plan import shape_report
import test_radix_forward_shapes as shapes

PREVIOUS = Path("/private/tmp/darkbloom-qwen-first-validation-plan1")


class B4ProjectionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.plan, cls.matrix = scoped.load_plan()

    def test_full_plan_and_all_critical_payload_bytes_unchanged(self):
        self.assertEqual((scoped.ROOT / "plan.json").read_bytes(), (PREVIOUS / "plan.json").read_bytes())
        for relative in scoped.read(PREVIOUS / "manifest.json")["files"]:
            if relative.startswith(("inputs/", "cpu-plans/", "runner/", "provenance/qwen")) or relative in ("matrix_cells.py", "selection-contract.json"):
                self.assertEqual((scoped.ROOT / relative).read_bytes(), (PREVIOUS / relative).read_bytes(), relative)
        self.assertEqual((len(self.plan["cells"]), len(self.plan["pairs"])), (108, 72))

    def test_only_stable_b4_schedule_move(self):
        previous = scoped.read(PREVIOUS / "schedule.json")["execution_order"]
        current = scoped.read(scoped.ROOT / "schedule.json")["execution_order"]
        first = [cell["id"] for cell in self.plan["cells"] if cell["quartet"] == "qwen38-retained-b4-r1"]
        self.assertEqual(current, first + [name for name in previous if name not in first])
        self.assertEqual(set(current), set(previous))
        self.assertEqual(len(current), len(set(current)))
        self.assertEqual([cell["concurrency"] for cell in scoped.select(self.plan, scoped.PILOT)], [4, 4, 4])

    def test_retained_cap_and_natural_eos_not_rewritten(self):
        value = scoped.read(scoped.ROOT / "inputs/retained/qwen38.json")
        for row in value["rows"]:
            self.assertEqual(row["request"]["max_tokens"], 128)
            self.assertEqual(row["case"]["max_tokens"], 128)
            self.assertIsNone(row["case"]["target_length"])
            self.assertNotIn("ignore_eos", row["request"])
        report = shape_report(4)
        for row in report["rows"]:
            row.update(completion_tokens=74, finish="stop")
        self.assertEqual(self.matrix.long_decode_errors(self.plan["workloads"]["retained"], report, 4), [])
        self.assertTrue(self.matrix.actual_model_width_verified(report))
        for batch in report["batches"]:
            batch["forward_shapes"] = shapes.packet(rows=2)
        self.assertFalse(self.matrix.actual_model_width_verified(report))

    def test_actual_b4_not_admission_b2_b1_padding_or_lookahead(self):
        for packet in (shapes.packet(rows=2), shapes.packet(rows=1, columns=4),
                       shapes.packet(rows=2, physical=4), shapes.packet(rows=4, phase="prefill")):
            report = shape_report(4)
            for batch in report["batches"]:
                batch["forward_shapes"] = copy.deepcopy(packet)
            self.assertFalse(self.matrix.actual_model_width_verified(report))
        self.assertTrue(self.matrix.actual_model_width_verified(shape_report(4)))

    def test_b4_selected_acceptance_cannot_promote_full_matrix(self):
        cells = scoped.select(self.plan, scoped.PILOT)
        for live in (2, 4):
            with tempfile.TemporaryDirectory() as directory:
                binding = {"results_root": directory, "_binding_sha256": "cpu-b4"}
                for index, cell in enumerate(cells):
                    output = Path(directory) / cell["id"]; output.mkdir()
                    report = shape_report(4)
                    for batch in report["batches"]:
                        batch["forward_shapes"] = shapes.packet(rows=live)
                    (output / "report.json").write_text(json.dumps(report))
                    (output / "metadata.json").write_text(json.dumps({"status": "completed", "exit_code": 0,
                        "matrix_host": {"id": "m5"}, "matrix_binding_sha256": "cpu-b4",
                        "started_unix": index * 10, "ended_unix": index * 10 + 1}))
                with patch.object(self.matrix, "cell_evidence_errors", return_value=[]), \
                     patch.object(self.matrix, "compare", return_value={"passed": True, "errors": []}):
                    result = scoped.collect(self.plan, self.matrix, binding, cells)
                self.assertEqual(result["all_selected_supported_cells_accepted"], live == 4)
                self.assertFalse(result["qwen_matrix_accepted"])
                self.assertFalse(result["all_matrix_requirements_accepted"])
                self.assertFalse(result["release_gates_satisfied"])

    def test_banked_b2_prerequisite_required_without_reusing_arms(self):
        scoped.require_b2_prerequisite(self.plan)
        original_read = scoped.read
        for kind in ("summary", "backend-comparison", "cache-comparison", "collection-receipt"):
            def changed_read(filename):
                value = original_read(filename)
                if Path(filename).name == kind + ".json":
                    value = copy.deepcopy(value)
                    if kind == "summary":
                        value["cache_passed"] = False
                    elif kind == "collection-receipt":
                        value["archive_sha256"] = "wrong"
                    else:
                        value["actual_model_batch_width_verified"] = False
                return value
            with patch.object(scoped, "read", side_effect=changed_read):
                with self.subTest(kind=kind), self.assertRaisesRegex(ValueError, "B2"):
                    scoped.require_b2_prerequisite(self.plan)
        self.assertFalse(scoped.read(scoped.ROOT / "b2-prerequisite.json")["reuse_as_result_arms"])

    def test_all_original_directories_preserved(self):
        for directory, inventory in scoped.read(scoped.ROOT / "preservation-before.json").items():
            root = Path(directory)
            actual = {str(filename.relative_to(root)): {"sha256": scoped.digest(filename),
                      "bytes": filename.stat().st_size, "mode": filename.stat().st_mode & 0o777}
                      for filename in root.rglob("*") if filename.is_file()}
            self.assertEqual(actual, inventory)


if __name__ == "__main__":
    unittest.main()
