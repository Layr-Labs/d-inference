"""Record detached child ownership around an unchanged frozen runner."""
from pathlib import Path
import json,os,runpy,signal,subprocess,sys,time
REGISTRY=Path(sys.argv[1]);ORIGINAL=sys.argv[2];sys.argv=[ORIGINAL]+sys.argv[3:]
sys.path.insert(0,str(Path(ORIGINAL).parent))
OriginalPopen=subprocess.Popen
SIGNALS=(signal.SIGTERM,signal.SIGHUP,signal.SIGINT)
def append(value):
 descriptor=os.open(REGISTRY,os.O_WRONLY|os.O_CREAT|os.O_APPEND,0o600)
 try:os.write(descriptor,(json.dumps(value,sort_keys=True)+'\n').encode());os.fsync(descriptor)
 finally:os.close(descriptor)
class TrackedPopen(OriginalPopen):
 def __init__(self,*args,**kwargs):
  self._tracked=False;self._exit_recorded=False
  detached=kwargs.get('start_new_session') is True
  old_mask=signal.pthread_sigmask(signal.SIG_BLOCK,SIGNALS) if detached else None
  before=kwargs.get('preexec_fn')
  if detached:
   def child_setup():
    signal.pthread_sigmask(signal.SIG_SETMASK,old_mask)
    if before is not None:before()
   kwargs['preexec_fn']=child_setup
  try:
   super().__init__(*args,**kwargs)
   if detached:
    argv=args[0] if args else kwargs.get('args');self._tracked=True
    try:birth=subprocess.check_output(['/bin/ps','-p',str(self.pid),'-o','lstart='],text=True).strip()
    except subprocess.CalledProcessError:birth=None
    self._ownership={'pid':self.pid,'pgid':self.pid,'parent_pid':os.getpid(),'argv':argv,'birth':birth,'created_unix':time.time()}
    append(dict(self._ownership,event='spawn',role='native' if Path(argv[0]).name=='radix-engine' else 'telemetry' if Path(argv[0]).name=='macmon' else 'owned_detached_child'))
  except BaseException:
   if detached and getattr(self,'pid',None) is not None:
    try:os.killpg(self.pid,signal.SIGTERM)
    except ProcessLookupError:pass
    try:super().wait(timeout=5)
    except subprocess.TimeoutExpired:os.killpg(self.pid,signal.SIGKILL);super().wait(timeout=5)
   raise
  finally:
   if detached:signal.pthread_sigmask(signal.SIG_SETMASK,old_mask)
 def _record_exit(self,value):
  if self._tracked and not self._exit_recorded and value is not None:
   append(dict(self._ownership,event='exit',exit_code=value,ended_unix=time.time()));self._exit_recorded=True
  return value
 def poll(self):return self._record_exit(super().poll())
 def wait(self,*args,**kwargs):return self._record_exit(super().wait(*args,**kwargs))
subprocess.Popen=TrackedPopen
runpy.run_path(ORIGINAL,run_name='__main__')
