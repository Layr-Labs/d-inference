from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile

REPO = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
PLAN = Path('/tmp/darkbloom-q36-attention-metadata-probe-plan2')
EVIDENCE = REPO / 'docs/reports/evidence/attention-metadata-2026-09-06'
STAGE = Path('/tmp/darkbloom-attention-metadata-bank1')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == '5b93195c93efce01a4d455f8e2d0f04e68268096'
    assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=REPO, text=True).strip() == 'M libs/mlx-swift-lm'
    STAGE.mkdir(exist_ok=False)
    payloads = STAGE / 'payloads'
    payloads.mkdir()
    originals = {}

    def add(source, relative):
        assert source.is_file() and not source.is_symlink(), source
        destination = payloads / relative
        assert not destination.exists(), relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        originals[relative] = str(source)

    for label, location, expected in [
        ('source', '/tmp/darkbloom-q36-attention-metadata-source1', 'f5a62e3340474ea3c50baddf9577982d7adc47301e98925307c345eb6a2fbf09'),
        ('native-validation', '/tmp/darkbloom-q36-attention-metadata-validation1', '5bd03a11a014e52a467b24415e6f221a78c42fb3875d5393a347db5873dd1f7f'),
        ('combined-option-tests', '/tmp/darkbloom-q36-attention-metadata-combined-option-tests1', '87357121130b17e367827a0cbe882623c4310a6e88ebf86d3b40fa3019f107aa'),
        ('benchmark-validation', '/tmp/darkbloom-q36-attention-metadata-harness-validation1', 'babacc62576603ad13d077a9ab71eb57ebe9c46813edb8744565802aebaa419a'),
        ('probe-source-union', str(PLAN), 'ccbf94e8fb059e8356928fd18d302e2670ad26f913f54866046d48b2e86881fc'),
    ]:
        root = Path(location)
        assert sha(root / 'manifest.json') == expected
        for name, record in json.loads((root / 'manifest.json').read_text())['files'].items():
            source = root / name
            assert sha(source) == record['sha256'] and source.stat().st_size == record['bytes'], name
            add(source, label + '/' + name)
        add(root / 'manifest.json', label + '/manifest.json')
    for name in [
        'darkbloom-q36-attention-metadata-root-source-review.json',
        'darkbloom-q36-attention-metadata-root-native-validation.json',
        'darkbloom-q36-attention-metadata-root-harness-validation.json',
        'darkbloom-q36-attention-metadata-root-combined-tests-review.json',
        'darkbloom-q36-attention-metadata-root-probe-build-review.json',
        'darkbloom-q36-attention-metadata-root-graph-review.json',
        'darkbloom-q36-attention-metadata-root-wrapper-tests.log',
        'darkbloom-q36-attention-metadata-root-combined-wrapper-tests.log',
    ]:
        add(Path('/tmp') / name, 'root-review/' + name)
    add(Path(__file__), 'root-review/bank.py')
    records = {name: {'sha256': sha(payloads / name), 'bytes': (payloads / name).stat().st_size}
               for name in sorted(originals)}
    EVIDENCE.mkdir(parents=True, exist_ok=False)
    manifest = {'scope': 'Bounded actual attention metadata source and native/benchmark/wrapper validation; no real-model runtime or release acceptance.',
                'native_commit': '847e32076abd1c7f2b28660b7deed902f5dec692', 'files': records}
    (EVIDENCE / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    archive = EVIDENCE / 'payloads.tar.gz'
    with tarfile.open(archive, 'w:gz') as tar:
        for name in records:
            tar.add(payloads / name, arcname=name, recursive=False)
    with tarfile.open(archive) as tar:
        assert set(tar.getnames()) == set(records)
        for member in tar:
            assert member.isfile() and not member.issym()
            record = records[member.name]
            assert member.size == record['bytes']
            assert hashlib.sha256(tar.extractfile(member).read()).hexdigest() == record['sha256']
            assert sha(Path(originals[member.name])) == record['sha256']

    changes = json.loads((PLAN / 'parent-source-union.json').read_text())['candidate_files']
    subprocess.run(['git', 'apply', '--check', str(PLAN / 'parent-union.patch')], cwd=REPO, check=True)
    subprocess.run(['git', 'apply', str(PLAN / 'parent-union.patch')], cwd=REPO, check=True)
    for name, record in changes.items():
        assert sha(REPO / name) == record['after_sha256'] and (REPO / name).stat().st_size == record['bytes'], name

    report = REPO / 'docs/reports/2026-09-06-attention-metadata-diagnostic.md'
    report.write_text(f'''# Actual attention metadata with confirmed sample identity

> Last updated: 2026-09-06 · commit `5b93195c9`

The standalone benchmark can observe original attention input and cache dtypes
at one ordinary decode position without another model forward or tensor readback.
Native, benchmark and wrapper tests pass. Actual Qwen metadata, numerical
reference comparison and the unresolved backend output differences remain open.

## Behavior and bounds

Native commit `847e32076abd1c7f2b28660b7deed902f5dec692` adds default-nil
`CBv2AttentionMetadataConfig` and binds the concrete caches only around the
selected normal forward. It captures host metadata for original post-RoPE Q,
incoming K/V, native backing storage, scale, offsets, compact/model layer indices,
actual dispatch, kernel output and outward output. Contiguous SDPA, fixed paged
decode and segmented paged decode keep their original arithmetic and inputs.

Selection requires an idle-configured MTP-off engine, ordinary B1/L1 text decode,
full-attention owners without shared KV, sinks, softcap or spans. At most one
forward, 128 owner records and 64 segment descriptions per owner are retained.
Shapes and strides describe graph construction; they do not prove evaluated
physical layout. No tensor handle or raw contents live in the host snapshot.

The existing request/sample lifecycle confirms or discards the capture. Direct
decode uses generated count; chained decode uses generated count plus one.
Concrete bindings clear in defer; failed, discarded and shutdown work cannot be
reported as a confirmed observation. The benchmark reports `captured` only for
one confirmed forward with complete owners and no refusals. Other observations
remain `inconclusive`.

## Validation

Nine native filters pass: 62 functions and 129 expanded cases, including eight
new functions and 16 expanded cases. They exercise native BF16/FP32 storage,
wider FP32 queries, all ten compact owner mappings, record bounds, unsupported
geometry, failure and cancellation. Ordinary direct/chained controls preserve
tokens, forward shapes and real recurrent-state staging. Existing logit,
recurrent, paged dtype, kernel and segment suites also pass.

Fourteen benchmark tests pass, covering metadata options, combined metadata/logit
flags, existing logit options and coherent idle observations. Twelve Python
wrapper tests pass independently. The native and benchmark builds complete in
71.00 and 92.74 seconds. No test skips or production source corrections occur.
The combined-options addition changes two test files only.

Root verifies all source/validation payloads, all 894 canonical native inputs
against the committed tree, and 759 declared native/dependency/Jinja references
in the native build graph. Benchmark graph references resolve to the tested
candidate. Graph membership alone is not a claim that every target is linked
into the selected executable. The existing local dependency-only package
overlays and pinned metallib are retained. SwiftPM's unused remote MLX checkout
does not supply the compiled MLX sources.

The first probe plan retained stale byte-size annotations for two updated tests;
its successor corrects those annotations. Actual hashes, compiled source,
validation payload sizes and test results are unchanged. The successor binds
the completed benchmark evidence. The optimized probe and real-model runs are
separate work and are not asserted by this source milestone.

## Evidence and remaining interpretation

The [manifest](evidence/attention-metadata-2026-09-06/manifest.json) and
[archive](evidence/attention-metadata-2026-09-06/payloads.tar.gz) preserve
{len(records)} verified payloads ({sum(item['bytes'] for item in records.values()):,} bytes).
They contain source freezes, raw tests, build graphs, corrected source union
and root reviews. Compiled binaries and model weights are excluded.
Manifest SHA-256: `{sha(EVIDENCE / 'manifest.json')}`.
Archive SHA-256: `{sha(archive)}`.

Use the [benchmark instructions](../developer/test.md#prefix-cache-benchmark-validation)
and compare identical uninstrumented/traced trajectories before interpreting
metadata. These observations cannot establish Q/K/V equality across backends or
numerical accuracy. Bounded raw tensor packets and an independent FP32 reference
remain required to investigate the [actual Qwen logit difference](2026-09-05-qwen36-actual-logits.md).
Diagnostic timings are not performance evidence. Cache defaults and release
activation are unchanged.
''')
    index = REPO / 'docs/reports/README.md'
    text = index.read_text().replace('> Last updated: 2026-09-06 · commit `dda0b8807`', '> Last updated: 2026-09-06 · commit `5b93195c9`', 1)
    marker = '- [Connected SSD routing and canceled settlement]'
    text = text.replace(marker, '- [Actual attention metadata diagnostic](2026-09-06-attention-metadata-diagnostic.md) — bounded original query/cache dtype observations, confirmed sample identity and passing native/benchmark tests; real-model numerical diagnosis remains open.\n' + marker, 1)
    index.write_text(text)
    howto = REPO / 'docs/developer/test.md'
    text = howto.read_text().replace('> Last updated: 2026-09-06 · commit `dda0b8807`', '> Last updated: 2026-09-06 · commit `5b93195c9`', 1)
    marker = '\nFor isolated Qwen3.6 attention geometry, run\n'
    assert text.count(marker) == 1
    addition = '''
To observe actual attention input/cache dtypes, append
`--attention-metadata-position <zero-based-output-index>` to an ordinary B1,
MTP-off command with explicit `--cache-mode ssd`. Preserve cache-on/off, backend,
prompt and output budget. Index zero is unsupported because it is a prefill
decision. This flag can accompany the logit flags for the same position. Require
`attention_metadata.status=captured`, complete owner records and confirmed
seed/target identity before interpreting the result. Strides describe graph
construction; no tensor contents are captured. Use identical uninstrumented
controls and keep diagnostic timings out of performance summaries. The
[attention metadata validation record](../reports/2026-09-06-attention-metadata-diagnostic.md)
describes the bounds and lifecycle checks.
'''
    howto.write_text(text.replace(marker, '\n' + addition + marker, 1))
    subprocess.run(['git', 'diff', '--check'], cwd=REPO, check=True)
    check = subprocess.run(['bash', 'scripts/docs-check.sh', '--all'], cwd=REPO, text=True, capture_output=True)
    (STAGE / 'docs-check.log').write_text(check.stdout + check.stderr)
    assert check.returncode == 0, check.stdout + check.stderr
    changed = list(changes) + ['libs/mlx-swift-lm', str(report.relative_to(REPO)),
                              str(index.relative_to(REPO)), str(howto.relative_to(REPO)),
                              str((EVIDENCE / 'manifest.json').relative_to(REPO)), str(archive.relative_to(REPO))]
    subprocess.run(['git', 'add', '--', *changed], cwd=REPO, check=True)
    staged = subprocess.check_output(['git', 'diff', '--cached', '--name-only'], cwd=REPO, text=True).splitlines()
    assert set(staged) == set(changed), staged
    subprocess.run(['git', 'commit', '-m', 'feat(benchmarks): record confirmed attention metadata'], cwd=REPO, check=True)
    result = {'commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip(),
              'native_commit': '847e32076abd1c7f2b28660b7deed902f5dec692', 'payloads': len(records),
              'manifest_sha256': sha(EVIDENCE / 'manifest.json'), 'archive_sha256': sha(archive),
              'archive_bytes': archive.stat().st_size, 'docs_check': check.stdout.strip()}
    (STAGE / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
