#!/usr/bin/env python3
"""Run the direct token/cache probe with dedicated-host ownership and telemetry."""

import argparse
from datetime import date
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from run_radix_http import ranked_job, terminate


def arguments(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True)
    parser.add_argument("--model-directory", required=True)
    parser.add_argument("--input", required=True, help="Retained HTTP report.json")
    parser.add_argument("--output", required=True)
    parser.add_argument("--cache", choices=["on", "off"], default="on")
    parser.add_argument("--mtp", choices=["on", "off"], default="off")
    parser.add_argument("--kv-backend", choices=["auto", "paged", "contiguous"], default="auto")
    parser.add_argument("--cache-mode", choices=["ssd", "resident"], help="New harness default is SSD; resident is explicit historical reproduction")
    parser.add_argument("--key-mode", choices=["persistent", "ephemeral"], help="SSD default requires persistent KEK; ephemeral is an explicit non-restart test control")
    parser.add_argument("--startup-timeout", type=float, default=180, help="Bound model/hash/key setup before first request (seconds)")
    parser.add_argument("--concurrency", type=int, choices=[1, 2, 4], default=1,
                        help="Copies of each input submitted concurrently; controls actual engine admission")
    parser.add_argument("--kv-budget-gib", type=int, default=16,
                        help="Explicit slot KV grant, not physical machine RAM (default16GiB)")
    parser.add_argument("--assistant-directory", help="Exact flat offline assistant artifact; ordinary production verification applies")
    parser.add_argument("--expected-model-sha256", help="Pinned target aggregate SHA-256; requires the candidate production path")
    parser.add_argument("--prompt-date", help="Pin missing request-owned UTC dates as YYYY-MM-DD for paired runs")
    parser.add_argument("--cache-directory", help="Explicit payload root reuse for a separate restart test; default is fresh per invocation")
    parser.add_argument("--trial", type=int, default=1, help="Independent process repetition label; each invocation keeps its own artifact")
    args = parser.parse_args(argv)
    if args.key_mode and args.cache_mode != "ssd":
        parser.error("--key-mode requires --cache-mode ssd")
    if args.startup_timeout <= 0:
        parser.error("--startup-timeout must be positive")
    if not 1 <= args.kv_budget_gib <= 128:
        parser.error("--kv-budget-gib must be between1 and128")
    if args.trial < 1:
        parser.error("--trial must be positive")
    if args.prompt_date:
        try:
            if date.fromisoformat(args.prompt_date).isoformat() != args.prompt_date:
                raise ValueError()
        except ValueError:
            parser.error("--prompt-date must be a valid YYYY-MM-DD date")
    if args.expected_model_sha256 and (len(args.expected_model_sha256) != 64
            or any(c not in "0123456789abcdef" for c in args.expected_model_sha256)):
        parser.error("--expected-model-sha256 must be 64 lowercase hexadecimal characters")
    if args.cache_mode == "resident" and (args.assistant_directory or args.expected_model_sha256):
        parser.error("artifact verification options require the production SSD path")
    return args


def probe_command(args, output):
    command = [args.binary, args.model_directory, args.input,
               str(output), "cache-" + args.cache, "mtp-" + args.mtp, args.kv_backend]
    if args.cache_mode:
        command.append(args.cache_mode)
    if args.key_mode:
        command.append(args.key_mode + "-key")
    # Preserve the historical command line for old immutable B1 artifacts.
    if args.concurrency != 1:
        command.extend(["--concurrency", str(args.concurrency)])
    if args.kv_budget_gib != 16:
        command.extend(["--kv-budget-gib", str(args.kv_budget_gib)])
    if args.assistant_directory:
        command.extend(["--assistant-directory", args.assistant_directory])
    if args.expected_model_sha256:
        command.extend(["--expected-model-sha256", args.expected_model_sha256])
    return command


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def pin_prompt_date(source, destination, day):
    """Keep the real HTTP body, including tools and explicit per-request dates."""
    report = json.loads(Path(source).read_text())
    ids = [row["case"]["id"] for row in report["rows"]]
    if not ids or len(ids) != len(set(ids)):
        raise ValueError("input plan must have nonempty, unique case IDs")
    for row in report["rows"]:
        body = row["request"]
        selected = body.setdefault("_darkbloom_prompt_date", day)
        if not isinstance(selected, str) or date.fromisoformat(selected).isoformat() != selected:
            raise ValueError("invalid explicit request-owned date")
    Path(destination).write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")


def mark_aborted_report(path, error):
    """Retain the last atomic checkpoint when the owned process was killed."""
    path = Path(path)
    if not path.exists():
        return
    report = json.loads(path.read_text())
    if report.get("status") not in ("loading", "running"):
        return
    report.update(status="aborted", error=error)
    cells = report.get("rows", []) + report.get("tenant_checks", [])
    cells += [report.get(key, {}) for key in ("warmup", "cancelled", "recovered")]
    for row in cells:
        if row.get("outcome") == "running":
            row["outcome"] = "aborted"
    temporary = path.with_suffix(".aborted.tmp")
    temporary.write_text(json.dumps(report, indent=2, sort_keys=True) + "\n")
    temporary.replace(path)


def main():
    args = arguments()
    if ranked_job() or subprocess.run(["pgrep", "-x", "darkbloom"], stdout=subprocess.DEVNULL).returncode == 0:
        raise SystemExit("Dedicated host is busy")
    if os.getloadavg()[0] > 4:
        raise SystemExit("Dedicated host load exceeds 4")
    root = Path(args.output).resolve()
    root.mkdir(parents=True, exist_ok=False)
    macmon = Path.home() / "bench-runner/bin/macmon"
    raw = subprocess.check_output([str(macmon), "pipe", "-s", "1", "-i", "200"], text=True, timeout=10)
    temperature = json.loads(raw.splitlines()[0])["temp"]["gpu_temp_avg"]
    if temperature > 42:
        raise SystemExit(f"GPU entry temperature {temperature} exceeds 42 C")
    metadata = {"started_unix": time.time(), "arguments": dict(vars(args)),
                "entry_gpu_temp_c": temperature, "status": "running",
                "binary_sha256": sha256(args.binary), "source_input_sha256": sha256(args.input)}
    if args.prompt_date:
        prepared = root / "input.json"
        pin_prompt_date(args.input, prepared, args.prompt_date)
        args.input = str(prepared)
    metadata["input_sha256"] = sha256(args.input)
    environment = os.environ.copy()
    selected_environment = {"DARKBLOOM_PREFIX_CACHE_TEST_ROOT":
                            str(Path(args.cache_directory).resolve()) if args.cache_directory else str(root / "prefix-cache")}
    environment.update(selected_environment)
    metadata["environment"] = selected_environment
    probe = telemetry = None
    try:
        with (root / "engine.log").open("w") as log, (root / "telemetry.jsonl").open("w") as telemetry_log:
            telemetry = subprocess.Popen([str(macmon), "pipe", "-i", "100"], stdout=telemetry_log,
                                         stderr=subprocess.DEVNULL, start_new_session=True)
            command = probe_command(args, root / "report.json")
            metadata["command"] = command
            probe = subprocess.Popen(command,
                                     env=environment, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            deadline = time.monotonic() + 1800
            setup_deadline = time.monotonic() + args.startup_timeout
            setup_ready = args.cache_mode == "resident"
            while probe.poll() is None:
                if not setup_ready:
                    setup_ready = "radix-model-ready" in (root / "engine.log").read_text(errors="replace")
                    if not setup_ready and time.monotonic() > setup_deadline:
                        raise RuntimeError("Bounded model/hash/persistent-key setup time exceeded")
                if ranked_job():
                    raise RuntimeError("Ranked job appeared; abandoning owned probe")
                if time.monotonic() > deadline:
                    raise RuntimeError("Bounded benchmark time exceeded")
                time.sleep(1)
            metadata["exit_code"] = probe.returncode
            if probe.returncode:
                raise RuntimeError("Probe failed; inspect engine.log")
        metadata["status"] = "completed"
    except BaseException as error:
        metadata["status"] = "failed" if probe is not None and probe.poll() not in (None, 0) else "aborted"
        metadata["error"] = str(error) or type(error).__name__
        raise
    finally:
        for process in (probe, telemetry):
            terminate(process)
        if metadata["status"] != "completed":
            mark_aborted_report(root / "report.json", metadata.get("error", "owned process stopped"))
        metadata["ended_unix"] = time.time()
        metadata["ranked_job_at_end"] = ranked_job()
        (root / "metadata.json").write_text(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, lambda signum, frame: sys.exit(128 + signum))
    main()
