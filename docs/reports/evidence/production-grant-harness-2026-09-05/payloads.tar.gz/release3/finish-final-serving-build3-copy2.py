from pathlib import Path
import gzip,hashlib,json,shutil,subprocess
out=Path('/tmp/darkbloom-final-serving-build3');src=Path('/tmp/darkbloom-production-grant-harness-validation1');ws=src/'workspace';scratch=Path('/tmp/darkbloom-final-serving-build1/build');info=json.loads((out/'integration.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert json.loads((out/'execution.json').read_text())[0]['exit_code']==0
(out/'source-proof-wrapper-failure.txt').write_text('Release compilation succeeded238.011s. Original wrapper stopped at AllocationFootprint.swift proof because SwiftPM used workspace/libs/mlx-swift symlink instead of direct dependency path. No source or compile failure. This addendum verifies each actual compiler input resolves to exact frozen source and retains original runner and graph unchanged.\n')
t=gzip.decompress((out/'radix-release-graph.yaml.gz').read_bytes()).decode();actuals=[(ws/'provider-swift/Sources/ProviderCore/Inference/EngineV2Factory+BenchmarkGrant.swift',ws/'provider-swift/Sources/ProviderCore/Inference/EngineV2Factory+BenchmarkGrant.swift'),(ws/'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVSegments.swift',Path('/tmp/darkbloom-checkpoint-native-validation4/native/Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVSegments.swift')),(ws/'libs/mlx-swift/Source/MLX/AllocationFootprint.swift',Path(info['swift_source'])/'Source/MLX/AllocationFootprint.swift'),(ws/'libs/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp',Path(info['swift_source'])/'Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp'),(Path('/private/tmp/darkbloom-final-serving-build3/radix-engine/Sources/radix-engine/BenchmarkOptions.swift'),out/'radix-engine/Sources/radix-engine/BenchmarkOptions.swift')];rows=[]
for actual,expected in actuals:
 assert str(actual) in t,str(actual);assert actual.resolve()==expected.resolve(),(actual,expected);assert sha(actual)==sha(expected);rows.append({'actual_compile_path':str(actual),'resolved_frozen_source':str(expected.resolve()),'sha256':sha(actual)})
assert '/checkouts/mlx-swift/Source/' not in t
for path,h in json.loads((src/'jinja-source-manifest.json').read_text())['files'].items():assert sha(scratch/'checkouts/swift-jinja'/path)==h,path
(out/'radix-release-actual-source-proof.json').write_text(json.dumps({'scope':'Explicit addendum for original wrapper spelling failure; actual compiler paths resolve exactly to frozen sources.','paths':rows,'remote_mlx_compile_source_absent':True,'exact_jinja_inputs_verified':27},indent=2)+'\n')
ns={};exec((src/'run.py').read_text().split("assert (policy / 'manifest.json').exists()")[0],ns);verified=ns['verify']()
for p,row in json.loads((out/'compile-source-manifest.json').read_text())['files'].items():assert sha(out/p)==row['sha256'],p
(out/'source-verified-after.json').write_text(json.dumps(verified,indent=2)+'\n')
release=scratch/'arm64-apple-macosx/release';artifact=out/'artifact';assert sha(release/'darkbloom')=='a81fd9f9ff01fb84f3c236ceaba5fed4fca730b261be1f332b87c38e69cd3cfd'
for p in [release/'radix-engine',*sorted(release.glob('*.bundle'))]:
 if p.is_dir():
  for child in p.rglob('*'):
   if not child.is_file():continue
   target=artifact/p.name/child.relative_to(p)
   if target.exists():assert sha(target)==sha(child),str(target)
   else:target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(child,target)
 else:shutil.copy2(p,artifact/p.name)
for name in ['darkbloom','radix-engine']:(out/(name+'-dylibs.txt')).write_text(subprocess.check_output(['otool','-L',str(artifact/name)],text=True))
files={str(p.relative_to(artifact)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(artifact.rglob('*')) if p.is_file()};(out/'artifact-manifest.json').write_text(json.dumps({'files':files,'metallib_source':'Carried exact release1 cli-artifact/mlx.metallib','scope':'Exact candidate CLI/probe and beside-executable SwiftPM resource bundles.'},indent=2)+'\n');print(json.dumps({'probe_sha256':sha(artifact/'radix-engine'),'cli_sha256':sha(artifact/'darkbloom'),'artifact_files':len(files),'resolved_path_proofs':len(rows)},indent=2),flush=True)
