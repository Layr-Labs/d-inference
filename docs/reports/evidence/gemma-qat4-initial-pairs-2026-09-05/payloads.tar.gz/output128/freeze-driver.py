from pathlib import Path
import json,hashlib,shutil,sys,subprocess
budget=sys.argv[1];assert budget in ('32','128');out=Path('/tmp/darkbloom-qat-output'+budget+'-pair-freeze1');out.mkdir(exist_ok=False)
def add(src,rel):
 src=Path(src);dst=out/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def tree(src,rel):
 src=Path(src)
 for p in sorted(src.rglob('*')):
  if p.is_file() and not p.is_symlink():add(p,Path(rel)/p.relative_to(src))
for mode in ('off','ssd'):tree('/tmp/darkbloom-gemma-qat-execution1/gemma-qat4-paged-'+mode+'-b1-output'+budget,'raw/'+mode)
tree('/tmp/darkbloom-gemma-qat-binding1/package','binding');tree('/tmp/darkbloom-qat-staging1','staging');tree('/tmp/darkbloom-qat-output'+budget+'-postcheck1','postcheck');add('/tmp/postcheck-qat-pair1.py','postcheck-driver.py')
for src,dst in [('/tmp/run-qat-supplement1.py','driver.py'),('/tmp/freeze-qat-supplement-pair1.py','freeze-driver.py'),('/tmp/darkbloom-final-serving-build6/manifest.json','provenance/build6-manifest.json'),('/tmp/darkbloom-final-serving-build6/artifact-manifest.json','provenance/build6-artifact-manifest.json'),('/tmp/darkbloom-build6-root-review.json','provenance/build6-root-review.json'),('/tmp/darkbloom-gemma-qat-supplemental-root-review.json','provenance/qat-source-root-review.json'),('/tmp/darkbloom-gemma-qat-m5-hash-verification.json','provenance/qat-original-m5-hash.json')]:add(src,dst)
for name in ('compare_radix_engine.py','radix_engine_evidence.py'):add('/tmp/darkbloom-repeated-matrix-plan1/runner/'+name,'comparison/'+name)
if budget=='32':
 tree('/tmp/darkbloom-gemma-qat-execution1/native-kv-observer1','native-observer/raw');add('/tmp/darkbloom-gemma-qat-native-observer-evaluation1.json','native-observer/evaluation.json')
cmd=['python3','-B',str(out/'comparison/compare_radix_engine.py'),str(out/'raw/off/report.json'),str(out/'raw/ssd/report.json'),'--expect-cache-hits'];r=subprocess.run(cmd,capture_output=True,text=True);(out/'comparison/stdout.json').write_text(r.stdout);(out/'comparison/stderr.log').write_text(r.stderr);(out/'comparison/command.json').write_text(json.dumps({'argv':cmd,'exit_code':r.returncode},indent=2)+'\n');verdict=json.loads(r.stdout)
summary={'scope':'One normal-MTP QAT B1 paged off/SSD pair on reviewed build6/nativea932; output budget '+budget+'. No contiguous parity, repeated-performance, HTTP or release acceptance. Exact same-budget comparison only.','max_output_tokens':int(budget),'passed':verdict['passed'],'arms':{}}
for mode in ('off','ssd'):
 report=json.loads((out/'raw'/mode/'report.json').read_text());summary['arms'][mode]={'mtp':report.get('mtp'),'rows':[{k:row.get(k) for k in ('id','prompt_tokens','completion_tokens','finish','cache_outcome','matched_tokens','saved_tokens','replay_tokens','strategy','ssd_stage_ms','ttft_s','terminal_tail_s','decode_tps')} for row in report.get('rows',[])],'verified_model_hash':report.get('verified_model_hash'),'runtime_identity':report.get('runtime_identity'),'kv_grant_mode':report.get('kv_grant_mode')}
(out/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n');files={str(p.relative_to(out)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file()};(out/'manifest.json').write_text(json.dumps({'scope':summary['scope'],'files':files},indent=2)+'\n');print(json.dumps({'root':str(out),'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),'payloads':len(files),'bytes':sum(x['bytes'] for x in files.values()),'comparison':verdict},indent=2));sys.exit(r.returncode)
