import Foundation

struct CBv2CheckpointStageEntry {
    var bytes: Int
    var transferred: Bool
    var settled = false
}

/// A native engine's typed staging charge. Its owner must drop all destination
/// aliases before close, or transfer them through Admission into its own pool.
/// After transfer, close releases only bounded scratch. Never provider credit.
final class CBv2CheckpointStageLease: @unchecked Sendable {
    let admission: AdmissionV2
    let identity: UUID
    private let lock = NSLock()
    private var retainedTargetBytes: Int
    private var didSettle = false
    var targetBytes: Int { lock.withLock { retainedTargetBytes } }
    let auxiliaryBytes: Int
    let scratchBytes: Int
    var destinationBytes: Int { targetBytes + auxiliaryBytes }
    var totalBytes: Int { destinationBytes + scratchBytes }

    init(admission: AdmissionV2, identity: UUID, targetBytes: Int,
         auxiliaryBytes: Int, scratchBytes: Int) {
        self.admission = admission
        self.identity = identity
        self.retainedTargetBytes = targetBytes
        self.auxiliaryBytes = auxiliaryBytes
        self.scratchBytes = scratchBytes
    }

    /// One private staging owner may settle its evaluated target footprint.
    /// The source has not been exposed or adopted; auxiliary/scratch stay held.
    func settleTargetAfterEvaluation(actualBytes: Int) throws {
        try lock.withLock {
            guard !didSettle, actualBytes >= 0, actualBytes <= retainedTargetBytes else {
                throw CBv2CompleteCheckpointError.incompatibleCheckpoint
            }
            try admission.settleCheckpointStage(
                identity: identity, expectedBytes: retainedTargetBytes + auxiliaryBytes + scratchBytes,
                reduction: retainedTargetBytes - actualBytes)
            retainedTargetBytes = actualBytes
            didSettle = true
        }
    }

    func closeAfterDroppingOwners() { admission.closeCheckpointStage(identity: identity) }
}

/// Short-lived engine-queue preparation ticket. It owns accounting, not arrays;
/// a failed preparation explicitly drops every private alias before rollback.
/// No automatic deinit refund can run ahead of stored-property destruction.
final class CBv2CheckpointAdoptionReservation {
    private var rollbackBody: (() -> Void)?
    private var commitBody: (() -> Void)?

    init(rollback: @escaping () -> Void, onCommit: (() -> Void)? = nil) {
        rollbackBody = rollback
        commitBody = onCommit
    }

    func commit() {
        let callback = commitBody
        rollbackBody = nil
        commitBody = nil
        callback?()
    }

    func rollbackAfterDroppingOwners() {
        let callback = rollbackBody
        rollbackBody = nil
        commitBody = nil
        callback?()
    }

    deinit { assert(rollbackBody == nil, "checkpoint transfer ticket was not resolved") }
}
