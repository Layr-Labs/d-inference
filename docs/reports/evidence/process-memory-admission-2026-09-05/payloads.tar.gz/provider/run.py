from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated');out=Path('/tmp/darkbloom-process-memory-combined-validation1');scratch=root/'provider-swift/.build';dep=root/'libs/mlx-swift'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
 source=json.loads((out/'source-manifest.json').read_text())
 for p,h in source['files'].items():
  full=root/(p.replace('dependency/','provider-swift/.build/checkouts/',1) if p.startswith('dependency/') else p)
  assert sha(full)==h,p
 deps=json.loads((out/'dependency-source-manifest.json').read_text())
 for key,h in deps['files'].items():
  alias,p=key.split('/',1);assert sha(Path(deps['repositories'][alias])/p)==h,key
 pins=json.loads((out/'dependency-pins.json').read_text())
 for alias,pin in pins.items():assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=deps['repositories'][alias],text=True).strip()==pin,alias
 for p in ['provider-swift/Package.swift','provider-swift/Package.resolved','libs/mlx-swift-lm/Package.swift']:assert sha(root/p)==sha(out/(p.replace('/','-'))),p
 owned=json.loads((out/'owned-manifest.json').read_text())
 for p,h in owned['files'].items():assert sha(root/p)==h,p
 return {'selected_provider_native_jinja_inputs':len(source['files']),'selected_dependency_inputs':len(deps['files']),'no_drift':True}
(out/'source-verified-before.json').write_text(json.dumps(verify(),indent=2)+'\n')
env=os.environ.copy();env['MLX_METALLIB_PATH']=str(scratch/'arm64-apple-macosx/debug/mlx.metallib');groups=json.loads((out/'filters.json').read_text());results=[]
def run(name,cmd):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 t=(out/(name+'.log')).read_text();valid=True
 if name in groups:valid=bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test',t)) and not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',t,re.M)
 e={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'nonzero_and_no_skips':valid};results.append(e);(out/'execution.json').write_text(json.dumps({'cwd':str(root),'environment':{'MLX_METALLIB_PATH':env['MLX_METALLIB_PATH']},'results':results},indent=2)+'\n');print(json.dumps({k:v for k,v in e.items() if k!='command'}),flush=True)
 if r.returncode or not valid:raise SystemExit(r.returncode or 1)
run('build',['swift','build','--package-path','provider-swift','--build-tests','--jobs','4','--disable-automatic-resolution'])
graph=(scratch/'debug.yaml').read_text();assert str(dep/'Source/MLX/Memory.swift') in graph;assert str(dep/'Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp') in graph;assert '/checkouts/mlx-swift/Source/' not in graph
native_import=root/'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVPool+CheckpointImport.swift'
assert str(native_import) in graph,str(native_import)
for p in ['provider-swift/Sources/ProviderCore/Inference/EngineProcessMemoryOwner.swift','provider-swift/Tests/ProviderCoreTests/ProcessMemoryNativeIntegrationTests.swift','libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/ProcessMemoryOwnership.swift']:assert str(root/p) in graph,p
(out/'actual-build-graph.yaml.gz').write_bytes(gzip.compress(graph.encode(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'actual-package-state.json')
proof={'mlx_path':str(dep),'native_import_path':str(native_import),'remote_mlx_source_path_absent':True,'heads':json.loads((out/'dependency-pins.json').read_text()),'graph_lines':[x for x in graph.splitlines() if str(dep/'Source/MLX/Memory.swift') in x or str(dep/'Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp') in x or str(native_import) in x]}
(out/'actual-compiler-source-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
run('identifiers',['swift','test','list','--skip-build','--package-path','provider-swift','--disable-automatic-resolution'])
for name,filters in groups.items():run(name,['swift','test','--skip-build','--package-path','provider-swift','--disable-automatic-resolution','--filter','|'.join(filters)])
(out/'source-verified-after.json').write_text(json.dumps(verify(),indent=2)+'\n');print('ALL COMMANDS PASSED AND SOURCE BYTES VERIFIED',flush=True)
