"""Run only reviewed standalone synthetic replay tests under the owned Swift lane."""
from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time
from test_selection import canonical_identifiers,exact_filter
OUT=Path(__file__).resolve().parent
INFO=json.loads((OUT/'integration.json').read_text())
SCRATCH=Path(INFO['scratch']);NATIVE=Path(INFO['native']);HARNESS=Path(INFO['harness'])
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def tracked(root):return {str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file() and not any(x in {'.build','.swiftpm','__pycache__'} for x in p.relative_to(root).parts)}
def verify():
 totals={}
 for label,root in [('native',NATIVE),('harness',HARNESS)]:
  expected=json.loads((OUT/(label+'-source-manifest.json')).read_text())['files'];assert tracked(root)==expected,(label,'source drift');totals[label]=len(expected)
 deps=json.loads((OUT/'dependency-source-manifest.json').read_text())
 for name,digest in deps['files'].items():
  alias,relative=name.split('/',1);assert sha(Path(deps['repositories'][alias])/relative)==digest,name
 jinja=json.loads((OUT/'jinja-source-manifest.json').read_text())
 for name,digest in jinja['files'].items():assert sha(SCRATCH/'checkouts/swift-jinja'/name)==digest,name
 totals.update(dependencies=len(deps['files']),jinja=len(jinja['files']));return totals

def main():
 result=OUT/'result';result.mkdir()
 env=os.environ.copy();env['ATTENTION_REPLAY_SOURCE_ROOT']=INFO['workspace']
 write(result/'source-before.json',verify())
 write(result/'environment.json',{k:v for k,v in env.items() if k.startswith(('ATTENTION_REPLAY_','MLX_','DARKBLOOM_CBV2_'))})
 records=[]
 def run(name,argv):
  start=time.monotonic();path=result/(name+'.log')
  with path.open('x') as log:r=subprocess.run(argv,cwd=HARNESS,env=env,stdout=log,stderr=subprocess.STDOUT)
  row={'name':name,'argv':argv,'cwd':str(HARNESS),'exit_code':r.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(path)}
  records.append(row);write(result/'execution.json',records);print(json.dumps(row),flush=True)
  assert r.returncode==0,('command failed; preserve current attempt',name)
  return path.read_text()
 def graph(label):
  for name in ['debug.yaml','workspace-state.json']:
   p=SCRATCH/name
   if p.exists():(result/(label+'-'+name+('.gz' if name.endswith('.yaml') else ''))).write_bytes(gzip.compress(p.read_bytes(),mtime=0) if name.endswith('.yaml') else p.read_bytes())
 try:
  run('build',['swift','build','--scratch-path',str(SCRATCH),'--build-tests','--jobs','4','--disable-automatic-resolution'])
  graph('built');write(result/'source-postcompile.json',verify())
  actual=(SCRATCH/'debug.yaml').read_text();paths=set(re.findall(r'"(/[^"\n]+)"',actual));proof=[]
  expected=list(HARNESS.glob('Sources/attention-replay/*.swift'))+list(HARNESS.glob('Tests/AttentionReplayTests/*.swift'))
  expected+=list((NATIVE/'Libraries/MLXLMCommon/ContinuousBatchingV2').glob('CBv2AttentionReplay*.swift'))
  for p in expected:
   found=next((x for x in paths if x.endswith('/'+p.name) and Path(x).resolve()==p.resolve()),None);assert found,('missing actual compiler source',str(p))
   proof.append({'path':found,'resolved':str(p.resolve()),'sha256':sha(p)})
  assert '/ProviderCore.build/' not in actual and '/checkouts/mlx-swift/Source/' not in actual
  write(result/'actual-compiler-source-proof.json',proof)
  debug=SCRATCH/'arm64-apple-macosx/debug';name='AttentionOperatorReplayPackageTests'
  bundle=debug/(name+'.xctest/Contents/MacOS');binary=bundle/name
  library=Path(INFO['metallib']);assert sha(library)==INFO['metallib_sha256']
  for target in [debug/'mlx.metallib',bundle/'mlx.metallib']:shutil.copy2(library,target);assert sha(target)==INFO['metallib_sha256']
  binary_hash=sha(binary);write(result/'test-binary.json',{'path':str(binary),'sha256':binary_hash,'bytes':binary.stat().st_size,'metallib_sha256':sha(library)})
  listing=run('identifiers',['swift','test','list','--skip-build','--scratch-path',str(SCRATCH),'--disable-automatic-resolution'])
  canonical=run('canonical-identifiers',['swift','test','-v','list','--skip-build','--scratch-path',str(SCRATCH),'--disable-automatic-resolution'])
  selected={};filters={};runtime={}
  for suite in ['ReplayHostTests','ReplayOperatorTests']:
   pattern=re.escape('AttentionReplayTests.'+suite+'/')+r'[A-Za-z_][A-Za-z0-9_]*\([^()\r\n]*\)'
   ids=[x for x in listing.splitlines() if re.fullmatch(pattern,x)];assert len(ids)==4,(suite,ids)
   selected[suite]=ids;runtime[suite]=canonical_identifiers(ids,canonical);filters[suite]=exact_filter(ids+runtime[suite])
   assert [x for x in listing.splitlines() if re.search(filters[suite],x)]==ids
   assert [x for x in canonical.splitlines() if re.search(filters[suite],x)]==runtime[suite]
  write(result/'selected-identifiers.json',selected);write(result/'canonical-selected-identifiers.json',runtime);write(result/'filters.json',filters)
  cases={}
  for suite in selected:
   text=run(suite,['swift','test','--skip-build','--scratch-path',str(SCRATCH),'--disable-automatic-resolution','--filter',filters[suite]])
   assert re.search(r'Test run with 4 tests? .* passed',text),(suite,'missing nonzero exact test count')
   assert not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped',text,re.M),(suite,'skipped test')
   argument_cases=len(re.findall(r'Test case passing [12] arguments?',text));expected_cases=24 if suite=='ReplayOperatorTests' else 0
   assert argument_cases==expected_cases,(suite,argument_cases)
   cases[suite]=argument_cases+(1 if suite=='ReplayOperatorTests' else 4)
  assert sha(binary)==binary_hash
  write(result/'verdict.json',{'status':'PASS','functions':8,'expanded_cases':sum(cases.values()),'cases':cases,'scope':'Synthetic actual attention operators and host transfer only; no model/key/release parity proof'})
 except BaseException as error:
  write(result/'verdict.json',{'status':'FAIL','error':str(error)});raise
 finally:
  write(result/'source-after.json',verify());graph('after')
if __name__=='__main__':main()
