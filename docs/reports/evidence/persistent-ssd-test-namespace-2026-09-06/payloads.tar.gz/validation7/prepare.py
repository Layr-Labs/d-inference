from pathlib import Path
import json,hashlib,shutil,difflib,subprocess,sys,gzip,importlib.util
out=Path('/tmp/darkbloom-persistent-test-namespace-swift-validation7');out.mkdir()
prior=Path('/tmp/darkbloom-persistent-test-namespace-swift-validation6')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in prior.glob('*.json'):
 if p.name not in ['preparation-manifest.json','REVIEW.json']:shutil.copy2(p,out/p.name)
for n in ['test_selection.py','test_test_selection.py','provider-identifiers-original.log','canonical-identifiers.log']:
 shutil.copy2(prior/n,out/n)
for n in ['native','workspace']:(out/n).symlink_to(prior/n,target_is_directory=True)
info=json.loads((out/'integration.json').read_text());info.update(status='Prepared source-only corrected exact24 selectors; reuse verified validation6 binary, no rebuild',reused_build_from=str(prior/'benchmark-result'))
(out/'integration.json').write_text(json.dumps(info,indent=2)+'\n')
s=(prior/'run.py').read_text().replace("'BenchmarkAttentionPacketOptionsTests': 3, 'BenchmarkAttentionPacketExportTests': 1", "'BenchmarkAttentionPacketOptionsTests': 2, 'BenchmarkAttentionPacketExportTests': 2")
start=s.index("        built, _ = run('build'")
end=s.index("        prove_compiler_sources(result, args.phase)",start)
s=s[:start]+'''        prior = Path(INFO['reused_build_from'])
        previous_build = json.loads((prior / 'execution.json').read_text())[0]
        assert previous_build['name'] == 'build' and previous_build['exit_code'] == 0
        previous_binary = json.loads((prior / 'test-binary.json').read_text())
        assert sha(Path(previous_binary['path'])) == previous_binary['sha256'], 'reused binary drift'
        assert (SCRATCH / 'debug.yaml').read_bytes() == gzip.decompress((prior / 'after-debug.yaml.gz').read_bytes()), 'compiler graph changed after approved build'
        assert (SCRATCH / 'workspace-state.json').read_bytes() == (prior / 'after-workspace-state.json').read_bytes(), 'dependency graph changed after approved build'
        write(result / 'reused-build-proof.json', {'source': str(prior), 'build': previous_build,
              'binary': previous_binary, 'scope': 'Exact already built binary and compiler/dependency graphs; no new build invocation'})
        save_graph(result, 'reused-build')
        write(result / 'source-verified-postcompile.json', verify())
'''+s[end:]
(out/'run.py').write_text(s)
(out/'driver.delta.patch').write_text(''.join(difflib.unified_diff((prior/'run.py').read_text().splitlines(keepends=True),s.splitlines(keepends=True),fromfile='validation6/run.py',tofile='validation7/run.py')))
for name in ['identifiers.log','canonical-identifiers.log']:
 shutil.copy2(prior/'benchmark-result'/name,out/('benchmark-actual-'+name))
p=out/'test_test_selection.py';s=p.read_text();s+='''\n\nclass FinalBenchmarkCountsTests(unittest.TestCase):
    def test_all_actual_functions_bind_to_exact_twenty_four(self):
        root = Path(__file__).parent
        listing = (root / 'benchmark-actual-identifiers.log').read_text()
        canonical = (root / 'benchmark-actual-canonical-identifiers.log').read_text()
        counts = {'BenchmarkPersistentTestKeysTests': 6, 'BenchmarkAttentionMetadataOptionsTests': 3,
                  'BenchmarkLogitDiagnosticOptionsTests': 3, 'BenchmarkIdleObservationTests': 8,
                  'BenchmarkAttentionPacketOptionsTests': 2, 'BenchmarkAttentionPacketExportTests': 2}
        total = []
        for selector, count in counts.items():
            ids = selected_identifiers(listing, selector, 'benchmark')
            self.assertEqual(len(ids), count)
            runtime = canonical_identifiers(ids, canonical)
            pattern = exact_filter(ids + runtime)
            self.assertEqual([x for x in listing.splitlines() if re.search(pattern, x)], ids)
            self.assertEqual([x for x in canonical.splitlines() if re.search(pattern, x)], runtime)
            total += ids
        self.assertEqual(len(total), 24)
        self.assertEqual(len(set(total)), 24)
''';p.write_text(s)
r=subprocess.run([sys.executable,'-B','-m','unittest','-v','test_test_selection'],cwd=out,capture_output=True)
(out/'cpu-tests.log').write_bytes(r.stdout+r.stderr);assert r.returncode==0,r.stderr
sys.path.insert(0,str(out));spec=importlib.util.spec_from_file_location('driver',out/'run.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
(out/'source-verified-prepared.json').write_text(json.dumps(mod.verify(),indent=2)+'\n')
(out/'REVIEW.json').write_text(json.dumps({'correction':'Packet options2/export2, not3/1; exact24 total remains unchanged. Source actually has these four functions.','previous_attempt':'validation6 build+actual graphs+ordinary/canonical lists PASS; count guard failed before test execution; preserved unchanged','new_validation':'12 CPU selector tests PASS including exact all24 actual display/runtime identifiers and adversarial lookalikes','execution':'Reuse unchanged validation6 binary guarded by binary hash and exact scratch compiler/dependency graph bytes; tests skip-build. Source/pins and all23 prior provider evidence remain explicit.','lane':'Await root review before running; sole local Swift retained','source_changes':'None; runner/count correction only'},indent=2)+'\n')
shutil.copy2(Path(__file__),out/'prepare.py')
files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file() and '__pycache__' not in p.parts}
(out/'preparation-manifest.json').write_text(json.dumps({'files':files,'symlinks':{'native':str(prior/'native'),'workspace':str(prior/'workspace')}},indent=2)+'\n')
print(json.dumps({'root':str(out),'payloads':len(files),'manifest_sha256':sha(out/'preparation-manifest.json'),'verify':mod.verify()},indent=2))
