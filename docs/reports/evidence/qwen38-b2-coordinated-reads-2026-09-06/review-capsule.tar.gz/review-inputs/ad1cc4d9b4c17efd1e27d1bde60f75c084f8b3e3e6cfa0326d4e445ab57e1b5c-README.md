# Qwen-first pilot 2 — mechanical source-bound successor, runtime unbound

**ROOT rejected manifest `90f18f4a6814c162f6ca04b29387d8ea579a09cae2c4a552e6220b9e8bddc956`.**
That complete version, its former 36-test log/proof and the review finding are
preserved byte-for-byte under `history/failed-review-90f18f4a/`; do not execute it.
It self-generated inner pings without observing caller/SSH stdin. Its passing
tests did not establish external-caller liveness. This revision requires a real
external control pipe and a new ROOT review of the updated manifest. Old review
hashes and unlaunched activations do not authorize the corrected driver.

This directory implements the **three Q38 retained B2 cells only**. It is not
another matrix plan, a build/staging script or a release promotion. No model,
SSH, network, staging or heavy build was run while implementing it. ROOT/Main
performs the existing source/runtime/scope review; there is no extra interactive
user confirmation or invented approval prompt.

Pinned source:

- primary: `35fea6d0e3b05ff65d60d9675ab480159913ac62`
- native: `f2d79145e040bbc28c6e0e355a19bc8923a70434`
- Remaining canonical dependencies are exact in `source-pins.json`.
- Main's build is `/private/tmp/darkbloom-qwen-first-runtime3`, corresponding to
  M5 `/Users/gaj/autoresearch/radix-prefix-cache/100-qwen-checkpoint-coordination1`.
  This package does not presume an artifact exists or is reviewed.

This is a mechanically bound successor of vetted pilot1 manifest
`e061f109b4d7f4582abcd294e09e2410936b52b20e0d3eb6505d719299bf854c`.
Only the active parent source pin and source/path metadata change; controllers,
lease behavior, acceptance gates and all 58 test fixtures remain unchanged.
Main is building the same-file SSD read/recency-coordination fix in runtime3.
Runtime/source reviews, artifact fields and execution clearance remain unbound
until the actual new artifact is reviewed. No prior runtime review is inherited.

The first Q38 B2 pilot's backend comparison passed and measured same-ID outputs
matched, but cache validation failed: repeat b0 was `skipped_policy`, while b1
hit/saved 5,120 tokens. Its original raw archive is preserved, SHA256
`e927b49bc1397dc2939a596796f271d66b60fedc0db4d213fe9f87d01115ef30`
(as recorded in its collection receipt; not rehashed by this preparation).
That cache failure stays failed. Run **all three arms fresh**, including both
cache-off arms, on the newly reviewed runtime in a new attempt root. No old
reports, common arms or cache results may enter this successor's comparisons.

## Implementation

`pilot.py activate` verifies the immutable frozen Qwen plan, its binding and ROOT
ACK, this driver review, exact three-cell scope, signed-source selection,
source/runtime manifests and all resource hashes. It records stable file
identities in a new activation JSON. It does not launch anything or set GPU ready.
`m5.candidate.json` remains unreviewed, with binary/resources/artifact/source
workspace and reviews unbound. Never activate the candidate by merely changing
its state: populate real artifacts and review records in a **separate** copy.

`pilot.py run` is the **remote** foreground controller. It requires externally fed
control stdin (pipe/socket, not a TTY or regular file), waits for a complete ping
before preparation, and requires a fresh ping immediately before owned launch.
It forwards only received pings to the inner supervisor: no self-ping timer and
no default unleased mode exist. Only exact newline-delimited JSON is accepted:

```json
{"command":"ping"}
{"command":"stop"}
```

The caller must send pings at least every 2 seconds. Missing/expired pings have a
bounded 30-second lease; EOF, stop, malformed/oversized control, signal or lease
loss marks the caller dead and stops/closes owned supervision. Signal handlers
raise a dedicated control exception, not `InterruptedError` that selectors may
swallow. The worker checks the caller receipt before each cell and immediately
before execution, preventing successor launch after cancellation/expiry.
The controller enforces deadlines using its own monotonic clock. The worker's
cross-process freshness guard uses Unix time, failing closed on clock jumps,
rather than comparing process-local monotonic epochs on older macOS Python.

The byte-identical `owner_helper.py` retains its inner 30-second lease and
10,800-second total deadline. Each unchanged frozen runner gets its original
measurement flags and a 1,900-second process deadline, wrapped by byte-identical
`tracked_runner.py`. The exclusive driver lock and all prior audit gates remain.
No GPT constants, old measurements, previous first-cell continuation or SSH
driver is reused. The old GPT driver was a reference for ownership, not executed.

The worker runs exactly:

1. `qwen38-retained-b2-r1-contiguous-cache-off`
2. `qwen38-retained-b2-r1-paged-cache-off`
3. `qwen38-retained-b2-r1-paged-cache-on`

Each cell has fresh full Q38 model file hashes (including tokenizer/config/MTP),
source inventory/git cleanliness, runtime hashes, and before/after stable
inode/device/size/mode/time/link records. It waits boundedly for M5 entry before
the audit, then checks entry again **without waiting** immediately before launch,
with a final audit-stat guard. Changed source/config, symlinks outside the model
blob store, unmanifested model payloads, altered review inputs, or replaced prior
results fail closed. Physical ownership must exclude concurrent writers; hashes
are not a replacement for that constraint.

M5 must be Mac17,6 / 137438953472 bytes, finite GPU temperature <=42 C, load <=4,
free space >100 GiB and the frozen 5%-volume/20-GiB storage floor, without foreign
or already-owned model workers. Normal MTP, production grant, seven-key profile,
no resident bank, real B2 target width, exact token/finish parity and both strict
backend/cache comparison gates come from the unchanged `qwen_plan.py` package.
Only completed endpoints gate intermediate prefixes; the final pilot requires
all three reports and both comparisons. Any failure stops dependent work.
This explicit-backend triad **does not validate the production default**. Actual
auto/default HTTP-path validation is a separate later ROOT scope, never an
expansion of this driver. Terminal results explicitly keep
`production_default_validated` and `auto_http_validated` false. Source policy gates
exact model IDs; the benchmark fingerprints bind experimental weights, not a new
production artifact-hash allowlist.

EOF, stop, lease expiry, deadline, SIGTERM/SIGHUP/SIGINT and foreground loss retire
only identified owned groups, including detached native/macmon children. Birth/
PGID mismatch refuses foreign signals; permission errors never imply retirement.
If the foreground dies, the supervisor seals partial failure evidence after
cleanup. Interrupted audits remain missing, never accepted. Killing **all**
controllers with SIGKILL or losing the machine cannot guarantee in-process cleanup;
retained PID/birth records are then for ROOT recovery, never a blanket kill command.

`ssh_controller.py` is the small **local** foreground caller for an already staged
and activated remote driver. It opens non-PTY SSH (`-T`, never `-n` or `-f`), owns
SSH's stdin, and sends a ping every 2 seconds while local control stdin remains
open. Local SIGTERM/SIGHUP/SIGINT, stdin EOF, JSON stop or deadline sends stop and
closes that pipe, then drains output during bounded cleanup. It never depends on
SSH propagating SIGHUP to remote Python. A hard connection loss still stops remote
execution at its external lease deadline. Local SSH exit alone does not certify
remote retirement: retain and inspect the remote retirement receipts.

## Existing ROOT review records

Use the frozen package's `OWNED-EXECUTION.md` schema for `source_review`,
`runtime_review`, live Q38 audit, `reviewed_cell_ids` and separate `--ack`.
Clear exactly the three IDs above, with `host_id: m5` and `gpu_ready: false`.
The driver adds these fields to that same review flow:

- Binding `source_workspace`: absolute path to runtime3's unchanged `workspace`.
- Binding `artifact_manifest`: `{path, sha256}` for runtime3's real artifact
  manifest. `runtime_review.artifact_manifest_sha256` must cover it.
- Binding `results_root`: absolute `RUN_ROOT/results`, with RUN_ROOT absent.
- ACK's existing `owned_controller_review` file must contain
  `status: QWEN_PILOT_CONTROLLER_REVIEWED`, `driver_manifest_sha256` (this
  `manifest.json`), `only_cells` (the three IDs), and `exclusive_host_id: m5`.
  ROOT reviews the source signatures/build provenance, actual passing native/
  compiler test logs, this driver, exclusive host grant and no-writer condition.

Neither code nor CPU fixtures manufacture those authorizations. The activation
and all reviews stay outside the fresh attempt root; no file is overwritten.

## Exact activation and controller commands

Main stages the driver and byte-identical frozen plan and prepares the real
reviewed binding/ACK on M5. For the following layout, use these commands **on M5**;
they are not SSH or staging commands. The reviewed binding must name
`$PILOT_DIR/attempt-1/results` and the already-existing runtime3 artifact/workspace.

```sh
PILOT_DIR=/Users/gaj/autoresearch/radix-prefix-cache/101-qwen-first-pilot2
cd "$PILOT_DIR"
python3 -B pilot.py activate \
  --plan "$PILOT_DIR/plan" \
  --binding "$PILOT_DIR/reviews/m5.reviewed.json" \
  --ack "$PILOT_DIR/reviews/root-ack.json" \
  --run-root "$PILOT_DIR/attempt-1" \
  --out "$PILOT_DIR/activation.json"
```

Then, **locally**, after ROOT has reviewed the corrected manifest and activation:

```sh
cd /private/tmp/darkbloom-qwen-first-pilot2
REMOTE=/Users/gaj/autoresearch/radix-prefix-cache/101-qwen-first-pilot2
python3 -B ssh_controller.py \
  --host gaj@100.124.35.99 \
  --identity /Users/gaj/.ssh/darkbloom_testbox \
  --remote-driver "$REMOTE/pilot.py" \
  --activation "$REMOTE/activation.json" \
  --remote-python /Applications/Xcode.app/Contents/Developer/usr/bin/python3 \
  --output /private/tmp/darkbloom-qwen-first-pilot2/ssh-control-attempt-1
```

Use the approved M5 address/key if they differ. These are handoff commands, not
actions performed during this task. Keep the local controller's terminal or
caller pipe open; Ctrl-C/EOF cancels it. Do not redirect stdin from `/dev/null`,
use `nohup`, background/disown the controller, or provide an unrelated endless
ping loop. Automation must retain a real foreground caller pipe that closes on
its own cancellation. Direct remote `pilot.py run --activation ...` is permitted
only with the same externally maintained JSON pipe; bare/unfed invocation never
launches. `_owned`/`_worker` modes are not activation shortcuts.

The public commands never prompt; unbound/changed/rejected inputs exit nonzero.
ROOT uses the existing review/ACK process, not a new manual user confirmation.
A retry is a
new ROOT-reviewed binding, activation and absent attempt root, never resume/reuse.
The frozen prompt date is September 6, 2026 UTC; another UTC date requires a
reviewed successor input/plan **and driver pin**, not a date bypass.

## Evidence and CPU checks

`attempt-1` contains exact argv, review/input snapshots, model/source/runtime
audits, both host-entry samples, all original reports/full token arrays/metadata,
raw logs/telemetry, per-cell comparison verdicts and all ownership/retirement
receipts. Completed outputs are rehashed before reuse and final collection.
`caller-lease.json` and the terminal receipt retain external ping/cancellation
state. Evidence sealing may finish after cancellation once model work is retired;
it never starts a successor cell or turns a cancelled attempt into acceptance.
The final `evidence-manifest.json`, verified `evidence.tar.gz` and
`collection-receipt.json` retain every original byte; files are made read-only.
This is tamper-evident retention, not an OS immutable flag or release approval.
Failures and partial runs are also retained. No pruning, overwrite, expansion,
cache/backend mismatch waiver or full-matrix promotion exists.

```sh
cd /private/tmp/darkbloom-qwen-first-pilot2
PYTHONPATH=. python3 -B -m unittest discover -s tests -v
```

All fixtures write only under this new directory and launch only harmless Python
sleep/ownership fixtures, never native models, macmon, SSH or a build. See
`cpu-tests.log` and `validation-result.json`. Frozen package/helper hashes are
checked in the tests; the earlier plan package remains byte-for-byte unchanged.
Existing inner ownership tests are retained. Added tests drive the real outer
controller's caller pipe, hold stdout open during EOF, expire the outer lease
before the inner lease, verify harmless child-group retirement/no successor,
and exercise the local relay with Python subprocesses instead of SSH.

## Exact successor diff

`vetted-pilot1-to-pilot2.diff` contains the exact unified diff of all reviewed
payload files plus `manifest.json`. Generated logs, lock/attempt state and
validation receipts are not driver payload and are deliberately not carried
forward as evidence of this run. `successor-proof.json` records byte equality of
every other payload, the one-line source-pin-only code change and preservation
of original pilot1, its reviewed history, and the frozen Qwen plan. No new
execution framework or test code is added. `validation-result.json` records this
successor's own CPU run and unbound refusal probes.
