from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys
import time

cell, review_sha = sys.argv[1:]
package = Path('/tmp/darkbloom-connected-m5-bundle5')
plan = json.loads((package / 'bundle-plan.json').read_text())
assert cell in [row['cell'] for row in plan['cells']]
remote = plan['remote_bundle_root']
output = remote + '/runs/' + cell + '-run'
local = Path('/tmp/darkbloom-connected-http5-results') / cell
local.mkdir(parents=True, exist_ok=False)
ssh = ['ssh', '-i', '/Users/gaj/.ssh/darkbloom_testbox', '-o', 'IdentitiesOnly=yes', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'gaj@100.124.35.99']
ownership = subprocess.run(['python3', '-B', '/tmp/darkbloom-fleet-smoke-continuation/preflight.py', str(local / 'ownership-before.json')],text=True,capture_output=True)
(local / 'ownership-before.log').write_text(ownership.stdout + ownership.stderr)
assert ownership.returncode == 0
check = """from pathlib import Path
import datetime,hashlib,json,shutil
root=Path(ROOT)
assert hashlib.sha256((root/'approved-root-review.json').read_bytes()).hexdigest()==REVIEW_SHA
assert hashlib.sha256((root/'package-manifest.json').read_bytes()).hexdigest()=='7c04de0ebc0064d31ce6aa642044d1075704bcf29779334c6d0a9d32aaa4efda'
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-09-06'
assert shutil.disk_usage(root).free>100*(1<<30)
assert not Path(OUTPUT).exists()
print(json.dumps({'date_utc':'2026-09-06','review_sha256':REVIEW_SHA,'fresh_output':OUTPUT,'free_disk_bytes':shutil.disk_usage(root).free},indent=2))
""".replace('ROOT',repr(remote)).replace('REVIEW_SHA',repr(review_sha)).replace('OUTPUT',repr(output))
precheck = subprocess.run(ssh+['python3 -B -'],input=check,text=True,capture_output=True)
(local / 'run-precheck.json').write_text(precheck.stdout)
(local / 'run-precheck.stderr').write_text(precheck.stderr)
assert precheck.returncode==0,precheck.stderr
command=['python3','-B',remote+'/run_connected_fixture.py','run','--cell',cell]
(local/'command.json').write_text(json.dumps({'command':command,'scope':'HTTP5 exact CLI8 with receipt ownership fix; strict ten-case cache pairing, not backend/release/persistent acceptance'},indent=2)+'\n')
started=time.monotonic()
with (local/'ssh-run.log').open('x') as log:
    result=subprocess.run(ssh+[shlex.join(command)],stdout=log,stderr=subprocess.STDOUT)
(local/'execution.json').write_text(json.dumps({'exit_code':result.returncode,'seconds':time.monotonic()-started},indent=2)+'\n')
# A transport interruption is not proof that the remote job stopped. Collect
# only after launch.json has a terminal state; otherwise leave the handle for
# the owner to inspect, never rerun the cell or kill by executable name.
inventory_code="""from pathlib import Path
import hashlib,json
root=Path(ROOT)
launch=json.loads((root/'launch.json').read_text())
assert launch['status'] in ('completed','failed'), 'Remote cell may still be live; inspect its existing handle'
files={}
for name in ['launch.json','connected.log','evidence/report.json']:
 p=root/name
 if p.is_file():files[name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'root':str(root),'launch_status':launch['status'],'files':files},indent=2))
""".replace('ROOT',repr(output))
inventory=subprocess.run(ssh+['python3 -B -'],input=inventory_code,text=True,capture_output=True)
(local/'remote-inventory.stderr').write_text(inventory.stderr)
assert inventory.returncode==0,inventory.stderr
(local/'remote-inventory.json').write_text(inventory.stdout)
for name,item in json.loads(inventory.stdout)['files'].items():
    target=local/name
    target.parent.mkdir(parents=True,exist_ok=True)
    transfer=subprocess.run(['scp','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','gaj@100.124.35.99:'+output+'/'+name,str(target)],text=True,capture_output=True)
    assert transfer.returncode==0,transfer.stderr
    assert target.stat().st_size==item['bytes'] and hashlib.sha256(target.read_bytes()).hexdigest()==item['sha256']
files={str(p.relative_to(local)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(local.rglob('*')) if p.is_file()}
(local/'manifest.json').write_text(json.dumps({'scope':'Raw HTTP5 cell; failed/unrun evidence retained, no pairing implied','exit_code':result.returncode,'files':files},indent=2)+'\n')
print(json.dumps({'cell':cell,'exit_code':result.returncode,'manifest_sha256':hashlib.sha256((local/'manifest.json').read_bytes()).hexdigest(),'local':str(local)},indent=2))
sys.exit(result.returncode)
