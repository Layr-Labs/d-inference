#!/usr/bin/env python3
"""Build exact, reviewable inputs; never launches providers or downloads models."""
from pathlib import Path
import hashlib
import json
import shutil

BASE = Path(__file__).resolve().parent
REMOTE = Path('/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http1')
RUNTIME = Path('/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-smoke1/payload')
REPO = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
AUDIT = Path('/tmp/darkbloom-cache-routing-release-audit/artifact-identities.json')
PLAN = Path('/tmp/darkbloom-final-fleet-smoke1/plan.json')
CATALOG = Path('/tmp/qwen35b-ssd-model-inventory/catalog.json')
FEATURE = Path('/tmp/darkbloom-0.9-validation/http-feature-plan.json')
TRANSFER = Path('/tmp/darkbloom-final-model-package1/payload/transfer-manifest.json')
ASSISTANT = Path('/tmp/darkbloom-final-model-package1/payload/gemma-assistant/manifest.json')


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    for name in ['inputs', 'manifests', 'assets', 'source-inputs']:
        (BASE/name).mkdir(exist_ok=True)
    artifacts = {x['model_id']: x for x in json.loads(AUDIT.read_text())['artifacts']}
    catalog = {x['id']: x for x in json.loads(CATALOG.read_text())['models']}
    plan = json.loads(PLAN.read_text())
    tools = json.loads(FEATURE.read_text())['tools_case']
    tools['tool_choice'] = 'auto'
    transfer = json.loads(TRANSFER.read_text())
    assistant = json.loads(ASSISTANT.read_text())
    entries, source_hashes = [], {}
    for p in [AUDIT, PLAN, CATALOG, FEATURE, TRANSFER, ASSISTANT]:
        dest = BASE/'source-inputs'/(p.parent.name+'--'+p.name)
        shutil.copyfile(p, dest)
        source_hashes[str(p)] = hashlib.sha256(p.read_bytes()).hexdigest()
    image = REPO/'landing/assets/cube-hero.png'
    shutil.copyfile(image, BASE/'assets/cube-hero.png')
    for model in plan['models']:
        label, mid = model['label'], model['model_id']
        a = artifacts[mid]
        manifest = json.loads(Path(a['manifest']).read_text())
        assert hashlib.sha256(Path(a['manifest']).read_bytes()).hexdigest() == a['manifest_sha256']
        assert model['aggregate_sha256'] == a['model_aggregate_sha256'] == manifest['aggregate_sha256'] == catalog[mid]['aggregate_sha256']
        # Catalog metadata is copied as supplied; no feature/status/capability inflation.
        cats = [{'Entry': catalog[mid], 'Manifest': manifest}]
        write(BASE/'manifests'/(label+'.json'), manifest)
        if mid == 'gemma-4-26b':
            # An assistant manifest is required by input validation but is never
            # served as a target. Its fixture registry entry has no claimed tools.
            cats.append({'Entry': {'id': assistant['model_id'], 'display_name': assistant['model_id'],
                                  'status': 'active', 'capabilities': []}, 'Manifest': assistant})
        prompt_input = Path('/tmp/darkbloom-0.9-validation/inputs/qwen35-serial-smoke.json')
        raw = json.loads(prompt_input.read_text())
        prompt = next(m['content'] for m in raw['rows'][0]['request']['messages'] if m['role'] == 'user')
        source_hashes[str(prompt_input)] = hashlib.sha256(prompt_input.read_bytes()).hexdigest()
        config = json.loads((Path('/tmp/darkbloom-release-090/prompt-artifacts')/a['prompt_contract_id']/'config.json').read_text())
        for cache in ['off', 'ssd']:
            cell = label+'-paged-'+cache+'-b1'
            data = {'catalog': cats, 'artifact': {k:a[k] for k in ['model_id','model_aggregate_sha256','prompt_contract_id']},
                    'prompt_artifact_dir': model['directory'],
                    'provider_binary': str(RUNTIME/'bin/darkbloom'),
                    'provider_sha256': transfer['files']['bin/darkbloom']['sha256'],
                    'metallib_sha256': transfer['files']['bin/mlx.metallib']['sha256'],
                    'sidecar_binary': str(RUNTIME/'bin/promptsidecar'),
                    'sidecar_sha256': transfer['files']['bin/promptsidecar']['sha256'],
                    'backend': 'paged', 'cache_mode': cache, 'mtp_mode': model['mtp'],
                    'tools_request': tools, 'prompt': prompt, 'max_concurrent': 1}
            if model['assistant_required']:
                data['assistant_path'] = str(RUNTIME/'gemma-assistant')
            if config.get('vision_config') is not None:
                data['vision_png'] = str(REMOTE/'assets/cube-hero.png')
                data['vision_sha256'] = hashlib.sha256(image.read_bytes()).hexdigest()
            write(BASE/'inputs'/(cell+'.json'), data)
            entries.append({'cell': cell, 'input': 'inputs/'+cell+'.json', 'model_directory': model['directory'],
                            'model_manifest': 'manifests/'+label+'.json',
                            'tool_validation': 'auto call execution with exact name/arguments; no inference-enforced constraint claim',
                            'vision': 'actual config declares vision' if 'vision_png' in data else 'not_applicable',
                            'discovery_alias_required': label in ['qwen35','qwen36'],
                            'status': 'not_run'})
    write(BASE/'bundle-plan.json', {'schema':1, 'go_test_binary_sha256':hashlib.sha256((BASE/'connected-e2e.test').read_bytes()).hexdigest(), 'source_commit':'3aa73029ef22a6292aefff005b2267856f665a3c',
          'remote_bundle_root':str(REMOTE), 'expected_request_date_utc':'2026-09-05',
          'canonical_config_sha256':'7236c7a23df7314a3504c484c52b2af596b97bf163c8a16f9836e9e3bcc9e3c1',
          'cells':entries, 'source_inputs_sha256':source_hashes,
          'state':'prepared, no connected real-provider execution',
          'additional_unrun_controls':['unsupported named tool_choice HTTP400','independent-machine routing','persistent restart/attestation', 'B2/B4 connected cohorts']})
    print('prepared',len(entries),'inputs')


if __name__ == '__main__': main()
