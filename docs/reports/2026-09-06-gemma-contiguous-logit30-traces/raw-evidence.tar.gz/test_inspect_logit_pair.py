"""Synthetic records test the offline validator; these are not measured logits."""
from copy import deepcopy
import json
from pathlib import Path
import struct
import unittest
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/'package'))
from inspect_logit_pair import BASE,inspect

class Checks(unittest.TestCase):
    def sample(self,mode='off'):
        control=json.loads((BASE/'controls'/mode/'report.json').read_text());report=deepcopy(control);off=mode=='off';token=795 if off else 735
        bits=lambda x:struct.unpack('<I',struct.pack('<f',x))[0]
        rec={'requestID':2,'outputIndex':30,'outputBase':30,'phase':'chained_decode' if off else 'rectangular_verify','batchIndex':0,'batchSize':1,'column':0,'verificationWidth':1 if off else 2,'draftDepth':0 if off else 1,'cacheOffset':5447,'backend':'CBv2ContiguousKVBackend','logitDType':'bfloat16','vocabularySize':262144,'seedToken':4615,'outcome':'confirmed','acceptedDrafts':0 if off else 1,'confirmedWidth':1 if off else 2,'draftPrefix':[],'targetToken':token,'argMaxID':token,'topTwoIDs':[token,735 if off else 795],'candidateIDs':[795,735],'valueBits':list(map(bits,[2.,2.,1.75,2. if off else 1.75,1.75 if off else 2.])),'nanCount':0,'infiniteCount':0}
        report['logit_diagnostic']={'status':'captured','snapshot':{'configuration':{'requestID':2,'outputIndex':30,'candidateIDs':[795,735],'maximumRecords':8},'records':[rec],'reservedRecords':1,'omittedRecords':0,'invalidVocabularyRecords':0,'hostMaterializationNanoseconds':1}}
        return report,control,rec
    def test_gaps_and_unknown_state(self):
        for mode,delta in [('off',.25),('automatic',-.25)]:
            r,c,_=self.sample(mode);out=inspect(r,c,mode);self.assertEqual(out['score_795_minus_735'],delta);self.assertEqual(out['top_two_gap'],.25);self.assertIsNone(out['full_target_input_ids']);self.assertEqual(out['pre_forward_state_equality'],'UNOBSERVED')
    def test_reject_context_and_value_defects(self):
        defects={'seedToken':999,'cacheOffset':5446,'argMaxID':735,'targetToken':735,'outcome':'speculative_suffix','outputIndex':29,'nanCount':1,'infiniteCount':1,'topTwoIDs':[735,795],'candidateIDs':[735,795],'valueBits':[0x7fc00000,0,0,0,0]}
        for key,value in defects.items():
            with self.subTest(key=key):
                r,c,rec=self.sample();rec[key]=value
                with self.assertRaises(ValueError):inspect(r,c,'off')
    def test_reject_incomplete_snapshots(self):
        for key,value in [('omittedRecords',1),('invalidVocabularyRecords',1),('reservedRecords',2)]:
            r,c,_=self.sample();r['logit_diagnostic']['snapshot'][key]=value
            with self.assertRaises(ValueError):inspect(r,c,'off')
    def test_reject_drift_after_boundary(self):
        r,c,_=self.sample();r['rows'][0]['token_ids'][55]=100
        with self.assertRaisesRegex(ValueError,'trajectory'):inspect(r,c,'off')
    def test_reject_auxiliary_trajectory_drift(self):
        r,c,_=self.sample();r['recovered']['token_ids'][55]=100
        with self.assertRaisesRegex(ValueError,'trajectory'):inspect(r,c,'off')
    def test_reject_counter_drift(self):
        r,c,_=self.sample('automatic');r['rows'][0]['metrics_after']['mtp']['rectangular_rounds']-=1
        with self.assertRaisesRegex(ValueError,'counters'):inspect(r,c,'automatic')
    def test_nonconfirmed_record_remains_separate(self):
        r,c,rec=self.sample();other=deepcopy(rec);other['outcome']='discarded';r['logit_diagnostic']['snapshot']['records'].append(other);r['logit_diagnostic']['snapshot']['reservedRecords']=2
        self.assertEqual(len(inspect(r,c,'off')['other_records']),1)
    def test_duplicate_confirmation_rejected(self):
        r,c,rec=self.sample();r['logit_diagnostic']['snapshot']['records'].append(deepcopy(rec));r['logit_diagnostic']['snapshot']['reservedRecords']=2
        with self.assertRaisesRegex(ValueError,'exactly one'):inspect(r,c,'off')
if __name__=='__main__':unittest.main()
