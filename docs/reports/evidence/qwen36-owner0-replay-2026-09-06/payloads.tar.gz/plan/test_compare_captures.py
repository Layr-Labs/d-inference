"""CPU-only planted-fault checks; no operator or model invocation."""
import copy
import json
from pathlib import Path
import sys
import unittest

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'runner'))
from attention_packet.files import PacketError
from attention_packet.packet import load_packet
from compare_captures import require_common_input, compare_output_to_both, native_comparison


class CommonInputTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        paths = json.loads((ROOT/'captures.json').read_text())
        cls.left = load_packet(Path(paths['contiguous']['path']))
        cls.right = load_packet(Path(paths['paged']['path']))

    def test_all_five_original_inputs_and_scale_match(self):
        result = require_common_input(self.left, self.right)
        self.assertEqual(len(result['commonInputNames']), 5)
        self.assertEqual(result['scaleBits'], 1031798784)
        self.assertEqual(result['seedToken'], 11346)

    def test_both_original_outputs_are_compared_and_mismatches_count_native_elements(self):
        for arm, packet in [('contiguous', self.left), ('paged', self.right)]:
            result = compare_output_to_both(packet.tensors['output'].raw, self.left, self.right)
            other = 'paged' if arm == 'contiguous' else 'contiguous'
            self.assertEqual(result[arm]['mismatchedNativeElements'], 0)
            self.assertEqual(result[other]['mismatchedNativeElements'], 786)
            self.assertEqual(result[other]['comparedNativeElements'], 4096)
            self.assertEqual(len(result[other]['float32DecodedComparison']['perHead']), 16)

    def test_changed_query_and_historical_stored_bytes_refuse(self):
        for name in ['queries', 'storedKeys', 'storedValues', 'incomingKeys', 'incomingValues']:
            changed = copy.deepcopy(self.right)
            raw = bytearray(changed.tensors[name].raw); raw[0] ^= 1
            changed.tensors[name].raw = bytes(raw)
            with self.assertRaisesRegex(PacketError, 'common input differs'):
                require_common_input(self.left, changed)

    def test_scale_context_model_identity_and_seed_refuse(self):
        for container, key in [('record', 'scaleBits'), ('record', 'outputIndex'),
                               ('record', 'offsetBefore'), ('snapshot', 'seedToken')]:
            changed = copy.deepcopy(self.right)
            getattr(changed, container)[key] += 1
            with self.assertRaises(PacketError): require_common_input(self.left, changed)
        changed = copy.deepcopy(self.right)
        changed.document['identity']['artifactSHA256'] = '0'*64
        with self.assertRaises(PacketError): require_common_input(self.left, changed)

    def test_unconfirmed_or_wrong_backend_refuse(self):
        changed = copy.deepcopy(self.right); changed.inconclusive_reasons = ['planted refusal']
        with self.assertRaises(PacketError): require_common_input(self.left, changed)
        changed = copy.deepcopy(self.right); changed.document['identity']['backend'] = 'contiguous'
        with self.assertRaises(PacketError): require_common_input(self.left, changed)

    def test_native_identity_preserves_signed_zero_and_rejects_short_bytes(self):
        descriptor = {'dtype': 'bfloat16', 'shape': [1, 1, 1, 1]}
        result = native_comparison(b'\x00\x00', b'\x00\x80', descriptor)
        self.assertEqual(result['mismatchedNativeElements'], 1)
        self.assertEqual(result['float32DecodedComparison']['global']['rmse'], 0)
        with self.assertRaises(PacketError): native_comparison(b'\x00', b'\x00\x00', descriptor)


if __name__ == '__main__': unittest.main()
