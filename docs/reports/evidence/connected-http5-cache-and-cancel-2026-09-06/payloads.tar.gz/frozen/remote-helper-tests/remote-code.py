import os,subprocess
os.chdir('/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http5')
raise SystemExit(subprocess.run(['python3','-B','-m','unittest','-v','test_connected_bundle','test_executable_modes','test_flat_runtime','test_local_assistant','test_temporary_model_alias']).returncode)
