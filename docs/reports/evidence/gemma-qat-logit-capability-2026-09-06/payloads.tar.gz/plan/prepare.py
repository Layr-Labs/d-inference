"""Plan four normal-MTP QAT controls around the first actual backend difference."""
from pathlib import Path
import hashlib,json,shutil,sys

OUT=Path('/tmp/darkbloom-qat-actual-logits-plan1');OUT.mkdir(exist_ok=False)
PILOT=Path('/tmp/darkbloom-q38-qat-backend-pilots1')
OLDROOT='/Users/gaj/autoresearch/radix-prefix-cache/090-q38-qat-backend-pilots1'
REMOTE='/Users/gaj/autoresearch/radix-prefix-cache/090-qat-actual-logits1'
WRAPPERS=Path('/tmp/darkbloom-q36-attention-owner-identity-plan1/runner')
RELEASE=Path('/tmp/darkbloom-q36-attention-owner-identity-runtime-binding1.json')

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(name,obj):
    p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def copy(name,p):
    q=OUT/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)

source_binding=json.loads(RELEASE.read_text())
assert sha(RELEASE)=='03bba023c5a22459469ee33bff351732a7adb4c3ab2d104d90d586a7f25f6377'
assert source_binding['artifacts']['radix-engine']['sha256']=='c15304623b6abc806fc47d312552eb888b10898ff6ef9f851e980fa1143578ba'
for name,row in source_binding['artifacts'].items():
    p=Path(source_binding['local_artifact_root'])/name
    assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'] and p.stat().st_mode&0o777==int(row['mode'],8)
copy('provenance/c153-runtime-binding.json',RELEASE)
copy('provenance/c153-root-release-review.json',Path(source_binding['review']))
copy('provenance/pilot-manifest.json',PILOT/'package/manifest.json')
copy('provenance/pilot-binding.json',PILOT/'bindings.reviewed.json')
copy('provenance/original-backend-difference.json',PILOT/'qat-cold-backend-divergence1.json')
copy('provenance/pilot-root-results-review.json',PILOT/'root-final-results-review.json')
copy('inputs/gemma-qat4.json',PILOT/'package/inputs/gemma-4-26b-qat-4bit.json')
assert sha(OUT/'inputs/gemma-qat4.json')=='1abb54db891314531df0b6ddfbe3cc3418c29fd014133cdf3837133c9e9a3080'
for row in json.loads((OUT/'inputs/gemma-qat4.json').read_text())['rows']:assert row['case']['max_tokens']==128
copy('model-manifest.json',PILOT/'package/provenance/qat/target-manifest.json')
assert sha(OUT/'model-manifest.json')=='c1fefb1fa593fa3ca83e72a1124fb3afca10a59eed272c7ac2ac4a57f8018dfd'
copy('assistant-files.json',Path('/tmp/darkbloom-connected-m5-bundle5/assistant-provenance/gemma-two-file-fixture-proof.json'))
copy('assistant-inventory.json',Path('/tmp/darkbloom-historical-window/gemma-assistant-inventory.json'))
for name in ['run_radix_engine.py','run_radix_http.py','radix_engine_evidence.py','compare_radix_engine.py','test_run_radix_engine.py']:
    copy('runner/'+name,WRAPPERS/name)
sys.path.insert(0,str(OUT/'runner'))
from run_radix_engine import arguments,probe_command
preview=json.loads((PILOT/'package/command-preview.json').read_text())['commands']
commands=[];historical={};correspondence=[]
for backend in ('contiguous','paged'):
    oldid=f'gemma-4-26b-qat-4bit-b1-r1-{backend}-cache-off'
    prior=next(c for c in preview if c['cell']==oldid)
    report=PILOT/'execution-qat-group1/payload/runs'/oldid/'report.json'
    copy('historical/'+backend+'-report.json',report)
    historical[backend]=json.loads(report.read_text())
    assert historical[backend]['input_sha256']==sha(OUT/'inputs/gemma-qat4.json')
    assert historical[backend]['rows'][0]['prompt_tokens']==5418
    for trace in (False,True):
        cell=f'gemma-qat4-{backend}-cache-off-mtp-on-trace-'+('on' if trace else 'off')
        argv=list(prior['argv'])
        argv[7]=REMOTE+'/runner/run_radix_engine.py'
        for flag,value in [('--binary',REMOTE+'/runtime/radix-engine'),('--input',REMOTE+'/inputs/gemma-qat4.json'),('--output',REMOTE+'/runs/'+cell)]:
            argv[argv.index(flag)+1]=value
        assert all(x==y for i,(x,y) in enumerate(zip(prior['argv'],argv))
                   if i not in [7,prior['argv'].index('--binary')+1,prior['argv'].index('--input')+1,prior['argv'].index('--output')+1])
        if trace:argv += ['--logit-diagnostic-position','7','--logit-diagnostic-candidates','42392,62203']
        args=arguments(argv[8:]);native=probe_command(args,REMOTE+'/runs/'+cell+'/report.json')
        assert args.mtp=='on' and args.cache=='off' and args.concurrency==1 and args.production_kv_grant
        assert args.attention_metadata_position is None
        observed=list(native);observed[2]=REMOTE+'/runs/'+cell+'/input.json'
        commands.append({'id':cell,'backend':backend,'trace':trace,'argv':argv,'native_argv_preview':native,
                         'expected_observed_native_argv':observed,'input_copy_substitution':{
                             'index':2,'from':native[2],'to':observed[2],'identical_sha256':sha(OUT/'inputs/gemma-qat4.json')}})
        correspondence.append({'cell':cell,'old_cell':oldid,'old_argv':prior['argv'],
                              'changes':'Wrapper/root, binary, input and output paths only; traced cell appends the two bounded logit options. All model/assistant/grant/cache/MTP/date/settings preserved.'})
a=historical['contiguous']['rows'][0];b=historical['paged']['rows'][0]
assert a['prompt_token_ids']==b['prompt_token_ids'] and a['token_ids'][:7]==b['token_ids'][:7]
assert [a['token_ids'][7],b['token_ids'][7]]==[42392,62203]
dump('source-correspondence.json',{'wrapper_files':{p.name:sha(p) for p in (OUT/'runner').iterdir()},
     'argv':correspondence,'historical_shared_prompt_count':5418,'historical_shared_output_prefix':a['token_ids'][:7],
     'historical_targets':[42392,62203],'historical_output_lengths':[len(a['token_ids']),len(b['token_ids'])],
     'cpu_argument_checks':4,'model_invoked':False,'remote_calls':False})
dump('plan.json',{'state':'SOURCE_ONLY_PENDING_ROOT_REVIEW','remote_root':REMOTE,
    'scope':'Actual QAT first-difference logits with four same-build controls; no numerical/performance acceptance.',
    'cells':commands,'input_sha256':sha(OUT/'inputs/gemma-qat4.json'),'prompt_tokens':5418,'output_cap':128,
    'expected_model_sha256':'2468a0cb3049a871f42052f4d9f9380bf12a0792f64c7a29f768559fc7d28785',
    'runtime_candidate':{**{k:source_binding[k] for k in ['artifacts','local_artifact_root','parent_commit','native_commit','review','review_sha256']},
                         'source_binding_sha256':sha(RELEASE),'remote_root':REMOTE,'remote_artifact_root':REMOTE+'/runtime',
                         'scope':'Candidate artifact identity only; Q36 input/model/commands are not bindings for this QAT plan. New plan/binding require root review before staging or execution.'},
    'selected_context':{'request_id':2,'output_index':7,'candidate_ids':[42392,62203],
                        'historical_prompt_tokens':5418,'historical_prior_ids':a['token_ids'][:7]},
    'gates':['Exact runtime7 artifacts bytes/modes, target model aggregate2468a0cb and bound assistant config/weights; no signing/key/default/config mutation.',
             'Sole M5 idle, fresh root and run roots, UTC September6, GPU<=42C/load1<=4/free>100GiB before each cell.',
             'All unchanged report_errors checks pass, requested/resolved backend exact without fallback, cacheoff/ephemeralSSD/B1/production grant/normal configured MTP.',
             'Control has no logit/attention diagnostics; each same-backend trace must preserve all7 completed prompt/output IDs, counts, finish and outcome. Canceled output must be own recovery prefix.',
             'Require captured selected logit record for request2/index7, exact candidates, confirmed sample, argmax/target equal emitted token, finite logits.',
             'Reconstruct selected MTP context using outputBase, column, seedToken and confirmed draftPrefix against actual emitted prior IDs. Do not assume chained_decode, seed=last prior ID, or fixed verification width.',
             'Require equal actual prompt IDs and seven generated prior IDs across backends before interpreting selected decision. Preserve phase/column/draft-depth/accepted/confirmed/cache-offset differences explicitly.',
             'If tracing changes trajectory or selected context, retain failure and block diagnostic comparison; do not disable MTP, change timers/capacity or substitute historical context.',
             'Original build8 failed pair remains separate earlier-build evidence. New control equality to historical trajectories is recorded separately; no mixed-build numerical waiver.'],
    'execution':'Not authorized; prepare immutable binding and strict driver for root review first.'})
copy('prepare.py',Path(__file__))
files={str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(OUT.rglob('*')) if p.is_file()}
dump('manifest.json',{'state':'SOURCE_ONLY_PENDING_ROOT_REVIEW','files':files})
print(json.dumps({'root':str(OUT),'payloads':len(files),'manifest_sha256':sha(OUT/'manifest.json'),
                  'cpu_argument_checks':4,'cells':len(commands),'shared_prefix':a['token_ids'][:7],
                  'no_remote_calls':True,'no_model_invocation':True},indent=2))
