"""Prepare staged recipes for existing runners; perform no inference execution."""
from pathlib import Path
import json
import re
import shutil
import unicodedata

from cohort_common import digest, identity, read_json, require, write_json
from quality_inputs import load

ROOT = Path(__file__).resolve().parent
MATRIX = Path('/tmp/darkbloom-six-artifact-batching-plan2')


def normalize(text):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', text)).strip().lower()


def main():
    cohort = load(ROOT)
    old = read_json(MATRIX/'plan.json')
    tuning, texts = [], []
    for model in old['models']:
        for length, item in old['workload_inputs'][model['label']].items():
            path = MATRIX/item['input']; document = read_json(path)
            tuning.append({'path': str(path), **identity(path), 'model': model['label'], 'workload': length})
            texts.extend(normalize(message['content']) for row in document['rows']
                         for message in row['request']['messages'] if message['role'] == 'user')
    old_spans = {text[index:index+128] for text in texts for index in range(max(0, len(text)-127))}
    overlaps = []
    for case in cohort['cases'].values():
        text = normalize(case['context_text'] + '\n' + case['reference_text'])
        if any(text[index:index+128] in old_spans for index in range(max(0, len(text)-127))):
            overlaps.append(case['id'])
    require(not overlaps, 'public case overlaps listed tuning fixture text')
    teacher_fixture_checks = []
    for label, name in [('qwen36', 'qwen36'), ('gemma-4-26b-qat-4bit', 'gemma-qat4')]:
        path = Path('/tmp/darkbloom-teacher-forced-model-inputs1')/(name+'.json')
        previous = read_json(path)
        for case in cohort['cases']:
            current = cohort['payloads'][(label, case)]['teacher']
            require(current['promptTokens'] != previous['promptTokens'], 'retained teacher prompt reused')
            require(current['continuation'] != previous['continuation'][:64], 'retained teacher continuation reused')
        teacher_fixture_checks.append({'path': str(path), **identity(path), 'new_prompts_and_reference_spans_distinct': True})
    write_json(ROOT/'holdout.json', {'schema': 1, 'listed_tuning_inputs': tuning,
        'retained_teacher_inputs': teacher_fixture_checks, 'normalized_shared_128_character_spans': overlaps,
        'scope': 'Disjoint from these listed local tuning fixtures only; no exclusion claim about model training or every prior experiment.',
        'training_data_exclusion_claim': False, 'corpus_selected_without_model_outputs': True})
    shutil.copy2(MATRIX/'provenance/gemma-two-file-fixture-proof.json', ROOT/'fleet/assistant-proof.json')
    for label, model in cohort['models'].items():
        path = ROOT/'config'/(label+'.toml'); path.parent.mkdir(exist_ok=True)
        path.write_text('[backend]\nmodel = '+json.dumps(model['model_id'])+'\nenabled_models = ['+json.dumps(model['model_id'])+']\n\n'
                        '[gemma_optimizations]\nprefill_layer18 = true\nweighted_r1 = true\n')
    pilot = ('gpt-oss-20b', 'prose-gutenberg-11-short')
    records = sorted(cohort['records'], key=lambda row: (0 if (row['model'], row['case_id']) == pilot else
        1 if row['length'] == 'short' else 2, row['domain'], row['model'], row['case_id']))
    cells = {}
    for scope in ['serving', 'teacher']:
        cells[scope] = [{'id': scope+'--'+row['model']+'--'+row['case_id']+'--'+backend,
                        'model': row['model'], 'case_id': row['case_id'], 'backend': backend,
                        'stage': 'pilot' if (row['model'], row['case_id']) == pilot else row['length'],
                        'input': row[scope]} for row in records for backend in ['contiguous', 'paged']]
    plan = {'schema': 1, 'state': 'prepared_no_model_execution', 'source_commit': '252ccfb94c7fa8c47a9eb35214e7e5e187d945b2',
        'source_lock_sha256': digest(ROOT/'source-lock.json'), 'payload_index_sha256': digest(ROOT/'payload-index.json'),
        'logical_cases': 12, 'artifacts': 6, 'model_case_payloads': 72,
        'serving_profile': old['serving_profile'], 'cells': cells,
        'stages': [{'id': 'pilot', 'model_cases': 1}, {'id': 'short', 'model_cases': 35}, {'id': 'long', 'model_cases': 36}],
        'serving_scope': 'B1, cache off, normal MTP per exact artifact, explicit contiguous/paged, production grant; existing exact trajectory comparator.',
        'teacher_scope': 'B1, cache/MTP off, scheduler-free eager reference likelihood; three exact controls; no serving-oracle role.',
        'reference_span': 'First 64 canonical reference tokens; may include protocol framing. Not a complete-answer accuracy score.',
        'preserved_external_gates': ['all existing numerical/trajectory gates', 'full B2/B4 admission and forward-width matrix',
            '2048-token and 10-second sustained decode qualification', 'HTTP/shared admission', 'persistent-key restart',
            'same-state geometry/path gate before any teacher-to-serving oracle claim', 'whole-verifier/default/release gates'],
        'new_numerical_tolerances': [], 'quality_pass': None,
        'gemma8_m3_prohibited': True, 'model_admission_clearance_claimed': False,
        'prompt_date_policy': 'Literal request-owned 2026-09-06 date. Do not silently rerender; a changed date produces a successor input identity.',
        'runtime_binding': 'Unbound until the new runtime and exact model/assistant paths are reviewed; no old runtime reuse.'}
    write_json(ROOT/'plan.json', plan)
    write_json(ROOT/'binding-template.json', {'schema': 1, 'state': 'unreviewed', 'review_id': None,
        'runtime_manifest': {'path': None, 'sha256': None}, 'runtime_directory': None, 'execution_root': None,
        'expected_runtime_source': {'parent': plan['source_commit'], 'native': 'f88dfefa18d18408432a5487ebacd7bd42615165',
                                    'swift': '9561227d55a07db29f70a78aadc5d6b5aaeb10bf'},
        'models': {label: {'directory': None, 'assistant_directory': None,
                           'teacher_fixture_home': None, 'teacher_snapshot': None} for label in cohort['models']},
        'python_executable': None, 'reviewed_cell_ids': [], 'host_id': None,
        'host_identity': {'hardware_model': None, 'physical_memory_bytes': None},
        'macmon': {'path': None, 'sha256': None}, 'serving_profile': plan['serving_profile']})
    print('Prepared 72 model/case payloads, 144 serving cells and 144 independent teacher cells; no model runs.')


if __name__ == '__main__':
    main()
