# Process facade and atomic model-load ownership

Status: 21 source/test paths frozen; no compilation, Swift tests or model work executed in this lane. Base966eac55c plus the explicitly verified3Swift ownership-audit overlay and core freeze1. See manifest.json for exact identities. Do not edit this freeze; fixes require a new version.

## Scope and file ownership

The actor facade now routes actual C through ProcessMemoryLedger. It keeps correlation, timestamps, reserve push epochs, audit and reclaimer orchestration. New GlobalKVCacheBudget+Headroom gives coherent usage plus explicit total C vs outstanding C-M; new +PendingLoads owns typed generation handles. ProcessMemoryLedger receives only an additive OS-reserve admission constraint, a same-C fresh recheck, and a policy-only getter; its original freeze1 remains untouched elsewhere.

EngineProcessMemoryOwner provides synchronous replaceCharge(UInt64), recordMaterialization(UInt64), withdrawCoverage(UInt64), retire() and diagnostic snapshot() methods. It conforms to root's new CBv2ProcessMemoryOwner protocol. One NSLock maintains its revision identity, with one bounded stale-policy retry on C replacement. Lock order: native Admission -> owner -> ledger -> coherent allocator counters. No callbacks, actor waits or GPU work occur in the adapter.

Daemon and standalone loading now obtain an accepted generation lease before weight loading. Both have a single atomic target+assistant claim; if the optional assistant's extra margin loses a concurrent race, a target-only claim retries once without further eviction. Hashing/pre-load hooks preserve the held claim, then an explicit same-owner fresh policy/usage recheck precedes allocation. Phase completion reduces only that handle. Catch/success cleanup cannot release a different generation sharing its model string.

The old unconditional reservePendingLoad and replacePendingLoadReservation APIs are deleted. The obsolete floating-point fitsAtAllocation read-and-add-back helper and its2 arithmetic tests are deleted; new tests exercise the actual transaction. MTP fallback and test seams use the typed handle, including explicit assertions that synthetic permits were actually accepted. The tests use minimumKVBytes=0 only when isolating existing weight-phase behavior, never as a production bypass.

ProviderLoop.availableMemoryGb, StandaloneServer.availableMemoryGb and heartbeat max-loadable-weight calculations now obtain U and C-M from one shared snapshot. The heartbeat retains the hasInflightWork guard before assuming model memory is reclaimable. Peak usage remains a separate advisory gauge. GlobalKVCacheBudget.outstandingReservedBytes retains total-C semantics for existing diagnostics/tests; capacity readers no longer add full C to independently sampled U.

## Load policy parity

Let R=UnifiedMemoryCap.loadReserveBytes, including the hard cap, absolute OS floor and operator reserve. The ordinary ledger policy has effectiveCap=physical-R and activation reserve A. Runtime headroom is min(effectiveCap-U, OSfree)-A, saturated at zero.

Load claim/recheck additionally subtracts R from the OS bound: min(effectiveCap-U, max(OSfree-R,0))-A. This equals the prior min(physical-U,OSfree)-R-A, including when OS availability is tighter than physical-cap headroom. R is an admission/recheck constraint; it does not silently become a stricter policy for every existing runtime reservation.

Pending C equals padded target weights (existing disk*1.2 estimate) + optional separately loaded assistant + minimumLoadKV. Activation is already held in policy and is not added again. Once target weights are resident, only assistant plus minimumLoadKV remain; once assistant construction ends, only minimumLoadKV remains. That allowance survives post-build validation and target-only rebuild and ends after final slot installation. Failure cleanup remains after native load/build unwind.

Load M remains zero. The code never invents exact model residency from concurrent process before/after deltas. Ordinary U accounts for completed weight phases after their pending promise is explicitly reduced. During loading, U plus the still-held conservative promise can temporarily overcount; no final mixed-mode capacity claim is made from this slice.

The setup allowance is additive to any native construction backing until setup ends. If real exact-fit construction shows that the same intended allowance is double-counted, transfer that allowance with explicit ownership into the native engine aggregate. Do not credit one backing allocation as M in both load and engine owners.

## Native dependency and remaining binding

This source intentionally depends on root's new native protocol in wt/native-process-memory and the coherent MLX Memory.snapshot implementation. Building against the old independent snapshot getters is insufficient evidence for capacity correctness even if the Swift name compiles.

Provider factory and EngineV2Bridge files are unchanged in this slice. Root owns binding before native resource preparation and removing legacy contiguous bridge reservations only when that backend has actual complete-C authority. Merely binding the new native owner while leaving old contiguous claims would double charge the request. Contiguous/recurrent/MTP/scratch materialization proof and real mixed-engine capacity remain required.

Contiguous hooks requiring native ownership: FullSequenceKV.ensureCapacity zeros/doubling/concatenation; WindowedSequenceKV ring backing and temporary copies; FrozenReplayFullSequenceKV retained source plus growth; evaluated engine roots after the actual step fence; explicit withdrawal before old aliases disappear. ContiguousKVBackend.bytesInUse/row.byteCount is not a proof that buffers are evaluated or uniquely owned. Its release method only removes registry references. The request/snapshot/donor aliases must drain before C refund. Borrowed layers and same backing in stage/active state must receive one M credit.

## Focused validation handoff

Only API's sole Swift/Metal lane may execute builds/tests. Verify all manifest hashes before overlaying these 21 paths together with consciously selected native/dependency commits. Retain commands, toolchain, full output, selected source identities and failed attempts.

Run the new processBudget filter (8 functions), processLedger filter (original 18 plus 1 load-constraint function and 1 preparation function), existing GlobalKVCacheBudget tests/audit, SpecDecCapacity, ModelLoadAdmission, MTPResliceFallback, activation-reserve/load-gate tests and affected provider/standalone capacity tests. New concurrency tests compete a synchronous native owner against an actor load claim at one exact remainder; no actual engine/GPU is simulated as proof here. The integration must compile all ProviderCore tests so removed APIs cannot leave dormant callers.

Explicit regressions covered by new tests: native M prevents load double tax; exact-fit/+1 under the same process owner set; stricter OS-limited load constraint with unchanged runtime policy; target/assistant/setup phase retention; stale generation cleanup; serving-floor increase before allocation; optional assistant refusal without target refusal; native/load concurrent claim exclusion; closing accepts already-reserved materialization and mandatory retirement. Core recheck test exercises a same-C fresh sample, stale policy, closing and unblocked reduction.

After those pass, real production binding still needs actual two-engine and mixed contiguous/paged growth/retirement, real model load/unload, B1/B2/B4 context/admission and HTTP validation. This source freeze adds no new model benchmark or release-readiness claim.

## Freeze2 startup correction and native review

Root review found that freeze1 eagerly touched MLX while constructing the public budget. All current CLI serve/benchmark entry points already bind runtime metallib before their constructors, but direct public construction and tests previously stayed lazy. Freeze2 restores that contract: ProcessInfo supplies physical total without MLX access. Production supplies a lazy static-once allocator warmup; ProcessMemoryLedger runs preparation before its lock for charge replacement, same-charge recheck and snapshots. EngineProcessMemoryOwner construction explicitly warms before native Admission can exist. Injected readers default to no-op preparation. Reductions remain unconditionally available after warmup and never reapply usage, policy or OS gates.

The new pure preparation test verifies constructor/scalar operations stay lazy, preparation can reenter policySnapshot outside the ledger lock, every usage transaction prepares before its coherent sample, and engine-owner construction warms before native use. The existing closing-owner adapter test now requires unknownOwner for a second zero write, growth or coverage withdrawal after that generation disappears; repeated retire remains idempotent. Native Admission must skip unchanged zero publications during subsequent empty-pool teardown. Actual native/provider integration still must execute that teardown path with this real adapter; these source tests do not claim it happened.

Read-only review of root's native paged draft found no additional correctness defect: complete C precedes native mutations; shared segment backing carries one evaluated M credit through rebase; trim/pool close invalidate M before floor C refund; partial preparation destroys private wrappers before rollback; deinit never refunds C. Lock direction is coverage/physical lease to Admission to provider owner to process ledger. Backing mutation depends on exclusive private-stage or engine-queue ownership. Remaining requirements are real U plus C-M exact-fit integration, contiguous/recurrent/MTP/scratch materialization, production binding and real-model tests.
