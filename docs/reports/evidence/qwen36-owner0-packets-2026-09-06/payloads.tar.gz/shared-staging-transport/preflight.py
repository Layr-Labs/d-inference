from pathlib import Path
import json
import subprocess
import sys

ssh = ['ssh', '-i', '/Users/gaj/.ssh/darkbloom_testbox', '-o', 'IdentitiesOnly=yes',
       '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'gaj@100.124.35.99']
code = '''import json,subprocess,os,shutil,time
from pathlib import Path
raw=subprocess.check_output(['ps','-axo','pid=,ppid=,comm=,args='],text=True)
markers=('Runner.Worker','benchctl measure-job','measure-job.sh','radix-engine','run_radix_engine.py','connected-e2e.test')
processes=[]
for line in raw.splitlines():
 bits=line.strip().split(None,3)
 if len(bits)>2 and (any(marker in line for marker in markers) or Path(bits[2]).name=='darkbloom'):
  processes.append({'pid':bits[0],'ppid':bits[1],'command':bits[2]})
temp=json.loads(subprocess.check_output([str(Path.home()/'bench-runner/bin/macmon'),'pipe','-s','1','-i','200'],text=True,timeout=10).splitlines()[0])['temp']['gpu_temp_avg']
print(json.dumps({'unix_time':time.time(),'processes':processes,'gpu_temp_c':temp,'load':os.getloadavg(),'free_disk_bytes':shutil.disk_usage('/Users/gaj').free},indent=2))
'''
compile(code, '<remote-preflight>', 'exec')
result = subprocess.run(ssh + ['python3 -'], input=code, text=True, capture_output=True)
assert result.returncode == 0, result.stderr
path = Path(sys.argv[1])
with path.open('x') as output:
    output.write(result.stdout)
value = json.loads(result.stdout)
print(result.stdout)
assert not value['processes'], 'Conflicting live processes'
assert value['gpu_temp_c'] <= 42, 'Entry temperature above 42 C'
assert value['load'][0] <= 4, 'Entry load above 4'
assert value['free_disk_bytes'] > 20 * 1024 ** 3, 'Less than 20 GiB free disk'
