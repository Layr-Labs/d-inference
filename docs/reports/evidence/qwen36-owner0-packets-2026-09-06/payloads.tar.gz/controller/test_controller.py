import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import sys

SOURCE=Path('/tmp/darkbloom-q36-attention-packet-plan1')
sys.path.insert(0,str(SOURCE/'runner'))
from evidence_files import remote_script,safe_download_name,prior_cells,verify_manifest
from strict_results import result_errors

class ControllerGuardTests(unittest.TestCase):
    def test_serialized_remote_configuration_preserves_ROOT_quotes_newlines(self):
        config={'root':"/tmp/ROOT's `$(secret)`\npath",'state':'SOURCE_ONLY_PENDING_ROOT_REVIEW'}
        code=remote_script('observed = CONFIG',config); namespace={};exec(code,namespace)
        self.assertEqual(namespace['observed'],config)

    def test_bad_remote_template_refused_before_transport(self):
        with self.assertRaises(SyntaxError): remote_script('not python ?',{'ROOT':'value'})

    def test_both_remote_programs_compile_with_serialized_constants(self):
        for name in ['remote_precheck.py','remote_inventory.py']:
            self.assertIsInstance(remote_script((Path(__file__).parent/name).read_text(),{'root':"/tmp/ROOT's path"}),str)

    def test_only_known_nested_packet_files_may_download(self):
        self.assertEqual(safe_download_name('report.attention-packet/stored-keys.bin'),('report.attention-packet','stored-keys.bin'))
        for name in ['../secret','/tmp/secret','prefix-cache/key','report.attention-packet/../secret','report.attention-packet/extra.bin']:
            with self.subTest(name=name),self.assertRaises(AssertionError): safe_download_name(name)

    def test_failed_prior_cell_blocks_successor(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);(root/'a').mkdir();(root/'a/summary.json').write_text(json.dumps({'exit_code':0,'report_integrity_passed':False}))
            plan={'cells':[{'id':'a'},{'id':'b'}]}
            with self.assertRaisesRegex(AssertionError,'Prior failed'): prior_cells(plan,plan['cells'][1],root)

    def test_drifted_successful_prior_evidence_blocks_successor(self):
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp);cell=root/'a';cell.mkdir();p=cell/'summary.json';p.write_text(json.dumps({'exit_code':0,'report_integrity_passed':True}))
            manifest={'files':{'summary.json':{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}}}
            m=cell/'manifest.json';m.write_text(json.dumps(manifest));(cell/'completion-receipt.json').write_text(json.dumps({'manifest_sha256':hashlib.sha256(m.read_bytes()).hexdigest()}))
            plan={'cells':[{'id':'a'},{'id':'b'}]};prior_cells(plan,plan['cells'][1],root)
            p.write_text(json.dumps({'exit_code':0,'report_integrity_passed':True,'extra':'drift'}))
            with self.assertRaises(AssertionError): prior_cells(plan,plan['cells'][1],root)

class TrajectoryBindingTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        self.plan=json.loads((SOURCE/'plan.json').read_text());self.cell=self.plan['cells'][3]
        old=Path('/tmp/darkbloom-q36-attention-metadata-execution1')
        self.report=json.loads((Path(__file__).parent/'test-inputs/paged-metadata-trace.json').read_text())
        control=self.root/self.plan['cells'][1]['id'];control.mkdir()
        (control/'report.json').write_bytes((Path(__file__).parent/'prior-controls/paged.json').read_bytes())
        self.local=self.root/self.cell['id'];self.local.mkdir()
        (self.local/'input.json').write_bytes((SOURCE/'expected-wrapper-input.json').read_bytes())
        self.binding={'artifacts':{'radix-engine':{'sha256':'e'*64}},'commands':[{'cell':self.cell['id'],'expected_observed_native_argv':self.cell['native_argv_after_date_pin']}]}
        self.meta={'command':copy.deepcopy(self.cell['native_argv_after_date_pin']),'source_input_sha256':self.plan['source_input_sha256'],
                   'input_sha256':self.plan['actual_wrapper_input_sha256'],'binary_sha256':'e'*64,'exit_code':0,'status':'completed'}
        self.save()
    def tearDown(self):self.temp.cleanup()
    def save(self):(self.local/'metadata.json').write_text(json.dumps(self.meta))
    def errors(self):return result_errors(self.local,self.cell,self.plan,self.binding,self.report,self.root)
    def test_retained_valid_paged_trajectory_and_metadata_pass_host_binding(self):self.assertEqual(self.errors(),[])
    def test_wrong_actual_input_copy_or_probe_hash_refuses(self):
        self.meta['command'][2]='canonical-not-actual-input';self.save();self.assertTrue(self.errors())
        self.meta['command']=self.cell['native_argv_after_date_pin'];self.meta['binary_sha256']='f'*64;self.save();self.assertTrue(self.errors())
    def test_wrong_backend_or_changed_completed_output_refuses(self):
        self.report['resolved_backend']='contiguous';self.assertTrue(self.errors())
        self.report['resolved_backend']='paged';self.report['rows'][0]['token_ids'][63]=1;self.assertTrue(self.errors())
    def test_repeated_owner_or_discarded_logit_refuses(self):
        records=self.report['attention_metadata']['snapshot']['records'];records[1]=copy.deepcopy(records[0]);self.assertTrue(self.errors())
        self.report['logit_diagnostic']['snapshot']['records'][0]['outcome']='discarded';self.assertTrue(self.errors())

if __name__=='__main__':unittest.main()
