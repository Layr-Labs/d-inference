#!/usr/bin/env python3
"""Verify frozen package files, without invoking any provider or service."""
from pathlib import Path
import json
from temporary_model_alias import digest
base = Path(__file__).resolve().parent
manifest = json.loads((base/'package-manifest.json').read_text())
for name, item in manifest['files'].items():
    rel = Path(name)
    if rel.is_absolute() or '..' in rel.parts:
        raise ValueError('nonlocal package path')
    path = base/rel
    if path.is_symlink() or path.stat().st_size != item['bytes'] or digest(path) != item['sha256']:
        raise ValueError('package mismatch: ' + name)
print(json.dumps({'verified_files':len(manifest['files']), 'source_commit':manifest['source_commit'],
                  'scope':'package integrity only; no connected execution'}, indent=2))
