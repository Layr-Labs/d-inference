from pathlib import Path
import json
ROOT=Path('/tmp/darkbloom-qat-mtp-off-execution2')
reports={k:json.loads((ROOT/('gemma-qat4-'+k+'-cache-off-mtp-off-trace-off')/'report.json').read_text()) for k in ['contiguous','paged']}
a,b=reports.values();fields=['prompt_token_ids','token_ids','prompt_tokens','completion_tokens','finish','outcome'];rows=[]
for group in ['rows','tenant_checks','cancel_donor','recovered']:
 left=a[group]if isinstance(a[group],list)else[a[group]];right=b[group]if isinstance(b[group],list)else[b[group]]
 assert len(left)==len(right)
 for i,(x,y)in enumerate(zip(left,right)):
  rows.append({'path':group+':'+str(i),'fields_equal':all(x[k]==y[k]for k in fields),'prompt_tokens':x['prompt_tokens'],'completion_tokens':x['completion_tokens'],'first_difference':next((j for j,(xx,yy)in enumerate(zip(x['token_ids'],y['token_ids']))if xx!=yy),None)})
assert len(rows)==7 and all(r['fields_equal']for r in rows)
result={'scope':'Same-build QAT MTP-off/B1/cache-off backend pair. Normal-MTP failed comparison remains separate.','rows':rows,'cancel_prefixes':{n:r['cancelled']['token_ids']==r['recovered']['token_ids'][:len(r['cancelled']['token_ids'])]for n,r in reports.items()},'main_ids':a['rows'][0]['token_ids'],'prompt_identical':a['rows'][0]['prompt_token_ids']==b['rows'][0]['prompt_token_ids'],'backend_strict':json.loads((ROOT/'gemma-qat4-paged-cache-off-mtp-off-trace-off/strict-backend-comparison.json').read_text())}
Path(__file__).with_name('analysis.json').write_text(json.dumps(result,indent=2)+'\n')
