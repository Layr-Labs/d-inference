from pathlib import Path
import difflib
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

OUT = Path('/tmp/darkbloom-provider-cancel-settlement-validation3')
PRIMARY = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
SOURCE = Path('/tmp/darkbloom-provider-cancel-settlement-source4')
REFERENCE = Path('/tmp/darkbloom-receipt-diagnostic-provider-validation1')
SCRATCH = Path('/tmp/darkbloom-process-memory-telemetry-swift-validation1/build')
MLX = Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift')
PARENT = '5b93195c93efce01a4d455f8e2d0f04e68268096'
NATIVE = '5cb848dfdaae04118ecfa901f53fc21a4aa86a06'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    path = OUT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def archive(repo, commit, target, path=None):
    target.mkdir(parents=True)
    command = ['git', 'archive', '--format=tar', commit]
    if path:
        command.append(path)
    raw = subprocess.check_output(command, cwd=repo)
    objects = {}
    tree = subprocess.check_output(['git', 'ls-tree', '-rz', commit], cwd=repo)
    for entry in tree.split(b'\0'):
        if not entry:
            continue
        header, name = entry.split(b'\t', 1)
        mode, kind, oid = header.decode().split()
        name = name.decode()
        if kind == 'blob' and (path is None or name.startswith(path + '/')):
            objects[name] = oid
    with tarfile.open(fileobj=io.BytesIO(raw)) as tar:
        for member in tar.getmembers():
            if member.isdir():
                (target / member.name).mkdir(parents=True, exist_ok=True)
                continue
            assert member.isfile(), ('unexpected archive member', member.name)
            payload = tar.extractfile(member).read()
            oid = hashlib.sha1(b'blob ' + str(len(payload)).encode() + b'\0' + payload).hexdigest()
            assert oid == objects[member.name], member.name
            dest = target / member.name
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(payload)
            dest.chmod(member.mode & 0o777)
    actual = {str(p.relative_to(target)) for p in target.rglob('*') if p.is_file()}
    assert actual == set(objects), (len(actual), len(objects))
    return objects


def inventory(root):
    return {str(p.relative_to(root)): sha(p) for p in sorted(root.rglob('*')) if p.is_file()}


def main():
    assert sha(SOURCE / 'manifest.json') == '3a3f7e3a8e9ebf5d041c019ad31fcbdeb825eb06859b2bacf94cc261bc3a600d'
    for row in json.loads((SOURCE / 'manifest.json').read_text())['files']:
        path = SOURCE / row['path']
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], row['path']
    assert sha(REFERENCE / 'manifest.json') == '78c24dfaf5aa2ae5c5e0692bf136f2610a8946062f008d0d61c11ffcfe61c4a6'
    reference = json.loads((REFERENCE / 'manifest.json').read_text())['files']
    for name in ['dependency-source-manifest.json', 'jinja-source-manifest.json']:
        assert sha(REFERENCE / name) == reference[name]['sha256']
        shutil.copy2(REFERENCE / name, OUT / name)
    dependencies = json.loads((OUT / 'dependency-source-manifest.json').read_text())
    for name, digest in dependencies['files'].items():
        alias, relative = name.split('/', 1)
        assert sha(Path(dependencies['repositories'][alias]) / relative) == digest, name
    jinja = json.loads((OUT / 'jinja-source-manifest.json').read_text())
    for name, digest in jinja['files'].items():
        assert sha(SCRATCH / 'checkouts/swift-jinja' / name) == digest, name
    write('scratch-workspace-before.json', json.loads((SCRATCH / 'workspace-state.json').read_text()))

    native = OUT / 'native'
    prior = Path('/tmp/darkbloom-provider-cancel-settlement-validation1')
    pinned = json.loads((prior / 'native-source-manifest.json').read_text())
    assert pinned['base'] == NATIVE
    for name, digest in pinned['files'].items():
        assert sha(prior / 'native' / name) == digest, name
    native.symlink_to(prior / 'native', target_is_directory=True)
    native_objects = pinned['git_objects_before_package_overlay']
    write('native-source-manifest.json', pinned)
    overlays = {'native/Package.swift': json.loads((prior / 'source-correspondence.json').read_text())['package_only_overlays']['native/Package.swift']}
    source_info = json.loads((SOURCE / 'summary.json').read_text())
    provider_counts = {}
    correspondence = []
    for variant in ['baseline', 'candidate']:
        workspace = OUT / variant / 'workspace'
        objects = archive(PRIMARY, PARENT, workspace, 'provider-swift')
        (workspace / 'libs').mkdir()
        (workspace / 'libs/mlx-swift-lm').symlink_to(native, target_is_directory=True)
        (workspace / 'libs/mlx-swift').symlink_to(MLX, target_is_directory=True)
        selected = source_info['baseline_files' if variant == 'baseline' else 'candidate_files']
        for relative in selected:
            dest = workspace / relative
            before = SOURCE / 'before' / relative
            if before.exists():
                assert sha(dest) == sha(before), relative
            else:
                assert not dest.exists(), relative
            staged = SOURCE / variant / relative
            shutil.copy2(staged, dest)
            correspondence.append({'variant': variant, 'path': relative, 'before_sha256': sha(before) if before.exists() else None, 'staged_sha256': sha(dest), 'frozen_source_sha256': sha(staged)})
        package = workspace / 'provider-swift/Package.swift'
        old = package.read_text()
        original = '.package(path: "../libs/mlx-swift")'
        assert old.count(original) == 1
        package.write_text(old.replace(original, '.package(path: "' + str(MLX) + '")'))
        overlays[variant + '/provider-swift/Package.swift'] = ''.join(difflib.unified_diff(old.splitlines(True), package.read_text().splitlines(True)))
        files = {'provider-swift/' + name: value for name, value in inventory(workspace / 'provider-swift').items()}
        provider_counts[variant] = len(files)
        write(variant + '/provider-source-manifest.json', {'base': PARENT, 'files': files, 'git_objects_before_overlays': objects})
    write('source-correspondence.json', {'changed_files': correspondence, 'package_only_overlays': overlays, 'provider_files': provider_counts, 'native_files': len(native_objects), 'native_identical_in_both_variants': True})
    shutil.copy2(SOURCE / 'manifest.json', OUT / 'approved-source-manifest.json')
    shutil.copy2('/tmp/darkbloom-provider-cancel-settlement-root-source-review2.json', OUT / 'root-source-review.json')
    lib = Path('/tmp/darkbloom-final-serving-build8/artifact/mlx.metallib')
    assert sha(lib) == '4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0'
    write('integration.json', {
        'status': 'prepared only; source4 diagnostic-only baseline retry authorized by root message; no Swift invocation', 'parent': PARENT, 'native': NATIVE,
        'source_manifest_sha256': sha(SOURCE / 'manifest.json'),
        'root_source_review_sha256': sha(OUT / 'root-source-review.json'),
        'scratch': str(SCRATCH), 'mlx_dependency': str(MLX),
        'metallib': str(lib), 'metallib_sha256': sha(lib),
        'package_changes': 'Only mlx-swift dependency locations; no resolution/pin mutations',
        'provider_files': provider_counts, 'native_files': len(native_objects),
        'dependencies_verified': len(dependencies['files']), 'jinja_verified': len(jinja['files']),
        'baseline': '5b parent, explicit 5cb native, neutral DEBUG hooks and the same real hit/cold handler tests',
        'candidate': 'Same pins and native, approved cancellation source/test overlay',
        'execution_policy': 'Root explicitly authorized source4 diagnostic-only baseline retry once frozen; current owner holds sole local Swift lane. No candidate, model weights, remote jobs, key or daemon mutations.'})
    print(json.dumps(json.loads((OUT / 'integration.json').read_text()), indent=2))


if __name__ == '__main__':
    main()
