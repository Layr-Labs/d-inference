"""Source-only retry calibration; remote calls and model execution are mocked."""
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
PLAN = Path('/tmp/darkbloom-qat-actual-logits-plan2')
OLD = Path('/tmp/darkbloom-qat-actual-logits-plan1')

def module():
    spec = importlib.util.spec_from_file_location('qat_successor_driver', ROOT/'run_cell.py')
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

class SuccessorDriverTests(unittest.TestCase):
    def test_all_four_cells_render_and_preserve_failures_without_network_or_model(self):
        plan = json.loads((PLAN/'plan.json').read_text())
        for index, cell in enumerate(plan['cells']):
            with self.subTest(cell=cell['id']), tempfile.TemporaryDirectory() as temp:
                value = module(); value.OUT = Path(temp)
                for source in ROOT.iterdir():
                    if source.is_file(): shutil.copy2(source, value.OUT/source.name)
                for prior in plan['cells'][:index]:
                    prior_root = value.OUT/prior['id']; prior_root.mkdir()
                    raw = json.dumps({'exit_code': 0, 'report_integrity_passed': True}).encode()
                    (prior_root/'summary.json').write_bytes(raw)
                    (prior_root/'manifest.json').write_text(json.dumps({'files': {'summary.json': {
                        'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}}}))
                rendered = []
                def fake_run(argv, **kwargs):
                    code = kwargs.get('input')
                    if code is not None:
                        compile(code, '<qat-successor-rendered>', 'exec')
                        self.assertNotIn('__REMOTE_ROOT_PATH__', code)
                        self.assertIn('090-qat-actual-logits2', code)
                        self.assertNotIn('090-qat-actual-logits1', code)
                        rendered.append(code)
                    return SimpleNamespace(returncode=0, stdout='{"files": {}}', stderr='')
                with patch.object(value.subprocess, 'run', side_effect=fake_run), patch.object(
                    sys, 'argv', [str(ROOT/'run_cell.py'), cell['id']]):
                    with self.assertRaises(SystemExit) as raised: value.main()
                self.assertEqual(raised.exception.code, 1)  # No model report exists in the mock.
                self.assertEqual(len(rendered), 2)
                summary = json.loads((value.OUT/cell['id']/'summary.json').read_text())
                self.assertEqual(summary['errors'], ['report missing'])
                self.assertTrue((value.OUT/cell['id']/'manifest.json').is_file())

    def test_only_owned_roots_change_in_cell_arguments_and_all_helpers_are_exact(self):
        old = json.loads((OLD/'plan.json').read_text()); new = json.loads((PLAN/'plan.json').read_text())
        def relocate(value):
            if isinstance(value, str) and value.startswith(old['remote_root']+'/'):
                return new['remote_root']+value[len(old['remote_root']):]
            if isinstance(value, list): return [relocate(v) for v in value]
            if isinstance(value, dict): return {k: relocate(v) for k, v in value.items()}
            return value
        self.assertEqual(new['cells'], relocate(old['cells']))
        for key in ['input_sha256', 'expected_model_sha256', 'output_cap', 'prompt_tokens', 'selected_context', 'gates']:
            self.assertEqual(new[key], old[key])
        for name in ['strict_results.py', 'test_strict_results.py', 'preflight.py']:
            self.assertEqual((ROOT/name).read_bytes(), (Path('/tmp/darkbloom-qat-actual-logits-execution2')/name).read_bytes())
        for source in (OLD/'runner').iterdir():
            if source.is_file(): self.assertEqual(source.read_bytes(), (PLAN/'runner'/source.name).read_bytes())
        self.assertEqual((OLD/'inputs/gemma-qat4.json').read_bytes(), (PLAN/'inputs/gemma-qat4.json').read_bytes())

    def test_wrong_binding_hash_refuses_before_host_or_remote_work(self):
        value = module(); original = value.sha
        def wrong(path): return '0'*64 if path == value.BINDING else original(path)
        with patch.object(value, 'sha', side_effect=wrong), patch.object(value.subprocess, 'run') as run:
            with self.assertRaises(AssertionError): value.main()
            run.assert_not_called()

if __name__ == '__main__': unittest.main()
