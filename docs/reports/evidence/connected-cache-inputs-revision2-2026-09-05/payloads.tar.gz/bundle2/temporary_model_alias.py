#!/usr/bin/env python3
"""Exclusive, reversible discovery aliases for this connected fixture only."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import secrets
import subprocess

MARKER = '.darkbloom-connected-owner.json'
ALIAS_MODELS = {'qwen3.5-35b-a3b', 'qwen3.6-35b-a3b-vl-mtp-mxfp8'}


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def verify_snapshot(target, manifest):
    target = Path(target)
    if not target.is_dir() or target.resolve() != target:
        raise ValueError('target must be an existing absolute canonical directory')
    for item in manifest['files']:
        rel = Path(item['path'])
        if rel.is_absolute() or '..' in rel.parts:
            raise ValueError('nonlocal manifest path')
        p = target / rel
        if p.stat().st_size != item['size_bytes'] or digest(p) != item['sha256']:
            raise ValueError('exact snapshot mismatch: ' + item['path'])


def create_alias(cache_root, target, manifest, journal, idle_check=None):
    cache_root, target, journal = map(Path, (cache_root, target, journal))
    mid, revision = manifest['model_id'], target.name
    if mid not in ALIAS_MODELS or not revision or '/' in revision:
        raise ValueError('only the two explicit undiscovered Qwen models may be aliased')
    if journal.exists() or journal.is_symlink():
        raise FileExistsError('journal already exists')
    model_root = cache_root / ('models--' + mid.replace('/', '--'))
    # Refuse an existing directory OR dangling symlink, before expensive hashing.
    if os.path.lexists(model_root):
        raise FileExistsError('model root already exists; never replace it')
    verify_snapshot(target, manifest)
    if idle_check is not None:
        idle_check()
    owner = {'nonce': secrets.token_hex(24), 'model_root': str(model_root),
             'target': str(target), 'revision': revision,
             'aggregate_sha256': manifest['aggregate_sha256']}
    body = (json.dumps(owner, sort_keys=True) + '\n').encode()
    # A pre-created exclusive journal prevents ambiguous recovery if interrupted.
    with journal.open('xb') as f:
        f.write(body)
    made = False
    try:
        os.mkdir(model_root, 0o700)
        made = True
        with (model_root / MARKER).open('xb') as f:
            f.write(body)
        os.mkdir(model_root / 'snapshots', 0o700)
        os.symlink(str(target), model_root / 'snapshots' / revision)
        if (model_root / 'snapshots' / revision).resolve() != target:
            raise ValueError('alias changed before verification')
    except BaseException:
        # Cleanup is deliberately conservative: interrupted/foreign state is
        # retained with the journal for inspection, never recursively removed.
        if made:
            try:
                cleanup_alias(journal)
            except (OSError, ValueError):
                pass
        raise
    return owner


def cleanup_alias(journal):
    journal = Path(journal)
    if journal.is_symlink():
        raise ValueError('journal symlink refused')
    body = journal.read_bytes()
    owner = json.loads(body)
    root = Path(owner['model_root'])
    snapshots = root / 'snapshots'
    link = snapshots / owner['revision']
    if root.is_symlink() or snapshots.is_symlink():
        raise ValueError('owned directory replaced by symlink')
    if not root.exists():
        # A journal may precede failed mkdir; no filesystem ownership claimed.
        return
    marker = root / MARKER
    if marker.is_symlink() or not marker.is_file() or marker.read_bytes() != body:
        raise ValueError('owner marker missing or changed; no cleanup')
    if set(p.name for p in root.iterdir()) - {MARKER, 'snapshots'}:
        raise ValueError('foreign entries in model root; no cleanup')
    if snapshots.exists():
        if set(p.name for p in snapshots.iterdir()) - {owner['revision']}:
            raise ValueError('foreign snapshot entries; no cleanup')
        if os.path.lexists(link):
            if not link.is_symlink() or os.readlink(link) != owner['target']:
                raise ValueError('alias changed; no cleanup')
            link.unlink()
        snapshots.rmdir()
    marker.unlink()
    root.rmdir()
    # Keep the immutable journal as evidence; repeated cleanup sees no root.


def assert_idle():
    for name in ("darkbloom", "radix-engine"):
        result = subprocess.run(["/usr/bin/pgrep", "-x", name], stdout=subprocess.DEVNULL)
        if result.returncode != 1:
            raise ValueError("model host is busy or process inspection failed: " + name)


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    c = sub.add_parser('create')
    c.add_argument('--target', required=True)
    c.add_argument('--manifest', required=True)
    c.add_argument('--journal', required=True)
    d = sub.add_parser('cleanup')
    d.add_argument('--journal', required=True)
    a = p.parse_args()
    assert_idle()  # Sole validation lane must own the launch/cleanup window.
    if a.command == 'create':
        manifest = json.loads(Path(a.manifest).read_text())
        result = create_alias(Path.home() / '.cache/huggingface/hub',
                              a.target, manifest, a.journal, idle_check=assert_idle)
        print(json.dumps(result, indent=2))
    else:
        cleanup_alias(a.journal)


if __name__ == '__main__':
    main()
