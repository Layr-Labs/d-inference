from pathlib import Path
import json,stat,hashlib
assistant=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-smoke1/payload/gemma-assistant')
target=Path('/Users/gaj/.cache/huggingface/hub/models--gemma-4-26b/snapshots/local')
def info(p):
 s=p.lstat();return {'name':p.name,'bytes':s.st_size,'symlink':p.is_symlink(),'regular':stat.S_ISREG(s.st_mode)}
a=json.loads((assistant/'config.json').read_text());t=json.loads((target/'config.json').read_text());tt=t.get('text_config',t);at=a.get('text_config',a)
keys=['model_type','hidden_size','vocab_size','num_hidden_layers','num_attention_heads','num_key_value_heads','num_global_key_value_heads','head_dim','global_head_dim','layer_types','num_kv_shared_layers']
print(json.dumps({'assistant_directory':str(assistant),'assistant_is_symlink':assistant.is_symlink(),'assistant_entries':[info(p) for p in sorted(assistant.iterdir())],'assistant_config_sha256':hashlib.sha256((assistant/'config.json').read_bytes()).hexdigest(),'assistant_model_type':a.get('model_type'),'assistant_backbone_hidden_size':a.get('backbone_hidden_size'),'assistant_text':{k:at.get(k) for k in keys},'target_model_type':t.get('model_type'),'target_text':{k:tt.get(k) for k in keys},'target_config_sha256':hashlib.sha256((target/'config.json').read_bytes()).hexdigest()},indent=2))
