# Qwen 3.6 first SSD smoke: identity/environment diagnosis

Read-only diagnosis on 2026-09-05, primary source 06af2f585. No Swift/GPU/model loads, key reads, config changes or remote writes. Source snapshots and remote metadata observations are preserved with hashes.

The strongest finding is an incomplete benchmark key-mode/environment handoff. `run_radix_engine.py` supplies only `DARKBLOOM_PREFIX_CACHE_TEST_ROOT`; BenchmarkLoader sets the cache on/off switch but never `DARKBLOOM_PREFIX_CACHE_ALLOW_EPHEMERAL`. `ephemeral-key` only disables the requirement for a persistent key. It does not select an ephemeral key.

`SSDPrefixCacheFactory.isolatedTestRoot` requires an affirmative ALLOW_EPHEMERAL value. Otherwise the requested test path is ignored and the factory uses `~/Library/Caches/darkbloom/kv3`. The live remote path observation found exactly one empty child `f9ef9283cdb1` there with mtime 1788637889.511, inside the failed probe's interval 1788637859.753–1788637890.509. The requested isolated path does not exist. All five cache environment controls are unset in a fresh SSH session; historical inherited environment was not included in the original run metadata, so that observation alone is not proof of the failed process's environment.

The complete store factory creates its model directory before loading key material. This timestamp/path evidence strongly indicates the probe passed complete storage/identity guards, attempted construction under the normal root, then failed during the unsigned persistent-key path. The original conclusion “before store construction because the requested root is absent” is not supported. Exact modelstatus diagnostic remains the direct confirmation; this lane does not convert inference into a confirmed thrown-key error.

| Condition | Evidence/result |
|---|---|
| Required prompt files | Remote standalone template, config.json, tokenizer.json and tokenizer_config.json all present; six selected metadata files total. No symlinks or unexpected extra selected metadata. |
| Artifact metadata identity | All six sizes/SHA256/roles match the audited immutable Q36 manifest. Only metadata was read; no model weights. |
| Template UTF-8 / clock gate | One template source, valid UTF-8, 7764 ASCII bytes. No strftime_now occurrence at all, so Swift supportsTemplate is unconditionally true for this source. |
| Directory digest encoding | Reconstructed the source's UInt32-BE length-delimited fields, role/path/hash sort, normalization-v3/renderer-v3/tokenizer-v1/block-hash-v1 and block size256. Result 68f43b6d035f17d5439eaf4a7f0b4d2bea6a7f999a93e8d6d561a468fc419a60, exactly the audit v3 tuple. |
| Swift canonical render guard | Not executed here. Cold setup renders actual input, which does not alone prove every canonical fixture. Seven fixtures apply because config has vision_config. If the observed model-root creation belongs to this probe, factory ordering implies this guard passed. |
| Binary identity | Remote streaming SHA256 is 601bce0923cfb2e12410073fe193a08a9c73830b5afd74d7f72e2facb49be21c, matching failed run metadata and the successful cold runtime identity. |
| Bound metallib identity | Remote streaming SHA256 is 4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0, matching failed bind log and successful cold runtime identity. Runtime getter reads the successfully bound immutable snapshot. |
| Runtime hash format | Both binary/metallib and exact loaded model hash are canonical lowercase64 hex; no version/hash mismatch found. OS metadata is present. |
| Master cache switch | BenchmarkLoader explicitly sets PREFIX_CACHE=1 for this arm; ssdUnavailable is only checked while enabled. Resident-cache guard precedes ssdUnavailable, so the run did not fail that guard. |
| Early complete store checks | The native storage/assistant gate is the other agent's lane. Store guard validates nonempty bounded identity strings, block contract and supported layout before any path creation. Empty default-root child at failure timestamp supports passing these guards. |
| Disk budget/minimum token/read-stage caps | Applied after root/key initialization or at request staging; cannot account for an empty root plus construction-time ssdUnavailable by themselves. |
| Key path | With no ALLOW_EPHEMERAL, no test root, forceEphemeral=false and persistent key is attempted. Unsigned-host failure is consistent with cacheInitFailed. No key bytes, Keychain entries or Secure Enclave operations were read/invoked by this diagnostic. |

A minimal harness correction should bind the explicit isolated-root/key-mode controls together. Set ALLOW_EPHEMERAL=1 for an isolated benchmark root, select TEST_PERSISTENT_KEY=1 only for persistent mode and clear/override inherited persistent mode for an explicitly ephemeral arm. Keep the existing actual persistent-key refusal for persistent runs, and assert actual snapshot key_mode equals requested mode. This is a benchmark handoff correction, not a reason to relax production native/identity/key gates. Implementation belongs to the assigned validator/root; no patch was made here.
