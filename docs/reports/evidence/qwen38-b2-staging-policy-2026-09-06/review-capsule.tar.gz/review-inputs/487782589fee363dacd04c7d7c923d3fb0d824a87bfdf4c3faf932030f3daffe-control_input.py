"""Bounded caller control; only received JSON pings renew a remote lease."""
import json
import os
import selectors
import stat
import time


class ControlLost(ValueError):
    pass


class ControlInput:
    def __init__(self, stream, lease=30, require_ping=True):
        if not 0 < lease <= 30:
            raise ValueError("caller lease must be within 30 seconds")
        self.stream = stream
        self.fd = stream.fileno()
        mode = os.fstat(self.fd).st_mode
        if not (stat.S_ISFIFO(mode) or stat.S_ISSOCK(mode) or (not require_ping and stream.isatty())):
            raise ControlLost("external control stdin must be a pipe/socket; local controller also permits a terminal")
        self.selector = selectors.DefaultSelector()
        self.selector.register(stream, selectors.EVENT_READ)
        self.lease = lease
        self.require_ping = require_ping
        self.started = time.monotonic()
        self.last_ping = None
        self.last_ping_unix = None
        self.pings = 0
        self.pending = b""

    def check_deadline(self):
        origin = self.last_ping if self.last_ping is not None else self.started
        if self.require_ping and time.monotonic() - origin >= self.lease:
            raise ControlLost("external caller lease expired")

    def poll(self):
        self.check_deadline()
        received = bytearray()
        total = 0
        while self.selector.select(0):
            block = os.read(self.fd, 4096)
            if not block:
                raise ControlLost("external caller stdin EOF")
            total += len(block)
            if total > 65536:
                raise ControlLost("external control flood refused")
            self.pending += block
            while b"\n" in self.pending:
                line, self.pending = self.pending.split(b"\n", 1)
                if len(line) > 4096:
                    raise ControlLost("external control frame exceeds limit")
                try:
                    value = json.loads(line)
                except (ValueError, UnicodeError) as error:
                    raise ControlLost("malformed external control JSON") from error
                if value == {"command": "stop"}:
                    raise ControlLost("external caller requested stop")
                if value != {"command": "ping"}:
                    raise ControlLost("external control accepts only exact JSON ping/stop")
                self.last_ping = time.monotonic()
                self.last_ping_unix = time.time()
                self.pings += 1
                received.extend(b'{"command":"ping"}\n')
            if len(self.pending) > 4096:
                raise ControlLost("external control frame exceeds limit")
        self.check_deadline()
        return bytes(received)

    def wait_for_ping(self):
        received = bytearray()
        while True:
            received.extend(self.poll())
            if received and not self.pending:
                return bytes(received)
            self.selector.select(.1)

    def receipt(self, alive, reason=None):
        return {"alive": alive, "reason": reason, "lease_seconds": self.lease,
                "last_ping_monotonic": self.last_ping, "last_ping_unix": self.last_ping_unix, "received_pings": self.pings,
                "requires_external_pings": self.require_ping}

    def close(self):
        self.selector.close()
