"""Pure plan/resume/evidence checks. No inference, subprocess, SSH or native compilation."""
import copy
import json
from pathlib import Path
import tempfile
import unittest
import matrix_cells as m
from radix_engine_evidence import decode_timing_errors

class PlanTests(unittest.TestCase):
    def test_exact_topology_and_unsupported_cells_retained(self):
        plan = m.load_plan()
        for group, count, unsupported in [('original',180,18), ('supplement',36,9)]:
            cells = [c for c in plan['cells'] if c['group']==group]
            self.assertEqual(len(cells), count)
            self.assertEqual(len({c['id'] for c in cells}), count)
            self.assertEqual(sum('historical_contiguous_ssd_unsupported_in_reviewed_source' in c['blockers'] for c in cells), unsupported)
            self.assertEqual(sum(p['group']==group for p in plan['pairs']), count)
        self.assertTrue(all(c['blockers'] for c in plan['cells'] if c['group']=='supplement'))
        for pair in plan['pairs']:
            cells = {c['id']: c for c in plan['cells']}
            self.assertEqual(cells[pair['baseline']]['quartet'], cells[pair['candidate']]['quartet'])
            self.assertLess(cells[pair['baseline']]['order'], cells[pair['candidate']]['order'])

    def test_original_requests_change_only_token_cap_and_pinned_date(self):
        plan = m.load_plan()
        for model in plan['models'][:5]:
            updated = m.read(m.ROOT / model['input'])
            self.assertEqual(updated['rows'][0]['request'], updated['rows'][1]['request'])
            original = m.read(m.ROOT / 'provenance/inputs32' / (model['label'] + '.json'))
            for row in updated['rows']:
                self.assertEqual(row['request'].pop('_darkbloom_prompt_date'), '2026-09-05')
                self.assertEqual(row['case']['max_tokens'], 128)
                self.assertEqual(row['request']['max_tokens'], 128)
                row['case']['max_tokens'] = row['request']['max_tokens'] = 32
            self.assertEqual(updated, original)

    def test_bindings_cannot_select_unreviewed_runtime(self):
        with self.assertRaisesRegex(ValueError, 'unreviewed'):
            m.verified_bindings(m.ROOT / 'bindings.template.json')

    def test_any_existing_attempt_is_retained_and_refuses_command(self):
        plan = m.load_plan()
        cell = plan['cells'][0]
        with tempfile.TemporaryDirectory() as tmp:
            binding = {'results_root': tmp}
            out = Path(tmp) / cell['id']
            self.assertEqual(m.cell_status(binding, cell), 'untouched')
            out.mkdir()
            self.assertEqual(m.cell_status(binding, cell), 'retained_failed_or_partial')
            with self.assertRaisesRegex(ValueError, 'already exists'):
                m.command(plan, binding, cell)
            (out / 'metadata.json').write_text(json.dumps({'status':'completed','exit_code':0}))
            (out / 'report.json').write_text(json.dumps({'status':'completed'}))
            self.assertEqual(m.cell_status(binding, cell), 'completed_unvalidated')
            with self.assertRaisesRegex(ValueError, 'already exists'):
                m.command(plan, binding, cell)

    def test_file_tampering_is_not_accepted(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / 'proof.json'
            p.write_text('first')
            record = {'path':str(p), 'sha256':m.sha256(p)}
            self.assertEqual(m.verify_file(record), p)
            p.write_text('changed')
            with self.assertRaisesRegex(ValueError, 'hash mismatch'):
                m.verify_file(record)

    def test_restore_requires_authenticated_read_and_native_saved_work(self):
        row = {'cache_outcome':'hit', 'ssd_stage_disposition':'staged', 'matched_tokens':4096, 'saved_tokens':4096,
               'metrics_before':{'ssd_cache':{'stage_read_bytes':10}}, 'metrics_after':{'ssd_cache':{'stage_read_bytes':20}}}
        self.assertTrue(m.native_hit(row))
        for key, value in [('cache_outcome','miss'), ('ssd_stage_disposition','miss'), ('matched_tokens',0), ('saved_tokens',0)]:
            bad = copy.deepcopy(row); bad[key] = value
            self.assertFalse(m.native_hit(bad))
        bad = copy.deepcopy(row); bad['metrics_after']['ssd_cache']['stage_read_bytes'] = 10
        self.assertFalse(m.native_hit(bad))

    def test_requested_b4_does_not_claim_four_admitted_rows(self):
        report = {'batches':[{'id':'donor','concurrency_requested':4,'peak_active_requests':2,'peak_waiting_requests':2,'completed':4,'failed':0}]}
        evidence = m.admission_summary(report)[0]
        self.assertTrue(evidence['observed_overlap'])
        self.assertFalse(evidence['observed_full_requested_width'])
        self.assertEqual(evidence['observed_peak_active'],2)
        report['batches'][0]['peak_active_requests'] = 1
        self.assertFalse(m.admission_summary(report)[0]['observed_overlap'])

    def test_first_mtp_delta_is_excluded_from_decode_numerator(self):
        row = {'chunks':[{'tokens':[1,2,3], 'elapsed_s':1.0}, {'tokens':[4,5], 'elapsed_s':2.0}],
               'first_delta_token_count':3,'decode_tokens_after_first_delta':2,'decode_tps':2.0}
        self.assertEqual(decode_timing_errors(row), [])
        row['decode_tps'] = 4.0
        self.assertEqual(decode_timing_errors(row), ['decode_timing_inconsistent_with_chunks'])

if __name__ == '__main__':
    unittest.main(verbosity=2)
