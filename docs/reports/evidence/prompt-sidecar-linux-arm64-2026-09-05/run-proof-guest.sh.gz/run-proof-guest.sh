#!/bin/sh
set -eu
umask 077
cd /home/gaj.guest/prompt-proof
./promptsidecarloadproof-linux-arm64 \
 --binary /home/gaj.guest/prompt-proof/source/coordinator/promptsidecar/target/aarch64-unknown-linux-musl/release/promptsidecar \
 --artifact-root /home/gaj.guest/prompt-proof/inputs/artifacts \
 --vectors /home/gaj.guest/prompt-proof/inputs/production_vectors.json \
 --duration 15s --qps 25 --max-rss-mib 1024 --max-rss-growth-mib 128
