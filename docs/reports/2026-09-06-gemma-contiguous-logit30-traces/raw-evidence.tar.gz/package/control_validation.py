import argparse
import json
from pathlib import Path
import sys

SOURCE = Path(__file__).resolve().parent / 'runner'
sys.path.insert(0, str(SOURCE))
from compare_radix_engine import mismatch
from radix_engine_evidence import report_errors

MODES = {'automatic': ('automatic', 'rectangular_rounds', 'serial_rounds'),
         'serial_target': ('serialTarget', 'serial_rounds', 'rectangular_rounds')}

def main_round_errors(row, mode):
    expected, selected, other = MODES[mode]
    before = row.get('metrics_before', {}).get('mtp', {})
    after = row.get('metrics_after', {}).get('mtp', {})
    errors = []
    for moment, metrics in [('before', before), ('after', after)]:
        if metrics.get('active') is not True or metrics.get('verification_mode') != expected:
            errors.append({'id': row.get('id'), 'wrong_main_row_mode': moment})
        if any(type(metrics.get(key)) is not int or metrics[key] < 0 for key in ['rounds', selected, other]):
            errors.append({'id': row.get('id'), 'invalid_main_row_counters': moment})
    if errors:
        return errors
    if after['rounds'] <= before['rounds'] or after[selected] <= before[selected]:
        errors.append({'id': row.get('id'), 'main_row_has_no_selected_verifier_rounds': True})
    if before[other] != 0 or after[other] != 0:
        errors.append({'id': row.get('id'), 'opposite_verifier_rounds': True})
    return errors

def trajectories(report):
    rows = [('main:' + str(row.get('id')), row) for row in report.get('rows', [])]
    rows += [('tenant:' + str(index), row) for index, row in enumerate(report.get('tenant_checks', []))]
    rows += [(name, report.get(name, {})) for name in ['cancel_donor', 'recovered']]
    return rows

def control_errors(report, backend, mode, artifact, prompt_reference):
    errors = report_errors(report)
    expected_selection = None if mode == 'off' else mode
    if (report.get('schema') != 2 or report.get('cache_requested') is not False
            or report.get('cache_mode_requested') != 'ssd' or report.get('max_concurrent_requests', 1) != 1
            or report.get('requested_backend') != backend or report.get('resolved_backend') != backend
            or report.get('backend_fallback') or report.get('kv_grant_mode') != 'production_single_slot'
            or report.get('gemma_mtp_verification_requested') != expected_selection
            or report.get('cancellation_probe_version') != 2):
        errors.append({'invalid_control_scope': True})
    if any(report.get(key) is not None for key in ['logit_diagnostic', 'attention_metadata', 'attention_packet', 'gemma_projection']):
        errors.append({'numerical_diagnostic_in_control_cell': True})
    runtime = report.get('runtime_identity', {})
    if (runtime.get('binary_sha256') != artifact['files']['radix-engine']['sha256']
            or runtime.get('metallib_sha256') != artifact['files']['mlx.metallib']['sha256']):
        errors.append({'wrong_combined_runtime_artifact': True})
    if report.get('verified_model_hash') != '2468a0cb3049a871f42052f4d9f9380bf12a0792f64c7a29f768559fc7d28785':
        errors.append({'wrong_target_artifact': True})
    if report.get('input_sha256') != '1abb54db891314531df0b6ddfbe3cc3418c29fd014133cdf3837133c9e9a3080':
        errors.append({'wrong_original_input_bytes': True})
    reference = prompt_reference['rows']
    main = report.get('rows', [])
    if len(main) != 2 or [row.get('id') for row in main] != ['long-first', 'long-repeat']:
        errors.append({'wrong_main_rows': True})
    elif any(row.get('prompt_token_ids') != original['prompt_token_ids']
             or row.get('prompt_render_date') != original['prompt_render_date'] for row, original in zip(main, reference)):
        errors.append({'original_prompt_identity_changed': True})
    complete = trajectories(report)
    if len(complete) != 7 or any(row.get('outcome') != 'completed' for label, row in complete):
        errors.append({'seven_complete_trajectories_required': True})
    loaded = report.get('metrics_loaded', {})
    if loaded.get('memory_cache_enabled') is not False or loaded.get('resident_bank_budget_bytes') != 0:
        errors.append({'unexpected_resident_prefix_cache': True})
    snapshots = [loaded, report.get('metrics_after_shutdown', {})]
    for label, row in complete + [('cancelled', report.get('cancelled', {}))]:
        snapshots += [row.get(moment, {}) for moment in ['metrics_before', 'metrics_after']]
    if mode == 'off':
        if not report.get('mtp', '').startswith('off') or loaded.get('assistant_identity', {}).get('source') != 'none':
            errors.append({'ordinary_assistant_not_off': True})
        if any(snapshot.get('mtp') is not None for snapshot in snapshots):
            errors.append({'ordinary_has_mtp_activity': True})
    else:
        expected, selected, other = MODES[mode]
        if not report.get('mtp', '').startswith('on') or any(
                snapshot.get('mtp', {}).get('active') is not True
                or snapshot.get('mtp', {}).get('verification_mode') != expected
                or snapshot.get('mtp', {}).get(other) != 0 for snapshot in snapshots):
            errors.append({'selected_verifier_not_consistent': True})
        for row in main:
            errors += main_round_errors(row, mode)
    return errors

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--artifact-manifest', required=True)
    parser.add_argument('--output', required=True)
    for backend in ['contiguous', 'paged']:
        for mode in ['off', 'automatic', 'serial_target']:
            parser.add_argument('--' + backend + '-' + mode.replace('_', '-'), required=True)
    args = parser.parse_args()
    artifact = json.loads(Path(args.artifact_manifest).read_text())
    reference = json.loads((Path(__file__).resolve().parent / 'inputs/reference-prompt-ids.json').read_text())
    reports, errors = {}, []
    for backend in ['contiguous', 'paged']:
        for mode in ['off', 'automatic', 'serial_target']:
            name = backend + '_' + mode
            report = json.loads(Path(getattr(args, name)).read_text())
            reports[name] = report
            errors += [dict(error, report=name) for error in control_errors(report, backend, mode, artifact, reference)]
    comparisons = []
    if not errors:
        pairs = [(backend + '_off', backend + '_' + mode) for backend in ['contiguous', 'paged'] for mode in ['automatic', 'serial_target']]
        pairs += [('contiguous_' + mode, 'paged_' + mode) for mode in ['off', 'automatic', 'serial_target']]
        for left_name, right_name in pairs:
            left, right = reports[left_name], reports[right_name]
            rows = []
            for (label, old), (other_label, new) in zip(trajectories(left), trajectories(right)):
                differences = mismatch(old, new)
                if label != other_label or old.get('prompt_render_date') != new.get('prompt_render_date'):
                    differences.append('trajectory_identity')
                rows.append({'label': label, 'differences': differences, 'exact_match': not differences})
            comparisons.append({'left': left_name, 'right': right_name, 'rows': rows,
                'exact_match': all(row['exact_match'] for row in rows)})
    result = {'execution_valid': not errors, 'execution_errors': errors, 'comparisons': comparisons,
              'scope': 'Independent exact-token comparisons; serial agreement does not waive automatic mismatch. No performance ratio.'}
    result['exit_semantics'] = '0: all compared trajectories exact; 1: invalid execution; 2: valid execution with retained token differences'
    Path(args.output).write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
    if errors:
        return 1
    return 0 if all(pair['exact_match'] for pair in comparisons) else 2

if __name__ == '__main__':
    raise SystemExit(main())
