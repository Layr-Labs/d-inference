"""Scoped CPU checks for explicit MTP-off controls; no model or network job."""
from pathlib import Path
import copy
import hashlib
import importlib.util
import json
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

ROOT=Path(__file__).resolve().parent
PLAN=Path('/tmp/darkbloom-qat-mtp-off-plan1')
OLD=Path('/tmp/darkbloom-qat-actual-logits-execution3')
from strict_results import result_errors


class MTPControlTests(unittest.TestCase):
    def setUp(self):
        self.temporary=tempfile.TemporaryDirectory();self.addCleanup(self.temporary.cleanup)
        self.root=Path(self.temporary.name)
        self.plan=json.loads((PLAN/'plan.json').read_text())
        self.binding=json.loads(Path('/tmp/darkbloom-qat-mtp-off-runtime-binding1.json').read_text())
        self.cell=self.plan['cells'][0]
        prior=OLD/'gemma-qat4-contiguous-cache-off-mtp-on-trace-off'
        self.report=json.loads((prior/'report.json').read_text());self.report['mtp']='off; no drafter supplied'
        meta=json.loads((prior/'metadata.json').read_text())
        meta['command']=self.binding['commands'][0]['expected_observed_native_argv']
        (self.root/'metadata.json').write_text(json.dumps(meta))
        shutil.copy2(prior/'input.json',self.root/'input.json')

    def errors(self):return result_errors(self.root,self.cell,self.plan,self.binding,self.report,self.root)

    def test_same_verified_runtime_and_input_accept_explicit_off_without_normal_prefix_assumption(self):
        self.report['rows'][0]['token_ids'][0]+=1  # Synthetic changed MTP-off trajectory; never a real-model claim.
        self.assertEqual(self.errors(),[])

    def test_normal_mtp_cannot_be_mislabeled_as_off(self):
        self.report['mtp']='on; production configured assistant'
        self.assertIn('serving mode mismatch',self.errors())

    def test_diagnostics_and_backend_fallback_still_refuse(self):
        self.report['logit_diagnostic']={'status':'captured'}
        self.assertIn('control emitted logit diagnostic',self.errors())
        self.report.pop('logit_diagnostic');self.report['backend_fallback']='planted'
        self.assertIn('backend/fallback mismatch',self.errors())

    def test_native_commands_change_only_owned_paths_and_explicit_mtp_mode(self):
        old=json.loads(Path('/tmp/darkbloom-qat-actual-logits-runtime-binding2.json').read_text())
        controls=[c for c in old['commands']if c['cell'].endswith('trace-off')]
        self.assertEqual(len(self.binding['commands']),2)
        for before,after in zip(controls,self.binding['commands']):
            for field in ['wrapper_argv','expected_observed_native_argv']:
                expected=[]
                for value in before[field]:
                    if value.startswith(old['remote_root']+'/'):
                        value=self.binding['remote_root']+value[len(old['remote_root']):]
                        value=value.replace('mtp-on-trace-off','mtp-off-trace-off')
                    if value=='mtp-on':value='mtp-off'
                    expected.append(value)
                if field=='wrapper_argv':expected[expected.index('--mtp')+1]='off'
                self.assertEqual(after[field],expected)
        self.assertEqual(self.binding['artifacts'],old['artifacts'])
        self.assertEqual(self.binding['assistant'],old['assistant'])
        self.assertEqual(self.binding['input_sha256'],old['input_sha256'])

    def test_both_cells_render_guards_and_retain_missing_report_failure_without_network(self):
        for index,cell in enumerate(self.plan['cells']):
            spec=importlib.util.spec_from_file_location('off_driver',ROOT/'run_cell.py')
            module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
            target=self.root/str(index);target.mkdir();module.OUT=target
            for name in ['strict_results.py','preflight.py']:shutil.copy2(ROOT/name,target/name)
            if index:
                prior=target/self.plan['cells'][0]['id'];prior.mkdir()
                raw=json.dumps({'exit_code':0,'report_integrity_passed':True}).encode();(prior/'summary.json').write_bytes(raw)
                (prior/'manifest.json').write_text(json.dumps({'files':{'summary.json':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}}}))
            rendered=[]
            def fake(argv,**kwargs):
                if 'input'in kwargs:
                    code=kwargs['input'];compile(code,'<off-remote>','exec')
                    self.assertIn('090-qat-mtp-off1',code);rendered.append(code)
                return SimpleNamespace(returncode=0,stdout='{"files":{}}',stderr='')
            with patch.object(module.subprocess,'run',side_effect=fake),patch.object(sys,'argv',[str(ROOT/'run_cell.py'),cell['id']]):
                with self.assertRaises(SystemExit)as stopped:module.main()
            self.assertEqual(stopped.exception.code,1);self.assertEqual(len(rendered),2)
            self.assertEqual(json.loads((target/cell['id']/'summary.json').read_text())['errors'],['report missing'])


if __name__=='__main__':unittest.main()
