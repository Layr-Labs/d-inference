from pathlib import Path
import difflib, hashlib, io, json, shutil, subprocess, tarfile

out = Path(__file__).resolve().parent
primary = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
candidate = Path('/Users/gaj/Documents/DarkbloomDev/wt/q36-attention-metadata-diagnostic')
native_validation = Path('/tmp/darkbloom-q36-attention-metadata-validation1')
source = Path('/tmp/darkbloom-q36-attention-metadata-source1')
build8 = Path('/tmp/darkbloom-final-serving-build8')
workspace = out/'workspace'
local_mlx = Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value):
    (out/name).write_text(json.dumps(value, indent=2)+'\n')

assert sha(source/'manifest.json') == 'f5a62e3340474ea3c50baddf9577982d7adc47301e98925307c345eb6a2fbf09'
parent = subprocess.check_output(['git', 'rev-parse', '5b93195c9'], cwd=primary, text=True).strip()
archive = subprocess.check_output(['git', 'archive', parent, 'provider-swift'], cwd=primary)
workspace.mkdir()
with tarfile.open(fileobj=io.BytesIO(archive)) as packed:
    packed.extractall(workspace, filter='data')
provider = workspace/'provider-swift'
canonical_provider = {str(p.relative_to(workspace)): sha(p)
                      for p in sorted(provider.rglob('*')) if p.is_file()}
before = (provider/'Package.swift').read_text()
old = '.package(path: "../libs/mlx-swift")'
assert before.count(old) == 1
after = before.replace(old, '.package(path: "'+str(local_mlx)+'")')
(provider/'Package.swift').write_text(after)
(out/'provider-package-compile-only-overlay.patch').write_text(''.join(difflib.unified_diff(
    before.splitlines(keepends=True), after.splitlines(keepends=True),
    fromfile='canonical/provider-swift/Package.swift', tofile='compiled/provider-swift/Package.swift')))
resolved = build8/'workspace/provider-swift/Package.resolved'
assert sha(resolved) == 'b2b12d24d48bbedc4583d8831e0b81fe68b96d641804e0ebc56715cd2d88a7ea'
shutil.copy2(resolved, provider/'Package.resolved')
(workspace/'libs').mkdir()
(workspace/'libs/mlx-swift').symlink_to(local_mlx, target_is_directory=True)
(workspace/'libs/mlx-swift-lm').symlink_to(native_validation/'native', target_is_directory=True)
harness = candidate/'scripts/benchmarks/radix-engine'
shutil.copytree(harness, out/'radix-engine')
shutil.copy2(resolved, out/'radix-engine/Package.resolved')
changes = json.loads((source/'review.json').read_text())['source_files']['parent']
for name, item in changes.items():
    assert sha(candidate/name) == item['after_sha256'], name
provider_files = {str(p.relative_to(workspace)): sha(p)
                  for p in sorted(provider.rglob('*')) if p.is_file()}
harness_files = {str(p.relative_to(out)): sha(p)
                 for p in sorted((out/'radix-engine').rglob('*')) if p.is_file()}
write('provider-source-manifest.json', {'source_commit': parent, 'canonical_files': canonical_provider,
                                      'files': provider_files})
write('harness-source-manifest.json', {'files': harness_files, 'parent_candidate_changes': changes})
write('integration.json', {
    'status': 'Prepared source union only; no benchmark Swift process started',
    'parent_commit': parent, 'native_baseline': '5cb848dfdaae04118ecfa901f53fc21a4aa86a06',
    'metadata_source_manifest_sha256': sha(source/'manifest.json'),
    'native_validation': str(native_validation), 'workspace': str(workspace),
    'scratch': '/tmp/darkbloom-process-memory-telemetry-swift-validation1/build',
    'environment': {'RADIX_SOURCE_ROOT': str(workspace), 'RADIX_CANDIDATE_BUILD': '1'},
    'provider_inputs': len(provider_files), 'harness_inputs': len(harness_files),
    'policy': 'Only the approved metadata candidate and established dependency overlays; native tests must pass before benchmark build',
    'other_unintegrated_candidates_included': False,
})
print(json.dumps({'provider_inputs': len(provider_files), 'harness_inputs': len(harness_files),
                  'parent_commit': parent}, indent=2))
