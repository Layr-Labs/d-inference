#include <chrono>
#include <iostream>
#include <thread>
#include <vector>
#include "mlx/array.h"
#include "mlx/ops.h"
#include "mlx/transforms.h"
#include "mlx/stream.h"

using namespace mlx::core;
struct Observation {
  const char* phase;
  long descriptor;
  long data;
  bool unique;
  double micros;
};
int main() {
  std::vector<Observation> observations;
  for (int i = 0; i < 100; ++i) {
    auto array = zeros({24576}, uint8);
    eval(array);
    observations.push_back({"after_eval", array.diagnostic_descriptor_count(),
      array.data_shared_ptr().use_count(), array.is_donatable(), 0});
    auto start = std::chrono::steady_clock::now();
    synchronize(default_stream(Device::gpu));
    observations.push_back({"after_stream_sync", array.diagnostic_descriptor_count(),
      array.data_shared_ptr().use_count(), array.is_donatable(),
      std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now()-start).count()});
    start = std::chrono::steady_clock::now();
    while (!array.is_donatable() && std::chrono::steady_clock::now()-start < std::chrono::milliseconds(10)) {
      std::this_thread::yield();
    }
    observations.push_back({"after_bounded_observation", array.diagnostic_descriptor_count(),
      array.data_shared_ptr().use_count(), array.is_donatable(),
      std::chrono::duration<double, std::micro>(std::chrono::steady_clock::now()-start).count()});
    auto view = slice(array, {1024}, {2048});
    eval(view);
    synchronize(default_stream(Device::gpu));
    observations.push_back({"original_with_view", array.diagnostic_descriptor_count(),
      array.data_shared_ptr().use_count(), array.is_donatable(), 0});
    observations.push_back({"view_retained", view.diagnostic_descriptor_count(),
      view.data_shared_ptr().use_count(), view.is_donatable(), 0});
  }
  for (auto& o : observations) {
    std::cout << "{\"phase\":\"" << o.phase << "\",\"descriptor_count\":" << o.descriptor
      << ",\"data_count\":" << o.data << ",\"unique\":" << (o.unique?"true":"false")
      << ",\"micros\":" << o.micros << "}\n";
  }
}
