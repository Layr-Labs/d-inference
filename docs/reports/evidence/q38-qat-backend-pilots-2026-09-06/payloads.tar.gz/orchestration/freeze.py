"""Freeze an offline handoff; no runtime, remote, model or native operations."""
from contextlib import ExitStack
import copy
import gzip
import hashlib
import io
import json
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tarfile
from unittest.mock import patch

BASE = Path('/tmp/darkbloom-q38-qat-backend-pilots1')
ROOT = BASE / 'package'
ORIGIN = Path('/tmp/darkbloom-repeated-matrix-plan3')
REMOTE = Path('/Users/gaj/autoresearch/radix-prefix-cache/090-q38-qat-backend-pilots1')
sys.path.insert(0, str(ROOT))
import pilot_cells as pilot
m = pilot.matrix

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')

def identity(path):
    return {'sha256': m.sha256(path), 'bytes': path.stat().st_size, 'mode': oct(path.stat().st_mode & 0o777)}

assert not (ROOT / 'manifest.json').exists(), 'already frozen'
correspondence = m.read(BASE / 'source-correspondence.json')
for source_relative in ['cpu-prompt-plan.json'] + [directory + '/' + model + '-current.json'
        for directory in ('cpu-requests', 'cpu-responses') for model in ('qwen38', 'gemma-4-26b-qat-4bit')]:
    source = ORIGIN / source_relative
    target = ROOT / 'provenance' / 'cpu' / source_relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
    correspondence['copies'][str(target.relative_to(ROOT))] = {
        'source': str(source), 'sha256': m.sha256(source), 'unchanged_bytes': True}
for relative, record in correspondence['copies'].items():
    assert (ROOT / relative).read_bytes() == Path(record['source']).read_bytes()
    assert m.sha256(ROOT / relative) == record['sha256']
write(ROOT / 'source-correspondence.json', correspondence)
plan = pilot.load_plan()
original_binding = m.read(ROOT / 'provenance/origin-bindings-reviewed3.json')
binding = copy.deepcopy(original_binding)
binding['state'] = 'pending_root_review'
binding['review_id'] = None
binding['models'] = {model['label']: copy.deepcopy(original_binding['models'][model['label']]) for model in plan['models']}
for label, target in binding['models'].items():
    target['identity_audit']['path'] = str(REMOTE / 'support/model-audits' / (label + '.json'))
binding['results_root'] = str(REMOTE / 'runs')
binding['runtime_source_manifest']['path'] = str(REMOTE / 'support/build8/manifest.json')
binding['plan_manifest']['path'] = str(REMOTE / 'manifest.json')
binding['notes'] = ('Source-only seven B1 repetition1 Q38/QAT pilots, derived from immutable matrix3. '
    'Pending root review and explicit sole-M5-lane handoff; not staged or launched. '
    'Canonical matrix3 remains unchanged/unstaged; no matrix/repeated-performance/release-completion claim.')
binding['storage_retention_review'] = None
binding['proposed_storage_retention'] = original_binding['storage_retention_review']
binding['refusal_review_records'] = {}

# Render from the frozen command builder with filesystem/date/storage spies.
# This records argv for review only; normal CLI retains all actual checks.
fixture = m.read(ROOT / 'provenance/gemma-two-file-fixture-proof.json')['copied']
previews = []
with ExitStack() as stack:
    stack.enter_context(patch.object(m, 'ROOT', REMOTE))
    stack.enter_context(patch.object(m, 'cell_status', return_value='untouched'))
    stack.enter_context(patch.object(m, 'require_current_prompt_date'))
    stack.enter_context(patch.object(m, 'verify_file'))
    stack.enter_context(patch.object(Path, 'is_dir', return_value=True))
    stack.enter_context(patch.object(Path, 'exists', return_value=True))
    stack.enter_context(patch.object(m.shutil, 'disk_usage', return_value=type('Space', (), {'total': 1 << 40, 'free': 1 << 39})()))
    stack.enter_context(patch.object(m, 'read', return_value={'copied': fixture}))
    for cell in plan['cells']:
        with patch.object(Path, 'iterdir', return_value=iter(Path(name) for name in fixture)):
            argv = m.command(plan, binding, cell)
        previews.append({'cell': cell['id'], 'origin_order': cell['order'], 'argv': argv, 'shell': shlex.join(argv),
                         'output_root': str(REMOTE / 'runs' / cell['id']),
                         'cache_root': str(REMOTE / 'runs' / cell['id'] / 'prefix-cache')})
write(ROOT / 'command-preview.json', {'scope': 'Static review preview; runtime guards were spied only during source-level rendering; no invocation authorized or executed',
                                    'reviewed_binding_required': True, 'commands': previews})

validation = ROOT / 'validation'; validation.mkdir()
results = []
for suite, cwd in [('test_pilot_cells.py', ROOT), ('test_matrix_cells.py', ORIGIN)]:
    result = subprocess.run([sys.executable, '-B', '-W', 'error', '-m', 'unittest', '-v', suite], cwd=cwd,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    (validation / (suite + '.log')).write_text(result.stdout)
    assert result.returncode == 0, result.stdout
    results.append({'suite': suite, 'cwd': str(cwd), 'exit_code': result.returncode, 'log': 'validation/' + suite + '.log'})
write(validation / 'summary.json', {'scope': 'CPU-only Python tests; no native/model/remote jobs', 'tests_passed': 30,
    'pilot_tests': 12, 'frozen_matrix_tests': 18, 'interpreter': sys.executable, 'python_version': sys.version, 'results': results})
# Recheck immutable origin inventories after all local work and test execution.
for manifest, count in [(ORIGIN / 'manifest.json', 279),
        (Path('/tmp/darkbloom-repeated-matrix-binding3/package/package-manifest.json'), 344)]:
    inventory = m.read(manifest)['files']; assert len(inventory) == count
    for relative, expected in inventory.items():
        path = manifest.parent / relative
        assert path.stat().st_size == expected['bytes'] and m.sha256(path) == expected['sha256'], str(path)
write(ROOT / 'manifest.json', {'schema': 'darkbloom.q38-qat-pilot-payload.v1',
    'scope': 'Static source/input/provenance inventory; binding and outer package manifest are separately bound',
    'files': {str(path.relative_to(ROOT)): identity(path) for path in sorted(ROOT.rglob('*')) if path.is_file()}})
binding['plan_manifest']['sha256'] = m.sha256(ROOT / 'manifest.json')
write(ROOT / 'bindings.candidate.json', binding)
# Pending binding is deliberately refused before touching any remote runtime path.
refusal = subprocess.run([sys.executable, '-B', str(ROOT / 'pilot_cells.py'), 'status', '--bindings',
    str(ROOT / 'bindings.candidate.json')], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
assert refusal.returncode != 0 and 'runtime binding is unreviewed' in refusal.stdout
write(BASE / 'pending-binding-refusal.json', {'exit_code': refusal.returncode, 'output': refusal.stdout})
write(ROOT / 'package-manifest.json', {'schema': 'darkbloom.q38-qat-pilot-package.v1',
    'state': 'source_only_pending_root_review', 'destination': str(REMOTE),
    'files': {str(path.relative_to(ROOT)): identity(path) for path in sorted(ROOT.rglob('*')) if path.is_file()}})
archive = BASE / 'package.tar.gz'
with archive.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
    with tarfile.open(fileobj=compressed, mode='w') as tar:
        for path in sorted(ROOT.rglob('*')):
            if path.is_file():
                info = tar.gettarinfo(str(path), arcname=str(path.relative_to(ROOT)))
                info.uid = info.gid = 0; info.uname = info.gname = ''; info.mtime = 0
                with path.open('rb') as stream: tar.addfile(info, stream)
with tarfile.open(archive) as tar:
    members = tar.getmembers()
    assert len(members) == len(m.read(ROOT / 'package-manifest.json')['files']) + 1
    for member in members:
        path = ROOT / member.name
        assert member.isfile() and tar.extractfile(member).read() == path.read_bytes()
        assert member.mode == (path.stat().st_mode & 0o777)
summary = {'state': 'source_only_pending_root_review', 'staged': False, 'launched': False,
    'package': str(ROOT), 'destination': str(REMOTE), 'archive': dict(path=str(archive), **identity(archive)),
    'manifest': dict(path=str(ROOT / 'manifest.json'), **identity(ROOT / 'manifest.json')),
    'package_manifest': dict(path=str(ROOT / 'package-manifest.json'), **identity(ROOT / 'package-manifest.json')),
    'candidate_binding': dict(path=str(ROOT / 'bindings.candidate.json'), **identity(ROOT / 'bindings.candidate.json')),
    'payloads': len(m.read(ROOT / 'package-manifest.json')['files']), 'archive_members': len(members),
    'copied_payloads_byte_identical': len(correspondence['copies']), 'tests_passed': 30,
    'canonical_plan3_and_binding3_payloads_unchanged': [279, 344],
    'changes_from_original': ['select seven supported original B1 repetition1 cells without changing their records',
        'new pilot helper uses frozen command/cell/compare validators and never aggregates full matrix or repeated performance',
        'staged helper/input/inventory root and fresh output/cache root', 'binding status reset pending root review; only two models retained'],
    'unchanged': ['input bytes and prepared hashes', 'model artifact hashes/directories', 'normal MTP and exact QAT assistant',
        'B1, repetition1, token cap128, UTC date2026-09-06', 'build8 binary and six resources', 'SSD/ephemeral/production grant',
        'strict numerical/token/cancellation/tenant/idle/restore gates', 'canonical matrix3 roots and ordered execution plan'],
    'not_claimed': ['matrix completion', 'repeated performance', 'release acceptance', 'fresh-process persistent SSD restart', 'native packet or model parity proof']}
write(BASE / 'freeze.json', summary)
print(json.dumps(summary, indent=2))
