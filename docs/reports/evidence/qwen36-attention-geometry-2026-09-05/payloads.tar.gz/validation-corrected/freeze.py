from pathlib import Path
import hashlib,json,re
out=Path('/tmp/darkbloom-q36-attention-kernel-validation1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
status=json.loads((out/'run-status.json').read_text());filters=json.loads((out/'filters.json').read_text());ids=(out/'identifiers.log').read_text().splitlines();coverage={};summaries={};numeric={};parameter_lines={}
for name,filter in filters.items():
 coverage[name]=[s for s in ids if '/' in s and filter in s]
 body=(out/(name+'.log')).read_text();summaries[name]=re.findall(r'Test run with [0-9]+ tests? in [0-9]+ suites? (?:passed|failed)[^\n]*',body)
 numeric[name]=[s for s in body.splitlines() if s.startswith('Q36 ')];parameter_lines[name]=[s for s in body.splitlines() if re.search(r'\bpassing\s+\d+\s+arguments?\b',s,re.I)]
unique=set(s for group in coverage.values() for s in group)
write('test-identifier-coverage.json',{'by_filter':coverage,'unique_test_functions':len(unique),'executed_functions_with_targeted_overlap':sum(map(len,coverage.values())),'parameter_case_lines':parameter_lines})
write('raw-numerical-observations.json',{'scope':'Named raw test log observations, not real-model logits or causal attribution. Original source numerical bars unchanged.','by_filter':numeric})
verdict={'status':'PASS' if not status['failed'] else 'FAIL','failed_filters':status['failed'],'all_filters_run':status['all_four_filters_run'],'new_functions':len(coverage['qwen36-new-cases']),'new_expanded_cases_expected':13,'new_parameterized_argument_invocations_observed':len(parameter_lines['qwen36-new-cases']),'new_named_numerical_observations':len(numeric['qwen36-new-cases']),'unique_test_functions':len(unique),'function_executions_including_targeted_overlap':sum(map(len,coverage.values())),'raw_summaries':summaries,'production_source_changed':False,'diagnostic_native_included':False,'numerical_bars_changed':False,'real_models_run':False,'model_backend_failures_waived':False,'limitations':'Attention/storage fixtures only; not model prefill, rotary, recurrent state, normal MTP geometry or actual model query dtype.'}
if not status['failed']:
 assert len(coverage['qwen36-new-cases'])==3
 assert len(parameter_lines['qwen36-new-cases'])==12
 assert len(numeric['qwen36-new-cases'])==61
 verdict['new_expanded_cases_observed']=13
write('verdict.json',verdict)
files={}
for p in sorted(out.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(out)
 if rel.parts[0] in ['native','__pycache__'] or p.name=='manifest.json':continue
 files[str(rel)]={'sha256':sha(p),'bytes':p.stat().st_size}
write('manifest.json',{'schema':1,'status':verdict['status'],'files':files})
print(json.dumps({'manifest_sha256':sha(out/'manifest.json'),'payloads':len(files),'verdict':verdict},indent=2))
