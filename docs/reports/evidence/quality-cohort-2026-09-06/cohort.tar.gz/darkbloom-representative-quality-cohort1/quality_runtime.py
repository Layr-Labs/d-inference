"""Bind later commands/comparisons to reviewed runtime identities; never launch."""
from pathlib import Path

from cohort_common import digest, read_json, require


def runtime_binding(path, expected_sha):
    require(digest(path) == expected_sha, 'execution binding SHA differs')
    binding = read_json(path)
    require(binding.get('state') == 'reviewed' and binding.get('review_id'), 'runtime binding is unreviewed')
    record = binding['runtime_manifest']
    manifest_path = Path(record['path'])
    require(manifest_path.is_absolute() and digest(manifest_path) == record['sha256'], 'runtime manifest identity differs')
    manifest = read_json(manifest_path)
    expected = binding['expected_runtime_source']
    require(expected and all(manifest['source'].get(key) == value for key, value in expected.items()), 'runtime source differs')
    directory = Path(binding['runtime_directory'])
    require(directory.is_absolute() and directory.is_dir(), 'runtime directory is unbound')
    for name in ['darkbloom', 'radix-engine', 'mlx.metallib']:
        file = directory/name; identity = manifest['files'][name]
        require(file.is_file() and not file.is_symlink() and file.stat().st_size == identity['bytes']
                and digest(file) == identity['sha256'], 'runtime file identity differs: ' + name)
        if name != 'mlx.metallib':
            require(file.stat().st_mode & 0o111, 'runtime binary is not executable: ' + name)
    require(Path(binding['execution_root']).is_absolute(), 'execution root is unbound')
    binding['_manifest'] = manifest
    binding['_binding_sha256'] = expected_sha
    return binding
