# Ownership changes after controller draft review

The peer review found that a native process in a new session could outlive an
SSH owner receiving HUP or TERM. Before any actual replay, the controller was
changed to convert those signals into an exception, reap its own process group,
and write the terminal execution receipt. Signal masking covers child creation
until the owner has retained the process handle; the child restores the prior
signal mask before exec. Repeated owner signals are ignored during cleanup.

SSH now has a 15-second keepalive and four unanswered-message limit. Remote
transport and scp calls have a 240-second local bound; the native arm retains
its 180-second timeout and a 10-second reap bound.

The initial 20-test controller log and revised 21-test log are retained. The
new test actually launches harmless sleeping children locally, sends HUP and
TERM to their owners, and checks that each child is reaped and its terminal
receipt retained. These CPU checks invoke no model, MLX operator or M5 job.
