from pathlib import Path
import json
import tempfile
import unittest
from unittest.mock import patch
import resume_stage
import resume_arm
import common


class ResumeTests(unittest.TestCase):
    def test_completion_contract_is_json_and_has_no_population_mutation(self):
        code=resume_stage.COMPLETION
        compile(common.render(code,{'remote_root':'SOURCE_ONLY_PENDING_ROOT_REVIEW'}),'<completion>','exec')
        self.assertIn('print(json.dumps(',code)
        self.assertNotIn('shutil.copy',code);self.assertNotIn('mkdir(',code)
        with self.assertRaises(json.JSONDecodeError):json.loads('')

    def fixture(self,root,error='JSONDecodeError: Expecting value: line 1 column 1 (char 0)'):
        common.write(root/'summary.json',{'status':'FAIL','error':error})
        (root/'populate.stdout').write_bytes(b'');(root/'populate.stderr').write_bytes(b'')
        code=common.render(resume_stage.remote_sources.POPULATE,{'remote_root':'/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1','binding_sha256':resume_stage.EXPECTED_BINDING,'resources_source':'/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact'})
        (root/'populate-rendered.py').write_text(code);common.seal(root)

    def test_only_exact_original_parse_failure_is_eligible(self):
        with tempfile.TemporaryDirectory()as temporary:
            root=Path(temporary);self.fixture(root)
            with patch.object(resume_stage,'EXPECTED_STAGING_MANIFEST',common.sha(root/'manifest.json')):
                self.assertEqual(resume_stage.validate_failure(root)['populate_exit_code'],0)
                common.write(root/'summary.json',{'status':'FAIL','error':'hash assertion failed'});common.seal(root)
                with self.assertRaises(AssertionError):resume_stage.validate_failure(root)

    def test_other_predecessors_always_use_original_gate(self):
        target=common.RESULTS/'arms/nativeSDPA'
        with patch.object(resume_arm,'ORIGINAL',side_effect=AssertionError('retained arm failure'))as original:
            with self.assertRaisesRegex(AssertionError,'retained arm failure'):resume_arm.verified_predecessor(target)
            original.assert_called_once_with(target)

    def test_unverified_resume_does_not_pass_staging(self):
        with patch.object(resume_arm,'validate_failure',return_value={'original_staging_manifest_sha256':'0'*64}), \
             patch.object(resume_arm,'ORIGINAL',side_effect=AssertionError('unverified resume')):
            with self.assertRaisesRegex(AssertionError,'unverified resume'):
                resume_arm.verified_predecessor(common.RESULTS/'staging')


if __name__=='__main__':unittest.main()
