from pathlib import Path
import hashlib,json,shlex,stat,subprocess,sys
PACKAGE=Path('/tmp/darkbloom-connected-m5-bundle6-q38')
SUMMARY=Path('/tmp/darkbloom-connected-http6-package-freeze1/summary.json')
REMOTE='/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http6-q38'
SSH=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99']
SCP=['scp','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes']
PYTHON='/Applications/Xcode.app/Contents/Developer/usr/bin/python3'
ENV=['/usr/bin/env','-i','HOME=/Users/gaj','PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','PYTHONDONTWRITEBYTECODE=1']
CASES=['cold_donor_a','same_prompt_a','tenant_isolation_a','continuation_b','original_after_continuation','tools','vision','cancel','after_cancel','sidecar_unavailable']
CELLS=['qwen38-paged-off-b1','qwen38-paged-ssd-b1']
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def item(p):return {'bytes':p.stat().st_size,'sha256':sha(p),'mode':stat.S_IMODE(p.lstat().st_mode)}
def run(out,argv,label,code=None):
 if code is not None:compile(code,'<remote-'+label+'>','exec')
 result=subprocess.run(argv,input=code,text=True,capture_output=True)
 (out/(label+'.stdout')).write_text(result.stdout);(out/(label+'.stderr')).write_text(result.stderr)
 save(out/(label+'.command.json'),{'argv':argv,'exit_code':result.returncode})
 if code is not None:(out/(label+'.remote.py')).write_text(code)
 assert result.returncode==0,(label,result.returncode,result.stderr)
 return result.stdout
def render(body,constants):
 code='import json\nC=json.loads('+repr(json.dumps(constants))+')\n'+body
 compile(code,'<rendered-remote>','exec');return code
def ownership(out,label):
 result=run(out,[sys.executable,'-B',str(Path(__file__).parent/'preflight.py'),str(out/(label+'.json'))],label)
 value=json.loads(result);assert value['free_disk_bytes']>100*(1<<30)
 return value
def frozen_inputs():
 summary=json.loads(SUMMARY.read_text());assert sha(PACKAGE/'package-manifest.json')==summary['manifest']['sha256']
 assert sha(PACKAGE/'runtime-binding.json')==summary['binding']['sha256']
 manifest=json.loads((PACKAGE/'package-manifest.json').read_text())
 for name,record in manifest['files'].items():assert item(PACKAGE/name)==record,name
 return summary,json.loads((PACKAGE/'runtime-binding.json').read_text())
def freeze(out,scope):save(out/'manifest.json',{'scope':scope,'files':{str(p.relative_to(out)):item(p) for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}})
def strict_cell(launch,report,cell):
 errors=[]
 if launch.get('status')!='completed' or launch.get('exit_code')!=0:errors.append('launcher incomplete or failed')
 if report.get('schema')!=1 or report.get('state')!='completed' or report.get('wire_dropped')!=0:errors.append('report incomplete, failed or truncated')
 rows=report.get('cases',[])
 if [r.get('name') for r in rows]!=CASES:errors.append('exact ten ordered cases required')
 for row in rows:
  if row.get('status')!='passed':errors.append(row.get('name','unknown')+': case not passed')
  if row.get('request_date_utc')!='2026-09-06':errors.append(row.get('name','unknown')+': request date differs')
 expected=json.loads((PACKAGE/'inputs'/(cell+'.json')).read_text())
 if launch.get('input_sha256')!=sha(PACKAGE/'inputs'/(cell+'.json')):errors.append('launch input hash differs')
 for key in ['provider_binary','provider_sha256','metallib_sha256','sidecar_binary','sidecar_sha256','artifact','backend','cache_mode','mtp_mode','max_concurrent','tools_request','prompt','vision_png','vision_sha256']:
  if report.get('input',{}).get(key)!=expected.get(key):errors.append('report input differs: '+key)
 return errors
