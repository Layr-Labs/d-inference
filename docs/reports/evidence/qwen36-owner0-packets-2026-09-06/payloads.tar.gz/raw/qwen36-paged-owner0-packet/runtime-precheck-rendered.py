import json
CONFIG = json.loads('{"root": "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1", "output": "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1/runs/qwen36-paged-owner0-packet", "date": "2026-09-06", "plan_manifest_sha256": "21467d42b7e710d8303cb2690f79edb16d793241b919fa303d6acea888660fce", "binding_sha256": "48cea7e3daa6fb0676ccc069891eb93170885d7ae85dc6540a155d4454df2cdc", "cell": "qwen36-paged-owner0-packet", "argv": ["/usr/bin/env", "-i", "HOME=/Users/gaj", "PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin", "PYTHONDONTWRITEBYTECODE=1", "/Applications/Xcode.app/Contents/Developer/usr/bin/python3", "-B", "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1/runner/run_radix_engine.py", "--binary", "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1/runtime/radix-engine", "--model-directory", "/Users/gaj/autoresearch/radix-prefix-cache/qwen35b/models/qwen3.6-35b-a3b-vl-mtp-mxfp8/73a03825c2226177f3e679210965dba3508cdee8", "--input", "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1/inputs/qwen36.json", "--output", "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1/runs/qwen36-paged-owner0-packet", "--cache", "off", "--mtp", "off", "--kv-backend", "paged", "--cache-mode", "ssd", "--key-mode", "ephemeral", "--production-kv-grant", "--concurrency", "1", "--expected-model-sha256", "d932e96b00404b0575fff47e2dac8ed113056b3f22d0040c3c8d3f9ef25b09ed", "--prompt-date", "2026-09-06", "--trial", "1", "--startup-timeout", "240", "--logit-diagnostic-position", "62", "--logit-diagnostic-candidates", "1928,6829", "--attention-metadata-position", "62", "--attention-packet-position", "62", "--attention-packet-layer", "0"]}')
# Executed only after a JSON CONFIG preamble; this source is locally compiled first.
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import stat

root = Path(CONFIG['root']); output = Path(CONFIG['output'])
assert not output.exists(), 'Fresh output root required'
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat() == CONFIG['date'], 'Date rollover requires reviewed successor'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'manifest.json') == CONFIG['plan_manifest_sha256']
assert sha(root/'runtime-binding.json') == CONFIG['binding_sha256']
binding = json.loads((root/'runtime-binding.json').read_text())
for name, row in json.loads((root/'manifest.json').read_text())['files'].items():
    p = root/name
    assert stat.S_ISREG(p.lstat().st_mode) and p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], name
artifacts = {}
for name, row in binding['artifacts'].items():
    p = root/'runtime'/name
    assert stat.S_ISREG(p.lstat().st_mode) and p.stat().st_size == row['bytes'], name
    assert oct(stat.S_IMODE(p.stat().st_mode)) == row['mode'] and sha(p) == row['sha256'], name
    if name == 'radix-engine': assert row['mode'] == '0o755' and os.access(p, os.X_OK)
    artifacts[name] = row
assert len(artifacts) == 7 and 'radix-engine' in artifacts
plan = json.loads((root/'plan.json').read_text())
cell = next(c for c in plan['cells'] if c['id'] == CONFIG['cell'])
assert cell['argv'] == CONFIG['argv']
free = shutil.disk_usage(root).free
assert free >= plan['guards']['minimum_free_bytes']
print(json.dumps({'fresh_output_root':True,'date':CONFIG['date'],'free_bytes':free,'artifacts':artifacts,'cell':cell['id']}))
