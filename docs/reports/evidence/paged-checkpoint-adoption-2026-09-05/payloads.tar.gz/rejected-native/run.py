from pathlib import Path
import json,os,re,subprocess,time
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated');native=root/'libs/mlx-swift-lm';out=Path('/tmp/darkbloom-paged-adoption-validation1')
env=os.environ.copy();env['MLX_METALLIB_PATH']=str(root/'provider-swift/.build/arm64-apple-macosx/debug/mlx.metallib')
commands=[('package-edit',['swift','package','--scratch-path','../../provider-swift/.build','--skip-update','edit','--path','../mlx-swift','mlx-swift']),('build',['swift','build','--scratch-path','../../provider-swift/.build','--build-tests','--jobs','4','--disable-automatic-resolution']),('identifiers',['swift','test','list','--skip-build','--scratch-path','../../provider-swift/.build','--disable-automatic-resolution'])]
filters=json.loads((out/'filters.json').read_text())
for name in filters:commands.append((name,['../../scripts/run-nested-suite.sh',name,'--scratch-path','../../provider-swift/.build','--disable-automatic-resolution']))
results=[]
for name,command in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:result=subprocess.run(command,cwd=native,env=env,stdout=log,stderr=subprocess.STDOUT)
 entry={'name':name,'command':command,'exit_code':result.returncode,'seconds':time.monotonic()-start}
 results.append(entry);(out/'execution.json').write_text(json.dumps({'cwd':str(native),'environment':{'MLX_METALLIB_PATH':env['MLX_METALLIB_PATH']},'results':results},indent=2)+'\n')
 print(json.dumps({k:v for k,v in entry.items() if k!='command'}),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
