from pathlib import Path
import json,os,re,subprocess,time
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/mlx-coherent-memory-snapshot')
out=Path('/tmp/darkbloom-mlx-memory-snapshot-validation1')
env=os.environ.copy();env['MLX_METALLIB_PATH']='/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated/provider-swift/.build/arm64-apple-macosx/debug/mlx.metallib'
commands=[('swift-retained-buffer-colocated',['swift','test','--scratch-path',str(out/'swift-build'),'--skip-build','--disable-automatic-resolution','--filter','MemoryTests/testCoherentSnapshotTracksRetainedBuffer'])]
results=[]
for name,command in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 text=(out/(name+'.log')).read_text()
 valid=True
 if name=='swift-retained-buffer-colocated':valid=bool(re.search(r'Executed 1 test, with 0 failures',text)) and not re.search(r'skipped[.:]|with [1-9][0-9]* tests? skipped',text)
 entry={'name':name,'command':command,'cwd':str(root),'exit_code':result.returncode,'seconds':time.monotonic()-start,'selected_count_verified':valid}
 results.append(entry);(out/'swift-colocated-execution.json').write_text(json.dumps({'environment':{'MLX_METALLIB_PATH':env['MLX_METALLIB_PATH']},'results':results},indent=2)+'\n')
 print(json.dumps({k:v for k,v in entry.items() if k not in ['command','cwd']}),flush=True)
 if result.returncode or not valid:raise SystemExit(result.returncode or 1)
