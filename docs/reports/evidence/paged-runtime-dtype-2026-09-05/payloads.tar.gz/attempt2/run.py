from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated'); out=Path('/tmp/darkbloom-paged-runtime-validation2'); native=out/'package'; scratch=Path('/tmp/darkbloom-paged-runtime-validation1/build'); dep=root/'libs/mlx-swift'
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def verify():
 source=json.loads((out/'source-manifest.json').read_text())
 for path,digest in source['files'].items(): assert sha(native/path)==digest,path
 baseline=json.loads((out/'primary-baseline.json').read_text())
 for path,digest in baseline['files'].items(): assert sha(root/'libs/mlx-swift-lm'/path)==digest,path
 owned=json.loads((out/'runtime-owned-merged-manifest.json').read_text())
 for path,digest in owned['files'].items():assert sha(native/path)==digest,path
 overlay=json.loads((out/'manifest-overlay.json').read_text())
 assert sha(root/'libs/mlx-swift-lm/Package.swift')==overlay['original_sha256']
 assert sha(native/'Package.swift')==overlay['validation_sha256']
 deps=json.loads((out/'dependency-source-manifest.json').read_text())
 for key,digest in deps['files'].items():
  alias,path=key.split('/',1); assert sha(Path(deps['repositories'][alias])/path)==digest,key
 pins=json.loads((out/'dependency-pins.json').read_text())
 for alias,pin in pins.items(): assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=deps['repositories'][alias],text=True).strip()==pin,alias
 return {'native_candidate_selected':len(source['files']),'primary_unchanged_selected':len(baseline['files']),'owned_runtime_merged_sources':len(owned['files']),'dependency_selected':len(deps['files']),'no_drift':True}
(out/'source-verified-before.json').write_text(json.dumps(verify(),indent=2)+'\n')
results=[]
def run(name,command):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(command,cwd=native,stdout=log,stderr=subprocess.STDOUT)
 e={'name':name,'command':command,'exit_code':r.returncode,'seconds':time.monotonic()-start};results.append(e)
 (out/'execution.json').write_text(json.dumps({'cwd':str(native),'results':results},indent=2)+'\n');print(json.dumps({k:v for k,v in e.items() if k!='command'}),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('build',['swift','build','--scratch-path',str(scratch),'--build-tests','--jobs','4','--disable-automatic-resolution'])
graph=(scratch/'debug.yaml').read_text(); assert str(dep/'Source/MLX/Memory.swift') in graph; assert str(dep/'Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp') in graph; assert '/checkouts/mlx-swift/Source/' not in graph
assert str((native/'Libraries/MLXLMCommon/ContinuousBatchingV2/ProcessMemoryOwnership.swift').resolve()) in graph
assert str((native/'Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVWriteValidation.swift').resolve()) in graph
(out/'actual-build-graph.yaml.gz').write_bytes(gzip.compress(graph.encode(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'actual-package-state.json')
compile_lines=[line for line in graph.splitlines() if (str(dep/'Source/MLX/Memory.swift') in line or str(dep/'Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp') in line or str(dep/'Source/Cmlx/mlx-c/mlx/c/memory.cpp') in line)]
(out/'actual-compiler-source-proof.json').write_text(json.dumps({'mlx_swift_path':str(dep),'heads':json.loads((out/'dependency-pins.json').read_text()),'graph_lines':compile_lines,'remote_mlx_source_path_absent':True},indent=2)+'\n')
lib=root/'provider-swift/.build/arm64-apple-macosx/debug/mlx.metallib'; debug=scratch/'arm64-apple-macosx/debug';targets=[debug/'mlx.metallib']+[p/'mlx.metallib' for p in debug.glob('*.xctest/Contents/MacOS')];assert len(targets)==2
for target in targets:shutil.copy2(lib,target)
(out/'metallib-placement.json').write_text(json.dumps({'source':str(lib),'sha256':sha(lib),'bytes':lib.stat().st_size,'destinations':[str(t) for t in targets],'kernels_unchanged_from_prebuilt_dependency':True},indent=2)+'\n')
run('identifiers',['swift','test','list','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution'])
for name in json.loads((out/'filters.json').read_text()):run(name,[str(root/'scripts/run-nested-suite.sh'),name,'--scratch-path',str(scratch),'--disable-automatic-resolution'])
(out/'source-verified-after.json').write_text(json.dumps(verify(),indent=2)+'\n')
print('ALL COMMANDS PASSED AND SOURCE BYTES VERIFIED',flush=True)
