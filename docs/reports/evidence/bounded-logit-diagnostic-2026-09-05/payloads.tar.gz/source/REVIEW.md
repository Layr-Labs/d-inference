# Bounded actual-logit diagnostic — source review

This is an isolated, uncompiled diagnostic candidate. Primary/native a932 remain unchanged. It has 11 native paths (8 implementation, 3 tests) and 4 benchmark paths (3 implementation, 1 test). No provider policy, kernel, scoring, MTP verification/depth setting, cache default, or production environment is changed.

The optional native Diagnostics SPI observes one request ID and one zero-based generated position, at most two candidate IDs, and at most 16 compact records (default 8). Installation/drain/clear require engine idle. Configuration is validated at construction; it is Encodable only so decoding cannot bypass validation. An unavailable model top-two provider is refused. Nil configuration performs no diagnostic tensor construction or evaluation; selected logit slicing uses an autoclosure after ID/position/budget guards. Draining preserves the consumed budget. Shutdown clears host storage.

Normal rectangular MTP reuses the actual existing fused top-two result. Serial, ordinary and seed paths use their actual already-produced target logits. Compact lazy arrays contain independent argMax ID/value, fused top-two IDs/values, the requested raw values and nonfinite counts. Float32 bit patterns serialize NaN/Inf without invalid JSON. No full logits, Q/K/V tensors, prompt text, KV/recurrent state or production logging is exported. Actual Q dtype, device strides and full-vector norms remain unmeasured.

The packet records actual request/output base, column, k, batch size, seed and launch cache offset. Acceptance reconciliation distinguishes emitted columns, first-rejection context, rejected speculative suffix, truncation and discarded rows. The existing output-token arrays supply the preceding-history proof; records alone do not establish shared context. The final host materialization runs AFTER the existing adaptive recordStepCost timestamp. Every diagnostic array is included in existing step evaluation targets; serial columns use their already-existing eval call. No new forward or explicit eval/synchronization site is introduced by observation. Additional GPU reductions can still alter timing and subsequent adaptive choices.

The benchmark accepts two explicit flags, both required:

```
--logit-diagnostic-position 53 --logit-diagnostic-candidates 7244,2919
```

It requires B1 and targets native request ID 2 (first main row). Installation occurs AFTER the unchanged warmup. After that request's existing idle observation, it drains a `logit_diagnostic` report section and clears capture before later requests. Any missing confirmed record, budget omission or invalid candidate vocabulary is `inconclusive`. The original request token IDs, MTP activity, timing and cache oracles remain intact. Diagnostic timing cannot be banked as performance.

Use the existing direct immutable probe invocation with these suffixes, same new probe/resources in both arms, and all current model/input/grant/cache settings unchanged:

- Q36 MTP-off backend pair: `--logit-diagnostic-position 62 --logit-diagnostic-candidates 1928,6829`
- Q36 normal-MTP backend pair: `--logit-diagnostic-position 53 --logit-diagnostic-candidates 7244,2919`
- Q35 later cap32/cap128 diagnosis: `--logit-diagnostic-position 31 --logit-diagnostic-candidates 944,19549`

Every trace-on claim must compare its emitted trajectory against the corresponding frozen uninstrumented arm. If the failure moves/disappears, preserve that observation. Do not claim that compact values alone identify a kernel defect, waive token equality, silently disable MTP, or run the existing broken Qwen teacherForcedTop1 path.

Before a release probe, compile and run the new `CBv2LogitDiagnosticTests`, `CBv2OrdinaryLogitDiagnosticTests`, and added parameterized `CBv2QwenMTPIntegrationTests.boundedActualMTPDiagnostic`; run existing actual `Qwen35MTPTopTwoTests` and the complete Qwen integration suite. Run the three new benchmark option tests and existing eight idle-observation tests in the final harness package. Broaden native MTP regression checks according to source review. New tests are not yet compiled or executed. Freeze any failure/correction as a successor attempt.

The helper tests cover invalid configuration, selected ID/index, candidate vocabulary rejection, budget persistence through drain, real Qwen fused reduction on strided/tied/NaN inputs, acceptance/rejection/truncation context, disabled autoclosure avoidance, unavailable provider refusal and discarded-packet retirement/shutdown clearing. Real tiny-engine tests compare ordinary trace-off/on tokens and forward shapes, including chained positions and both prompt-frontier forms. Stateful MTP tests cover serial/rectangular verification, speculative suffix vs confirmed output, unchanged target geometry and existing rectangular top-two reuse.
