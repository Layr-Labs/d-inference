from pathlib import Path
import gzip, hashlib, io, json, sys, tarfile

out = Path(__file__).resolve().parent
worktree = Path('/Users/gaj/Documents/DarkbloomDev/wt/q36-attention-packet-090')
destination = worktree/'docs/reports/evidence/attention-packet-capture-2026-09-06'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
payloads = {}
inputs = {}

def add(name, path):
    assert name not in payloads and path.is_file() and not path.is_symlink(), name
    payloads[name] = path.read_bytes()

def frozen(label, root, expected):
    manifest = root/'manifest.json'
    assert sha(manifest) == expected, str(manifest)
    rows = json.loads(manifest.read_text())['files']
    for name, row in rows.items():
        path = root/name
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], name
        add(label+'/'+name, path)
    add(label+'/manifest.json', manifest)
    inputs[label] = {'manifest_sha256': expected, 'verified_payloads': len(rows)}

assert len(sys.argv) == 2, 'Pass the completed benchmark freeze SHA256'
benchmark = Path('/tmp/darkbloom-attention-packet-benchmark-validation1')
assert json.loads((benchmark/'verdict.json').read_text())['status'] == 'PASS_BENCHMARK_PACKET_METADATA_LOGIT_AND_IDLE_TESTS'
frozen('source', Path('/tmp/darkbloom-attention-packet-capture-source1'),
       '45e11082b4422bac8d7b008e4cf6b046cde972d28ef5b3218348217cfda58982')
frozen('native-validation', Path('/tmp/darkbloom-attention-packet-native-validation1'),
       'beaf85286316000be32d3168dc2dce4c3db92e3038964de536e6ecbe2d26b875')
frozen('benchmark-validation', benchmark, sys.argv[1])
for name, path in {
    'reviews/source-review.json': '/tmp/darkbloom-attention-packet-capture-root-source-review1.json',
    'reviews/preparation-review.json': '/tmp/darkbloom-attention-packet-root-preparation-review1.json',
}.items():
    add(name, Path(path))
add('bank.py', Path(__file__).resolve())
destination.mkdir(parents=True)
files = {name: {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
         for name, data in sorted(payloads.items())}
archive = destination/'payloads.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as packed:
            for name, data in sorted(payloads.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                entry.mtime = 0
                entry.uid = entry.gid = 0
                packed.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as packed:
    assert set(packed.getnames()) == set(files)
    for member in packed.getmembers():
        data = packed.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest() == files[member.name]['sha256']
        assert len(data) == files[member.name]['bytes']
manifest = {
    'scope': 'One-owner native attention packet source and native/benchmark validation. No optimized packet artifact, real target model capture, common-input backend replay or independent history mirror is asserted.',
    'parent_base_commit': '384c321aa7565864182c02210fc4d212efc6501b',
    'native_base_commit': 'e972340a7ba6e22fda5d8be1a7af918f9bf67b03',
    'source_freezes': inputs, 'files': files,
    'archive': {'file': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size},
    'payload_count': len(files), 'payload_bytes': sum(row['bytes'] for row in files.values()),
    'numerical_or_performance_acceptance': False,
}
(destination/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
result = {'manifest': str(destination/'manifest.json'), 'manifest_sha256': sha(destination/'manifest.json'),
          'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
          'payload_count': len(files), 'payload_bytes': manifest['payload_bytes']}
(out/'bank-result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
