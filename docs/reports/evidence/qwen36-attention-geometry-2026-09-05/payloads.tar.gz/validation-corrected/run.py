from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time
out=Path('/tmp/darkbloom-q36-attention-kernel-validation1');pkg=out/'native';scratch=Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
assert json.loads(Path('/tmp/darkbloom-final-serving-build8/verdict.json').read_text())['status']=='PASS_COMPILE_AND_LOCAL_VALIDATION'
known={}
def add(p,d,g):
 key=str(p.resolve());assert key not in known or known[key]['sha256']==d;known[key]={'sha256':d,'group':g}
for name,g in [('native-source-manifest.json','native'),('ancillary-package-manifest.json','ancillary')]:
 for p,d in json.loads((out/name).read_text())['files'].items():add(pkg/p,d,g)
deps=json.loads((out/'dependency-source-manifest.json').read_text())
for key,d in deps['files'].items():
 alias,p=key.split('/',1);add(Path(deps['repositories'][alias])/p,d,'dependency')
for p,d in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():add(scratch/'checkouts/swift-jinja'/p,d,'jinja')
def verify():
 for p,row in known.items():assert sha(Path(p))==row['sha256'],p
 return {'no_drift':True,'counts':{g:sum(r['group']==g for r in known.values()) for g in ['native','ancillary','dependency','jinja']}}
def graph(label):
 for name in ['debug.yaml','workspace-state.json']:
  p=scratch/name
  if p.exists():(out/(label+'-'+name+('.gz' if name.endswith('yaml') else ''))).write_bytes(gzip.compress(p.read_bytes(),mtime=0) if name.endswith('yaml') else p.read_bytes())
results=[]
def run(name,command,test=False):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(command,cwd=pkg,stdout=log,stderr=subprocess.STDOUT)
 body=(out/(name+'.log')).read_text();nonzero=bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test',body));skips=bool(re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',body,re.M));row={'name':name,'command':command,'cwd':str(pkg),'exit_code':r.returncode,'seconds':time.monotonic()-start,'nonzero_no_skips':not test or nonzero and not skips};results.append(row);write('execution.json',results);print(json.dumps(row),flush=True)
 if not test and r.returncode:graph('failed-build');write('source-verified-after-failure.json',verify());raise SystemExit(r.returncode)
write('source-verified-before.json',verify());write('environment.json',{k:v for k,v in os.environ.items() if k.startswith(('DARKBLOOM_MTP_','MLX_'))})
run('build',['swift','build','--scratch-path',str(scratch),'--build-tests','--jobs','4','--disable-automatic-resolution']);graph('actual-build');write('source-verified-postcompile.json',verify())
text=(scratch/'debug.yaml').read_text();rows={};unmapped=[]
for literal in sorted(set(re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',text))):
 p=Path(literal);key=str(p.resolve())
 if key in known:assert sha(p)==known[key]['sha256'];rows[literal]={'resolved_frozen_source':key,**known[key]}
 elif key.startswith(str(pkg.resolve())+'/'):unmapped.append(literal)
assert not unmapped,unmapped;assert '/checkouts/mlx-swift/Source/' not in text;assert any(p.endswith('/CBv2PagedKernelTests.swift') for p in rows)
write('all-owned-graph-source-proof.json',{'files':rows,'counts':{g:sum(r['group']==g for r in rows.values()) for g in ['native','ancillary','dependency','jinja']},'unmapped_owned_sources':unmapped,'remote_mlx_source_excluded':True})
debug=scratch/'arm64-apple-macosx/debug';bundle=debug/'mlx-swift-lmPackageTests.xctest/Contents/MacOS';binary=bundle/'mlx-swift-lmPackageTests';lib=Path('/tmp/darkbloom-final-serving-build7/artifact/mlx.metallib');assert sha(lib)=='4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0'
for target in [debug/'mlx.metallib',bundle/'mlx.metallib']:shutil.copy2(lib,target);assert sha(target)==sha(lib)
write('test-binary.json',{'path':str(binary),'sha256':sha(binary),'bytes':binary.stat().st_size,'metallib_sha256':sha(lib)})
run('identifiers',['swift','test','list','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution'])
filters={'qwen36-new-cases':'CBv2PagedKernelTests/qwen36','CBv2PagedKernelTests':'CBv2PagedKernelTests','CBv2PagedSegmentTests':'CBv2PagedSegmentTests','CBv2PagedNativeDTypeTests':'CBv2PagedNativeDTypeTests'};write('filters.json',filters)
for name,filter in filters.items():run(name,['swift','test','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution','--filter',filter],test=True)
graph('actual-after');write('source-verified-after.json',verify());assert sha(binary)==json.loads((out/'test-binary.json').read_text())['sha256'];failed=[r['name'] for r in results if r['exit_code'] or not r['nonzero_no_skips']];write('run-status.json',{'failed':failed,'all_four_filters_run':len(results)==6});print('GEOMETRY FAILED FILTERS='+str(failed),flush=True);raise SystemExit(bool(failed))
