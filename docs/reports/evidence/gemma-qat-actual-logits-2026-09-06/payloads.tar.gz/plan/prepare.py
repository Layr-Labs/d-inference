from pathlib import Path
import difflib, hashlib, json, shutil, subprocess, sys, tarfile

old_plan = Path('/tmp/darkbloom-qat-actual-logits-plan1')
old_execution = Path('/tmp/darkbloom-qat-actual-logits-execution2')
plan_root = Path('/tmp/darkbloom-qat-actual-logits-plan2')
execution_root = Path('/tmp/darkbloom-qat-actual-logits-execution3')
binding_path = Path('/tmp/darkbloom-qat-actual-logits-runtime-binding2.json')
build = Path('/tmp/darkbloom-generic-qat-release-probe1')
review = Path(sys.argv[1])
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def write(path, value): path.write_text(json.dumps(value, indent=2)+'\n')
assert not plan_root.exists() and not execution_root.exists() and not binding_path.exists()
assert sha(old_plan/'manifest.json') == '1af100278043a8187343e08a0d515d09fbbd7139f87d461e6aed9ef75ae3d985'
old_manifest = json.loads((old_plan/'manifest.json').read_text())
for name, row in old_manifest['files'].items():
    path = old_plan/name
    assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
verdict = json.loads((build/'verdict.json').read_text())
assert verdict['parent_commit'] == '6790dea1c7044ca336cd6383aac7e6d27afb7359'
assert verdict['native_commit'] == 'b01e1af06902c82e22227bf923447cc71c47b148'
assert verdict['smoke_checks'] == 25
json.loads(review.read_text())
artifacts = json.loads((build/'artifact-manifest.json').read_text())['files']
assert len(artifacts) == 7
for name, row in artifacts.items():
    path = build/'artifact'/name
    assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
    assert oct(path.stat().st_mode & 0o777) == row['mode']
plan_root.mkdir(); execution_root.mkdir()
for name in old_manifest['files']:
    target = plan_root/name; target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(old_plan/name, target)
shutil.copy2(old_plan/'manifest.json', plan_root/'provenance/first-attempt-plan-manifest.json')
shutil.copy2(old_plan/'source-correspondence.json', plan_root/'provenance/first-attempt-source-correspondence.json')
shutil.copy2('/tmp/darkbloom-qat-actual-logits-attempt1-freeze/manifest.json', plan_root/'provenance/first-attempt-failure-manifest.json')
shutil.copy2(review, plan_root/'provenance/generic-probe-root-release-review.json')
shutil.copy2(build/'manifest.json', plan_root/'provenance/generic-probe-build-manifest.json')
shutil.copy2(Path(__file__), plan_root/'prepare.py')
old = json.loads((old_plan/'plan.json').read_text())
old_remote = old['remote_root']
new_remote = '/Users/gaj/autoresearch/radix-prefix-cache/090-qat-actual-logits2'
def relocate(value):
    if isinstance(value, str) and (value == old_remote or value.startswith(old_remote+'/')):
        return new_remote+value[len(old_remote):]
    if isinstance(value, list): return [relocate(x) for x in value]
    if isinstance(value, dict): return {k: relocate(v) for k, v in value.items()}
    return value
plan = relocate(old)
plan['runtime_candidate'] = {
    'artifacts': artifacts, 'parent_commit': verdict['parent_commit'], 'native_commit': verdict['native_commit'],
    'local_artifact_root': str(build/'artifact'), 'remote_artifact_root': new_remote+'/runtime',
    'remote_root': new_remote, 'review': str(review), 'review_sha256': sha(review),
    'source_binding_sha256': sha(build/'source-union.json'),
    'scope': 'Reviewed generic-fix artifact identity only; new QAT binding still requires root execution review.',
}
plan['scope'] = 'Gemma QAT generic-diagnostic retry with four same-build controls; original c153 capability failure preserved. No numerical/performance acceptance.'
plan['execution'] = 'Source-only successor. No remote calls or model invocation; explicit root execution review required.'
assert plan['cells'] == relocate(old['cells'])
for key in ['input_sha256', 'expected_model_sha256', 'output_cap', 'prompt_tokens', 'selected_context', 'gates']:
    assert plan[key] == old[key]
write(plan_root/'plan.json', plan)
write(plan_root/'source-correspondence.json', {
    'new_parent_commit': verdict['parent_commit'], 'new_native_commit': verdict['native_commit'],
    'new_build_manifest_sha256': sha(build/'manifest.json'),
    'previous_plan_manifest_sha256': sha(old_plan/'manifest.json'),
    'changes': ['Fresh remote root and local execution root', 'Reviewed generic-diagnostic optimized probe'],
    'unchanged': ['Input bytes/date/output cap', 'Target and assistant artifacts', 'Four backend/trace cells and all arguments except owned roots', 'Selection/confirmed-MTP checks and seven completed trajectories', 'All five established Python runner files'],
    'wrapper_note': 'QAT uses the exact previously reviewed runner bytes and no namespace flags. The new probe includes namespace support, which remains unselected in these ephemeral cache-off cells.',
    'first_attempt_failure_preserved': '/tmp/darkbloom-qat-actual-logits-attempt1-freeze',
})
files = {str(p.relative_to(plan_root)): {'sha256': sha(p), 'bytes': p.stat().st_size,
         'mode': oct(p.stat().st_mode & 0o777)} for p in sorted(plan_root.rglob('*')) if p.is_file()}
write(plan_root/'manifest.json', {'scope': plan['scope'], 'files': files})
binding = relocate(json.loads(Path('/tmp/darkbloom-qat-actual-logits-runtime-binding1.json').read_text()))
binding.update(artifacts=artifacts, parent_commit=verdict['parent_commit'], native_commit=verdict['native_commit'],
    local_artifact_root=str(build/'artifact'), plan_manifest_sha256=sha(plan_root/'manifest.json'),
    review=str(review), review_sha256=sha(review), scope=plan['scope'])
binding['commands'] = [{'cell': c['id'], 'wrapper_argv': c['argv'],
                        'expected_observed_native_argv': c['expected_observed_native_argv']} for c in plan['cells']]
write(binding_path, binding)
for name in ['strict_results.py', 'test_strict_results.py', 'preflight.py']:
    shutil.copy2(old_execution/name, execution_root/name)
driver = (old_execution/'run_cell.py').read_text()
replacements = {
    str(old_plan): str(plan_root), str(old_execution): str(execution_root),
    '/tmp/darkbloom-qat-actual-logits-runtime-binding1.json': str(binding_path),
    '1af100278043a8187343e08a0d515d09fbbd7139f87d461e6aed9ef75ae3d985': sha(plan_root/'manifest.json'),
    '1c714fa86469c935c911cb7b02a318da9ee0490319457d692cad0f8bae39875f': sha(binding_path),
}
for before, after in replacements.items():
    assert before in driver, before
    driver = driver.replace(before, after)
compile(driver, 'run_cell.py', 'exec')
(execution_root/'run_cell.py').write_text(driver)
(execution_root/'driver-delta.patch').write_text(''.join(difflib.unified_diff(
    (old_execution/'run_cell.py').read_text().splitlines(True), driver.splitlines(True),
    fromfile='execution2/run_cell.py', tofile='execution3/run_cell.py')))
shutil.copy2(binding_path, execution_root/'runtime-binding.json')
shutil.copy2(review, execution_root/'runtime-root-review.json')
shutil.copy2(plan_root/'manifest.json', execution_root/'plan-manifest.json')
write(execution_root/'preparation-summary.json', {
    'state': 'SOURCE_ONLY_PENDING_ROOT_EXECUTION_REVIEW', 'no_remote_calls': True, 'no_model_invocation': True,
    'source_plan': str(plan_root), 'plan_manifest_sha256': sha(plan_root/'manifest.json'),
    'binding': str(binding_path), 'binding_sha256': sha(binding_path),
    'strict_helper_sha256': sha(execution_root/'strict_results.py'),
    'strict_helper_unchanged': sha(execution_root/'strict_results.py') == sha(old_execution/'strict_results.py'),
    'driver_delta': 'Exact path/digest substitutions; remote code compilation and all strict assertions retained.',
})
print(json.dumps({'plan_manifest_sha256': sha(plan_root/'manifest.json'), 'binding_sha256': sha(binding_path),
                  'execution_root': str(execution_root), 'state': 'AWAITING_LOCAL_RENDER_TEST_AND_ROOT_REVIEW'}, indent=2))
