#!/bin/sh
set -eu
umask 077
PATH=/home/gaj.guest/prompt-proof/toolchain/bin:$PATH
export PATH
cd /home/gaj.guest/prompt-proof/source/coordinator/promptsidecar
cargo build --locked --release --target aarch64-unknown-linux-musl --bin promptsidecar
file target/aarch64-unknown-linux-musl/release/promptsidecar
file target/aarch64-unknown-linux-musl/release/promptsidecar | grep -Eq "statically linked|static-pie linked"
sha256sum target/aarch64-unknown-linux-musl/release/promptsidecar
