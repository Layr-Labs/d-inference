from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time

out=Path('/tmp/darkbloom-receipt-diagnostic-provider-validation1')
scratch=Path('/tmp/darkbloom-process-memory-telemetry-swift-validation1/build')
native=Path('/tmp/darkbloom-q36-logit-diagnostic-validation3/native')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(path,v):path.write_text(json.dumps(v,indent=2)+'\n')
def verify(variant):
 ws=out/variant/'workspace';p=json.loads((out/variant/'provider-source-manifest.json').read_text())
 for name,digest in p['files'].items():assert sha(ws/name)==digest,(variant,name)
 for name in p.get('deleted_files',[]):assert not (ws/name).exists(),name
 for manifest in ['native-source-manifest.json','ancillary-package-manifest.json']:
  for name,digest in json.loads((out/manifest).read_text())['files'].items():assert sha(native/name)==digest,name
 deps=json.loads((out/'dependency-source-manifest.json').read_text())
 for key,digest in deps['files'].items():
  alias,name=key.split('/',1);assert sha(Path(deps['repositories'][alias])/name)==digest,key
 for name,digest in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():assert sha(scratch/'checkouts/swift-jinja'/name)==digest,name
 return {'provider':len(p['files']),'native':484,'ancillary_native':405,'dependencies':1356,'jinja':27,'no_drift':True}
executions=json.loads((out/'execution.json').read_text())
def run(variant,name,command,test=False):
 phase=out/variant;pkg=phase/'workspace/provider-swift';started=time.monotonic()
 with (phase/(name+'.log')).open('w') as log:p=subprocess.run(command,cwd=pkg,stdout=log,stderr=subprocess.STDOUT)
 body=(phase/(name+'.log')).read_text()
 nonzero=bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test',body))
 skips=bool(re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',body,re.M))
 result={'variant':variant,'name':name,'command':command,'cwd':str(pkg),'seconds':time.monotonic()-started,'exit_code':p.returncode,'nonzero_no_skips':not test or nonzero and not skips};executions.append(result);write(out/'execution.json',executions);print(json.dumps(result),flush=True)
 return p.returncode,body
def graph(variant,label):
 phase=out/variant
 for name in ['debug.yaml','workspace-state.json']:
  path=scratch/name
  if path.exists():(phase/(label+'-'+name+('.gz' if name.endswith('yaml') else ''))).write_bytes(gzip.compress(path.read_bytes(),mtime=0) if name.endswith('yaml') else path.read_bytes())
def build(variant):
 phase=out/variant;write(phase/'source-verified-before.json',verify(variant))
 if variant=='baseline':
  assert any(r['variant']=='baseline' and r['name']=='build' and r['exit_code']==0 for r in executions)
  code=0
 else:
  code,_=run(variant,'build',['swift','build','--scratch-path',str(scratch),'--build-tests','--jobs','4','--disable-automatic-resolution'])
 graph(variant,'actual-build');write(phase/'source-verified-postcompile.json',verify(variant));assert code==0,variant+' build'
 text=(scratch/'debug.yaml').read_text();proof=[]
 actual_paths=sorted(set(re.findall(r'"(/[^"\n]+)"',text)))
 for path in [phase/'workspace/provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge+Submission.swift',phase/'workspace/provider-swift/Tests/ProviderCoreTests/EngineV2BridgeTests.swift',native/'Libraries/MLXLMCommon/ContinuousBatchingV2/CBv2LogitDiagnostic.swift']:
  actual=next((p for p in actual_paths if p.endswith('/'+path.name) and Path(p).resolve()==path.resolve()),None);assert actual,str(path);proof.append({'actual_path':actual,'resolved_path':str(path.resolve()),'sha256':sha(path)})
 assert '/checkouts/mlx-swift/Source/' not in text
 write(phase/'actual-compiler-source-proof.json',{'paths':proof,'remote_mlx_source_excluded':True})
 debug=scratch/'arm64-apple-macosx/debug';bundle=debug/'DarkbloomProviderPackageTests.xctest/Contents/MacOS';binary=bundle/'DarkbloomProviderPackageTests'
 lib=Path('/tmp/darkbloom-final-serving-build7/artifact/mlx.metallib');assert sha(lib)=='4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0'
 for target in [debug/'mlx.metallib',bundle/'mlx.metallib']:shutil.copy2(lib,target);assert sha(target)==sha(lib)
 write(phase/'test-binary.json',{'path':str(binary),'sha256':sha(binary),'bytes':binary.stat().st_size,'metallib_sha256':sha(lib)})
 run(variant,'identifiers',['swift','test','list','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution'])
def test(variant,name,filter):
 return run(variant,name,['swift','test','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution','--filter',filter],test=True)
write(out/'environment.json',{k:v for k,v in os.environ.items() if k.startswith(('DARKBLOOM_MTP_','MLX_'))})
build('baseline')
code,body=test('baseline','readyAfterSubmitReturns','EngineV2BridgePumpReceiptTests/readyAfterSubmitReturns')
write(out/'baseline/source-verified-after.json',verify('baseline'));graph('baseline','actual-after')
expected=code!=0 and 'readyReceipts.count' in body and 'Expectation failed' in body and '→ 0' in body
write(out/'baseline/verdict.json',{'status':'EXPECTED_REGRESSION_FAILURE' if expected else 'UNEXPECTED_CONTROL_RESULT','exit_code':code,'expected_assertion':'readyReceipts.count is 0 after successful submit, expected1','source_changed':False})
assert expected,'baseline did not reproduce the intended receipt regression'
build('candidate')
filters=['EngineV2BridgePumpReceiptTests','EngineV2SharedBudgetTests','EngineV2ErrorMappingTests','EngineV2CancellationTests','EngineV2LookupReceiptCoverageTests','EngineV2ShutdownTests','EngineV2HardeningTests','EngineProfileCancelTests','SSDHybridCheckpointStoreTests','PrefixCacheReceiptTests','OuterPrefixCacheReceiptTests','ResidentPrefixCacheEvidenceTests','RetirementGateTests','EngineV2ResliceUnwindTests']
write(out/'candidate/filters.json',filters)
for name in filters:test('candidate',name,name)
write(out/'candidate/source-verified-after.json',verify('candidate'));graph('candidate','actual-after')
failed=[r['name'] for r in executions if r['variant']=='candidate' and (r['exit_code'] or not r['nonzero_no_skips'])]
write(out/'candidate/verdict.json',{'status':'PASS' if not failed else 'FAIL','failed':failed,'filters':len(filters),'default_native_diagnostics':'nil; no capture configured','benchmark_tests_run':False,'real_models_run':False})
print('RECEIPT CANDIDATE FAILED FILTERS='+str(failed),flush=True);raise SystemExit(bool(failed))
