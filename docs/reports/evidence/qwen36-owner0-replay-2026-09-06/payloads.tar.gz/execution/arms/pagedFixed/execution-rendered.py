import json
C=json.loads('{"remote_root": "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1", "binding_sha256": "a04631ec25459596b98561910463c88e334ed0e059714def34f54cfca57ee4c8", "arm": "pagedFixed", "argv": ["/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1/runtime/attention-replay", "--input", "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1/transfer/input.json", "--input-sha256", "17114f5243a9657bfcc3d4c7d1f3d9362bffeb744b1ceb5f815c321f0479d487", "--output", "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1/runs/pagedFixed", "--arm", "pagedFixed"]}')
from pathlib import Path
import hashlib,json,stat
root=Path(C['remote_root']);assert root.resolve()==root and not root.is_symlink()
def check(path,row):
 status=path.lstat();assert stat.S_ISREG(status.st_mode) and not path.is_symlink(),str(path)
 assert status.st_size==row['bytes'] and stat.S_IMODE(status.st_mode)==int(row['mode'],8),str(path)
 digest=hashlib.sha256()
 with path.open('rb') as file:
  for chunk in iter(lambda:file.read(1<<20),b''):digest.update(chunk)
 assert digest.hexdigest()==row['sha256'],str(path)
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()==C['binding_sha256']
binding=json.loads((root/'runtime-binding.json').read_text())
assert binding['remote_root']==str(root)
assert hashlib.sha256((root/'plan/manifest.json').read_bytes()).hexdigest()==binding['plan_manifest_sha256']
for name,row in json.loads((root/'plan/manifest.json').read_text())['files'].items():check(root/'plan'/name,row)
for name,row in binding['artifacts'].items():check(root/'runtime'/name,row)
assert {str(p.relative_to(root/'runtime'))for p in (root/'runtime').rglob('*')if p.is_file()}==set(binding['artifacts'])
mapping=json.loads((root/'plan/native-buffer-map.json').read_text())
for row in mapping.values():check(root/'transfer'/row['destination_file'],{k:row[k]for k in ('sha256','bytes','mode')})
assert {p.name for p in (root/'transfer').iterdir()}=={'input.json'}|{row['destination_file']for row in mapping.values()}
assert hashlib.sha256((root/'transfer/input.json').read_bytes()).hexdigest()==binding['input_sha256']

import os,signal,subprocess,time
arm=C['arm'];command=next(x for x in binding['commands']if x['arm']==arm)
assert command['argv']==C['argv'] and command['timeout_seconds']==180
output=root/'runs'/arm;assert not output.exists()
execution=root/'runs'/(arm+'-execution.json');log=root/'runs'/(arm+'.log')
assert not execution.exists() and not log.exists()
start=time.monotonic();record={'arm':arm,'argv':command['argv'],'input_sha256':binding['input_sha256'],'binary_sha256':binding['artifacts']['attention-replay']['sha256'],'timeout_seconds':180,'exit_code':None,'failure':None};process=None
owned_signals=(signal.SIGHUP,signal.SIGTERM)
previous_handlers={sig:signal.getsignal(sig)for sig in owned_signals}
class OwnerInterrupted(RuntimeError):pass
def interrupt_owner(signum,frame):
 for sig in owned_signals:signal.signal(sig,signal.SIG_IGN)
 raise OwnerInterrupted('received signal '+str(signum))
for sig in owned_signals:signal.signal(sig,interrupt_owner)
try:
 with log.open('x') as stream:
  try:
   # The single-threaded owner cannot lose a freshly forked child before storing its PID.
   prior_mask=signal.pthread_sigmask(signal.SIG_BLOCK,owned_signals)
   try:
    process=subprocess.Popen(command['argv'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True,env={'HOME':'/Users/gaj','PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'},preexec_fn=lambda:signal.pthread_sigmask(signal.SIG_SETMASK,prior_mask))
   finally:signal.pthread_sigmask(signal.SIG_SETMASK,prior_mask)
   record['pid']=process.pid;record['pgid']=os.getpgid(process.pid)
   execution.write_text(json.dumps(record,indent=2)+'\n')
   record['exit_code']=process.wait(timeout=180)
  except Exception as error:record['failure']=type(error).__name__+': '+str(error)
  finally:
   for sig in owned_signals:signal.signal(sig,signal.SIG_IGN)
   if process is not None:
    record['pid']=process.pid;record['pgid']=process.pid
    if process.poll() is None:
     try:os.killpg(process.pid,signal.SIGKILL)
     except ProcessLookupError:pass
    record['exit_code']=process.wait(timeout=10)
finally:
 record['seconds']=time.monotonic()-start
 execution.write_text(json.dumps(record,indent=2)+'\n')
 for sig,handler in previous_handlers.items():signal.signal(sig,handler)
print(json.dumps(record,indent=2))
