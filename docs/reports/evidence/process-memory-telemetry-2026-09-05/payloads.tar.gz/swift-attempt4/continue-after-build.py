from pathlib import Path
import json
p=Path('/tmp/darkbloom-process-memory-telemetry-swift-validation4')
t=(p/'run.py').read_text()
head,tail=t.split("run('build',",1)
exec(head)
results=json.loads((p/'execution.json').read_text())['results']
assert len(results)==1 and results[0]['exit_code']==0
exec(tail.split('\n',1)[1])
