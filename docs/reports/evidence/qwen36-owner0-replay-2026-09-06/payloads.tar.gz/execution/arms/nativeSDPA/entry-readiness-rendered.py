import json
C=json.loads('{"entry": true}')
from pathlib import Path
import json,os,shutil,subprocess,time
processes=[]
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,comm=,args='],text=True).splitlines():
 bits=line.strip().split(None,3)
 if len(bits)<3:continue
 markers=('Runner.Worker','benchctl measure-job','measure-job.sh','radix-engine','run_radix_engine.py','connected-e2e.test','run_connected_fixture.py','attention-replay')
 if any(marker in line for marker in markers) or Path(bits[2]).name=='darkbloom':
  processes.append({'pid':bits[0],'ppid':bits[1],'command':bits[2]})
temperature=json.loads(subprocess.check_output(['/Users/gaj/bench-runner/bin/macmon','pipe','-s','1','-i','200'],text=True,timeout=10).splitlines()[0])['temp']['gpu_temp_avg']
value={'unix_time':time.time(),'processes':processes,'gpu_temp_c':temperature,'load':os.getloadavg(),'free_bytes':shutil.disk_usage('/Users/gaj').free}
print(json.dumps(value,indent=2))
assert not processes
if C['entry']:
 assert temperature<=42 and value['load'][0]<=4 and value['free_bytes']>100*(1<<30)
