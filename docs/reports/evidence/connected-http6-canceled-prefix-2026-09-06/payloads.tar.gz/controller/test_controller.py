import copy,json,unittest
from pathlib import Path
from common import *
import remote_scripts

class ControllerTests(unittest.TestCase):
 def test_all_rendered_scripts_compile_and_constants_remain_literal(self):
  constants={'remote':REMOTE,'output':REMOTE+'/runs/test','review_sha':'a'*64,'archive_sha':'b'*64,'manifest_sha':'c'*64,'binding_sha':'d'*64,'members':1183,'state':'SOURCE_ONLY_PENDING_ROOT_REVIEW'}
  for name in ['CREATE','EXTRACT','RUNTIME','CHECK','INVENTORY']:
   source=render(getattr(remote_scripts,name),constants)
   namespace={};exec(source.split('from pathlib import Path')[0],namespace)
   self.assertEqual(namespace['C'],constants)
 def fixture(self):
  previous=Path('/tmp/darkbloom-connected-http5-results/qwen38-paged-off-b1')
  launch=json.loads((previous/'launch.json').read_text());report=json.loads((previous/'evidence/report.json').read_text())
  expected=json.loads((PACKAGE/'inputs'/(CELLS[0]+'.json')).read_text())
  launch['input_sha256']=sha(PACKAGE/'inputs'/(CELLS[0]+'.json'))
  for key in ['provider_binary','provider_sha256','vision_png']:report['input'][key]=expected[key]
  return launch,report
 def test_strict_gate_accepts_complete_fixture_only(self):
  launch,report=self.fixture();self.assertEqual(strict_cell(launch,report,CELLS[0]),[])
 def test_failed_cancel_and_missing_rows_are_rejected(self):
  launch,report=self.fixture();report['cases'][7]['status']='failed';self.assertTrue(strict_cell(launch,report,CELLS[0]))
  launch,report=self.fixture();report['cases'].pop();self.assertTrue(strict_cell(launch,report,CELLS[0]))
 def test_input_and_wire_and_date_changes_are_rejected(self):
  for mutate in [lambda a,b:a.update(input_sha256='bad'),lambda a,b:b.update(wire_dropped=1),lambda a,b:b['input'].update(cache_mode='ssd'),lambda a,b:b['cases'][0].update(request_date_utc='2026-09-07')]:
   launch,report=self.fixture();mutate(launch,report);self.assertTrue(strict_cell(launch,report,CELLS[0]))
 def test_preflight_remote_source_compiles_without_execution(self):
  import ast
  tree=ast.parse((Path(__file__).parent/'preflight.py').read_text())
  literal=next(n.value.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='code' for t in n.targets))
  compile(literal,'<remote-preflight>','exec')

if __name__=='__main__':unittest.main()
