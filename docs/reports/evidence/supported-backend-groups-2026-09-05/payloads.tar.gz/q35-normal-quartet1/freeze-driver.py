from pathlib import Path
import json,hashlib,shutil
out=Path('/tmp/darkbloom-q35-normal-quartet1-freeze');out.mkdir(exist_ok=False);base=Path('/tmp/darkbloom-repeated-matrix-execution1');names=['qwen35-b1-r1-'+backend+'-cache-'+cache for backend in ('contiguous','paged') for cache in ('off','on')]
def add(src,rel):
 src=Path(src);dst=out/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def tree(src,rel):
 src=Path(src)
 for p in sorted(src.rglob('*')):
  if p.is_file() and not p.is_symlink():add(p,Path(rel)/p.relative_to(src))
for name in names:tree(base/name,'raw/'+name)
plan=Path('/tmp/darkbloom-repeated-matrix-plan1');pm=json.loads((plan/'manifest.json').read_text())
for name,item in pm['files'].items():
 p=plan/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'];add(p,Path('source-plan')/name)
add(plan/'manifest.json','source-plan/manifest.json');tree('/tmp/darkbloom-q35-quartet1-postcheck','postcheck')
for src,rel in [('/tmp/run-reviewed-matrix-q35-quartet1.py','driver.py'),('/tmp/darkbloom-q35-quartet1-driver-proof.json','driver-proof.json'),('/tmp/postcheck-q35-quartet1.py','postcheck-driver.py'),('/tmp/freeze-q35-quartet1.py','freeze-driver.py'),('/tmp/darkbloom-repeated-matrix-bindings-reviewed1.json','support/bindings.reviewed1.json'),('/tmp/darkbloom-repeated-matrix-binding1-root-review.json','support/binding-root-review.json'),('/tmp/darkbloom-final-serving-build6/manifest.json','support/build6-manifest.json'),('/tmp/darkbloom-final-serving-build6/artifact-manifest.json','support/build6-artifact-manifest.json'),('/tmp/darkbloom-build6-root-review.json','support/build6-root-review.json')]:add(src,rel)
collection=json.loads((base/names[-1]/'collection.json').read_text());pairs=[x for x in collection['comparisons'] if x.get('quartet')=='qwen35-b1-r1'];assert len(pairs)==4
reports={name:json.loads((base/name/'report.json').read_text()) for name in names};summary={'scope':'One normal-MTP Q35 build6 B1 repetition1 quartet from unchanged approved original matrix; exact within-backend cache and across-backend comparison. No repeated-performance or release acceptance.','native_commit':'a932d38cee0beca41ca1a0e71c1e867913a65353','runtime_sha256':'1b0df2f9ba18bf6738ae529adaf4e1ad9d7dc43f20dba54c244de71f517cbba3','pairs':pairs,'arms':{},'direct_backend_comparisons':{}}
def snapshot(row):
 return {k:row.get(k) for k in ('id','prompt_tokens','completion_tokens','finish','token_ids','text','matched_tokens','saved_tokens','cache_outcome','ttft_s','terminal_tail_s','decode_steps','prefill_chunks','prefill_chunk_tokens_max')}|{'mtp_before':row.get('metrics_before',{}).get('mtp'),'mtp_after':row.get('metrics_after',{}).get('mtp')}
for name,r in reports.items():
 summary['arms'][name]={'status':r['status'],'mtp':r['mtp'],'resolved_backend':r['resolved_backend'],'verified_model_hash':r['verified_model_hash'],'runtime_identity':r['runtime_identity'],'rows':[snapshot(row) for row in r['rows']],'warmup':snapshot(r['warmup']) if isinstance(r.get('warmup'),dict) else r.get('warmup'),'cancel_donor':snapshot(r['cancel_donor']),'cancelled':snapshot(r['cancelled']),'recovered':snapshot(r['recovered']),'tenant_checks':r['tenant_checks'],'shutdown_mtp':r.get('metrics_after_shutdown',{}).get('mtp')}
for cache in ('off','on'):
 a=reports['qwen35-b1-r1-contiguous-cache-'+cache];b=reports['qwen35-b1-r1-paged-cache-'+cache];items=[]
 for x,y in zip(a['rows'],b['rows']):
  assert x['id']==y['id'];u=x['token_ids'];v=y['token_ids'];common=0
  while common<min(len(u),len(v)) and u[common]==v[common]:common+=1
  same=u==v;items.append({'id':x['id'],'prompt_ids_equal':x['prompt_token_ids']==y['prompt_token_ids'],'token_ids_equal':same,'contiguous_tokens':len(u),'paged_tokens':len(v),'common_prefix_tokens':common,'first_differing_position_one_based':None if same else common+1,'contiguous_token_at_difference':None if same or common==len(u) else u[common],'paged_token_at_difference':None if same or common==len(v) else v[common],'contiguous_near_difference':[] if same else u[max(0,common-3):common+6],'paged_near_difference':[] if same else v[max(0,common-3):common+6]})
 summary['direct_backend_comparisons'][cache]=items
(out/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n');files={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()};(out/'manifest.json').write_text(json.dumps({'scope':summary['scope'],'files':files},indent=2)+'\n');print(json.dumps({'root':str(out),'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),'payloads':len(files),'bytes':sum(x['bytes'] for x in files.values()),'comparisons':[{k:p.get(k) for k in ('id','axis','state','passed','errors')} for p in pairs],'direct':summary['direct_backend_comparisons']},indent=2))
