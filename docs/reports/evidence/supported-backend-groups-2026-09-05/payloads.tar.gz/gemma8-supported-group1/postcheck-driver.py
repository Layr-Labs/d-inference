from pathlib import Path
import json,subprocess,hashlib
out=Path('/tmp/darkbloom-gemma8-group1-postcheck');out.mkdir(exist_ok=False)
for helper,name in [('/tmp/darkbloom-fleet-smoke-continuation/preflight.py','ownership'),('/tmp/measure-repeated-matrix-storage.py','storage')]:
 r=subprocess.run(['python3','-B',helper,str(out/(name+'.json'))],capture_output=True,text=True);(out/(name+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
manifest=Path('/tmp/qwen35b-ssd-model-inventory/gemma-4-26b-fleet-manifest.json');m=json.loads(manifest.read_text());(out/'expected-model-manifest.json').write_bytes(manifest.read_bytes())
code='''from pathlib import Path
import hashlib,json,time
root=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-repeated-matrix1');p=root/'bindings.reviewed1.json';assert hashlib.sha256(p.read_bytes()).hexdigest()=='bab4d1512a1bebb5cf305b2b019f9d084042c201161b7114bda56ada9d1ce47f';b=json.loads(p.read_text());model=Path(b['models']['gemma-4-26b']['directory']);expected=EXPECTED;start=time.monotonic();files=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
 return h.hexdigest()
assert {p.name for p in model.iterdir() if p.is_file()}=={x['path'] for x in expected['files']}
for item in expected['files']:
 p=model/item['path'];actual=sha(p);assert p.stat().st_size==item['size_bytes'] and actual==item['sha256'];files.append({'path':str(p),'bytes':p.stat().st_size,'sha256':actual})
runtime={}
for item in [b['binary']]+list(b['resources'].values()):
 p=Path(item['path']);actual=sha(p);assert actual==item['sha256'];runtime[str(p)]=actual
wrapper=root/'plan/runner/run_radix_engine.py';actual=sha(wrapper);assert actual=='b5166c413e72f871ff8ebe17493b4628a8f0479e9eba376b0090eb65e3db29a1';runtime[str(wrapper)]=actual
assistant=Path(b['models']['gemma-4-26b']['assistant_directory']);assert str(assistant)=='/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-smoke1/payload/gemma-assistant-local-override1';assistant_expected={'config.json':'0cd54ff36e53a258532c5c1433bc44b88ba758cfe9b59bb4e6eecfd5453fabcf','model.safetensors':'3c4d43863abbbf455ec537c726eff7abeb88bb361e3ab23ff0d2d6006f620f74'};assert {p.name for p in assistant.iterdir()}==set(assistant_expected)
for name,h in assistant_expected.items():assert sha(assistant/name)==h
print(json.dumps({'scope':'Original Gemma8 supported three-cell group completed; contiguous SSD remains unsupported; exact target/runtime/wrapper bytes reverified at idle without source or state mutations','seconds':time.monotonic()-start,'model_aggregate_sha256':expected['aggregate_sha256'],'model_files':files,'runtime_sha256':runtime,'assistant_directory':str(assistant),'assistant_sha256':assistant_expected},indent=2))
'''.replace('EXPECTED',repr(m));ssh=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','gaj@100.124.35.99'];r=subprocess.run(ssh+['python3 -B -'],input=code,capture_output=True,text=True);(out/'hashes.json').write_text(r.stdout);(out/'hashes.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr;print(r.stdout)
