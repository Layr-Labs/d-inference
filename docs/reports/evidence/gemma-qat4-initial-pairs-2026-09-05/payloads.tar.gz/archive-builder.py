from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import tarfile

work = Path('/Users/gaj/Documents/DarkbloomDev/wt/gemma-qat4-initial-pairs')
out = work / 'docs/reports/evidence/gemma-qat4-initial-pairs-2026-09-05'
out.mkdir(parents=True, exist_ok=False)
sha = lambda data: hashlib.sha256(data).hexdigest()
payloads = {}
sources = {}
omitted = []
frozen = {}
verified = 0
for cap, expected in [(32, '0b5c3e2dc7bc87091924896733fd9b8c934ee9d8d9e0c924f89be892ab0fb6c5'),
                      (128, '9e2d704b3528c93313440edff39e425a8e15b66804c852de250bd8d6bbe89b4a')]:
    source = Path(f'/tmp/darkbloom-qat-output{cap}-pair-freeze1')
    manifest = (source / 'manifest.json').read_bytes()
    assert sha(manifest) == expected
    frozen[str(cap)] = expected
    for rel, record in json.loads(manifest)['files'].items():
        data = (source / rel).read_bytes()
        assert sha(data) == record['sha256'] and len(data) == record['bytes'], rel
        verified += 1
        if rel == 'binding/plan/assets/cube-hero.png':
            omitted.append({'source': str(source / rel), **record,
                            'reason': 'Unexercised vision asset; identity retained in original manifest.'})
            continue
        name = f'output{cap}/{rel}'
        payloads[name] = data
        sources[name] = str(source / rel)
    name = f'output{cap}/manifest.json'
    payloads[name] = manifest
    sources[name] = str(source / 'manifest.json')
assert verified == 252 and len(omitted) == 2
for name in ['darkbloom-gemma-qat-pairs-root-review.json',
             'darkbloom-gemma-qat-native-observer-root-review.json']:
    source = Path('/tmp') / name
    rel = 'review/' + name
    payloads[rel] = source.read_bytes()
    sources[rel] = str(source)
source = Path(__file__)
payloads['archive-builder.py'] = source.read_bytes()
sources['archive-builder.py'] = str(source)
proof = {'scope': 'Local archive verification only; no new Swift/model/remote execution.',
         'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'source_commit': '12e941bb128bf3450c6c040d920382a525f33274',
         'original_frozen_manifests': frozen, 'original_payloads_verified': verified,
         'omitted': omitted,
         'root_reviews_preserved': True,
         'compiled_runtime_and_model_binaries_included': False}
payloads['archive-preparation.json'] = (json.dumps(proof, indent=2) + '\n').encode()
sources['archive-preparation.json'] = 'generated from verified original manifests'

archive = out / 'payloads.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(payloads.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive) as tar:
    members = tar.getmembers()
    assert len(members) == len(payloads)
    assert {item.name for item in members} == set(payloads)
    for item in members:
        assert item.isfile() and tar.extractfile(item).read() == payloads[item.name], item.name

manifest = {
    'scope': 'Exact production Gemma QAT4bit target-only KV observer and initial normal-MTP paged B1 cache pairs at caps32/128. No backend/repeated-performance/HTTP/restart/default acceptance.',
    'source_commit': '12e941bb128bf3450c6c040d920382a525f33274',
    'native_commit': 'a932d38cee0beca41ca1a0e71c1e867913a65353',
    'probe_sha256': '1b0df2f9ba18bf6738ae529adaf4e1ad9d7dc43f20dba54c244de71f517cbba3',
    'target_aggregate_sha256': '2468a0cb3049a871f42052f4d9f9380bf12a0792f64c7a29f768559fc7d28785',
    'original_frozen_manifests': frozen,
    'original_payloads_verified': verified,
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes())},
    'payload_count': len(payloads), 'payload_bytes': sum(map(len, payloads.values())),
    'omitted': omitted,
    'files': {name: {'source': sources[name], 'bytes': len(data), 'sha256': sha(data)}
              for name, data in sorted(payloads.items())}}
path = out / 'manifest.json'
path.write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'manifest_sha256': sha(path.read_bytes()), 'archive': manifest['archive'],
                  'payload_count': manifest['payload_count'], 'payload_bytes': manifest['payload_bytes']}, indent=2))
