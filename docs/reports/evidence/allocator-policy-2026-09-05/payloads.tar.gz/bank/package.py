from pathlib import Path
import gzip
import hashlib
import io
import json
import tarfile

root = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
validation = Path('/tmp/darkbloom-allocator-footprint-policy-validation1')
evidence = root / 'docs/reports/evidence/allocator-policy-2026-09-05'
evidence.mkdir(parents=True, exist_ok=True)
digest = lambda data: hashlib.sha256(data).hexdigest()
source_manifest = json.loads((validation / 'manifest.json').read_text())
payloads = {}
for relative, item in source_manifest['files'].items():
    data = (validation / relative).read_bytes()
    assert digest(data) == item['sha256'] and len(data) == item['bytes']
    payloads['validation/' + relative] = data
for relative, path in {
    'validation/manifest.json': validation / 'manifest.json',
    'source/requested-manifest.json': Path('/tmp/darkbloom-allocator-footprint-policy/freeze1/manifest.json'),
    'source/root-review.json': Path('/tmp/darkbloom-allocator-footprint-policy/root-review.json'),
    'bank/commits.json': Path('/tmp/darkbloom-allocator-policy-final-commits.json'),
    'bank/package.py': Path(__file__),
}.items():
    payloads[relative] = path.read_bytes()
archive = evidence / 'payloads.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for name, data in sorted(payloads.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                tar.addfile(entry, io.BytesIO(data))
commits = json.loads(Path('/tmp/darkbloom-allocator-policy-final-commits.json').read_text())
manifest = {
    'schema': 1,
    'scope': 'Detached allocation policy over the accepted allocator foundation; CPU/Metal/Swift validation only.',
    'commits': commits,
    'validation': json.loads((validation / 'verdict.json').read_text()),
    'foundation_evidence': '../allocator-footprint-2026-09-05/manifest.json',
    'archive': {'path': archive.name, 'sha256': digest(archive.read_bytes()), 'bytes': archive.stat().st_size},
    'entries': [{'path': name, 'sha256': digest(data), 'bytes': len(data)} for name, data in sorted(payloads.items())],
}
manifest_path = evidence / 'manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
with tarfile.open(archive, 'r:gz') as tar:
    assert {entry.name for entry in tar.getmembers()} == set(payloads)
    for name, data in payloads.items():
        assert tar.extractfile(name).read() == data
manifest_hash = digest(manifest_path.read_bytes())
archive_hash = manifest['archive']['sha256']
report = root / 'docs/reports/2026-09-05-allocator-policy.md'
report.write_text(f'''# Detached allocator sizing policy

> Last updated: 2026-09-05 · commit `2dcec3574`

Allocator bounds can now be projected from an immutable policy value without
entering the allocator, allocating memory, waiting, throwing or invoking an
error callback. This supports conservative auxiliary-memory admission while
keeping logical tensor geometry separate from allocator backing.

`Memory.allocationFootprintPolicy()` exposes the backend's five sizing
parameters. Its checked `upperBound(byteCount:)` and `maximumExtraBytes`
projections return nil on invalid input or overflow. The existing throwing
prediction API uses the same arithmetic; actual allocation behavior is unchanged.

| Validation | Result |
|---|---|
| CPU allocator | Four cases pass: policy, bound, prediction and cache regression |
| Metal allocator | The same four cases pass |
| Swift wrapper | Six functions / six cases pass; build 46.43 seconds |
| Source identity | 12 changed files and 1,356 dependency inputs verified; no drift |

The new coverage comprises one C++ policy test and two Swift functions. The
policy test also exercises CUDA's sizing parameters as data; no CUDA backend
was compiled or executed. The existing Foundation import and completion-fenced
ownership fixtures were preserved. No test or production correction was needed.
The native source remains `a486a55d032deae001190bf9795ece1cb3d9a609`;
the [foundation's 404 native cases](2026-09-05-allocator-footprint.md) were
not rerun in this dependency-only gate.

Committed pins are Swift `{commits['commits']['swift']}`,
MLX `{commits['commits']['mlx']}`, and
mlx-c `{commits['commits']['mlx-c']}`. Provider accounting, full checkpoint
integration and all five fleet-model tests remain pending; this report makes
no latency, usable-capacity or rollout claim.

The [manifest](evidence/allocator-policy-2026-09-05/manifest.json)
(SHA-256 `{manifest_hash}`) records {len(payloads)} verified
payloads, including all 55 validation records, source archives, compiler graphs,
test logs and commit verification. The
[archive](evidence/allocator-policy-2026-09-05/payloads.tar.gz) has SHA-256
`{archive_hash}`. The accepted validation manifest is
`45fa645950258545f9b1942f1db585007e8b16607afdf5dc42f48949acd541a9`.
Build products and model weights are excluded. Current APIs are documented in
the [MLX stack](../architecture/components/mlx-swift.md#allocator-footprint-and-backing-ownership).
''')
index = root / 'docs/reports/README.md'
text = index.read_text().replace('commit `69a75de82`', 'commit `2dcec3574`', 1)
anchor = '- [Allocator footprint and native ownership]'
text = text.replace(anchor, '- [Detached allocator sizing policy](2026-09-05-allocator-policy.md) — pure per-buffer projection, CPU/Metal allocator checks and six Swift cases.\n' + anchor, 1)
index.write_text(text)
stack = root / 'docs/architecture/components/mlx-swift.md'
text = stack.read_text().replace('commit `69a75de82`', 'commit `2dcec3574`', 1)
for old, new in [('2814c8ad5c2858b74bd364977bc1a59844621af8', commits['commits']['swift']), ('c31408ca', commits['commits']['mlx'][:8]), ('1cff8fd', commits['commits']['mlx-c'][:7])]:
    text = text.replace(old, new)
anchor = 'Neither API grants ownership or prices an entire graph.\n'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '''
`Memory.allocationFootprintPolicy()` returns the backend's immutable sizing
parameters. The value's `upperBound(byteCount:)` and `maximumExtraBytes` perform
checked arithmetic without allocator access, locks, allocation or callbacks;
invalid or overflowing projections return nil. Admission can price independent
future buffers with this value. It does not inspect available cache entries or
reserve memory. The throwing prediction API uses the same arithmetic. See the
[policy validation](../../reports/2026-09-05-allocator-policy.md).
''')
stack.write_text(text)
changelog = root / 'CHANGELOG.md'
text = changelog.read_text()
anchor = '## Unreleased — paged attention foundation\n'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '\n- Add immutable allocator sizing projections for admission without allocation, locks or error callbacks.\n', 1)
changelog.write_text(text)
print(json.dumps({'manifest_sha256': manifest_hash, 'archive_sha256': archive_hash, 'payloads': len(payloads), 'archive_bytes': archive.stat().st_size}, indent=2))
