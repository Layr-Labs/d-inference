from pathlib import Path
import gzip,hashlib,json,re,shutil
out=Path(__file__).resolve().parent;info=json.loads((out/'integration.json').read_text());ws=Path(info['workspace']);scratch=Path(info['scratch'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
assert not (out/'manifest.json').exists()
results=json.loads((out/'execution.json').read_text());filters=json.loads((out/'filters.json').read_text());assert len(results)==len(filters)+2 and all(r['exit_code']==0 and r['nonzero_no_skips'] for r in results)
assert json.loads((out/'run-status.json').read_text())=={'failed':[],'all_filters_run':True}
identifiers=[line.strip() for line in (out/'identifiers.log').read_text().splitlines() if line.startswith('ProviderCoreTests.')]
selected={}
for name in filters:
 ids=[i for i in identifiers if i.startswith('ProviderCoreTests.'+name+'/')];body=(out/(name+'.log')).read_text()
 count=max([int(x) for x in re.findall(r'Test run with (\d+) tests?|Executed (\d+) tests?, with 0 failures',body) for x in x if x]+[0]);assert count==len(ids)>0,(name,count,len(ids))
 assert not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',body,re.M)
 selected[name]={'identifiers':ids,'test_functions':count,'log_sha256':sha(out/(name+'.log'))}
assert sum(s['test_functions'] for s in selected.values())==1
write('selected-identifiers.json',selected)
known={};counts={}
for name,root,group in [('provider-source-manifest.json',ws,'provider'),('native-source-manifest.json',ws/'libs/mlx-swift-lm','native')]:
 files=json.loads((out/name).read_text())['files'];counts[group]=len(files)
 for p,digest in files.items():
  path=root/p;assert sha(path)==digest,p;known[str(path.resolve())]={'group':group,'sha256':digest}
deps=json.loads((out/'dependency-source-manifest.json').read_text());counts['dependency']=len(deps['files'])
for key,digest in deps['files'].items():
 alias,p=key.split('/',1);path=Path(deps['repositories'][alias])/p;assert sha(path)==digest,key;known[str(path.resolve())]={'group':'dependency','sha256':digest}
jinja=json.loads((out/'jinja-source-manifest.json').read_text());counts['jinja']=len(jinja['files'])
for p,digest in jinja['files'].items():
 path=scratch/'checkouts/swift-jinja'/p;assert sha(path)==digest,p;known[str(path.resolve())]={'group':'jinja','sha256':digest}
body=gzip.decompress((out/'actual-build-debug.yaml.gz').read_bytes()).decode();matched={};unknown=[]
roots=[str((ws/'provider-swift').resolve()),str((ws/'libs/mlx-swift-lm').resolve())]
for literal in sorted(set(re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',body))):
 p=Path(literal);key=str(p.resolve());row=known.get(key)
 if row:
  assert sha(p)==row['sha256'],literal;matched[literal]={'resolved_source':key,**row}
 elif any(key.startswith(root+'/') for root in roots):unknown.append(literal)
assert not unknown,unknown
assert '/checkouts/mlx-swift/Source/' not in body
write('all-owned-graph-source-proof.json',{'scope':'Declared SwiftPM build graph source references matched against frozen input hashes. This does not claim every graph entry links into the selected test product. Selected test executions and binary identity are recorded separately.','counts':{g:sum(r['group']==g for r in matched.values()) for g in counts},'files':matched,'unmapped_owned_source_paths':unknown,'remote_mlx_source_excluded':True,'dependency_identity':'SwiftPM reports local aliases with the same mlx-swift identity; all matched MLX source paths resolve to the same frozen pinned local dependency. An unused remote checkout is not compile identity evidence.'})
parent=json.loads((out/'provider-source-manifest.json').read_text())['candidate_changes']
for p,row in parent.items():
 source=ws/p;assert sha(source)==row['after_sha256'],p;target=out/'owned'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
native=Path(info['native_validation']);assert sha(native/'manifest.json')=='b072176bfa8d23fcd7e9a6223b51de67341a5eb2a5b64f6ad8e24141bc5f5abc'
for p,row in json.loads((native/'manifest.json').read_text())['files'].items():assert sha(native/p)==row['sha256'],p
shutil.copy2(native/'manifest.json',out/'native-validation-manifest.json')
write('verdict.json',{'status':'PASS_ACTUAL_QWEN_PRODUCTION_OWNER_REGRESSION','test_functions':1,'failed':0,'skipped':0,'inputs':counts,'source_scope':'Primary c9bd/native 847 + exact reviewed owner-identity source1; only one provider regression added.','build_seconds':results[0]['seconds'],'source_corrections_during_validation':False,'real_models_run':False,'actual_model_family_fixture':'Tiny Qwen35MoEModel: real production backend/adapter and 40 layers; ten original contiguous owner indices preserved and ten dense metadata indices recorded.','other_unintegrated_candidates_included':False,'limitations':'This is a tiny actual-family regression, not target artifact numerical parity or performance evidence.','next':'Root review and integration; separately reviewed diagnostic probe source union before optimized build.'})
files={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.relative_to(out).parts[0] not in ['workspace','radix-engine'] and p.name!='manifest.json'}
write('manifest.json',{'schema':1,'status':'PASS_ACTUAL_QWEN_PRODUCTION_OWNER_REGRESSION','files':files,'test_binary':json.loads((out/'test-binary.json').read_text())})
for p,row in files.items():assert sha(out/p)==row['sha256']
print(json.dumps({'manifest':str(out/'manifest.json'),'sha256':sha(out/'manifest.json'),'payloads':len(files),'verdict':json.loads((out/'verdict.json').read_text())},indent=2))
