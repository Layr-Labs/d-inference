from pathlib import Path
import hashlib,json,shutil

out=Path('/tmp/darkbloom-receipt-diagnostic-provider-validation1')
base=Path('/tmp/darkbloom-final-serving-build7')
native=Path('/tmp/darkbloom-q36-logit-diagnostic-validation3')
receipt=Path('/tmp/darkbloom-prefix-receipt-pump-ownership2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
expected={base:'34d04469c5edb39dbd8fbefcd0d5ea20093b5d44a01d70f05b3343103ae7ae6b',native:'5b2e3d6136498a5964f725ccebefcc42d7eb7d8d349164a26bdf7a27bb735ffd',receipt:'771c8d366fe67e7ff67b9b57e2af0c0c6a4479f7767e6e2283d0f3eec4ff6758'}
for root,digest in expected.items():
 assert sha(root/'manifest.json')==digest
 for name,row in json.loads((root/'manifest.json').read_text())['files'].items():assert sha(root/name)==row['sha256'],name
source_changes=json.loads((receipt/'source-change.json').read_text())['paths']
for variant in ['baseline','candidate']:
 ws=out/variant/'workspace';ws.mkdir(parents=True)
 shutil.copytree(base/'workspace/provider-swift',ws/'provider-swift')
 (ws/'libs').mkdir()
 (ws/'libs/mlx-swift').symlink_to((base/'workspace/libs/mlx-swift').resolve(),target_is_directory=True)
 (ws/'libs/mlx-swift-lm').symlink_to(native/'native',target_is_directory=True)
 manifest=json.loads((base/'provider-source-manifest.json').read_text())
 for row in source_changes:
  name=row['path'];assert sha(ws/name)==row['before_sha256'],(variant,name)
  if variant=='candidate' or '/Tests/' in name:
   shutil.copy2(receipt/'after'/name,ws/name);manifest['files'][name]=row['after_sha256']
 for name,digest in manifest['files'].items():assert sha(ws/name)==digest,(variant,name)
 write(variant+'/provider-source-manifest.json',manifest)
for name in ['native-source-manifest.json','ancillary-package-manifest.json','dependency-source-manifest.json']:
 shutil.copy2(native/name,out/name)
shutil.copy2(base/'jinja-source-manifest.json',out/'jinja-source-manifest.json')
write('integration.json',{'baseline_build7_manifest':str(base/'manifest.json'),'baseline_build7_sha256':sha(base/'manifest.json'),'native_unit_manifest':str(native/'manifest.json'),'native_unit_sha256':sha(native/'manifest.json'),'receipt_manifest':str(receipt/'manifest.json'),'receipt_sha256':sha(receipt/'manifest.json'),'native_source':str(native/'native'),'scratch':'/tmp/darkbloom-process-memory-telemetry-swift-validation1/build','scope':'Baseline new tests + original Submission.swift, then reviewed candidate. Diagnostic native present but disabled by default in both. No real models.'})
print('Prepared immutable baseline and candidate provider workspaces; same frozen native/deps.')
