from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,io,difflib
OUT=Path('/tmp/darkbloom-attention-operator-replay-release-build1');OUT.mkdir()
REPO=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated');PARENT='0b91fa8d4ed56f03c60ed5f155183bc457d6952b';NATIVE='7d32d43977a5774f223b6892ecfbbaa844047600'
PRIOR=Path('/tmp/darkbloom-attention-operator-replay-swift-validation1');RESOURCES=Path('/tmp/darkbloom-generic-qat-release-probe1/runtime-resource-inputs.json')
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as s:
  for b in iter(lambda:s.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def files(root):return {str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file()}
def archive(repo,rev,target,paths=[]):
 target.mkdir(parents=True);raw=subprocess.check_output(['git','archive',rev]+paths,cwd=repo)
 with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(target,filter='data')
assert subprocess.check_output(['git','rev-parse',PARENT+':libs/mlx-swift-lm'],cwd=REPO,text=True).strip()==NATIVE
ws=OUT/'workspace';archive(REPO,PARENT,ws,['scripts/benchmarks/attention-replay'])
archive(REPO/'libs/mlx-swift-lm',NATIVE,ws/'libs/mlx-swift-lm')
harness=ws/'scripts/benchmarks/attention-replay';native=ws/'libs/mlx-swift-lm'
canonical_native=files(native);canonical_harness=files(harness)
mlx=Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift');(ws/'libs/mlx-swift').symlink_to(mlx,target_is_directory=True)
p=native/'Package.swift';before=p.read_text();old='.package(url: "https://github.com/Layr-Labs/mlx-swift.git", branch: "main")';assert before.count(old)==1;after=before.replace(old,'.package(path: "'+str(mlx)+'")');p.write_text(after)
(OUT/'native-package-location-overlay.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='canonical/Package.swift',tofile='prepared/Package.swift')))
for target in [native/'Package.resolved',harness/'Package.resolved']:shutil.copy2(PRIOR/'workspace/libs/mlx-swift-lm/Package.resolved',target)
for name in ['dependency-source-manifest.json','jinja-source-manifest.json']:shutil.copy2(PRIOR/name,OUT/name)
shutil.copy2(RESOURCES,OUT/'runtime-resource-inputs.json')
write('native-source-manifest.json',{'canonical_commit':NATIVE,'canonical_files':canonical_native,'files':files(native)})
write('harness-source-manifest.json',{'canonical_commit':PARENT,'canonical_files':canonical_harness,'files':files(harness)})
rows=json.loads(Path('/tmp/darkbloom-attention-operator-replay-source2/source-map.json').read_text())
for row in rows:
 if row['scope']=='native':actual=native/row['path']
 elif row['path'].startswith('scripts/benchmarks/attention-replay/'):actual=ws/row['path']
 else:continue
 assert sha(actual)==row['sha256'],row['path']
write('reviewed-source-correspondence.json',rows)
write('integration.json',{'status':'PREPARED_SOURCE_ONLY; wait for http agent explicit Swift handoff','parent_commit':PARENT,'native_commit':NATIVE,'workspace':str(ws.resolve()),'native':str(native.resolve()),'harness':str(harness.resolve()),'scratch':'/tmp/darkbloom-final-serving-build1/build','environment':{'ATTENTION_REPLAY_SOURCE_ROOT':str(ws.resolve())},'product':'attention-replay','resources':6,'resource_origin':'/tmp/darkbloom-final-serving-build8/artifact','policy':'Root authorized optimized build plus host parse/refusal smokes after current probe explicitly yields; no model/key/numerical replay/M5 operations','validated_native':'dcf39f6 plus byte-identical two SPI files, eight funcs29 cases; not relabeled after rebase'})
write('package-resolution-inputs.json',{str(p.relative_to(OUT)):sha(p) for p in [native/'Package.resolved',harness/'Package.resolved']})
shutil.copy2(Path(__file__),OUT/'prepare.py')
print(json.dumps({'out':str(OUT),'native_files':len(files(native)),'harness_files':len(files(harness))},indent=2))
