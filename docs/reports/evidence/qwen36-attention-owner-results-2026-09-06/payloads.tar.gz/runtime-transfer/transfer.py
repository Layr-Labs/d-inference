from pathlib import Path
import argparse
import hashlib
import json
import shutil
import subprocess

OUT = Path('/tmp/darkbloom-q36-attention-owner-identity-runtime-transfer1')
ROOT = '/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-owner-identity1'
BUILD8 = '/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact'
HOST = 'gaj@100.124.35.99'
OPTIONS = ['-i', '/Users/gaj/.ssh/darkbloom_testbox', '-o', 'IdentitiesOnly=yes',
           '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15']


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def remote(name, code):
    result = subprocess.run(['ssh'] + OPTIONS + [HOST, 'python3 -B -'],
                            input=code, text=True, capture_output=True)
    (OUT / (name + '.stdout')).write_text(result.stdout)
    (OUT / (name + '.stderr')).write_text(result.stderr)
    assert result.returncode == 0, name + ': ' + result.stderr
    return json.loads(result.stdout)


def send(name, source, target):
    result = subprocess.run(['scp'] + OPTIONS + [str(source), HOST + ':' + target],
                            text=True, capture_output=True)
    (OUT / (name + '.stdout')).write_text(result.stdout)
    (OUT / (name + '.stderr')).write_text(result.stderr)
    assert result.returncode == 0, result.stderr


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--binding-sha256', required=True)
    args = parser.parse_args()
    assert not (OUT / 'binding.json').exists(), 'Preserve previous transfer attempts'
    assert sha(args.binding) == args.binding_sha256
    binding = json.loads(args.binding.read_text())
    assert binding['state'] == 'runtime_bound_execution_review_pending'  # Frozen binding; root subsequently approved execution.
    assert binding['remote_root'] == ROOT and binding['remote_artifact_root'] == ROOT + '/runtime'
    assert binding['plan_manifest_sha256'] == 'ab6907c6e6d2efed1fbe56f0b0168964713fa95022d1783ca3b8aa00f2a29a48'
    review = Path(binding['review'])
    assert sha(review) == binding['review_sha256']
    files = {name: {**row, 'mode': int(row['mode'], 8)} for name, row in binding['artifacts'].items()}
    assert len(files) == 7 and files['radix-engine']['mode'] == 0o755
    probe = Path(binding['local_artifact_root']) / 'radix-engine'
    for name, row in files.items():
        path = Path(binding['local_artifact_root']) / name
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
        assert path.stat().st_mode & 0o777 == row['mode']
    build8 = Path('/tmp/darkbloom-final-serving-build8/artifact-manifest.json')
    assert sha(build8) == '1dd03934e5d5cf9a960c68484100aa4ad02b7f742cfe4996a10abbfd3d664541'
    resources = {name: row for name, row in json.loads(build8.read_text())['files'].items()
                 if name not in ['darkbloom', 'radix-engine']}
    assert set(files) - {'radix-engine'} == set(resources)
    for name, row in resources.items():
        assert row['sha256'] == files[name]['sha256'] and row['bytes'] == files[name]['bytes']
    shutil.copy2(args.binding, OUT / 'binding.json')
    shutil.copy2(review, OUT / 'root-review.json')
    inventory_path = Path('/tmp/darkbloom-q36-attention-owner-identity-staging1/file-inventory.json')
    inventory = json.loads(inventory_path.read_text())
    code = '''from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
root=Path(ROOT);runtime=root/'runtime';expected=FILES;inventory=INVENTORY
assert not runtime.exists()
for name,item in inventory.items():
 p=root/name;assert p.stat().st_size==item['bytes'] and p.stat().st_mode&0o777==item['mode']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
assert json.loads((root/'plan.json').read_text())['runtime_binding'] is None
processes=[]
for row in subprocess.check_output(['ps','-axo','pid=,ppid=,pgid=,args='],text=True).splitlines():
 bits=row.strip().split(None,3)
 if len(bits)!=4:continue
 markers=('Runner.Worker','benchctl measure-job','measure-job.sh','radix-engine','run_radix_engine.py','connected-e2e.test','run_connected_fixture.py')
 role=next((m for m in markers if m in bits[3]),None)
 if role is None and Path(bits[3].split()[0]).name=='darkbloom':role='darkbloom'
 if role:processes.append({'pid':int(bits[0]),'ppid':int(bits[1]),'pgid':int(bits[2]),'role':role})
temp=json.loads(subprocess.check_output(['/Users/gaj/bench-runner/bin/macmon','pipe','-s','1','-i','200'],text=True,timeout=10).splitlines()[0])['temp']['gpu_temp_avg']
state={'unix_time':time.time(),'utc_date':datetime.datetime.now(datetime.timezone.utc).date().isoformat(),'processes':processes,'gpu_temp_c':temp,'load':os.getloadavg(),'free_bytes':shutil.disk_usage(root).free}
print(json.dumps(state,indent=2))
assert not processes and state['utc_date']=='2026-09-06'
assert temp<=42 and state['load'][0]<=4 and state['free_bytes']>100*1024**3
for name,item in expected.items():
 if name=='radix-engine':continue
 p=Path(BUILD8)/name;assert p.stat().st_size==item['bytes']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
runtime.mkdir()
for name,item in expected.items():
 if name=='radix-engine':continue
 target=runtime/name;target.parent.mkdir(parents=True,exist_ok=True)
 shutil.copy2(Path(BUILD8)/name,target);target.chmod(item['mode'])
'''.replace('ROOT', repr(ROOT)).replace('BUILD8', repr(BUILD8)).replace('FILES', repr(files)).replace('INVENTORY', repr(inventory))
    preflight = remote('preflight-and-resources', code)
    send('scp-probe', probe, ROOT + '/runtime/radix-engine')
    send('scp-binding', OUT / 'binding.json', ROOT + '/runtime-binding.json')
    send('scp-review', OUT / 'root-review.json', ROOT + '/runtime-root-review.json')
    code = '''from pathlib import Path
import hashlib,json
root=Path(ROOT);runtime=root/'runtime';files=FILES
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()==BINDING_SHA
assert hashlib.sha256((root/'runtime-root-review.json').read_bytes()).hexdigest()==REVIEW_SHA
actual={str(p.relative_to(runtime)) for p in runtime.rglob('*') if p.is_file()}
assert actual==set(files)
for name,item in files.items():
 p=runtime/name;assert p.stat().st_size==item['bytes'] and p.stat().st_mode&0o777==item['mode']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
print(json.dumps({'runtime_files_verified':len(files),'bytes_hashes_modes_match':True,'model_invoked':False},indent=2))
'''.replace('ROOT', repr(ROOT)).replace('FILES', repr(files)).replace('BINDING_SHA', repr(sha(OUT / 'binding.json'))).replace('REVIEW_SHA', repr(binding['review_sha256']))
    verified = remote('verify', code)
    (OUT / 'receipt.json').write_text(json.dumps({'preflight':preflight,'verification':verified,'binding_sha256':sha(OUT/'binding.json')},indent=2)+'\n')
    entries = {str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.iterdir()) if p.is_file()}
    (OUT / 'manifest.json').write_text(json.dumps({'status':'runtime transferred and verified; no model invocation','files':entries},indent=2,sort_keys=True)+'\n')
    print(json.dumps({'receipt':str(OUT/'receipt.json'),'manifest_sha256':sha(OUT/'manifest.json'),**verified},indent=2))


if __name__ == '__main__':
    main()
