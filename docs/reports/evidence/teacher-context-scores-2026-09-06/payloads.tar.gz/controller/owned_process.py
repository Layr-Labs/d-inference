"""Own the one Go test process group; retain a receipt through interruption."""
import types
import os
import signal
import subprocess
import time
from pathlib import Path
from common import HOST, write_json


def helper_module():
    module = types.ModuleType('banked_provider_host')
    exec(compile(HOST.read_text(), str(HOST), 'exec'), module.__dict__)
    return module


def run_owned(argv, environment, output, timeout=1500, graceful_seconds=45):
    output = Path(output)
    process = None
    signals = (signal.SIGHUP, signal.SIGTERM, signal.SIGINT)
    previous = {sig: signal.getsignal(sig) for sig in signals}
    record = {'pid': None, 'exit_code': None, 'failure': None, 'argv': argv, 'started_unix': time.time()}
    def interrupted(signum, _frame):
        for sig in signals:
            signal.signal(sig, signal.SIG_IGN)
        raise InterruptedError('controller signal ' + str(signum))
    for sig in signals:
        signal.signal(sig, interrupted)
    try:
        with (output / 'go.stdout').open('xb') as stdout, (output / 'go.stderr').open('xb') as stderr:
            mask = signal.pthread_sigmask(signal.SIG_BLOCK, signals)
            try:
                process = subprocess.Popen(argv, env=environment, stdout=stdout, stderr=stderr,
                    start_new_session=True, preexec_fn=lambda: signal.pthread_sigmask(signal.SIG_SETMASK, mask))
            finally:
                signal.pthread_sigmask(signal.SIG_SETMASK, mask)
            record['pid'] = process.pid
            write_json(output / 'live.json', {'pid': process.pid, 'pgid': process.pid, 'argv': argv})
            record['exit_code'] = process.wait(timeout=timeout)
    except Exception as error:
        record['failure'] = type(error).__name__ + ': ' + str(error)
    finally:
        for sig in signals:
            signal.signal(sig, signal.SIG_IGN)
        try:
            if process is not None:
                try:
                    if process.poll() is None:
                        # First let Go cancel its context and collect owned-host
                        # receipts before retiring any remaining group members.
                        process.send_signal(signal.SIGTERM)
                        try:
                            process.wait(timeout=graceful_seconds)
                        except subprocess.TimeoutExpired:
                            pass
                    helper_module().retire_group(process, record)
                except Exception as error:
                    record['group_cleanup_complete'] = False
                    record['failure'] = (record['failure'] or '') + ' cleanup ' + str(error)
            record['ended_unix'] = time.time()
            write_json(output / 'process.json', record)
        finally:
            for sig, handler in previous.items():
                signal.signal(sig, handler)
    return record
