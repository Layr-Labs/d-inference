from pathlib import Path
import json,hashlib,shutil,subprocess
out=Path('/tmp/darkbloom-q36-actual-logits-four-cell-freeze1');out.mkdir(exist_ok=False);source=Path('/tmp/darkbloom-q36-actual-logits-plan3/package');plan=json.loads((source/'plan.json').read_text());raw=Path('/tmp/darkbloom-q36-actual-logits-execution1')
def add(src,rel):
 p=out/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,p)
def tree(src,rel):
 src=Path(src)
 for p in sorted(src.rglob('*')):
  if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:add(p,Path(rel)/p.relative_to(src))
for c in plan['cells']:tree(raw/c['id'],'raw/'+c['id'])
tree(source,'approved-package');tree('/tmp/darkbloom-q36-actual-logits-postcheck1','postcheck');tree('/tmp/darkbloom-q36-actual-logits-staging1','package-staging')
for p in Path('/tmp/darkbloom-build8-m5-transfer1').iterdir():
 if p.is_file() and not p.name.endswith('.gz'):add(p,'runtime-staging/'+p.name)
for src,dst in [('/tmp/darkbloom-q36-actual-logits-plan-root-review.json','reviews/plan-root-review.json'),('/tmp/darkbloom-build8-root-review.json','reviews/build8-root-review.json'),('/tmp/run-q36-actual-logits1.py','driver.py'),('/tmp/postcheck-q36-actual-logits1.py','postcheck-driver.py'),('/tmp/freeze-q36-actual-logits1.py','freeze-driver.py')]:add(src,dst)
reports={c['id']:json.loads((raw/c['id']/'report.json').read_text()) for c in plan['cells']};summary={'scope':'Actual Q36 MTP-off/cache-off four-cell diagnostic; no normal-MTP, cache/performance or release acceptance. Raw records retained; root independently interprets Float32 bits/contexts.','trajectory_comparisons':[],'diagnostics':{}}
def compare(a,b,label):
 results=[]
 for x,y in zip(a['rows'],b['rows']):
  assert x['id']==y['id'];u=x['token_ids'];v=y['token_ids'];n=0
  while n<min(len(u),len(v)) and u[n]==v[n]:n+=1
  results.append({'id':x['id'],'prompt_ids_equal':x['prompt_token_ids']==y['prompt_token_ids'],'full_emitted_ids_equal':u==v,'baseline_tokens':len(u),'candidate_tokens':len(v),'common_prefix_tokens':n,'first_difference_zero_based':None if u==v else n,'baseline_ids':u,'candidate_ids':v})
 summary['trajectory_comparisons'].append({'label':label,'rows':results})
for backend in ('contiguous','paged'):
 ids=[c['id'] for c in plan['cells'] if c['backend']==backend];compare(reports[ids[0]],reports[ids[1]],backend+' same-build trace impact');historical=json.loads((source/plan['historical_controls'][backend]['report']).read_text())
 for id in ids:compare(historical,reports[id],id+' versus historical build6')
 summary['diagnostics'][backend]=reports[ids[1]].get('logit_diagnostic')
ids=[c['id'] for c in plan['cells'] if not c['trace']];compare(reports[ids[0]],reports[ids[1]],'same-build uninstrumented backend comparison')
cmd=['python3','-B',str(source/'runner/compare_radix_engine.py'),str(raw/ids[0]/'report.json'),str(raw/ids[1]/'report.json'),'--axis','backend'];r=subprocess.run(cmd,text=True,capture_output=True);(out/'backend-comparison.json').write_text(r.stdout);(out/'backend-comparison.stderr').write_text(r.stderr);(out/'backend-comparison-command.json').write_text(json.dumps({'argv':cmd,'exit_code':r.returncode},indent=2)+'\n');summary['strict_backend_verdict']=json.loads(r.stdout)
(out/'analysis.json').write_text(json.dumps(summary,indent=2)+'\n');files={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()};(out/'manifest.json').write_text(json.dumps({'scope':summary['scope'],'files':files},indent=2)+'\n');print(json.dumps({'root':str(out),'manifest_sha256':hashlib.sha256((out/'manifest.json').read_bytes()).hexdigest(),'payloads':len(files),'bytes':sum(x['bytes'] for x in files.values()),'backend_passed':summary['strict_backend_verdict']['passed'],'comparisons':[{'label':c['label'],'equal':all(x['full_emitted_ids_equal'] and x['prompt_ids_equal'] for x in c['rows'])} for c in summary['trajectory_comparisons']]},indent=2))
