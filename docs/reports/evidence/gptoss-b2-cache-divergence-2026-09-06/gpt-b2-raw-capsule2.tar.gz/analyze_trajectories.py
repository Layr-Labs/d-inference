"""Analyze retained bytes only; emission timing is not a per-forward trace."""
from pathlib import Path
import argparse,csv,hashlib,json
ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--evidence',type=Path,default=Path('/tmp/darkbloom-forward-width-gpt-b2-pilot1/pilot-evidence'))
parser.add_argument('--output',type=Path,default=ROOT)
args=parser.parse_args();EVIDENCE=args.evidence;OUTPUT=args.output;OUTPUT.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((EVIDENCE/'pilot-evidence-manifest.json').read_text())
assert sha(EVIDENCE/'pilot-evidence-manifest.json')=='a8b0d59e86c721b45d83b00ad02581b0ffa7b068f1400c9602204059cd5a4807'
binding=json.loads((EVIDENCE/'m5.runtime-binding2.json').read_text());rows=[];groups={};cohorts=[];emissions=[]
def vector_sha(values):return hashlib.sha256(json.dumps(values,separators=(',',':')).encode()).hexdigest()
for cell in binding['reviewed_cell_ids']:
 path=EVIDENCE/'results'/cell/'report.json';assert sha(path)==manifest['files'][str(path.relative_to(EVIDENCE))]['sha256'];report=json.loads(path.read_text());mapped={}
 for row in report['rows']:
  tokens=row['token_ids'];prompt=row['prompt_token_ids'];assert len(tokens)==128 and row['finish']=='length' and len(prompt)==5472
  digest=vector_sha(tokens);cluster=groups.setdefault(digest,{'label':chr(ord('A')+len(groups)),'tokens':tokens,'members':[]});assert cluster['tokens']==tokens
  name=cell+'/'+row['id'];cluster['members'].append(name);flat=[];per_token=[]
  for chunk_index,chunk in enumerate(row['chunks']):
   for within,token in enumerate(chunk['tokens']):
    index=len(flat);flat.append(token);item={'cell':cell,'row':row['id'],'cohort':row['batch_id'],'batch_index':row['batch_index'],'token_index':index,'token_id':token,'chunk_index':chunk_index,'within_chunk':within,'row_elapsed_s':chunk['elapsed_s'],'batch_elapsed_s':row['batch_start_offset_s']+chunk['elapsed_s']};emissions.append(item);per_token.append(item)
  assert flat==tokens
  value={'name':name,'cell':cell,'row':row['id'],'cohort':row['batch_id'],'batch_index':row['batch_index'],'cluster':cluster['label'],'token_ids_sha256':digest,'prompt_ids_sha256':vector_sha(prompt),'token_count':len(tokens),'finish':row['finish'],'saved_tokens':row['saved_tokens'],'cache_outcome':row['cache_outcome'],'batch_start_offset_s':row['batch_start_offset_s'],'first_emission_batch_s':per_token[0]['batch_elapsed_s'],'index3_emission_batch_s':per_token[3]['batch_elapsed_s'],'index3_token':tokens[3],'emissions':per_token};rows.append(value);mapped[row['id']]=value
 for batch in report['batches']:
  a,b=[mapped[batch['id']+'-b'+str(i)] for i in range(2)];counts={}
  for item in batch['forward_shapes']['delta']['entries']:
   axis=item['axes']
   if axis['kind']=='target' and axis['phase']=='decode':counts[str(axis['live_batch_rows'])]=counts.get(str(axis['live_batch_rows']),0)+item['completed_calls']
  cohort={'cell':cell,'cohort':batch['id'],'b0_cluster':a['cluster'],'b1_cluster':b['cluster'],'full_128_token_outputs_equal':a['token_ids_sha256']==b['token_ids_sha256'],'b0_index3_batch_s':a['index3_emission_batch_s'],'b1_first_token_batch_s':b['first_emission_batch_s'],'b0_index3_emitted_before_b1_first_token':a['index3_emission_batch_s']<b['first_emission_batch_s'],'b0_tokens_emitted_before_b1_first':sum(e['batch_elapsed_s']<b['first_emission_batch_s'] for e in a['emissions']),'completed_decode_target_calls_by_width':counts,'selection_forward_geometry_at_index3':'UNOBSERVED: only aggregate forward deltas and chunk emission times exist','capacity_samples':batch['capacity_samples']};cohorts.append(cohort)
assert len(rows)==12 and len(groups)==2 and len({x['prompt_ids_sha256'] for x in rows})==1
ordered=list(groups.values());a,b=ordered[0]['tokens'],ordered[1]['tokens'];different=[i for i,(x,y) in enumerate(zip(a,b)) if x!=y]
equalities=[{'left':x['name'],'right':y['name'],'all_128_tokens_equal':x['token_ids_sha256']==y['token_ids_sha256']} for index,x in enumerate(rows) for y in rows[index+1:]]
result={'source_evidence_manifest_sha256':sha(EVIDENCE/'pilot-evidence-manifest.json'),'row_count':12,'all_prompts_identical_5472_ids':True,'all_outputs_128_ids_length_finish':True,'clusters':[dict(v,token_ids_sha256=k) for k,v in groups.items()],'first_cluster_difference':{'index':different[0],'A':a[different[0]],'B':b[different[0]],'differing_positions':len(different)},'rows':[{k:v for k,v in row.items() if k!='emissions'} for row in rows],'cross_row_equality_matrix':equalities,'cohorts':cohorts,'cache_gate':'FAILED_UNCHANGED','restore_byte_correctness':'UNPROVEN','causal_kernel':'UNOBSERVED','interpretation':'Cache-off already has two complete trajectories. Chunk-emission order correlates with the cluster change, but cannot identify the selection forward or prove internal KV equality.'}
(OUTPUT/'trajectory-analysis.json').write_text(json.dumps(result,indent=2)+'\n')
with (OUTPUT/'token-emissions.csv').open('w') as f:
 writer=csv.DictWriter(f,fieldnames=list(emissions[0]));writer.writeheader();writer.writerows(emissions)
print(json.dumps({'clusters':[{k:v for k,v in g.items() if k!='tokens'} for g in result['clusters']],'difference':result['first_cluster_difference'],'cohorts':[{k:v for k,v in c.items() if k!='capacity_samples'} for c in cohorts]},indent=2))
