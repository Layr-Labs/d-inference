from pathlib import Path
import hashlib, json, shutil, subprocess

out = Path(__file__).resolve().parent
candidate = Path('/Users/gaj/Documents/DarkbloomDev/wt/q36-attention-packet-090')
primary = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
native_base = 'e972340a7ba6e22fda5d8be1a7af918f9bf67b03'
parent_base = '384c321aa7565864182c02210fc4d212efc6501b'
parent_files = [
    'scripts/benchmarks/radix-engine/Sources/radix-engine/BenchmarkAttentionPacket.swift',
    'scripts/benchmarks/radix-engine/Sources/radix-engine/BenchmarkOptions.swift',
    'scripts/benchmarks/radix-engine/Sources/radix-engine/RadixBenchmark.swift',
    'scripts/benchmarks/radix-engine/Tests/RadixEngineBenchmarkTests/BenchmarkAttentionPacketExportTests.swift',
    'scripts/benchmarks/radix-engine/Tests/RadixEngineBenchmarkTests/BenchmarkAttentionPacketOptionsTests.swift',
    'scripts/benchmarks/run_radix_engine.py', 'scripts/benchmarks/test_run_radix_engine.py',
]
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value):
    (out/name).write_text(json.dumps(value, indent=2)+'\n')

def execute(name, command, cwd):
    result = subprocess.run(command, cwd=cwd, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    (out/name).write_text(result.stdout)
    assert result.returncode == 0, (name, result.stdout)
    return {'command': command, 'cwd': str(cwd), 'exit_code': result.returncode, 'log': name}

assert not (out/'manifest.json').exists()
native = candidate/'libs/mlx-swift-lm'
native_files = subprocess.check_output(['git', 'diff', '--name-only', native_base], cwd=native, text=True).splitlines()
assert len(native_files) == 15
proof = {}
checks = []
for label, repo, target, base, names in [
    ('native', native, primary/'libs/mlx-swift-lm', native_base, native_files),
    ('parent', candidate, primary, parent_base, parent_files),
]:
    patch = subprocess.check_output(['git', 'diff', '--binary', base, '--', *names], cwd=repo)
    (out/(label+'.patch')).write_bytes(patch)
    checks.append(execute(label+'-diff-check.log', ['git', 'diff', '--check', base, '--', *names], repo))
    checks.append(execute(label+'-apply-check.log', ['git', 'apply', '--check', str(out/(label+'.patch'))], target))
    rows = {}
    for name in names:
        path = repo/name
        previous = subprocess.run(['git', 'show', base+':'+name], cwd=repo, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        before = hashlib.sha256(previous.stdout).hexdigest() if previous.returncode == 0 else None
        live = sha(target/name) if (target/name).is_file() else None
        assert live == before, name
        destination = out/'sources'/label/name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, destination)
        rows[name] = {'before_sha256': before, 'after_sha256': sha(path), 'bytes': path.stat().st_size}
    proof[label] = {'base_commit': base, 'files': rows}
write('source-proof.json', proof)
checks.append(execute('wrapper-tests.log', ['python3', '-B', '-m', 'unittest', '-v', 'test_run_radix_engine'], candidate/'scripts/benchmarks'))
write('checks.json', checks)
design = Path('/tmp/darkbloom-q36-actual-attention-diagnostic-design2/PROPOSAL.md')
shutil.copy2(design, out/'approved-design.md')
analyzer = Path('/tmp/darkbloom-attention-packet-analyzer-source2')
assert sha(analyzer/'manifest.json') == '53d4fd44743bdf291bcf64b80e42f7e730249854558668f8639e3be8b6d911c0'
shutil.copy2(analyzer/'manifest.json', out/'analyzer-source2-manifest.json')
format_path = primary/'scripts/benchmarks/attention_packet/FORMAT.md'
shutil.copy2(format_path, out/'packet-format.md')
deps_file = Path('/tmp/darkbloom-q36-attention-owner-identity-native-validation1/dependency-source-manifest.json')
deps = json.loads(deps_file.read_text())
dependency_keys = [
    'mlx-swift/Source/MLX/MLXArray+Bytes.swift', 'mlx-c/mlx/c/array.cpp',
    'mlx-c/mlx/c/array.h', 'mlx/mlx/array.cpp', 'mlx/mlx/transforms.cpp',
]
dependency_proof = {}
for key in dependency_keys:
    alias, name = key.split('/', 1)
    path = Path(deps['repositories'][alias])/name
    assert sha(path) == deps['files'][key], key
    copied = out/'pinned-availability-api'/key
    copied.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(path, copied)
    dependency_proof[key] = {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}
write('pinned-availability-api.json', {
    'source_manifest': str(deps_file), 'source_manifest_sha256': sha(deps_file), 'files': dependency_proof,
    'scope': 'The pinned Cmlx availability query is nonblocking. asData(.copy) calls eval; the new guard refuses if any original handle is not already available. async_eval signals one completion event per touched stream after the scheduled tape.',
})
write('verdict.json', {
    'status': 'SOURCE_FROZEN_FOR_REVIEW_NOT_SWIFT_VALIDATED',
    'native_changed_files': 15, 'parent_changed_files': 7, 'wrapper_tests_passed': 14,
    'swift_tests_run': False, 'real_models_run': False, 'primary_mutated': False,
    'scope': 'Bounded one-owner native raw attention capture; default nil, no new model forward, unchanged attention math. Same-input native replay and independent history mirror are not implemented by this source milestone.',
})
files = {str(p.relative_to(out)): {'sha256': sha(p), 'bytes': p.stat().st_size}
         for p in sorted(out.rglob('*')) if p.is_file() and p.name != 'manifest.json'}
write('manifest.json', {'status': 'SOURCE_FROZEN_FOR_REVIEW_NOT_SWIFT_VALIDATED', 'files': files})
for name, row in files.items(): assert sha(out/name) == row['sha256'], name
print(json.dumps({'manifest': str(out/'manifest.json'), 'sha256': sha(out/'manifest.json'), 'payloads': len(files)}, indent=2))
