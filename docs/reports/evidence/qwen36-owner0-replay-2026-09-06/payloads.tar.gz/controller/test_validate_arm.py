"""CPU faults for bounded transport checks, without a model or device job."""
import copy
import json
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

PLAN = Path('/tmp/darkbloom-q36-owner0-replay-plan1')
sys.path.insert(0, str(PLAN / 'runner'))
from attention_packet.files import MAX_JSON_BYTES, PacketError, sha256
from attention_packet.native import packed_strides
from attention_replay.transfer import ARMS, DISPATCH
from validate_arm import validate_arm


class ArmIntegrityTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        descriptor = {'dtype': 'bfloat16', 'shape': [1, 1, 1, 64],
                      'packedStrides': packed_strides([1, 1, 1, 64]), 'byteOrder': 'little',
                      'byteCount': 128, 'sha256': sha256(bytes(128))}
        self.left = SimpleNamespace(packet_sha256='1' * 64, tensors={
            name: SimpleNamespace(descriptor=copy.deepcopy(descriptor))
            for name in ('queries', 'storedKeys', 'storedValues')})
        self.right = SimpleNamespace(packet_sha256='2' * 64)
        self.transfer = {'packetSHA256': self.left.packet_sha256, 'geometry': {'length': 1}}
        self.transfer_sha = '3' * 64

    def fixture(self, arm='pagedSegmented'):
        tensors = {}
        for name in (('output',) if arm == 'nativeSDPA' else ('output', 'storedKeys', 'storedValues')):
            tensors[name] = {**self.left.tensors['queries'].descriptor, 'file': name + '.bin'}
            (self.root / (name + '.bin')).write_bytes(bytes(128))
        return {'schema': 'darkbloom.attention-replay-result.v1', 'arm': arm,
                'inputSHA256': self.transfer_sha, 'dispatch': DISPATCH[arm],
                'geometry': self.transfer['geometry'], 'tensors': tensors}

    def run_result(self, result, arm='pagedSegmented'):
        (self.root / 'result.json').write_text(json.dumps(result))
        return validate_arm(self.root, arm, self.left, self.right, self.transfer, self.transfer_sha)

    def test_all_three_arms_have_explicit_limited_scope(self):
        for arm in ARMS:
            with self.subTest(arm=arm):
                report = self.run_result(self.fixture(arm), arm)
                self.assertEqual(report['status'], 'analyzed')
                self.assertTrue(report['requiresFinalCollection'])
                self.assertEqual(report['resultSHA256'], sha256((self.root / 'result.json').read_bytes()))
                self.assertNotIn('storedHistoryByteIdentity', report)
                self.assertNotIn('originalQueryReference', report)

    def test_wrong_arm_input_dispatch_or_geometry_is_refused(self):
        for key, value in [('arm', 'nativeSDPA'), ('inputSHA256', '4' * 64),
                           ('dispatch', 'contiguous_sdpa'), ('geometry', {'length': 2})]:
            with self.subTest(key=key):
                result = self.fixture(); result[key] = value
                with self.assertRaises(PacketError): self.run_result(result)

    def test_transfer_packet_mismatch_is_refused(self):
        self.transfer['packetSHA256'] = '4' * 64
        with self.assertRaisesRegex(PacketError, 'packet identity'): self.run_result(self.fixture())

    def test_missing_tensor_is_refused(self):
        result = self.fixture(); del result['tensors']['storedKeys']
        with self.assertRaisesRegex(PacketError, 'incomplete'): self.run_result(result)

    def test_corrupt_or_short_bytes_are_refused(self):
        for raw in (bytes(127), b'X' + bytes(127)):
            with self.subTest(length=len(raw)):
                result = self.fixture(); (self.root / 'storedKeys.bin').write_bytes(raw)
                with self.assertRaises(PacketError): self.run_result(result)

    def test_missing_payload_is_refused(self):
        result = self.fixture(); (self.root / 'output.bin').unlink()
        with self.assertRaises(FileNotFoundError): self.run_result(result)

    def test_escaping_and_alias_paths_are_refused(self):
        for name in ('../outside.bin', 'output.bin'):
            with self.subTest(name=name):
                result = self.fixture(); result['tensors']['storedKeys']['file'] = name
                with self.assertRaises(PacketError): self.run_result(result)

    def test_external_symlink_is_refused(self):
        result = self.fixture()
        with tempfile.TemporaryDirectory() as outside:
            target = Path(outside) / 'external.bin'; target.write_bytes(bytes(128))
            (self.root / 'storedKeys.bin').unlink()
            (self.root / 'storedKeys.bin').symlink_to(target)
            with self.assertRaisesRegex(PacketError, 'symlink escapes'): self.run_result(result)

    def test_wrong_dtype_and_strides_are_refused(self):
        for key, value in [('dtype', 'float16'), ('packedStrides', [1, 1, 1, 1])]:
            with self.subTest(key=key):
                result = self.fixture(); result['tensors']['output'][key] = value
                with self.assertRaises(PacketError): self.run_result(result)

    def test_oversized_descriptor_is_refused_before_payload_read(self):
        result = self.fixture()
        result['tensors']['output']['shape'] = [1, 1, 1, 32 * 1024 * 1024]
        with patch('validate_arm.hashed_file') as reader:
            with self.assertRaisesRegex(PacketError, 'byte budget'): self.run_result(result)
            reader.assert_not_called()

    def test_oversized_json_is_refused_before_parse(self):
        with (self.root / 'result.json').open('wb') as destination:
            destination.truncate(MAX_JSON_BYTES + 1)
        with patch('validate_arm.parse_json') as parser:
            with self.assertRaisesRegex(PacketError, 'byte budget'):
                validate_arm(self.root, 'pagedSegmented', self.left, self.right,
                             self.transfer, self.transfer_sha)
            parser.assert_not_called()

    def test_duplicate_json_key_is_refused(self):
        (self.root / 'result.json').write_text('{"schema":1,"schema":2}')
        with self.assertRaisesRegex(PacketError, 'duplicate JSON key'):
            validate_arm(self.root, 'pagedSegmented', self.left, self.right,
                         self.transfer, self.transfer_sha)


if __name__ == '__main__':
    unittest.main()
