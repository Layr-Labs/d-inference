# Connected M5 cache fixture, revision 3

This successor preserves both earlier packages and their failed evidence. Its reviewed remote root is `/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http3`. It prepares twelve off/SSD inputs for the original five exact artifacts plus production Gemma QAT4. All cells in this revision remain unrun at package freeze. Root reviews the complete immutable package before the sole fleet owner stages or executes it.

CLI7 is bound to `/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build7/artifact/darkbloom`, SHA-256 `678f631cf31b2a62413ae0b318bc5317ace6e1f6b5c7440219456c85940bc82e` (86,103,432 bytes). Its provider source is9e49059a1 and native sourcea932d38cee0beca41ca1a0e71c1e867913a65353, including the useful MTP tail policy. Build/root provenance verifies677 provider and481 native files except the two documented compile-only Package.swift overlays. All8 runtime files and37 build-evidence files were reverified locally; root approved the build. The existing sidecar remains `090-final-serving-smoke1/payload/bin/promptsidecar`, SHA-256 `6a0c4498c6a3d23f85001fe1d1e0b8a502e2397858a586808e792b66e85576ea`. This new complete package still awaits its own root review before staging.

## Concrete changes and evidence

The tool fixture still asks for `record_color(color="blue", count=2)` with ordinary `tool_choice:auto`, normal reasoning/MTP and exact actual-call/argument checks. Only its output budget increases from64 to512. The revision2 Qwen3.8 cold run completed its first five cases but exhausted the tool budget after61 reasoning tokens and a partial call. That failure remains failed under `prior-failure-evidence/qwen38-tools64/`; its SSD companion and final cases were unrun. Raising the budget is a new paired fixture, not a reinterpretation of the old run. Main text, continuation and vision caps remain64; restored cancellation remains2048.

The Go executable/source remain the exact reviewed `089d9ade3398b7660b9c0745ea17a8f584d11f9f`: executable SHA-256 `6e30a1e53cc26ac1bb7953216b6d0af835b8b08a29f1920b2df07999c0e2bc8f`, all988 bank-matched source/resource files. The SSE reader reconstructs equal reasoning aliases once and refuses conflicting aliases. Original build commands, dependency graph, source before/after manifests and bank proof are retained. The exact executable previously passed12 helper functions/18 subtests; no Go rebuild is performed here.

Build7 uses a flat artifact directory. The launcher verifies declared provider/metallib paths, every colocated resource relative to the provider parent, and the separately declared pinned Rust sidecar. Virtual `bin/` prefixes in the source transfer manifest are provenance keys, not an extra required runtime directory. Its focused regression accepts the real layout and rejects corruption of a nested resource or the external sidecar. Production config/date/ownership/entitlement checks and pre/post artifact verification remain active.

QAT is `gemma-4-26b-qat-4bit`, aggregate `2468a0cb3049a871f42052f4d9f9380bf12a0792f64c7a29f768559fc7d28785`. Exact10-file local verification and parent-supplied M5 hash proof are retained. Its template94899c0f… matches the production Gemma constrained-tool contract, unlike the earlier8-bit template85a…. The auto fixture does not claim forced-tool execution. Named-tool CPU normalization passed separately, but actual advertisement, loaded grammar and named HTTP tests remain separate gates. Catalog status and capabilities are copied exactly, with no promotion or inferred coverage.

Both Gemma inputs use the same verified two-file assistant override at `090-final-serving-smoke1/payload/gemma-assistant-local-override1`. Its manifest stays external. The launcher verifies the actual declared directory's exact flat membership, file types, sizes and hashes. Normal target compatibility and MTP-active checks remain required. QAT supplemental native32/128 input and target-only KV observation plans are historical preparation evidence under `qat-supplemental-evidence/`; those model cells remain unrun, and their unresolved runtime fields are not launch instructions for this connected package.

## Input and validation boundaries

All twelve inputs are regenerated and paired identically except `cache_mode`. Exact model/catalog identities, prompt and tool definitions are preserved. The authored long prompt is35,273 characters, SHA-256 `10982a0c99a7e612803ee7b2c8fa62f9ebfcf3de9ae34c2dde25bf8831aee896`. CPU plans measure eligible interior boundaries; real coordinator receipts and provider saved-token/SSD-stage outcomes still must pass independently. Original PNG vision input is retained where config declares vision, with the existing required-cold assertion.

Sixteen Python helper tests and all six exact local CPU plans passed. Planned prompt tokens are Qwen3.6/Qwen3.5=5503, Qwen3.8=5545, GPT=5454, Gemma8-bit=5399 and GemmaQAT4=5399. Their results and actual commands are retained in `preparation/` and `tokenizer-plan.json`. The request-owned date is2026-09-05, captured from actual current UTC during generation. The launcher and postflight fence a different date. If UTC rolls over before execution, prepare and review another complete paired revision plus CPU plans. Never edit frozen inputs or change the production clock. Reports retain raw SSE/content/reasoning/tools/counts/finish; HTTP token IDs are unavailable. The fixture is B1, sequential cases, two providers/two authenticated tenants on one Mac. It does not prove independent-machine capacity, B2/B4, attestation or persistent restart.

## Sole-lane execution after root review

The fleet owner extracts the archive into a fresh absent `090-connected-http3` directory and runs `python3 verify_package.py`. The archive uses paths relative to that root. Model bytes, CLI artifacts and sidecar stay at their separately verified paths; no remote Go/Rust/Swift compilation or production credentials are needed. The fixture uses the in-memory coordinator store, mock billing and fresh local tokens/routing keys.

Inspect the host for foreign/ranked model work and thermal suitability. Existing Q35/Q36 discovery aliases may belong to earlier journals. Never overwrite or adopt them. The included alias helper only creates absent roots with exact manifest verification and exclusive ownership markers. Cleanup acts only on unchanged entries owned by its exact journal. Q38/GPT/both Gemma snapshots must independently resolve to their pinned directories.

Run one owned cell and its companion at a time, retaining failures and unrun cells:

```sh
cd /Users/gaj/autoresearch/radix-prefix-cache/090-connected-http3
python3 run_connected_fixture.py preflight --cell qwen38-paged-off-b1
python3 run_connected_fixture.py run --cell qwen38-paged-off-b1
python3 run_connected_fixture.py run --cell qwen38-paged-ssd-b1
python3 compare_connected_cache_http.py runs/qwen38-paged-off-b1-run/evidence/report.json runs/qwen38-paged-ssd-b1-run/evidence/report.json --output runs/qwen38-paired-comparison.json
```

The other labels are qwen36, qwen35, gpt-oss-20b, gemma-4-26b and gemma-qat4. Each run creates fresh evidence/cache roots and refuses reuse. Prefix resident mode and inherited policy overrides remain absent. SSD tests use explicitly ephemeral keys, so no persistent-restart claim applies. The helper drains only its fresh owned process group, including descendants after abnormal Go exit; interruption/timeout cannot become a pass. It never globally kills by name or repairs host configuration.

The default-backend release rollout remains pending; these inputs explicitly select paged storage. Complete model/HTTP validation remains the fleet owner's next step after root review. Package preparation, helper tests and CPU planning alone cannot satisfy any final serving release gate.
