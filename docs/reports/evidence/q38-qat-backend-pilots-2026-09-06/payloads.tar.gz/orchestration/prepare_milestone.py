"""Prepare a reviewable documentation/evidence milestone; no commit or runtime jobs."""
from datetime import datetime,timezone
import gzip,hashlib,json,tarfile
from pathlib import Path
BASE=Path('/tmp/darkbloom-q38-qat-backend-pilots1')
WT=Path('/Users/gaj/Documents/DarkbloomDev/wt/q38-qat-backend-pilot-milestone')
OUT=WT/'docs/reports/evidence/q38-qat-backend-pilots-2026-09-06';OUT.mkdir(parents=True)

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
def identity(path):return {'sha256':sha(path),'bytes':path.stat().st_size,'mode':oct(path.stat().st_mode&0o777)}
# Rehash each frozen package before selecting nonduplicated source/raw payloads.
verified=[]
for root,name in [(BASE/'package','package-manifest.json'),(BASE/'execution-qat-group1','manifest.json'),
                  (BASE/'execution-failed-cell1','manifest.json'),(BASE/'execution-qwen38-group1','manifest.json')]:
 manifest=read(root/name)
 for relative,expected in manifest['files'].items():
  got=identity(root/relative)
  assert all(got[key]==expected[key] for key in ('sha256','bytes','mode'))
 verified.append({'path':str(root/name),'sha256':sha(root/name),'payloads':len(manifest['files'])})
sequence={'scope':'Stop/review retained; final cell approved only for independent same-backend cache evidence',
 'after_sixth_cell':{'state':'Stopped after strict QAT cold-backend failure; final cache-on root untouched',
  'evidence_manifest_sha256':sha(BASE/'execution-failed-cell1/manifest.json'),
  'exact_comparison':'execution/payload/collection-after-gemma-4-26b-qat-4bit-b1-r1-paged-cache-off.json'},
 'root_review':{'source':'Root-agent conversation instruction after independently rehashing69 payloads and rerunning the strict comparison',
  'authorization':'Proceed final original QAT paged/cache-on cell now under unchanged guards solely to finish independent paged cache comparison. Preserve coldbackendfailure in final collection and report.'},
 'after_seventh_cell':{'state':'Individual and same-paged-cache comparison pass; cold-backend failure retained',
  'root_review_record':'analysis/root-final-results-review.json','handoff':'analysis/final-postflight-handoff1.json'}}
sequence_path=BASE/'pilot-review-sequence1.json'
with sequence_path.open('x') as stream:json.dump(sequence,stream,indent=2);stream.write('\n')
sources={}
for prefix,root in [('plan',BASE/'package'),('execution',BASE/'execution-qat-group1')]:
 for path in sorted(root.rglob('*')):
  if path.is_file() and path.name!='evidence.tar':sources[prefix+'/'+str(path.relative_to(root))]=path
for name in ('qat-cold-backend-divergence1.json','qwen38-mtp-observations1.json','final-postflight-handoff1.json',
             'root-final-results-review.json','pilot-review-sequence1.json','freeze.json','pending-binding-refusal.json'):
 sources['analysis/'+name]=BASE/name
for name in ('execute_pilot_cell.py','freeze_execution.py','freeze.py','prepare_milestone.py'):
 sources['orchestration/'+name]=BASE/name
for short,directory in [('first-cell','execution-first-cell1'),('qwen38-group','execution-qwen38-group1'),('six-cell-stop','execution-failed-cell1')]:
 sources['provenance/'+short+'-manifest.json']=BASE/directory/'manifest.json'
archive=OUT/'payloads.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as compressed:
 with tarfile.open(fileobj=compressed,mode='w') as tar:
  for relative,source in sorted(sources.items()):
   info=tar.gettarinfo(str(source),arcname=relative);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
   with source.open('rb') as stream:tar.addfile(info,stream)
with tarfile.open(archive) as tar:
 assert {m.name for m in tar.getmembers()}==set(sources)
 for member in tar.getmembers():
  source=sources[member.name]
  assert member.isfile() and tar.extractfile(member).read()==source.read_bytes()
  assert member.mode==(source.stat().st_mode&0o777)
manifest={'schema':1,'scope':'Seven actual B1r1 pilots; seven individual passes, five strict pair passes, one strict QAT backend failure and two unsupported comparisons. No performance/release acceptance.',
 'review_base_commit':'384c321aa7565864182c02210fc4d212efc6501b','source_inventories_reverified':verified,
 'payloads':len(sources),'uncompressed_bytes':sum(p.stat().st_size for p in sources.values()),
 'archive':identity(archive),'files':{relative:{'source':str(path),**identity(path)} for relative,path in sorted(sources.items())}}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
summary=read(BASE/'execution-qat-group1/row-summary.json')
table=[]
for cell in summary:
 model='Q38' if cell['cell'].startswith('qwen38') else 'QAT'
 backend='contiguous' if 'contiguous' in cell['cell'] else 'paged'
 cache=cell['cell'].rsplit('-',1)[-1]
 for row in cell['rows']:
  after=row['metrics_after'];memory=after['mlx_memory']
  table.append(f"| {model} | {backend} | {cache} | {row['id'].removeprefix('long-')} | {row['ttft_s']:.3f} | {row['decode_tps']:.2f} | {memory['peak_bytes']/2**30:.3f} | {after['process_rss_bytes']/2**30:.3f} |")
report='''# Qwen 3.8 and Gemma QAT backend/cache pilots

> Last updated: 2026-09-06 · commit `384c321aa`

Seven real-model B1 runs pass their individual integrity checks. Five strict
comparisons pass, but Gemma QAT contiguous/paged output parity fails; two historical
contiguous-SSD comparisons remain unsupported. This report records one repetition
per supported arm, not full-matrix completion, stable performance or release readiness.

## Scope and identities

The dedicated M5 runs use build8 `radix-engine`, SHA-256
`8e476149db74cede08a78a39d718c01f19e2d74a5654d00e2338250ba8b0eda1`.
The archive binds its executable mode and six exact resource hashes, frozen runner
and strict validators, model manifests, assistant inventory, CPU prompt evidence,
reviewed binding, and all actual reports, logs and telemetry. No executable or
model weights are archived.

- Q38 is `EigenLabs/Qwen3.8-27B-4bit-mtp`, model aggregate
  `bbd0e0adcfe74e095073fefd0b9e116e4311d606ad9989cf81f8175e8ac18463`;
  input/prepared SHA-256
  `fc0416c745ee7f7811fe4c3b92b07d0f4eec5af9612331fd94fb9611a7f59ec3`.
- QAT is `gemma-4-26b-qat-4bit`, model aggregate
  `2468a0cb3049a871f42052f4d9f9380bf12a0792f64c7a29f768559fc7d28785`;
  input/prepared SHA-256
  `1abb54db891314531df0b6ddfbe3cc3418c29fd014133cdf3837133c9e9a3080`.
  Its normal assistant is the exact two-file local override, aggregate
  `d8c5fae1f4b7a07376c9f0b92f3ec283ba276d57ec3b675d8cf758a79d73bd34`.

All cells preserve the reviewed matrix3 input bytes: UTC prompt date 2026-09-06,
128-token cap, concurrency 1, repetition 1, normal MTP and production single-slot
KV grants. QAT uses normal reasoning with no provisional thinking override.
Q38 prompts contain 5,523 tokens; QAT prompts contain 5,418. Each invocation uses
its own fresh SSD root and the original ephemeral benchmark key mode. These are
standalone engine pilots, not connected HTTP or persistent-key restart proof.

The separate `090-q38-qat-backend-pilots1` namespace changes only owned staging,
output and cache paths. The canonical matrix3 namespace remains absent and its
216 conceptual cells, 189 supported cells, 27 unsupported cells, 162 executable
comparisons and 54 dependent missing comparisons remain unchanged.

## Strict outcomes and retained failure

| Comparison | Result |
| --- | --- |
| Q38 contiguous cache off/on | PASS |
| Q38 paged cache off/on | PASS |
| Q38 contiguous/paged, cache off | PASS |
| Q38 contiguous/paged, cache on | PASS |
| QAT paged cache off/on | PASS |
| QAT contiguous/paged, cache off | FAIL: output mismatch |
| QAT comparisons needing contiguous SSD-on | Two unsupported; unrun |

Every passing cache comparison requires identical prompt/generated IDs, finish
reasons and token counts, authenticated native SSD staging with saved work,
tenant isolation, cancellation/recovery and coherent idle/shutdown evidence.
All seven cells pass individual checks; this alone does not establish backend
parity. No measured process overlaps another, and failed comparisons remain failed.

QAT's cold backend outputs first differ at zero-based output index **7**:
contiguous token **42392**, paged token **62203**. Contiguous produces 61 tokens
and paged 38; both finish with `stop`. The same difference appears in both main
rows, all three tenant rows, the cancellation donor and recovery. All 5,418
prompt IDs, model/input/runtime and assistant identities match. Performance across
those different output trajectories is not an accepted backend comparison.

Execution stopped after the sixth cell. The original failed comparison and
six-cell freeze were reviewed before the last original paged SSD cell was
authorized solely for independent cache evidence. That cache comparison passes
with the same 38-token paged output; it does not clear the cold backend failure.
The archive preserves the stop, review sequence and unchanged final result.

## Individual timing and memory observations

These are individual rows, with no averages or performance acceptance. MLX peak
is the **cumulative process peak observed at that row's final sample**, not an
isolated row peak. RSS is the final row-boundary sample, not peak RSS. GiB means
2^30 bytes. Exact before/after coherent memory, capacity, idle, MTP and production
grant records remain beside these values in `execution/row-summary.json`.

| Model | Backend | Cache | Row | TTFT s | Decode tok/s | MLX peak GiB | RSS GiB |
| --- | --- | --- | --- | ---: | ---: | ---: | ---: |
'''+ '\n'.join(table)+'''

All cache-on repeat rows authenticate and reuse 4,096 tokens. In these single
same-backend comparisons, Q38 repeat TTFT changes from 6.528 to 1.838 seconds
with contiguous attention and 6.581 to 1.845 with paged attention; QAT paged changes
from 1.099 to 0.395 seconds. Resident prefix-bank budgets remain zero. Row-boundary
coherent samples have age zero, no commitment debt and ready idle observations;
the paged pool's retained owner must not be mistaken for leaked live request KV.

Q38 cold paged decode is about 10–11% slower than cold contiguous in this pilot.
Normal MTP policy also differs between paged cache arms. For first/repeat rows,
paged-off proposes 101/104 speculative tokens and selects depth4 23/27 times;
paged-on proposes 88/84 and selects depth4 13/11 times. Accepted-token deltas
46/47 and round deltas 27/26 match. These are per-row deltas from cumulative
counters, not generated-token totals. [INFERENCE] Extra speculative work may
contribute to the observed decode difference; these observations do not isolate
its cause. Repeated normal-policy cells and a separately controlled follow-up
remain necessary. No policy, settings or gate was changed to improve the result.

## Evidence and remaining work

The [manifest](evidence/q38-qat-backend-pilots-2026-09-06/manifest.json) and
[archive](evidence/q38-qat-backend-pilots-2026-09-06/payloads.tar.gz) preserve
'''+f"{manifest['payloads']} verified payloads, {manifest['uncompressed_bytes']:,} uncompressed bytes; the archive is {archive.stat().st_size:,} bytes.\n\n"+f"Manifest SHA-256: `{sha(OUT/'manifest.json')}`.\nArchive SHA-256: `{sha(archive)}`.\n"+'''
The source-only pilot checks pass 12 CPU tests and the unchanged original matrix
checks pass 18. The final seven-cell raw collection was independently rechecked
both locally and by the root reviewer. Payload/runtime bytes and modes were
verified on M5. Final postflight finds no remaining model/helper/telemetry jobs,
353,395,228,672 free bytes and 5,896,409,343 retained SSD payload bytes. M5 was
handed to the next approved diagnostic owner; all pilot roots remain preserved.

QAT backend parity, existing Qwen3.5/Qwen3.6 failures, the full ordered B1/B2/B4
repeated matrix, native numerical/storage proof and persistent-key fresh-process
SSD restart remain open. No readiness-refusal probe is counted as a success.
Cache correctness in these pilots does not authorize a release/default change.

Related: [initial supported backend groups](2026-09-05-supported-backend-groups.md),
[initial QAT SSD pairs](2026-09-05-gemma-qat4-initial-pairs.md), and
[Qwen3.6 actual logits](2026-09-05-qwen36-actual-logits.md).
'''
report_path=WT/'docs/reports/2026-09-06-q38-qat-backend-pilots.md';report_path.write_text(report)
index=WT/'docs/reports/README.md';text=index.read_text();text=text.replace('commit `c9bd3ab78`','commit `384c321aa`',1)
line='- [Qwen3.8 and Gemma QAT backend/cache pilots](2026-09-06-q38-qat-backend-pilots.md) — seven individual passes and five strict pair passes; QAT backend output mismatch and Q38 decode-policy signal remain unresolved.\n'
pos=text.index('- [Production attention diagnostic owners]');text=text[:pos]+line+text[pos:];index.write_text(text)
print(json.dumps({'worktree':str(WT),'report':str(report_path),'manifest_sha256':sha(OUT/'manifest.json'),'archive_sha256':sha(archive),'payloads':manifest['payloads'],'uncompressed_bytes':manifest['uncompressed_bytes'],'archive_bytes':archive.stat().st_size},indent=2))
