"""Use existing comparison gates; teacher likelihood never becomes a serving oracle."""
from pathlib import Path
import sys

from cohort_common import read_json, require
from teacher_checks import compare_reports, report_checks

VENDOR = Path(__file__).resolve().parent/'vendor'
sys.path.insert(0, str(VENDOR))
from compare_radix_engine import compare as existing_serving_compare


def selected(cohort, model, case):
    record = next(row for row in cohort['records'] if row['model'] == model and row['case_id'] == case)
    return record, cohort['models'][model], cohort['payloads'][(model, case)]


def serving_identity(report, record, model, payload, runtime):
    require(report.get('schema') == 3 and report.get('forward_shape_telemetry_schema') == 1, 'instrumented serving schema 3 required')
    require(report.get('model') == model['model_id'] and report.get('verified_model_hash') == model['aggregate_sha256'], 'serving model identity differs')
    require(report.get('input_sha256') == record['serving']['sha256'], 'serving corpus input SHA differs')
    require(report.get('cache_requested') is False and report.get('max_concurrent_requests') == 1, 'quality serving posture differs')
    require(str(report.get('mtp', '')).startswith('on' if model['normal_mtp'] else 'off'), 'normal MTP posture differs')
    observed = report.get('runtime_identity', {})
    require(observed.get('binary_sha256') == runtime['files']['radix-engine']['sha256']
            and observed.get('metallib_sha256') == runtime['files']['mlx.metallib']['sha256'], 'serving runtime differs')
    rows = report.get('rows', [])
    require([row.get('id') for row in rows] == ['long-first', 'long-repeat'], 'serving row coverage differs')
    require(all(row.get('prompt_token_ids') == payload['teacher']['promptTokens'] for row in rows), 'serving tokenization differs from frozen canonical prompt')


def compare_serving(cohort, model_label, case_id, contiguous, paged, binding, metadata=None):
    record, model, payload = selected(cohort, model_label, case_id)
    require(metadata is not None and len(metadata) == 2, 'both original serving metadata receipts required')
    for meta, backend in zip(metadata, ['contiguous', 'paged']):
        require(meta.get('status') == 'completed' and meta.get('exit_code') == 0, 'serving process did not complete')
        require(meta.get('matrix_binding_sha256') == binding['_binding_sha256'], 'serving binding differs')
        require(meta.get('matrix_host') == {'id': binding['host_id'], **binding['host_identity']}, 'serving host differs')
        require(meta.get('serving_profile') == binding['serving_profile'], 'serving profile differs')
        require(meta.get('binary_sha256') == binding['_manifest']['files']['radix-engine']['sha256']
                and meta.get('input_sha256') == meta.get('source_input_sha256') == record['serving']['sha256'],
                'serving metadata source identity differs')
        require(meta.get('arguments', {}).get('kv_backend') == backend
                and meta.get('arguments', {}).get('production_kv_grant') is True, 'serving metadata posture differs')
    require(metadata[0]['ended_unix'] <= metadata[1]['started_unix'], 'serving pair ordering/overlap differs')
    for report in [contiguous, paged]:
        serving_identity(report, record, model, payload, binding['_manifest'])
    result = existing_serving_compare(contiguous, paged, expect_hits=False, axis='backend')
    return {'schema': 1, 'scope': 'existing_serving_backend_trajectory_gates', 'case_id': case_id,
            'model': model_label, 'comparison': result, 'quality_pass': None,
            'teacher_likelihood_used_as_oracle': False}


def teacher_oracle_gate(teacher, serving_row=None, observed_serving_prefill_chunks=None):
    reasons = ['scheduler_free_eager_teacher_path_is_not_serving_path',
               'ordered_geometry_and_kernel_path_evidence_not_bound']
    teacher_chunks = teacher['activity'][0]['prefillChunks']
    if observed_serving_prefill_chunks is not None and teacher_chunks != observed_serving_prefill_chunks:
        reasons.append('prefill_chunk_geometry_mismatch')
    if serving_row is not None:
        count = len(teacher['input']['continuation'])
        if (serving_row.get('prompt_token_ids') != teacher['input']['promptTokens']
                or serving_row.get('token_ids', [])[:count] != teacher['input']['continuation']):
            reasons.append('conditioned_token_history_differs')
    # This cohort has no API accepting a boolean equivalence waiver. A separate
    # reviewed same-state geometry/path gate must establish that evidence.
    return {'eligible': False, 'reasons': reasons, 'teacher_prefill_chunks': teacher_chunks,
            'serving_prefill_chunks': observed_serving_prefill_chunks,
            'required_evidence': ['same prompt and per-position histories', 'ordered prefill/decode geometry',
                                  'observed dtype, attention/recurrent and compiled/eager paths',
                                  'unchanged numerical and exact-trajectory gates']}


def compare_teacher(cohort, model_label, case_id, contiguous, paged, binding):
    record, model, payload = selected(cohort, model_label, case_id)
    descriptor = {'model_id': model['model_id'], 'model_sha256': model['aggregate_sha256'],
                  'input_sha256': record['teacher']['sha256'], 'prompt_tokens': record['prompt_tokens'],
                  'continuation_tokens': record['continuation_tokens']}
    snapshot = Path(binding['models'][model_label]['teacher_snapshot'])
    native_binding = {'runtime': {'files': binding['_manifest']['files']}}
    for backend, report in [('contiguous', contiguous), ('paged', paged)]:
        report_checks(report, descriptor, {'backend': backend}, native_binding, payload['teacher'], snapshot,
                      {'gemma_optimizations': {'prefill_layer18': True, 'weighted_r1': True}})
        require(all(row['vocabularySize'] == model['vocabulary_size'] for row in report['diagnostic']['records']), 'teacher vocabulary differs')
    result = compare_reports(descriptor, payload['teacher'], contiguous, paged)
    return {'schema': 1, 'scope': 'public_reference_likelihood_only', 'case_id': case_id, 'model': model_label,
            'comparison': result, 'quality_pass': None, 'teacher_likelihood_used_as_oracle': False,
            'execution_control_receipts': 'Separate prerequisite: retain existing controller readiness, identity, ownership and retirement checks.',
            'serving_oracle_gate': teacher_oracle_gate(contiguous)}
