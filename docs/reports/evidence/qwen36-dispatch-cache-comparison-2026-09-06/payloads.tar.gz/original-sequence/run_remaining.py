from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
DRIVER=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-execution1/run_cell.py')
PLAN=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-plan1/plan.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads(PLAN.read_text());records=[]
for cell in plan['cells'][1:]:
 start=time.time();command=[sys.executable,'-B',str(DRIVER),cell['id']]
 print(json.dumps({'starting':cell['id'],'unix_time':start}),flush=True)
 result=subprocess.run(command)
 record={'cell':cell['id'],'command':command,'started_unix':start,'ended_unix':time.time(),'exit_code':result.returncode,'driver_sha256':sha(DRIVER)}
 records.append(record);(ROOT/'executions.json').write_text(json.dumps(records,indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
print(json.dumps({'sequence_complete':True,'remaining_cells_completed':len(records)}),flush=True)
