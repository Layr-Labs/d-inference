from pathlib import Path
import hashlib,json,shutil,tarfile
OUT=Path(__file__).parent;SOURCE=Path('/tmp/darkbloom-q36-attention-packet-plan1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
assert sha(SOURCE/'manifest.json')=='21467d42b7e710d8303cb2690f79edb16d793241b919fa303d6acea888660fce'
manifest=json.loads((SOURCE/'manifest.json').read_text())
archive=OUT/'plan-package.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for name in sorted(list(manifest['files'])+['manifest.json']):
  p=SOURCE/name
  if name!='manifest.json':assert p.stat().st_size==manifest['files'][name]['bytes'] and sha(p)==manifest['files'][name]['sha256']
  tar.add(p,arcname=name,recursive=False)
summary={'remote_root':'/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1','plan_manifest_sha256':sha(SOURCE/'manifest.json'),'archive_sha256':sha(archive),'archive_bytes':archive.stat().st_size,'archive_members':30,'binding_sha256':'48cea7e3daa6fb0676ccc069891eb93170885d7ae85dc6540a155d4454df2cdc','binding_review_sha256':'bcef01db59932780e017de10bc6e3ed132f1a80fe6dbc6fd89659ef50cfce4cd','reviewed_transport_common_sha256':sha(Path('/tmp/darkbloom-connected-http6-execution-prep2/common.py')),'scope':'Fresh plan source archive only. No model binaries, weights, key material or remote calls.'}
save(OUT/'transport.json',summary);print(json.dumps(summary,indent=2))
