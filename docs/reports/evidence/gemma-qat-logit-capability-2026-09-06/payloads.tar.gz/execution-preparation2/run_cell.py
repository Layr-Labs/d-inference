from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys
import time

SOURCE = Path('/tmp/darkbloom-qat-actual-logits-plan1')
OUT = Path('/tmp/darkbloom-qat-actual-logits-execution2')
BINDING = Path('/tmp/darkbloom-qat-actual-logits-runtime-binding1.json')
OPTIONS = ['-i', '/Users/gaj/.ssh/darkbloom_testbox', '-o', 'IdentitiesOnly=yes',
           '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15']
HOST = 'gaj@100.124.35.99'
SSH = ['ssh'] + OPTIONS + [HOST]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def remote(local, name, code):
    compile(code, '<remote-' + name + '>', 'exec')
    result = subprocess.run(SSH + ['python3 -B -'], input=code, text=True, capture_output=True)
    (local / (name + '.stdout')).write_text(result.stdout)
    (local / (name + '.stderr')).write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)


def main():
    sys.dont_write_bytecode = True
    assert sha(OUT / 'strict_results.py') == '3b696b7c15a9efd628bb4a478c62370a23538aeea473d11c4b70eb7adaaac264'
    assert sha(OUT / 'preflight.py') == '8ba55ca6f113442ee6740ed8ff2a505c80ff4130e2a8d0da412a8165c5fe6516'
    assert sha(SOURCE / 'manifest.json') == '1af100278043a8187343e08a0d515d09fbbd7139f87d461e6aed9ef75ae3d985'
    assert sha(BINDING) == '1c714fa86469c935c911cb7b02a318da9ee0490319457d692cad0f8bae39875f'
    plan = json.loads((SOURCE / 'plan.json').read_text())
    binding = json.loads(BINDING.read_text())
    assert sha(Path(binding['review'])) == binding['review_sha256']
    assert len(plan['cells']) == 4 and [c['backend'] for c in plan['cells']] == ['contiguous', 'contiguous', 'paged', 'paged']
    chosen = next(cell for cell in plan['cells'] if cell['id'] == sys.argv[1])
    for prior_cell in plan['cells'][:plan['cells'].index(chosen)]:
        prior_root = OUT / prior_cell['id']
        prior = json.loads((prior_root / 'summary.json').read_text())
        assert prior['exit_code'] == 0 and prior['report_integrity_passed'], 'Prior failed or incomplete cell blocks later execution'
        for name, item in json.loads((prior_root / 'manifest.json').read_text())['files'].items():
            path = prior_root / name
            assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], name
    bound_command = next(c for c in binding['commands'] if c['cell'] == chosen['id'])
    assert bound_command['wrapper_argv'] == chosen['argv']
    command = chosen['argv']
    local = OUT / chosen['id']
    local.mkdir(exist_ok=False)
    (local / 'command.json').write_text(json.dumps(chosen, indent=2) + '\n')
    (local / 'expected-native-command.json').write_text(json.dumps(bound_command, indent=2) + '\n')
    check = subprocess.run(['python3', '-B', str(OUT / 'preflight.py'),
                            str(local / 'ownership-before.json')], text=True, capture_output=True)
    (local / 'ownership-before.log').write_text(check.stdout + check.stderr)
    assert check.returncode == 0, check.stdout + check.stderr
    output = command[command.index('--output') + 1]
    code = '''from pathlib import Path
import datetime,hashlib,json,shutil
root=Path(__REMOTE_ROOT_PATH__);assert not Path(OUTPUT).exists()
date=datetime.datetime.now(datetime.timezone.utc).date().isoformat();assert date=='2026-09-06'
assert hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()=='1af100278043a8187343e08a0d515d09fbbd7139f87d461e6aed9ef75ae3d985'
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()=='1c714fa86469c935c911cb7b02a318da9ee0490319457d692cad0f8bae39875f'
binding=json.loads((root/'runtime-binding.json').read_text())
assert hashlib.sha256((root/'runtime-root-review.json').read_bytes()).hexdigest()==binding['review_sha256']
inventory=json.loads((root/'manifest.json').read_text())['files']
for name,item in inventory.items():
 p=root/name;assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
 assert p.stat().st_mode&0o777==int(item['mode'],8)
runtime={}
for name,item in binding['artifacts'].items():
 p=root/'runtime'/name;assert p.stat().st_size==item['bytes'] and p.stat().st_mode&0o777==int(item['mode'],8)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'];runtime[name]=item
plan=json.loads((root/'plan.json').read_text());selected=next(c for c in plan['cells'] if c['id']==CELL)
assert selected['argv']==ARGV
assistant=binding['assistant'];directory=Path(assistant['directory'])
assert directory.is_dir() and not directory.is_symlink() and directory.resolve()==directory
assert {p.name for p in directory.iterdir()}==set(assistant['files'])
for name,item in assistant['files'].items():
 p=directory/name;assert p.is_file() and not p.is_symlink() and p.stat().st_size==item['bytes']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
free=shutil.disk_usage(root).free;assert free>binding['min_free_bytes']
print(json.dumps({'utc_date':date,'free_bytes':free,'runtime':runtime,'assistant_verified':assistant,'cell':CELL,'fresh_output_root':True},indent=2))
'''.replace('__REMOTE_ROOT_PATH__', repr(plan['remote_root'])).replace('OUTPUT', repr(output)).replace('CELL', repr(chosen['id'])).replace('ARGV', repr(command))
    remote(local, 'runtime-precheck', code)
    started = time.monotonic()
    with (local / 'ssh-run.log').open('x') as log:
        run = subprocess.run(SSH + [shlex.join(command)], stdout=log, stderr=subprocess.STDOUT)
    (local / 'execution.json').write_text(json.dumps({'exit_code':run.returncode,'seconds':time.monotonic()-started,'scope':plan['scope']},indent=2)+'\n')
    inventory = remote(local, 'remote-inventory', '''from pathlib import Path
import hashlib,json
root=Path(OUTPUT);files={}
if root.exists():
 for p in sorted(root.iterdir()):
  if p.is_file() and not p.is_symlink():files[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'root':str(root),'files':files},indent=2))
'''.replace('OUTPUT', repr(output)))
    for name, item in inventory['files'].items():
        assert name and all(c.isalnum() or c in '.-_' for c in name)
        result = subprocess.run(['scp'] + OPTIONS + [HOST + ':' + output + '/' + name,str(local/name)],text=True,capture_output=True)
        assert result.returncode == 0, result.stderr
        assert (local/name).stat().st_size == item['bytes'] and sha(local/name) == item['sha256']
    summary = {'cell':chosen['id'],'exit_code':run.returncode,'trace':chosen['trace'],
               'scope':'Four same-build QAT logit controls with normal MTP; earlier build8 failure remains separate. No performance or numerical acceptance waiver'}
    errors = []
    if (local/'report.json').exists():
        sys.path.insert(0,str(SOURCE/'runner'))
        from radix_engine_evidence import report_errors
        report=json.loads((local/'report.json').read_text())
        errors=report_errors(report)
        from strict_results import result_errors
        errors += result_errors(local, chosen, plan, binding, report, OUT)
        metadata=report.get('attention_metadata')
        if chosen['trace']:
            if not isinstance(report.get('logit_diagnostic'), dict) or report['logit_diagnostic'].get('status') != 'captured':
                errors.append('selected actual logit decision was not captured')
        elif metadata is not None:
            errors.append('uninstrumented control unexpectedly emitted attention metadata')
        summary.update(report_integrity_passed=not errors,errors=errors,
                       attention_metadata_status=(metadata or {}).get('status'),
                       logit_diagnostic_status=(report.get('logit_diagnostic') or {}).get('status'))
    else:
        errors=['report missing'];summary['errors']=errors
    (local/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    files={str(p.relative_to(local)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(local.rglob('*')) if p.is_file()}
    (local/'manifest.json').write_text(json.dumps({'scope':summary['scope'],'files':files},indent=2,sort_keys=True)+'\n')
    print(json.dumps({**summary,'manifest_sha256':sha(local/'manifest.json')},indent=2),flush=True)
    raise SystemExit(run.returncode or (1 if errors else 0))


if __name__ == '__main__':
    main()
