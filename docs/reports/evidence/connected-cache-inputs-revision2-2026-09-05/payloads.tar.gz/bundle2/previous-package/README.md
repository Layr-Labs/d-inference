# Connected M5 cache fixture — prepared, not executed

This bundle runs the existing `TestIntegrationConnectedCacheHTTP` from parent commit `3aa73029ef22a6292aefff005b2267856f665a3c`. The Go test executable was compiled locally with Go 1.27.1 for darwin/arm64. Its 986 selected source/resource files are pinned in `go-source-manifest.json`; dependencies and build flags are in `go-binary-build-info.txt`. No Go, PostgreSQL, Docker, Rust compiler, Swift compiler, Privy, Stripe or production credentials are needed on M5. The coordinator uses the existing in-memory test store and mock billing; API/provider tokens and the routing master key are minted for each isolated suite.

The supplied CLI is `a81fd9f9ff01fb84f3c236ceaba5fed4fca730b261be1f332b87c38e69cd3cfd`, its bound metallib is `4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0`, and the Rust sidecar is `6a0c4498c6a3d23f85001fe1d1e0b8a502e2397858a586808e792b66e85576ea`. They and the flat Gemma assistant remain in the already verified `090-final-serving-smoke1/payload` package. Every run verifies their files. It copies the CLI/resources into its owned evidence root, containing updater-side writes without changing the installed daemon package.

Ten prepared inputs pair paged/cache-off with paged/default-SSD for all five exact artifacts. Each test uses two provider processes and two API-authenticated tenant accounts on this single host, with configured B1 and sequential requests. This proves neither independent-machine capacity/latency nor B2/B4 throughput. Normal MTP is on for all Qwens and Gemma, off for GPT. The exact flat assistant manifest is preserved; ordinary production assistant compatibility and actual MTP telemetry must still pass.

The shared, untruncated 35,273-character prompt comes from the existing `qwen35-serial-smoke.json`; SHA256 `10982a0c99a7e612803ee7b2c8fa62f9ebfcf3de9ae34c2dde25bf8831aee896`. Local CPU-only pinned sidecar planning produced Q36=5503, Q35=5503, Q38=5545, GPT=5454 and Gemma=5399 prompt tokens; see `tokenizer-plan.json`. All exceed 4096, leaving genuine interior checkpoint boundaries. Actual provider saved tokens, accepted lookup receipts and read/stage outcomes remain required at execution. No checkpoint is inferred from token count alone.

Inputs pin the expected request-owned UTC date to **2026-09-05**. The launcher refuses a different current date; it never sets the OS clock or overrides the production request date. Paired reports must retain equal dates. If the date expires, produce a new reviewed paired bundle and CPU plan proof rather than changing frozen evidence.

Tools use ordinary `tool_choice:auto` with an explicit request for exactly `record_color(color="blue", count=2)`; the existing test validates the actual call and arguments. These are auto-tool execution tests, not inference-enforced named constraints. Qwen/GPT do not advertise the latter. This exact Gemma artifact's template (`85a08664…`) differs from the native constrained-tool contract (`94899c0f…`), so it also uses auto. `source-gates.json` records the source evidence. The earlier `http-feature-plan.json` is preserved as a superseded proposal. Unsupported named-choice HTTP400 is a separate unrun control. Vision uses the original cube-hero PNG only when the exact model config declares vision, and must stay cold.

Read-only M5 inventory found Python3/codesign/xcrun/git, existing canonical config version3/hash `7236c7a23df7314a3504c484c52b2af596b97bf163c8a16f9836e9e3bcc9e3c1`, no retired telemetry files, no running darkbloom daemon, and an unentitled CLI. The old Gemma assistant install path was absent; its correct flat path is the verified final payload's `gemma-assistant`. Q38/GPT/Gemma target discovery already selects the exact snapshots. Q35/Q36 require the temporary aliases below. Inventory is evidence at one time; execution rechecks relevant preconditions.

The launcher rejects inherited serving/numerics/cache policy overrides, including SSD limits, resident-cache flags, persistent-key flags, activation/reserve/cap controls, prefill/decode/MTP switches and MLX environment settings. It changes only the child environment. `Suite.EnableEphemeralPrefixCache` explicitly sets **both** `DARKBLOOM_PREFIX_CACHE_ALLOW_EPHEMERAL=1` and a unique per-provider `DARKBLOOM_PREFIX_CACHE_TEST_ROOT`; it must not repeat the standalone wrapper's earlier TEST_ROOT-only error. Resident caching stays unset, persistent-key overrides are absent. This is ephemeral fixture validation, not attestation or restart durability evidence.

## Commands for the sole validation lane

Transfer/extract the verified package into the new directory `/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http1`. Do not overwrite an existing directory. Run `python3 verify_package.py` there first. Root/validator must own an idle, thermally suitable model window and confirm no ranked/foreign model job is active; the scripts never stop foreign jobs.

Create the two exact discovery aliases **only if their model roots are absent**. The script streams every manifest-file hash, rechecks idle state immediately afterward, uses exclusive mkdir and a random ownership marker outside the model payload, and writes a durable journal. It creates no model copy and never edits a target file, host config, daemon or keychain. Root reviewed the mechanism; the final script hash is in the package manifest.

```sh
cd /Users/gaj/autoresearch/radix-prefix-cache/090-connected-http1
mkdir alias-journals
python3 temporary_model_alias.py create --manifest manifests/qwen36.json --target /Users/gaj/autoresearch/radix-prefix-cache/qwen35b/models/qwen3.6-35b-a3b-vl-mtp-mxfp8/73a03825c2226177f3e679210965dba3508cdee8 --journal alias-journals/qwen36.json
python3 temporary_model_alias.py create --manifest manifests/qwen35.json --target /Users/gaj/autoresearch/radix-prefix-cache/qwen35b/models/qwen3.5-35b-a3b/8964653177a21be79662d51e69fe6a2263ffabb3 --journal alias-journals/qwen35.json
```

Run one paired model at a time, with the same bundle and runtime. `preflight` performs no inference and may be run first; `run` repeats it, executes only the named connected test, preserves partial evidence, verifies owned process-group retirement and rehashes the target/runtime/config afterward. Existing output is refused. The full list of ten cells is in `bundle-plan.json`.

```sh
python3 run_connected_fixture.py preflight --cell qwen36-paged-off-b1
python3 run_connected_fixture.py run --cell qwen36-paged-off-b1
python3 run_connected_fixture.py run --cell qwen36-paged-ssd-b1
python3 compare_connected_cache_http.py runs/qwen36-paged-off-b1-run/evidence/report.json runs/qwen36-paged-ssd-b1-run/evidence/report.json --output runs/qwen36-paired-comparison.json
```

Replace `qwen36` with `qwen35`, `qwen38`, `gpt-oss-20b`, or `gemma-4-26b` for the other pairs. No cell runs automatically, and no result is currently passed. A failure remains failed with later cells unrun. Keep both raw reports, launch records, coordinator/WS/HTTP correlation and canonical config/artifact postflight hashes. The same-host reports preserve the existing HTTP limitation: generated token IDs are unavailable, while raw SSE content/reasoning/tools/counts/finish are retained.

On normal completion the wrapper sends no signal to an empty group. On abnormal Go exit or interrupt it drains only the newly created session's process group with bounded INT→TERM→KILL; it never uses global name-kills. A focused subprocess test proves cleanup of an ignoring descendant without touching an unrelated group. An interrupted or timed-out cell never becomes a pass. The original report may remain partial if Go exits before its cleanup, and that evidence is preserved.

After both affected model pairs and all their owned children stop, retire the aliases. Cleanup verifies the exact journal/marker/symlink and refuses foreign entries or changed paths. It uses only unlink/rmdir, never recursive deletion; journals remain as evidence. Do not remove the empty default-cache namespace discovered during the earlier standalone failed run.

```sh
python3 temporary_model_alias.py cleanup --journal alias-journals/qwen36.json
python3 temporary_model_alias.py cleanup --journal alias-journals/qwen35.json
```

Nine Go connected helper functions passed in the compiled artifact; nine Python package/lifecycle tests passed. CPU token plans passed for all five artifacts. These validate fixture preparation, not real HTTP cache behavior. No aliases were created on M5 and no connected inference ran during preparation.
