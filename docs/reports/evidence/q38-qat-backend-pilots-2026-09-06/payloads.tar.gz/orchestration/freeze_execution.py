"""Copy owned text evidence after an idle completed group; retain SSD payloads on M5."""
from pathlib import Path
import hashlib,json,subprocess,sys,tarfile
BASE=Path('/tmp/darkbloom-q38-qat-backend-pilots1')
label=sys.argv[1]
assert label in ('qwen38-group1','qat-group1','failed-cell1')
evidence=BASE/('execution-'+label);evidence.mkdir()
remote=r'''
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,subprocess,sys,tarfile
root=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-q38-qat-backend-pilots1')
label=sys.argv[1]
sys.path.insert(0,str(root));import pilot_cells as pilot
m=pilot.matrix
plan=pilot.load_plan();binding=m.verified_bindings(root/'bindings.reviewed.json');pilot.require_owned_results_root(binding)
active=[line.strip() for line in subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines() if re.search(r'Runner\.Worker|benchctl measure-job|measure-job\.sh|(^|/)radix-engine( |$)|run_radix_engine\.py|run_radix_http\.py|(^|/)darkbloom( |$)|macmon pipe',line)]
assert not active,'Cannot freeze active measured process'
collection=pilot.collect(plan,binding)
def identity(path):return {'sha256':m.sha256(path),'bytes':path.stat().st_size,'mode':oct(path.stat().st_mode&0o777)}
receipt={'utc':datetime.now(timezone.utc).isoformat(),'processes':active,'binding':identity(root/'bindings.reviewed.json'),'binary':identity(Path(binding['binary']['path'])),'canonical_matrix3_absent':not root.with_name('090-repeated-matrix3').exists(),'collection':collection}
with (root/('group-'+label+'.json')).open('x') as out:json.dump(receipt,out,indent=2);out.write('\n')
names=['preflight-before-stage.json','staging-receipt.json','runtime-and-payload-receipt1.json','bindings.reviewed.json','root-review.json']
names += [p.name for p in root.iterdir() if p.is_file() and p.name.startswith(('readiness-','launch-','wrapper-','postflight-','collection-after-','group-'))]
paths=[root/name for name in names]
paths += [p for p in (root/'runs').rglob('*') if p.is_file() and 'prefix-cache' not in p.relative_to(root).parts]
with tarfile.open(fileobj=sys.stdout.buffer,mode='w|') as tar:
 for path in sorted(paths):tar.add(path,arcname=str(path.relative_to(root)),recursive=False)
'''
ssh=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99','/Applications/Xcode.app/Contents/Developer/usr/bin/python3 -B - '+label]
archive=evidence/'evidence.tar'
with archive.open('xb') as out:subprocess.run(ssh,input=remote.encode(),stdout=out,check=True)
payload=evidence/'payload';payload.mkdir()
with tarfile.open(archive) as tar:
 for member in tar.getmembers():
  name=Path(member.name);assert member.isfile() and not name.is_absolute() and '..' not in name.parts
  path=payload/name;path.parent.mkdir(parents=True,exist_ok=True)
  with path.open('xb') as out:out.write(tar.extractfile(member).read())
  path.chmod(member.mode)
# Re-run unchanged strict validators independently over the copied raw files.
sys.path.insert(0,str(BASE/'package'));import pilot_cells as pilot
binding=pilot.matrix.read(payload/'bindings.reviewed.json')
assert pilot.matrix.sha256(payload/'bindings.reviewed.json')=='073dbc2123892971a4581c66a7abeeb5276fd749b639fa0756e0d4d253d23f28'
binding['results_root']=str(payload/'runs')
collection=pilot.collect(pilot.load_plan(),binding)
remote_collection=pilot.matrix.read(payload/('group-'+label+'.json'))['collection']
assert collection==remote_collection,'Local validation changed from remote validation'
(evidence/'independent-collection.json').write_text(json.dumps(collection,indent=2,sort_keys=True)+'\n')
summary=[]
memory_keys=('process_rss_bytes','mlx_memory','process_memory','idle_observation','capacity',
             'production_grant','resident_bank_budget_bytes','memory_cache_enabled','key_mode','cache_mode','mtp')
for path in sorted((payload/'runs').glob('*/report.json')):
 report=pilot.matrix.read(path)
 rows=[]
 for row in report.get('rows',[]):
  item={key:row.get(key) for key in ('id','prompt_tokens','completion_tokens','finish','ttft_s','decode_tps',
    'cache_outcome','matched_tokens','saved_tokens','ssd_stage_disposition')}
  item['memory_measurement_scope']='Exact reported before/after row samples; MLX peak_bytes is cumulative process peak observed at that sample, not an isolated per-row peak'
  for phase in ('metrics_before','metrics_after'):
   item[phase]={key:row.get(phase,{}).get(key) for key in memory_keys}
  rows.append(item)
 summary.append({'cell':path.parent.name,'status':report.get('status'),'model_hash':report.get('verified_model_hash'),
  'actual_settings':{key:report.get(key) for key in ('mtp','production_grant','requested_backend','resolved_backend',
    'max_concurrent_requests','cache_mode_requested','key_mode_requested','kv_grant_mode','kv_budget_bytes')},
  'rows':rows})
(evidence/'row-summary.json').write_text(json.dumps(summary,indent=2,sort_keys=True)+'\n')
files={str(p.relative_to(evidence)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(evidence.rglob('*')) if p.is_file() and p!=archive}
manifest={'scope':'Owned raw pilot evidence; no cache payload export; local strict collection exactly matches remote','archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':files}
(evidence/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'evidence':str(evidence),'manifest_sha256':hashlib.sha256((evidence/'manifest.json').read_bytes()).hexdigest(),'archive_sha256':manifest['archive_sha256'],'files':len(files),'bytes':sum(x['bytes'] for x in files.values()),'cells':collection['cells'],'pairs':[{k:p.get(k) for k in ('id','state','passed','errors')} for p in collection['comparisons']],'process_errors':collection['process_order_errors']},indent=2))
