# Independent source review of recurrent teacher forcing

Review target: `8344e8bdc44c57e09527467a5dc5c415a8f90010` in `/Users/gaj/Documents/DarkbloomDev/wt/teacher-recurrent-scoring-native`, based on `32206d90ff69b4f42bb7703a18ac88e317358b8a`. Integration target: `30ca217c5072c727d0eff29dc92789af5e98f2c9`.

## Verdict

The state-routing correction and retirement ordering look sound from source. The patch applies cleanly to the primary target without changing its corrected MLX pin. It is suitable for integration and GPU correctness validation with explicit memory headroom, but I do not give unconditional final approval: teacher scoring undercounts recurrent peak capacity (P2 below). Fix that accounting before treating the new path as capacity-safe.

No primary files were edited. No Swift build, compiler invocation, GPU execution, remote operation, or M5 call was made during this review. The reserved validation lane remained untouched.

## Actionable finding

**P2 — Teacher allocation checks only one recurrent generation while bypassing the peak reservation.**

- Changed call site: `Libraries/MLXLMCommon/ContinuousBatchingV2/EngineLoopV2.swift:2692`.
- The reused helper at `EngineLoopV2.swift:4441-4453` checks `backend.bytesReserved + existingRecurrentBytes + recurrent.byteCount`. `byteCount` is the single-generation `fixedBytesPerRequest()` at `RecurrentStateV2.swift:300-303`.
- Ordinary `EngineV2` admission separately reserves three recurrent generations, with allocator-aware per-generation pricing for segmented storage (`EngineV2.swift:270-300`). `scoreTeacherForced` enters neither that admission reservation nor the scheduler.
- After the first successful teacher forward, the next evaluation retains the committed input in `CBv2RecurrentStateEvaluation.input` while its output is pending in the owner (`RecurrentStateV2.swift:362-405`, `519-546`). `finishForward` evaluates that output before committing it (`EngineLoopV2.swift:2714-2719`). Thus at least two generations can coexist even though only one was checked. This is also explicitly reflected by the state's `materializedByteCount` calculation (`RecurrentStateV2.swift:244-268`).
- Concrete bound: let KV reservations be V and one recurrent generation be F. A budget C satisfying `V + F <= C < V + 2F` is accepted by this new path even though a subsequent forward can exceed it. Normal admission would refuse its larger peak obligation. Segmented allocation rounding can widen the discrepancy.
- Requested change: establish a call-scoped, target-only recurrent peak obligation before forwarding, including allocator footprint accounting when applicable. Either reuse the normal target recurrent admission projection conservatively or explicitly prove and price the teacher path's smaller maximum overlap. Release that obligation along with the private row on every exit. Do not rely on this single-generation helper as the full admission check.
- Regression: on each backend, use a recurrent fixture and a budget where KV plus one generation fits but the required peak does not; assert refusal before model forwarding and zero retained KV/reservation state. The new tests' 64 MiB capacity does not exercise this boundary.

This finding concerns the newly added teacher use of the helper. Ordinary serving already has the separate peak admission reservation; this patch does not introduce a new ordinary-serving capacity regression.

## Other reviewed behavior

- **Normal serving:** `targetForward` still binds exactly the request IDs supplied by its callers, returns the same ID/evaluation mapping, and passes positions, embeddings, and prefill requirements unchanged. The extracted `recurrentTargetForward` retains the old dispatch branches and evaluation-root collection. I found no changed ordinary forward semantics in the extraction.
- **Allocation failure:** KV allocation precedes recurrent allocation, but the `defer` is installed before `makeRecurrentRequestState`. A thrown recurrent allocation releases the KV row on both backends.
- **Continuity:** one call-owned recurrent state is shared by every prompt chunk and forced decode. Each successful forward evaluates KV roots, recurrent roots, and scoring roots before committing. The next bind therefore reads the preceding state; each new teacher call begins with empty committed state.
- **Failure retirement:** a paged forward fault throws from `checkedModelForward` before recurrent `evaluate()` or scoring can run. Cleanup synchronizes already-submitted work, drops the local evaluation (abandoning an open bind), discards pending generations, and releases the owner. Geometry errors after evaluation synchronize the valid graph and then retire the entire private request. Committing or individually rolling back that doomed private request is unnecessary.
- **Paged cleanup:** the existing saved write-fence boundary restores the valid graph on a paged fault. Bound cache rows are released before pages are recycled and the fault latch is cleared only after retirement. Contiguous cleanup unregisters the private row and its reservations. No retained teacher evaluation is inserted into the scheduler's recurrent dictionary.
- **Synchronization:** the teacher path now waits per forward for recurrent models. This is a throughput change confined to teacher scoring; it does not add waits to normal serving. Actual GPU equivalence remains unproven until execution.

## Test adequacy and remaining execution

The four new parameterized cases (dense/MoE x contiguous/paged) use real tiny Qwen trunks. They verify ordinary greedy replay, exact prompt/forced input calls, chunk lengths, recurring input presence, plain/diagnostic/repeated output equivalence, context metadata, and KV cleanup after a geometry failure. The plain-forward sentinel would expose the original missing-recurrent route.

The geometry failure at `CBv2TeacherForcedRecurrentTests.swift:175-178` occurs after recurrent evaluation. It does not exercise the open-binding failure path from a paged dtype fault. Existing `CBv2PagedRuntimeDTypeTests.swift:248-265` tests teacher faults only with `recurrent: false`; parameterizing that test over recurrent true/false would cover the newly exposed failure combination. Backend byte counters alone do not directly inspect recurrent release, although source ordering looks correct.

The call-shape assertions currently assume prefill narrowing is enabled. A process launched with `DARKBLOOM_CBV2_PREFILL_NARROWING=0` should exercise the full recurrent fallback, but the test's unconditional `prefill == true` expectation would reject that valid route. Use a separate fallback expectation for any planned A/B run.

The author's handoff reports syntax parsing and test typechecking only. I did not repeat those commands or run tests. Runtime acceptance still needs the four new hybrid cases and the relevant existing teacher/recurrent/paged-fault coverage on the combined corrected runtime; physical-model teacher validation remains outstanding.

## Integration evidence

`integration-check.json` records a successful application to a temporary Git index loaded from `30ca217`; the worktree and primary index were untouched. Both resulting changed files exactly match `8344e8b`. `Package.swift` exactly matches `30ca217`, retaining MLX Swift `c06149b4f7defa1b958c1e175f6c9a12c86c8a4f`. No dependency or package changes are needed to integrate this commit. `git diff --check` also passed.
