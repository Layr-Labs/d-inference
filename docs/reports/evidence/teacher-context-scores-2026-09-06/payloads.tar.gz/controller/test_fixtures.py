from pathlib import Path
import copy
import json
import shutil
import sys

from common import ROOT, digest, identity, read_json
from controller import SOURCE_FILES


def save(path, value):
    path.write_text(json.dumps(value))


def fixture(root, mode='normal'):
    for name in SOURCE_FILES:
        shutil.copy2(ROOT / name, root / name)
    (root / 'inputs').mkdir()
    (root / 'config').mkdir()
    plan = copy.deepcopy(read_json(ROOT / 'plan.json'))
    for key, model in plan['models'].items():
        target = root / ('model-' + key)
        target.mkdir()
        (target / 'config.json').write_text('{}')
        (target / 'weights.safetensors').write_bytes(b'CPU placeholder, never loaded')
        model.update(model_directory=str(target), prompt_tokens=2, continuation_tokens=2)
        value = {'modelID': model['model_id'], 'expectedModelAggregateSHA256': model['model_sha256'], 'promptTokens': [1, 2], 'continuation': [3, 4]}
        save(root / model['input'], value)
        model['input_sha256'] = digest(root / model['input'])
        shutil.copy2(ROOT / model['config'], root / model['config'])
    ready = {'unix_time': 1, 'processes': [], 'gpu_temp_c': 30, 'load': [0, 0, 0], 'free_disk_bytes': 100 << 30,
             'username': 'gaj', 'ipv4_addresses': ['100.124.35.99'], 'hardware_model': 'Mac17,6', 'memory_bytes': 128 << 30}
    (root / 'readiness.py').write_text('import json\nprint(json.dumps(' + repr(ready) + '))\n')
    (root / 'foundation_home.py').write_text('import json,os\nprint(json.dumps({"foundation_home":os.environ["CFFIXED_USER_HOME"]}))\n')
    artifact = root / 'artifact'
    artifact.mkdir()
    (artifact / 'mlx.metallib').write_bytes(b'CPU placeholder metallib')
    program = '''import hashlib,json,os,signal,subprocess,sys,time
from pathlib import Path
mode=__MODE__
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
if mode in ('descendant','timeout','signals'):
    ready=Path(__READY__)
    child_source='import signal,time;from pathlib import Path;signal.signal(signal.SIGTERM,signal.SIG_IGN);Path('+repr(str(ready))+').write_text("ready");time.sleep(120)'
    child=subprocess.Popen([sys.executable,'-c',child_source])
    deadline=time.monotonic()+5
    while not ready.exists() and time.monotonic()<deadline:time.sleep(.01)
    if not ready.exists():raise RuntimeError('child signal handler did not become ready')
    Path(__MARKER__).write_text(json.dumps({'leader':os.getpid(),'child':child.pid}))
    if mode!='descendant':time.sleep(120)
arguments=sys.argv
value=json.loads(Path(arguments[arguments.index('--teacher-forced-input')+1]).read_text())
model=value['modelID'];backend=arguments[arguments.index('--kv-backend')+1]
records=[]
for index,token in enumerate(value['continuation']):
    row={'index':index,'contextLength':len(value['promptTokens'])+index,'forcedToken':token,'argMaxID':7,'nanCount':0,'infiniteCount':0,'topTwoValueBits':[1056964608,1056964608]}
    for name in ('argMaxValueBits','forcedTokenValueBits','logSumExpBits','forcedLogProbabilityBits','nllBits','topTwoMarginBits'):row[name]=1056964608
    records.append(row)
diagnostic={'records':records,'top1':[7]*len(records)}
report={'schema':1,'scope':'ordinary_teacher_forced_scores','status':'observed','inconclusiveReasons':[],'input':value,
        'inputSHA256':digest(Path(arguments[arguments.index('--teacher-forced-input')+1])),
        'verifiedModelAggregateSHA256':value['expectedModelAggregateSHA256'],'executableSHA256':digest(Path(__file__)),
        'metallibSHA256':digest(Path(__file__).parent/'mlx.metallib'),
        'modelDirectory':str(Path(os.environ['CFFIXED_USER_HOME'])/'.cache/huggingface/hub'/('models--'+model.replace('/','--'))/'snapshots/local'),
        'resolvedBackend':backend,'cacheMode':'off','mtpEnabled':False,'concurrency':1,
        'gemmaOptimizations':{'prefill_layer18':True,'weighted_r1':True},
        'productionGrant':{'slotCount':1,'assistantWeightBytes':0,'ramPrefixAllowanceBytes':0,'grantBytes':123},'kvCapacityBytes':123,
        'plainTop1':diagnostic['top1'],'diagnostic':diagnostic,'repeatedDiagnostic':diagnostic,
        'activity':[{'prefillChunks':1,'decodeForwards':len(records)-1}]*3,'meanForcedTokenNLL':0.5}
if mode=='malformed':print('{broken')
elif mode=='nonzero':sys.exit(3)
else:print(json.dumps(report))
'''.replace('__MODE__', repr(mode)).replace('__MARKER__', repr(str(root / 'descendant.json'))).replace('__READY__', repr(str(root / 'child-ready')))
    executable = artifact / 'darkbloom'
    executable.write_text('#!' + sys.executable + '\n' + program)
    executable.chmod(0o755)
    runtime = {'files': {path.name: identity(path) for path in artifact.iterdir()}, 'source': {'parent': 'a' * 40, 'native': 'b' * 40}}
    save(root / 'runtime-manifest.json', runtime)
    plan['files'] = {name: identity(root / name) for name in sorted(SOURCE_FILES | {model[key] for model in plan['models'].values() for key in ('input', 'config')})}
    save(root / 'plan.json', plan)
    binding = {'schema': 2, 'state': 'peer_reviewed', 'plan_sha256': digest(root / 'plan.json'), 'execution_root': str(root),
               'target_host': 'gaj@100.124.35.99', 'host_identity': {'hardware_model': 'Mac17,6', 'memory_bytes': 128 << 30},
               'timeout_seconds': 1 if mode == 'timeout' else 60, 'required_metallib_sha256': runtime['files']['mlx.metallib']['sha256'],
               'runtime': {'artifact_root': str(artifact), 'source_manifest': str(root / 'runtime-manifest.json'),
                           'source_manifest_sha256': digest(root / 'runtime-manifest.json'),
                           'source_manifest_identity': identity(root / 'runtime-manifest.json'), **runtime}}
    save(root / 'binding.json', binding)
    return plan, binding


def invocation(root, cell='qwen36-contiguous'):
    flags = ['-O'] if sys.flags.optimize else []
    return [sys.executable, '-B', *flags, str(root / 'controller.py'), cell, '--binding', str(root / 'binding.json'), '--binding-sha256', digest(root / 'binding.json')]
