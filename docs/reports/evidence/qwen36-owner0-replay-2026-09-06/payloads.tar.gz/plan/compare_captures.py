"""Exact native comparisons to both captures; numerical metrics are descriptive."""
import numpy as np

from attention_packet.files import require
from attention_packet.native import ITEM_BYTES, decode
from attention_packet.reference import compare

INPUTS = ("queries", "incomingKeys", "incomingValues", "storedKeys", "storedValues")
SELECTION = ("requestID", "outputIndex", "phase", "storageLayerIndex", "modelLayerIndex",
             "offsetBefore", "offsetAfter", "scaleBits")


def require_common_input(left, right):
    require(not left.inconclusive_reasons and not right.inconclusive_reasons,
            "both original packets must be confirmed and complete")
    require(left.document["identity"]["backend"] == "contiguous"
            and right.document["identity"]["backend"] == "paged", "capture backend identities differ")
    for key in ("artifactSHA256", "inputSHA256", "modelID"):
        require(left.document["identity"][key] == right.document["identity"][key],
                "capture identity differs: " + key)
    require(left.document["geometry"] == right.document["geometry"], "capture geometry differs")
    for key in SELECTION:
        require(left.record[key] == right.record[key], "selected context differs: " + key)
    require(left.snapshot["seedToken"] == right.snapshot["seedToken"], "selected seed differs")
    for name in INPUTS:
        a, b = left.tensors[name], right.tensors[name]
        for key in ("dtype", "shape", "packedStrides", "byteOrder"):
            require(a.descriptor[key] == b.descriptor[key], "native descriptor differs: " + name)
        require(a.raw == b.raw, "captured common input differs: " + name)
    a, b = left.tensors["output"], right.tensors["output"]
    require(a.descriptor["dtype"] == b.descriptor["dtype"]
            and a.descriptor["shape"] == b.descriptor["shape"], "capture output layout differs")
    return {"commonInputNames": list(INPUTS), "scaleBits": left.record["scaleBits"],
            "selection": {key: left.record[key] for key in SELECTION},
            "seedToken": left.snapshot["seedToken"],
            "packetSHA256": {"contiguous": left.packet_sha256, "paged": right.packet_sha256}}


def native_comparison(actual_raw, reference_raw, descriptor):
    item_bytes = ITEM_BYTES[descriptor["dtype"]]
    count = int(np.prod(descriptor["shape"]))
    require(len(actual_raw) == len(reference_raw) == count * item_bytes,
            "native comparison byte length differs")
    native_type = "<u4" if item_bytes == 4 else "<u2"
    unequal = np.frombuffer(actual_raw, native_type) != np.frombuffer(reference_raw, native_type)
    actual = decode(actual_raw, descriptor["dtype"], descriptor["shape"])
    reference = decode(reference_raw, descriptor["dtype"], descriptor["shape"])
    return {"comparedNativeElements": count, "mismatchedNativeElements": int(np.count_nonzero(unequal)),
            "byteIdentity": actual_raw == reference_raw, "float32DecodedComparison": compare(actual, reference)}


def compare_output_to_both(raw, left, right):
    require_common_input(left, right)
    return {name: native_comparison(raw, packet.tensors["output"].raw,
                                   packet.tensors["output"].descriptor)
            for name, packet in (("contiguous", left), ("paged", right))}
