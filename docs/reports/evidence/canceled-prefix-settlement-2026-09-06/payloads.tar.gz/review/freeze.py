#!/usr/bin/env python3
"""Freeze reviewed source, negative controls and final provider validation."""
from pathlib import Path
import collections, gzip, hashlib, io, json, re, shutil, subprocess, tarfile

OUT = Path('/tmp/darkbloom-provider-cancel-settlement-bank1')
WT = Path('/Users/gaj/Documents/DarkbloomDev/wt/provider-cancel-settlement-milestone')
PRIMARY = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
FINAL = Path('/tmp/darkbloom-provider-cancel-settlement-validation5')
SOURCE = Path('/tmp/darkbloom-provider-cancel-settlement-source6')
OUT.mkdir(exist_ok=False)
PAYLOAD = OUT / 'payloads'
PAYLOAD.mkdir()
origins = {}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write(rel, data):
    p = PAYLOAD / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(data)
    return p

def put(rel, path):
    assert path.is_file() and not path.is_symlink(), path
    write(rel, path.read_bytes())
    origins[rel] = str(path)

def dump(rel, value):
    return write(rel, (json.dumps(value, indent=2, sort_keys=True)+'\n').encode())

def git(repo, *args):
    return subprocess.check_output(['git','-C',str(repo),*args])

for n in range(1,7):
    root = Path('/tmp/darkbloom-provider-cancel-settlement-source'+str(n))
    manifest = json.loads((root/'manifest.json').read_text())
    for row in manifest['files']:
        p = root/row['path']
        assert len(p.read_bytes()) == row['bytes'] and sha(p.read_bytes()) == row['sha256'], p
        put(f'source{n}/'+row['path'], p)
    put(f'source{n}/manifest.json', root/'manifest.json')

for n in range(1,6):
    root = Path('/tmp/darkbloom-provider-cancel-settlement-validation'+str(n))
    # Only immediate proof files: never descend into workspace/native/build trees.
    for folder in (root,root/'baseline',root/'candidate'):
        for p in sorted(folder.iterdir()):
            if p.is_file() and not p.is_symlink():
                assert p.suffix in ('.json','.py','.patch','.log','.gz'), p
                if p.suffix == '.gz':
                    assert p.name.endswith('.yaml.gz'), p
                    gzip.decompress(p.read_bytes()).decode()
                else:
                    p.read_text()
                put(f'validation{n}/'+str(p.relative_to(root)),p)

for name in ('darkbloom-provider-cancel-settlement-root-source-review2.json',
             'darkbloom-provider-cancel-settlement-root-preparation-review.json',
             'darkbloom-provider-cancel-settlement-source5-baseline-freeze1/manifest.json'):
    p = Path('/tmp')/name
    put('reviews/'+name.replace('/','-'),p)

candidate = FINAL/'candidate'
identifiers = [x for x in (candidate/'identifiers.log').read_text().splitlines()
               if re.match(r'\w+Tests\.',x)]
groups = []
for row in json.loads((candidate/'executions.json').read_text())[2:]:
    name = row['name']
    raw = (candidate/(name+'.log')).read_text()
    count = int(re.findall(r'Test run with (\d+) tests? .*passed',raw)[-1])
    exact = [x for x in identifiers if name in x]
    if name == 'EngineV2LivenessRecoveryTests':
        # Swift filter runs both suites in this file; raw log proves overlap.
        assert 'Suite "EngineV2 liveness: confirmed-wedge verdict + reloading state"' in raw
        exact += [x for x in identifiers if 'EngineV2LivenessVerdictTests' in x]
    assert len(exact) == count and row['exit_code'] == 0 and row['nonzero_no_skips']
    assert sha(raw.encode()) == row['log_sha256']
    assert not re.search(r'(?:◇|✘|✔).*\bskipped\b',raw)
    groups.append({'filter':name,'functions_executed':count,'identifiers':exact,
                   'log_sha256':row['log_sha256'],'status':'PASS'})
unique = sorted({x for g in groups for x in g['identifiers']})
assert len(groups)==15 and sum(g['functions_executed'] for g in groups)==76 and len(unique)==73
baseline = (FINAL/'baseline/ProviderCancelledPrefixCacheTests.log').read_text()
issues = [x for x in baseline.splitlines() if 'recorded an issue' in x]
issue_lines = collections.Counter(re.search(r'Tests.swift:(\d+):',x).group(1) for x in issues)
assert issue_lines == collections.Counter({'132':2,'134':2,'162':2,'163':2,'165':2,'166':2})
dump('review/exact-test-results.json',{
    'baseline':{'status':'EXPECTED_ORDERING_FAILURE','function_count':1,'argument_cases':2,
                'issues':12,'issue_lines':dict(issue_lines),
                'log_sha256':sha(baseline.encode()),
                'required_preconditions':'normal donor output/completion, actual first content, native SSD hit512 or miss0, delivered billing and cleanup all passed'},
    'candidate':{'status':'PASS','filters':groups,'function_executions':76,'distinct_identifiers':73,
                 'overlap':'Three verdict functions also execute under recovery filter.',
                 'unique_identifiers':unique},
    'limits':['Synthetic tiny model through real encrypted handler and native paged engine; no real-model HTTP rerun.',
              'Test counts are functions, not parameterized argument cases.',
              'Native pinned to 5cb848d, not current e972340.']})

base = '5b93195c93efce01a4d455f8e2d0f04e68268096'
current = git(WT,'rev-parse','HEAD').decode().strip()
native_base = '5cb848dfdaae04118ecfa901f53fc21a4aa86a06'
native_current = 'e972340a7ba6e22fda5d8be1a7af918f9bf67b03'
summary = json.loads((SOURCE/'summary.json').read_text())
correspondence = []
for rel in summary['candidate_files']:
    frozen = (SOURCE/'candidate'/rel).read_bytes()
    compiled = (candidate/'workspace'/rel).read_bytes()
    integrated = (WT/rel).read_bytes()
    assert frozen == compiled == integrated, rel
    item = {'path':rel,'sha256':sha(frozen),'frozen_equals_compiled_equals_integration':True}
    before = SOURCE/'before'/rel
    if before.exists():
        assert before.read_bytes() == git(WT,'show',current+':'+rel)
        item['preimage_equals_integration_parent'] = True
    correspondence.append(item)
native_diff = git(PRIMARY/'libs/mlx-swift-lm','diff',native_base,native_current)
write('review/native-5cb-to-e972.patch',native_diff)
write('review/native-5cb-to-e972-paths.txt',git(PRIMARY/'libs/mlx-swift-lm','diff','--name-status',native_base,native_current))
write('review/provider-5b-to-integration-parent-paths.txt',git(WT,'diff','--name-status',base,current,'--','provider-swift'))
dump('review/integration-correspondence.json',{
    'tested_provider_base':base,'integration_parent':current,
    'tested_native':native_base,'integration_native':native_current,
    'files':correspondence,'native_delta_sha256':sha(native_diff),
    'scope':'Current native adds bounded attention diagnostics and owner identity plus tests. Cancellation test run used explicit 5cb archive in both variants; no test claim on e972.',
    'final_after_source_checks':json.loads((candidate/'source-verified-after.json').read_text())})
put('review/freeze.py',Path(__file__))

files=[]
for p in sorted(PAYLOAD.rglob('*')):
    if p.is_file():
        rel = str(p.relative_to(PAYLOAD))
        row = {'path':rel,'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
        if rel in origins:
            row['original_path']=origins[rel]
        files.append(row)
archive = OUT/'payloads.tar.gz'
with archive.open('wb') as f:
    with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for row in files:
                data=(PAYLOAD/row['path']).read_bytes()
                item=tarfile.TarInfo(row['path']); item.size=len(data); item.mode=0o644
                item.mtime=0; item.uid=0; item.gid=0; item.uname=''; item.gname=''
                tar.addfile(item,io.BytesIO(data))
manifest={'schema_version':1,'status':'FINAL_BASELINE_REPRODUCED_CANDIDATE_PASS',
          'archive':{'path':'payloads.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},
          'payload_count':len(files),'payload_bytes':sum(r['bytes'] for r in files),
          'files':files,'excluded':'No executables, metallibs, weights, keys or full workspace/dependency trees. Compressed YAML contains source graph text only.'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
dest=WT/'docs/reports/evidence/canceled-prefix-settlement-2026-09-06'
dest.mkdir(parents=True,exist_ok=False)
for name in ('manifest.json','payloads.tar.gz'):
    shutil.copyfile(OUT/name,dest/name)
print(json.dumps({'payload_count':len(files),'archive':manifest['archive'],
                 'manifest_sha256':sha((OUT/'manifest.json').read_bytes())},indent=2))
