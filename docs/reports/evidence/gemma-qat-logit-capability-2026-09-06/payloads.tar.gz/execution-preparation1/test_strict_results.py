"""CPU-only synthetic logit packets; no model evidence is produced here."""
from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

from strict_results import logit_errors, result_errors

PLAN_ROOT = Path('/tmp/darkbloom-qat-actual-logits-plan1')
PLAN = json.loads((PLAN_ROOT / 'plan.json').read_text())
BINDING = json.loads(Path('/tmp/darkbloom-qat-actual-logits-runtime-binding1.json').read_text())


def sample():
    r = json.loads((PLAN_ROOT / 'historical/contiguous-report.json').read_text())
    r['runtime_identity']['binary_sha256'] = BINDING['artifacts']['radix-engine']['sha256']
    packet = {'requestID': 2, 'outputIndex': 7, 'outputBase': 6, 'phase': 'mtp_verify',
              'batchIndex': 0, 'batchSize': 1, 'column': 1, 'verificationWidth': 2,
              'draftDepth': 1, 'cacheOffset': 5423, 'backend': 'ContiguousKVBackend',
              'logitDType': 'bfloat16', 'vocabularySize': 262144, 'seedToken': 3605,
              'outcome': 'confirmed', 'acceptedDrafts': 1, 'confirmedWidth': 2,
              'draftPrefix': [529], 'targetToken': 42392, 'argMaxID': 42392,
              'topTwoIDs': [42392, 62203], 'candidateIDs': [42392, 62203],
              'valueBits': [1102839808] * 5, 'nanCount': 0, 'infiniteCount': 0}
    r['logit_diagnostic'] = {'status': 'captured', 'snapshot': {
        'configuration': {'requestID': 2, 'outputIndex': 7, 'candidateIDs': [42392, 62203]},
        'records': [packet], 'reservedRecords': 1, 'invalidVocabularyRecords': 0,
        'omittedRecords': 0}}
    return r


class StrictMTPContextTests(unittest.TestCase):
    def packet(self, report):
        return report['logit_diagnostic']['snapshot']['records'][0]

    def test_confirmed_mtp_column_uses_seed_and_draft_history(self):
        self.assertEqual(logit_errors(sample()), [])

    def test_last_prior_token_is_wrong_seed_for_multi_column_verification(self):
        r = sample(); self.packet(r)['seedToken'] = 529
        self.assertTrue(logit_errors(r))

    def test_changed_draft_history_or_cache_offset_is_rejected(self):
        for field, value in [('draftPrefix', [530]), ('cacheOffset', 5424)]:
            with self.subTest(field=field):
                r = sample(); self.packet(r)[field] = value
                self.assertTrue(logit_errors(r))

    def test_unconfirmed_or_ambiguous_decision_is_rejected(self):
        r = sample(); self.packet(r)['outcome'] = 'speculative_suffix'
        self.assertTrue(logit_errors(r))
        r = sample(); s = r['logit_diagnostic']['snapshot']
        s['records'].append(deepcopy(s['records'][0])); s['reservedRecords'] = 2
        self.assertTrue(logit_errors(r))

    def test_unconfirmed_attempt_is_retained_but_not_used_as_decision(self):
        r = sample(); s = r['logit_diagnostic']['snapshot']
        extra = deepcopy(s['records'][0]); extra['outcome'] = 'speculative_suffix'
        extra['draftPrefix'] = [999]; s['records'].insert(0, extra); s['reservedRecords'] = 2
        self.assertEqual(logit_errors(r), [])

    def test_rejected_column_or_wrong_target_is_rejected(self):
        for field, value in [('acceptedDrafts', 0), ('targetToken', 62203), ('outputBase', 5), ('nanCount', 1)]:
            with self.subTest(field=field):
                r = sample(); self.packet(r)[field] = value
                self.assertTrue(logit_errors(r))

    def test_ordinary_confirmed_geometry_does_not_need_mtp_phase(self):
        r = sample(); self.packet(r).update(outputBase=7, column=0, phase='chained_decode',
            seedToken=529, draftPrefix=[], cacheOffset=5424, acceptedDrafts=0, draftDepth=0,
            confirmedWidth=1, verificationWidth=1)
        self.assertEqual(logit_errors(r), [])

    def full(self, mutate=None, paged=False):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            control = deepcopy(sample()); control.pop('logit_diagnostic')
            for c in PLAN['cells']:
                if not c['trace']:
                    p = root / c['id']; p.mkdir()
                    (p / 'report.json').write_text(json.dumps(control))
            cell = next(c for c in PLAN['cells'] if c['trace'] and c['backend'] == ('paged' if paged else 'contiguous'))
            local = root / cell['id']; local.mkdir()
            (local / 'input.json').write_bytes((PLAN_ROOT / 'inputs/gemma-qat4.json').read_bytes())
            command = next(c for c in BINDING['commands'] if c['cell'] == cell['id'])
            meta = {'command': command['expected_observed_native_argv'],
                    'source_input_sha256': PLAN['input_sha256'], 'input_sha256': PLAN['input_sha256'],
                    'binary_sha256': BINDING['artifacts']['radix-engine']['sha256'], 'exit_code': 0, 'status': 'completed'}
            report = sample()
            if paged:
                report['requested_backend'] = report['resolved_backend'] = 'paged'
            if mutate:
                mutate(report, meta, root)
            (local / 'metadata.json').write_text(json.dumps(meta))
            return result_errors(local, cell, PLAN, BINDING, report, root)

    def test_full_same_build_seven_trajectory_controls(self):
        self.assertEqual(self.full(), [])

    def test_secondary_trajectory_change_blocks_interpretation(self):
        def mutate(report, meta, root):
            report['tenant_checks'][1]['token_ids'][8] += 1
        self.assertTrue(any('same-build trajectory' in x for x in self.full(mutate)))

    def test_runtime_or_literal_canonical_input_argument_is_rejected(self):
        def runtime(report, meta, root):
            report['runtime_identity']['binary_sha256'] = '0' * 64
        def argv(report, meta, root):
            meta['command'] = list(meta['command']); meta['command'][2] = PLAN['remote_root'] + '/inputs/gemma-qat4.json'
        for mutate in (runtime, argv):
            self.assertTrue(self.full(mutate))

    def test_cross_backend_conditioning_change_blocks_interpretation(self):
        def mutate(report, meta, root):
            report['rows'][0]['prompt_token_ids'][-1] += 1
        self.assertTrue(any('backend selected prompt/prior context differs' in x for x in self.full(mutate, paged=True)))


if __name__ == '__main__':
    unittest.main()
