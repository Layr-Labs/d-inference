from pathlib import Path
import gzip, hashlib, json, os, re, shutil, subprocess, time

out = Path(__file__).resolve().parent
package = out/'native'
scratch = Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value):
    (out/name).write_text(json.dumps(value, indent=2)+'\n')

def verify():
    native = json.loads((out/'native-source-manifest.json').read_text())
    for name, digest in native['files'].items():
        assert sha(package/name) == digest, name
    deps = json.loads((out/'dependency-source-manifest.json').read_text())
    for name, digest in deps['files'].items():
        alias, relative = name.split('/', 1)
        assert sha(Path(deps['repositories'][alias])/relative) == digest, name
    jinja = json.loads((out/'jinja-source-manifest.json').read_text())
    for name, digest in jinja['files'].items():
        assert sha(scratch/'checkouts/swift-jinja'/name) == digest, name
    return {'native': len(native['files']), 'dependency': len(deps['files']),
            'jinja': len(jinja['files']), 'no_drift': True}

def graph(label):
    for name in ['debug.yaml', 'workspace-state.json']:
        path = scratch/name
        if path.exists():
            destination = out/(label+'-'+name+('.gz' if name.endswith('yaml') else ''))
            destination.write_bytes(gzip.compress(path.read_bytes(), mtime=0)
                                    if name.endswith('yaml') else path.read_bytes())

results = []
def run(name, command, test=False):
    started = time.monotonic()
    with (out/(name+'.log')).open('x') as log:
        process = subprocess.run(command, cwd=package, stdout=log, stderr=subprocess.STDOUT)
    body = (out/(name+'.log')).read_text()
    nonzero = bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test', body))
    skipped = bool(re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test', body, re.M))
    row = {'name': name, 'command': command, 'cwd': str(package),
           'exit_code': process.returncode, 'seconds': time.monotonic()-started,
           'nonzero_no_skips': not test or nonzero and not skipped}
    results.append(row)
    write('execution.json', results)
    print(json.dumps(row), flush=True)
    if not test and process.returncode:
        graph('failed-build')
        write('source-verified-after-failure.json', verify())
        raise SystemExit(process.returncode)

graph('before')
write('source-verified-before.json', verify())
write('environment.json', {k: v for k, v in os.environ.items() if k.startswith(('DARKBLOOM_MTP_', 'MLX_'))})
run('build', ['swift', 'build', '--scratch-path', str(scratch), '--build-tests', '--jobs', '4', '--disable-automatic-resolution'])
graph('actual-build')
write('source-verified-postcompile.json', verify())
text = (scratch/'debug.yaml').read_text()
changed = json.loads((out/'native-source-manifest.json').read_text())['candidate_changes']
proof = []
for name in changed:
    path = package/name
    aliases = [str(path), str(path.resolve()), str(path).replace('/tmp/', '/private/tmp/', 1)]
    actual = next((item for item in aliases if item in text), None)
    assert actual, name
    proof.append({'actual_path': actual, 'sha256': sha(path)})
assert '/checkouts/mlx-swift/Source/' not in text
write('actual-compiler-source-proof.json', {'paths': proof, 'remote_mlx_source_excluded': True, 'scope': 'Declared build graph source references; not a claim that every graph path is linked into the selected test product.'})
debug = scratch/'arm64-apple-macosx/debug'
bundle = debug/'mlx-swift-lmPackageTests.xctest/Contents/MacOS'
binary = bundle/'mlx-swift-lmPackageTests'
metallib = Path('/tmp/darkbloom-final-serving-build8/artifact/mlx.metallib')
assert sha(metallib) == '4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0'
for target in [debug/'mlx.metallib', bundle/'mlx.metallib']:
    shutil.copy2(metallib, target)
    assert sha(target) == sha(metallib)
write('test-binary.json', {'path': str(binary), 'sha256': sha(binary), 'bytes': binary.stat().st_size,
                          'metallib_sha256': sha(metallib)})
run('identifiers', ['swift', 'test', 'list', '--skip-build', '--scratch-path', str(scratch), '--disable-automatic-resolution'])
filters = json.loads((out/'filters.json').read_text())
for name in filters:
    run(name, [str(out/'run-nested-suite.sh'), name, '--scratch-path', str(scratch), '--disable-automatic-resolution'], test=True)
graph('actual-after')
write('source-verified-after.json', verify())
assert sha(binary) == json.loads((out/'test-binary.json').read_text())['sha256']
failed = [row['name'] for row in results if row['exit_code'] or not row['nonzero_no_skips']]
write('run-status.json', {'failed': failed, 'all_filters_run': len(results) == len(filters)+2})
print('FAILED FILTERS='+str(failed), flush=True)
raise SystemExit(bool(failed))
