# Segmented production grants — source review

This delta removes the unused provider eager-pool sizing policy and forwards the already admitted slot grant into empty segmented native construction. No runtime cap, operator reserve, activation floor, load transient, serviceability floor, backend default, codec eligibility or model identity changes.

## Reader and ownership map

- `ProviderLoop+EngineV2.fleetKVBudgetBytes` / standalone counterpart: budget is effective physical cap minus loaded target+assistant parameter bytes, serving-set activation reserve and optional RAM prefix allowance. Draining/loading slots remain in fleet accounting.
- `EngineV2Reslice`: one slot receives the entire fleet KV budget; co-resident grants use existing fp16 owning-full marginal-rate × capped-context weights. The existing load serviceability floor remains. Shrink precedes newcomer construction; unload/rollback restores grants.
- `EngineV2Factory+BackendPreparation`: validates positive/capped slot grant, native model capability, kill switch, kernel preflight and loaded K/V dtype probe. New `+SegmentedBackend` builds native segmented metadata with this grant, actual dtype table, normal scheduler's maximum chunk, true context and Metal per-buffer limit. No separate physical/16, live/4, 8 GiB, useful-context or 1 GiB eager pool rules remain.
- `EngineV2Factory+Production` / `EngineV2SlotFactory`: continue one shared process owner bound before the first native request/allocation. Removed only the unused internal activation argument to preparation; public compatibility signatures remain unchanged. Production cap/activation authority is the supplied budget and admitted grant.
- `EngineV2Bridge+Resizing`: `capacity.pagedStorage != nil` is native segmented capability, set at engine construction and independent of heartbeat telemetry cadence. Forward the full runtime grant. Fixed-reference pools retain clamp/shortfall behavior. Segmented committed bytes come from pagedStorage, not kvBytesBackendCapacity.
- Bridge Capacity/PrefixCache comments now describe mutable segmented ceilings; existing conservative minimum/slot-claim arithmetic is unchanged.
- Native `EngineV2.updateKVBytesCapacity` shrinks Admission before backend and grows backend before Admission. Existing `PagedKVGrant` epochs prevent stale publication. `AdmissionV2` keeps max(P,N)+A+X and process C under shrink, refusing extra charge while debt persists; nominal pages can reuse already held P without growth. Actual backing allocation is reserved before allocation and settled from allocator-owned measurements. This delta does not edit native code.

## Preserved native bounds

`PagedKVPool` validates positive capacity, page/chunk/context arithmetic, layer ownership/dtypes and window rings. `PagedKVSegmentLayout` limits each actual segment to maxBufferLength and each group's addressability to Int32.max/pageSize; checked overflow and kernel head/GQA restrictions stay authoritative. A grant is not a whole-grant Metal buffer. Empty construction has no segment/page backing; tiny lazy fence graph objects still exist, so tests do not call construction literally allocation-free.

## Tests and limitations

New configuration/Admission/process tests use all five exact model geometries from pinned config and the banked native dtype probes (GPT: layer 0 BF16, later 23 FP32). Qwen uses four allocator-bounded recurrent generations and normal MTP cache/hidden/token projections; Gemma's configured per-round drafter declares no persistent request state, which is distinct from disabling MTP. Default 2048 solo stripe (dense Qwen 4096) feeds window ring calculation.

- Qwen 3.5/3.6 B1 before-control: old 32768 × 20480 = 640 MiB demand ceiling was below its 1 GiB minimum. Actual native segmented construction now creates zero pages under the admitted grant and native Admission includes target+recurrent+MTP.
- Sub-1 GiB and above-8 GiB admitted grants, per-buffer rejection, native borrowed ownership/dtype mismatch and overflow checks.
- B1/B2/B4 × 36/64/128 GiB synthetic envelopes: production cap/reserve/fair-share math, exact slot boundary, shared-owner competition without synthetic M credit, OS+activation refusal despite a larger private grant.
- Co-resident shrink/grow/floor policy and native physical obligation surviving shrink until cleanup; no added C while debt exists. Existing real allocator/process integration remains separate evidence.
- Scripted segmented bridge shrink/regrow retains physical snapshot; scripted fixed-reference lifecycle and diagnostics stay covered.
- Existing live historical two-model suite retains real stream/load/decode/unload assertions and now requires both grants to shrink/regrow. Its obsolete fp16-only admission probes were replaced by dtype/ring/MTP Admission tests. Those historical model IDs are not substitutes for final exact five-model runs.
- Separate EGate hunk replaces old eager-minimum refusal assertion; it is kept separate from validator-owned FP32/complete-store fixture correction.

All Swift source is uncompiled/unrun in this worktree. No GPU/model/remote commands were executed. The validator owns compilation and execution. No performance or measured capacity claim follows from synthetic envelopes.

## Actual production grant for final 128 GiB cells

With default cap fraction and 4 GiB operator reserve, cap=floor(0.90×137438953472)=123695058124 bytes. Default SSD has zero RAM prefix allowance. One exact GPT slot gets cap − actual loaded target+assistant weights − 3758096384 bytes. Each Qwen/Gemma gets cap − actual loaded target+assistant weights − 5905580032 bytes. Approximately 111.7 GiB minus weights for GPT and 109.7 GiB minus weights for the others. Co-resident slots recompute from total resident weights and share that budget; actual system availability still independently gates new process C.

`SlotSizingSnapshot.build` uses loaded parameter nbytes and prepared assistant retained bytes. Neither disk×1.2 (load transient), Memory.active (allocator observation), nor the benchmark's explicit 16 GiB default is this input. The existing benchmark computes SlotSizing internally; a separately reviewed opt-in production-grant mode will use it and report all policy inputs before final model runs. This source delta changes no benchmark override.
