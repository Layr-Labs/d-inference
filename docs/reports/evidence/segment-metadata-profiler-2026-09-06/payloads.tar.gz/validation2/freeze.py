from pathlib import Path
import gzip,hashlib,json,re,shutil
O=Path(__file__).resolve().parent;N=O/'native';S=Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,j):(O/n).write_text(json.dumps(j,indent=2)+'\n')
assert not (O/'manifest.json').exists()
assert json.loads((O/'run-status.json').read_text())=={'failed':[],'all_filters_run':True}
results=json.loads((O/'execution.json').read_text());assert len(results)==4 and all(r['exit_code']==0 and r['nonzero_no_skips']for r in results)
ids=[l for l in (O/'identifiers.log').read_text().splitlines()if l.startswith('MLXLMTests.')];selected={}
for name in json.loads((O/'filters.json').read_text()):
 body=(O/(name+'.log')).read_text();count=int(re.findall(r'Test run with (\d+) tests?',body)[-1]);identifiers=[i for i in ids if i.startswith('MLXLMTests.'+name+'/')]
 assert len(identifiers)==count==2
 expanded=count+sum(int(n)-1 for n in re.findall(r'✔ Test .* with (\d+) test cases passed',body))
 selected[name]={'identifiers':identifiers,'test_functions':count,'expanded_cases':expanded,'log_sha256':sha(O/(name+'.log'))}
dump('selected-identifiers.json',selected)
known={};native=json.loads((O/'native-source-manifest.json').read_text())
for n,d in native['files'].items():known[str((N/n).resolve())]={'group':'native','sha256':d}
deps=json.loads((O/'dependency-source-manifest.json').read_text())
for n,d in deps['files'].items():
 alias,relative=n.split('/',1);known[str((Path(deps['repositories'][alias])/relative).resolve())]={'group':'dependency','sha256':d}
for n,d in json.loads((O/'jinja-source-manifest.json').read_text())['files'].items():known[str((S/'checkouts/swift-jinja'/n).resolve())]={'group':'jinja','sha256':d}
for n,r in known.items():assert sha(Path(n))==r['sha256']
body=gzip.decompress((O/'actual-build-debug.yaml.gz').read_bytes()).decode();matched={};unknown=[]
for literal in sorted(set(re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',body))):
 resolved=str(Path(literal).resolve())
 if resolved in known:matched[literal]=known[resolved]
 elif resolved.startswith(str(N.resolve())+'/'):unknown.append(literal)
assert not unknown and '/checkouts/mlx-swift/Source/'not in body
dump('graph-source-proof.json',{'files':matched,'counts':{g:sum(r['group']==g for r in matched.values())for g in ['native','dependency','jinja']},'unmapped_owned':unknown,'remote_mlx_source_excluded':True,'scope':'Declared source graph references; not every graph target is linked into the selected test product. SwiftPM may create an unused remote checkout; actual local pinned source paths are the identity evidence.'})
source=Path('/tmp/darkbloom-segment-metadata-profiler-source2')
for n,row in native['candidate_changes'].items():
 p=source/'sources'/n;assert sha(p)==row['after_sha256'];target=O/'owned'/n;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
dump('verdict.json',{'status':'PASS','source_manifest_sha256':sha(source/'manifest.json'),'test_functions':sum(x['test_functions']for x in selected.values()),'expanded_cases':sum(x['expanded_cases']for x in selected.values()),'skipped':0,'production_changes':False,'model_runs':False,'optimized_measurement':'separate release evidence; native debug timings are not performance results'})
files={str(p.relative_to(O)):{'sha256':sha(p),'bytes':p.stat().st_size}for p in sorted(O.rglob('*'))if p.is_file()and p.relative_to(O).parts[0]!='native'and p.name!='manifest.json'}
dump('manifest.json',{'files':files,'status':'PASS'})
print(json.dumps({'manifest_sha256':sha(O/'manifest.json'),'payloads':len(files),'verdict':json.loads((O/'verdict.json').read_text())},indent=2))
