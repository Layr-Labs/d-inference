This is a source-only handoff for seven B1, repetition 1 pilots. It has not been staged or launched. `bindings.candidate.json` requires root review; it is deliberately refused by the command helper until a separately retained reviewed binding is supplied. Current M5 ownership must be handed off before any execution.

The owned destination is `/Users/gaj/autoresearch/radix-prefix-cache/090-q38-qat-backend-pilots1`. All seven output directories are below its `runs/` directory; each uses a fresh `prefix-cache/` underneath its output directory. The canonical `090-repeated-matrix3` package and run roots remain unchanged and unstaged. Remote absence of the new destination still needs a fresh check by the owner.

| Order | Model | Backend | Cache | Original matrix order |
| --- | --- | --- | --- | --- |
| 1 | Qwen 3.8 27B | contiguous | off | 73 |
| 2 | Qwen 3.8 27B | contiguous | on | 74 |
| 3 | Qwen 3.8 27B | paged | off | 75 |
| 4 | Qwen 3.8 27B | paged | on | 76 |
| 5 | Gemma 4 26B QAT 4bit | contiguous | off | 181 |
| 6 | Gemma 4 26B QAT 4bit | paged | off | 183 |
| 7 | Gemma 4 26B QAT 4bit | paged | on | 184 |

`pilot-selection.json` preserves these seven original IDs in order. `origin-plan.json` is byte-identical to reviewed matrix3, including all 216 conceptual cells, 189 supported cells, 27 historical contiguous-SSD unsupported cells, 162 executable comparisons, 54 dependent missing comparisons, and 27 separate readiness-refusal controls. This pilot contains neither a new refusal control nor a historical codec workaround. The two comparisons depending on Gemma QAT contiguous cache-on remain explicitly unsupported. A refusal is not a cache or performance success.

The two input files, target manifests, audit records, frozen matrix validator and four runner files are copied without changes; hashes and original locations are in `source-correspondence.json`. The cap remains 128 tokens, B1 remains B1, normal MTP remains enabled, the prompt date remains 2026-09-06 UTC, and the original donor/repeat plus tenant/cancellation/recovery controls remain intact. QAT uses the already reviewed normal-reasoning input with no `enable_thinking: false` override. The earlier removal of that provisional override and the later date change are recorded in the original plan provenance; this pilot changes neither. Copied CPU request/response evidence binds the previously checked 5,523-token Q38 and 5,418-token QAT prompts; no new sidecar or model was run for this handoff.

The runtime remains build8 `radix-engine`, SHA256 `8e476149db74cede08a78a39d718c01f19e2d74a5654d00e2338250ba8b0eda1`, with the same six resource identities. The target model directories and Gemma's exact two-file assistant override remain unchanged. `command-preview.json` gives every exact argument and per-cell output/cache root. Its paths are a review preview, not a current runtime verification or execution receipt. CPU tests compare each command with the original command and allow only the staged helper/input and owned output path substitutions.

Root should review the inner payload `manifest.json`, outer `package-manifest.json`, source correspondence and candidate binding. The outer manifest binds the inner manifest and pending binding without circular hashes. A later reviewed binding must retain all runtime/resource/model identities, use this package's `manifest.json`, use this package's `runs` root, and record its review ID and storage/retention decision. Preserve the pending binding; put the reviewed successor in a separate file. Staging must verify payload bytes and modes, the destination must be fresh, and no canonical matrix root may be consumed.

After an explicit M5 handoff, run one selected cell at a time in the listed order. The helper prints commands only:

```text
<bound-python> -B <pilot-root>/pilot_cells.py command --bindings <reviewed-binding> --cell <exact-cell-id> --format shell
<bound-python> -B <pilot-root>/pilot_cells.py collect --bindings <reviewed-binding>
```

Generate each command immediately before execution. The frozen helper verifies reviewed package inventory, executable/resource hashes, target audit, exact assistant inventory, current UTC prompt date, unused attempt root and free space. The unchanged wrapper then verifies exact model bytes, applies dedicated-host/process/load/thermal guards, and records the binary/input/runtime identities and telemetry. Entry requires more than the greatest of 100 GiB free, 20 GiB free, or 5% of volume capacity; check owned cache bytes and free bytes before each model group and retain every successful, failed and partial root. Wrapper entry load must be at most 4 and GPU temperature at most 42 C; setup is bounded to 240 seconds and the overall process to 1,800 seconds. Stop for owner review on a failed/partial attempt, busy host, inadequate storage, or date rollover. A date rollover requires a separately reviewed successor input/CPU plan; do not override the date guard.

The collector uses the original per-cell and strict comparison validators. It requires exact prompt/generated token IDs, finish reasons and token counts, backend identity without fallback, normal MTP, model/input/binary/resource identity, authenticated native SSD restores with positive saved tokens and stage reads where expected, tenant isolation, cancellation/recovery and coherent idle/shutdown evidence. Q38 has four executable cache/backend comparisons; QAT has two. A failed, overlapping or unbounded process cannot leave comparisons passing. Existing Q35/Q36 failures and every numerical/token gate remain unchanged. Inspect raw report/metadata/log/telemetry before interpreting timings.

Passing these pilots establishes only the observed B1 comparisons. The collector always declares no matrix completion or release-gate completion and produces no repeated-performance summary. All B2/B4 and repeated fixed-width performance work remains in the full ordered matrix. The key mode is deliberately the original ephemeral benchmark mode, so these pilots provide no persistent-key fresh-process restart proof. There is no native packet capture, same-input operator replay, storage mirror, Swift compilation, signing, Keychain or model execution in this preparation.

Offline validation: `python3 -B -m unittest -v test_pilot_cells.py` (12 checks). The frozen original matrix3 suite was independently rerun in its original directory (18 checks); both logs are retained under `validation/`.
