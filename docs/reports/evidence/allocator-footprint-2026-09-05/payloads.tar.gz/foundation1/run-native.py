from pathlib import Path
import gzip,json,re,shutil,subprocess,time
exec(Path('/tmp/darkbloom-allocator-footprint-foundation1/verify.py').read_text())
assert (out/'source-verified-after-swift.json').exists()
scratch=out/'build-swift';package=repos['native'];(out/'source-verified-before-native.json').write_text(json.dumps(verify(),indent=2)+'\n');results=[]
def run(name,cmd,test=False):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=package,stdout=log,stderr=subprocess.STDOUT)
 body=(out/(name+'.log')).read_text();valid=not test or (bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test',body)) and not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped',body,re.M));e={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'selected_count_verified':valid};results.append(e);(out/'native-execution.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:v for k,v in e.items() if k!='command'}),flush=True)
 if r.returncode or not valid:raise SystemExit(r.returncode or 1)
run('native-build',['swift','build','--scratch-path',str(scratch),'--build-tests','--jobs','4','--disable-automatic-resolution'])
graph=(scratch/'debug.yaml').read_text();paths=[repos['swift']/'Source/MLX/AllocationFootprint.swift',repos['mlx']/'mlx/backend/metal/allocator.cpp',repos['mlx-c']/'mlx/c/array.cpp',package/'Tests/MLXLMTests/CBv2AllocatorFootprintTests.swift',package/'Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVWriteValidation.swift']
for p in paths:assert str(p) in graph or str(p.resolve()) in graph,p
assert '/checkouts/mlx-swift/Source/' not in graph
(out/'native-actual-build-graph.yaml.gz').write_bytes(gzip.compress(graph.encode(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'native-actual-package-state.json')
(out/'native-compiler-source-proof.json').write_text(json.dumps({'paths':[str(p) for p in paths],'remote_mlx_source_path_absent':True,'graph_lines':[x for x in graph.splitlines() if 'AllocationFootprint.swift' in x or 'mlx/backend/metal/allocator.cpp' in x or 'mlx/c/array.cpp' in x or 'CBv2AllocatorFootprintTests.swift' in x]},indent=2)+'\n')
lib=root/'provider-swift/.build/arm64-apple-macosx/debug/mlx.metallib';debug=scratch/'arm64-apple-macosx/debug';bundle=debug/'mlx-swift-lmPackageTests.xctest/Contents/MacOS';assert bundle.is_dir();targets=[debug/'mlx.metallib',bundle/'mlx.metallib']
for p in targets:shutil.copy2(lib,p)
(out/'native-metallib-placement.json').write_text(json.dumps({'source':str(lib),'sha256':sha(lib),'destinations':[str(p) for p in targets],'kernel_sources_unchanged_by_footprint_candidate':True},indent=2)+'\n')
run('native-identifiers',['swift','test','list','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution'])
for name in json.loads((out/'native-filters.json').read_text()):run(name,[str(root/'scripts/run-nested-suite.sh'),name,'--scratch-path',str(scratch),'--disable-automatic-resolution'],test=True)
(out/'source-verified-after-native.json').write_text(json.dumps(verify(),indent=2)+'\n');(out/'native-actual-build-graph-after.yaml.gz').write_bytes(gzip.compress((scratch/'debug.yaml').read_bytes(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'native-actual-package-state-after.json');print('NATIVE FOOTPRINT PASSED AND SOURCE VERIFIED',flush=True)
