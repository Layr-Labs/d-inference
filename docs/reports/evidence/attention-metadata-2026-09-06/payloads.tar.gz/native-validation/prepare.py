#!/usr/bin/env python3
"""Stage exact native sources against the established local dependency graph."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys

OUT = Path(__file__).resolve().parent
SOURCE = Path('/tmp/darkbloom-q36-attention-metadata-source1')
WORKTREE = Path('/Users/gaj/Documents/DarkbloomDev/wt/q36-attention-metadata-diagnostic/libs/mlx-swift-lm')
PRIOR = Path('/tmp/darkbloom-q36-logit-diagnostic-validation3')
SCRATCH = Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift')
LOCAL_MLX = Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2)+'\n')


def main():
    review = Path(sys.argv[1]).resolve()
    assert review.is_file(), 'Root source review is required before validation preparation'
    assert sha(SOURCE/'manifest.json') == 'f5a62e3340474ea3c50baddf9577982d7adc47301e98925307c345eb6a2fbf09'
    for name, item in json.loads((SOURCE/'manifest.json').read_text())['files'].items():
        assert sha(SOURCE/name) == item['sha256'], name
    changes = json.loads((SOURCE/'review.json').read_text())['source_files']['native']
    for name, item in changes.items():
        assert sha(WORKTREE/name) == item['after_sha256'], name
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORKTREE, text=True).strip() == '5cb848dfdaae04118ecfa901f53fc21a4aa86a06'
    package = OUT/'native'
    package.mkdir()
    files = subprocess.check_output(['git', 'ls-files', '-z'], cwd=WORKTREE).decode().split('\0')
    canonical = {}
    for name in files:
        if not name:
            continue
        source = WORKTREE/name
        assert source.is_file() and not source.is_symlink(), name
        destination = package/name
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, destination)
        canonical[name] = sha(source)
    before = (package/'Package.swift').read_text()
    original = '.package(url: "https://github.com/Layr-Labs/mlx-swift.git", branch: "main")'
    assert before.count(original) == 1
    after = before.replace(original, '.package(path: "'+str(LOCAL_MLX)+'")')
    (package/'Package.swift').write_text(after)
    (OUT/'package-compile-only-overlay.patch').write_text(''.join(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile='canonical/Package.swift', tofile='compiled/Package.swift')))
    shutil.copy2(PRIOR/'native/Package.resolved', package/'Package.resolved')
    for name in ['dependency-source-manifest.json', 'jinja-source-manifest.json', 'run-nested-suite.sh']:
        shutil.copy2(PRIOR/name, OUT/name)
    deps = json.loads((OUT/'dependency-source-manifest.json').read_text())
    for name, digest in deps['files'].items():
        alias, rel = name.split('/', 1)
        assert sha(Path(deps['repositories'][alias])/rel) == digest, name
    jinja = json.loads((OUT/'jinja-source-manifest.json').read_text())
    for name, digest in jinja['files'].items():
        assert sha(SCRATCH/'checkouts/swift-jinja'/name) == digest, name
    actual = {str(p.relative_to(package)): sha(p) for p in sorted(package.rglob('*')) if p.is_file()}
    write('native-source-manifest.json', {'canonical_files': canonical, 'files': actual,
                                         'candidate_changes': changes})
    write('filters.json', [
        'CBv2AttentionMetadataTests', 'CBv2OrdinaryAttentionMetadataTests',
        'CBv2OrdinaryLogitDiagnosticTests', 'CBv2LogitDiagnosticTests',
        'CBv2RecurrentStateTests', 'CBv2PagedNativeDTypeTests',
        'CBv2PagedRuntimeDTypeTests', 'CBv2PagedKernelTests', 'CBv2PagedSegmentTests',
    ])
    shutil.copy2(review, OUT/'root-source-review.json')
    write('integration.json', {
        'status': 'Prepared only; no Swift process started by this script',
        'source_manifest': str(SOURCE/'manifest.json'), 'source_manifest_sha256': sha(SOURCE/'manifest.json'),
        'root_source_review': str(review), 'root_source_review_sha256': sha(review),
        'package': str(package), 'scratch': str(SCRATCH),
        'native_inputs': len(actual), 'canonical_inputs': len(canonical),
        'package_resolved_source': str(PRIOR/'native/Package.resolved'),
        'package_resolved_sha256': sha(package/'Package.resolved'),
        'dependency_inputs_verified': len(deps['files']), 'jinja_inputs_verified': len(jinja['files']),
        'compile_policy': 'Sole local Swift lane, jobs4, --disable-automatic-resolution, existing pinned metallib',
        'primary_mutated': False,
    })
    print(json.dumps({'package': str(package), 'native_inputs': len(actual),
                      'dependency_inputs_verified': len(deps['files'])}, indent=2))


if __name__ == '__main__':
    main()
