from pathlib import Path
import json
import shlex
import shutil
import subprocess
import sys
import time

from evidence_files import sha, verify_manifest, prior_cells, remote_script, safe_download_name

SOURCE = Path('/tmp/darkbloom-q36-attention-packet-plan1')
OUT = Path(__file__).resolve().parent
BINDING = OUT/'runtime-binding.json'
OPTIONS = ['-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15']
HOST = 'gaj@100.124.35.99'; SSH = ['ssh']+OPTIONS+[HOST]

def write(root, name, value): (root/name).write_text(json.dumps(value,indent=2)+'\n')
def remote(local, name, source, configuration):
    code = remote_script(source, configuration)
    (local/(name+'-rendered.py')).write_text(code)
    result = subprocess.run(SSH+['python3 -B -'],input=code,text=True,capture_output=True)
    (local/(name+'.stdout')).write_text(result.stdout); (local/(name+'.stderr')).write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)

def main():
    assert len(sys.argv) == 3, 'Pass one cell and the exact root-reviewed runtime-binding SHA256. No automatic successor.'
    assert sha(BINDING) == sys.argv[2], 'Runtime-binding SHA differs from explicit reviewed invocation'
    binding = json.loads(BINDING.read_text())
    verify_manifest(OUT,binding['controller_manifest_sha256'],'preparation-manifest.json')
    verify_manifest(SOURCE,binding['plan_manifest_sha256'])
    for name in ['artifact_review','controller_review']:
        assert sha(Path(binding[name])) == binding[name+'_sha256']
    plan = json.loads((SOURCE/'plan.json').read_text())
    assert len(plan['cells']) == 4 and [c['capture'] for c in plan['cells']] == [False,False,True,True]
    chosen = next(c for c in plan['cells'] if c['id'] == sys.argv[1])
    prior_cells(plan,chosen,OUT)
    command = next(c for c in binding['commands'] if c['cell'] == chosen['id'])
    assert command['wrapper_argv'] == chosen['argv']
    assert command['expected_observed_native_argv'] == chosen['native_argv_after_date_pin']
    local = OUT/chosen['id']; local.mkdir(exist_ok=False)
    write(local,'command.json',chosen); write(local,'expected-native-command.json',command)
    started = time.monotonic(); exit_code = 1; errors = []; analysis = None
    try:
        check = subprocess.run(['/usr/bin/python3','-B',str(OUT/'preflight.py'),str(local/'ownership-before.json')],text=True,capture_output=True)
        (local/'ownership-before.log').write_text(check.stdout+check.stderr)
        assert check.returncode == 0, check.stdout+check.stderr
        output = chosen['argv'][chosen['argv'].index('--output')+1]
        remote(local,'runtime-precheck',(OUT/'remote_precheck.py').read_text(),{
            'root':plan['remote_root'],'output':output,'date':plan['prompt_date_utc'],
            'plan_manifest_sha256':binding['plan_manifest_sha256'],'binding_sha256':sha(BINDING),
            'cell':chosen['id'],'argv':chosen['argv']})
        with (local/'ssh-run.log').open('x') as log:
            run = subprocess.run(SSH+[shlex.join(chosen['argv'])],stdout=log,stderr=subprocess.STDOUT)
        exit_code = run.returncode
        write(local,'execution.json',{'exit_code':exit_code,'seconds':time.monotonic()-started,'scope':plan['scope']})
        inventory = remote(local,'remote-inventory',(OUT/'remote_inventory.py').read_text(),{'output':output})
        errors += inventory['errors']
        for name,row in inventory['directories'].items():
            assert name == 'report.attention-packet'
            (local/name).mkdir(mode=int(row['mode'],8))
        for name,row in inventory['files'].items():
            safe_download_name(name)
            target = local/name
            result = subprocess.run(['scp','-p']+OPTIONS+[HOST+':'+output+'/'+name,str(target)],text=True,capture_output=True)
            assert result.returncode == 0, result.stderr
            assert target.stat().st_size == row['bytes'] and sha(target) == row['sha256']
            assert oct(target.stat().st_mode&0o777) == row['mode']
        sys.path.insert(0,str(SOURCE/'runner'))
        from radix_engine_evidence import report_errors
        from strict_results import result_errors
        from packet_results import inspect_packet
        report = json.loads((local/'report.json').read_text())
        errors += report_errors(report)+result_errors(local,chosen,plan,binding,report,OUT)
        if chosen['capture']:
            packet_errors,analysis = inspect_packet(local,chosen,plan,report)
            errors += packet_errors
            if analysis is not None: write(local,'packet-analysis.json',analysis)
            if chosen['id'] == plan['cells'][3]['id'] and not errors:
                from compare_packets import compare_packet_bytes
                left = OUT/plan['cells'][2]['id']/'report.attention-packet/packet.json'
                write(local,'cross-backend-native-bytes.json',compare_packet_bytes(left,local/'report.attention-packet/packet.json'))
        else:
            if (local/'report.attention-packet').exists(): errors.append('control unexpectedly created a raw packet')
        # Cross-backend strict control verdict is preserved, not converted into success.
        if chosen['id'] == plan['cells'][1]['id']:
            from compare_radix_engine import compare
            control = json.loads((OUT/plan['cells'][0]['id']/'report.json').read_text())
            write(local,'strict-backend-control-comparison.json',compare(control,report,axis='backend'))
            if control['rows'][0]['prompt_token_ids'] != report['rows'][0]['prompt_token_ids'] or control['rows'][0]['token_ids'][:62] != report['rows'][0]['token_ids'][:62]:
                errors.append('new controls differ before selected decision; packet attribution blocked')
    except Exception as error:
        errors.append('execution or evidence refused: '+type(error).__name__+': '+str(error))
    summary = {'cell':chosen['id'],'exit_code':exit_code,'capture':chosen['capture'],
               'report_integrity_passed':exit_code == 0 and not errors,'errors':errors,
               'numerical_release_gate_evaluated':False,'scope':plan['scope']}
    write(local,'summary.json',summary)
    files = {str(p.relative_to(local)):{'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(local.rglob('*')) if p.is_file()}
    write(local,'manifest.json',{'scope':plan['scope'],'files':files})
    write(local,'completion-receipt.json',{'manifest_sha256':sha(local/'manifest.json')})
    print(json.dumps(summary,indent=2),flush=True)
    raise SystemExit(0 if summary['report_integrity_passed'] else 1)

if __name__ == '__main__': main()
