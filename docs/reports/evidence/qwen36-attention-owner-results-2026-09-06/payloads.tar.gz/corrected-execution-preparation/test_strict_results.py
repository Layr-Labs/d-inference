"""CPU fault injection only; synthetic complete metadata is not model evidence."""
import copy
import json
from pathlib import Path
import shutil
import tempfile
import unittest

from strict_results import result_errors

ORIGINAL = Path('/tmp/darkbloom-q36-attention-metadata-execution1')
PLAN = Path('/tmp/darkbloom-q36-attention-metadata-plan1/plan.json')
BINDING = Path('/tmp/darkbloom-q36-attention-metadata-runtime-binding1.json')


class StrictResultsTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='q36-owner-driver-test-')
        self.root = Path(self.temporary.name)
        self.plan = json.loads(PLAN.read_text())
        self.plan['cells'] = self.plan['cells'][:2]
        self.binding = json.loads(BINDING.read_text())
        self.binding['commands'] = []
        for cell in self.plan['cells']:
            source, target = ORIGINAL / cell['id'], self.root / cell['id']
            target.mkdir()
            for name in ['input.json', 'metadata.json', 'report.json']:
                shutil.copy2(source / name, target / name)
            meta = json.loads((target / 'metadata.json').read_text())
            self.binding['commands'].append(dict(cell=cell['id'], expected_observed_native_argv=meta['command']))

    def tearDown(self):
        self.temporary.cleanup()

    def evaluate(self, trace=False, report=None):
        cell = self.plan['cells'][int(trace)]
        local = self.root / cell['id']
        if report is None:
            report = json.loads((local / 'report.json').read_text())
        return result_errors(local, cell, self.plan, self.binding, report, self.root)

    def synthetic_complete_trace(self):
        report = json.loads((self.root / self.plan['cells'][1]['id'] / 'report.json').read_text())
        snapshot = report['attention_metadata']['snapshot']
        exemplar = snapshot['records'][0]
        snapshot['records'] = []
        for index in range(10):
            record = copy.deepcopy(exemplar)
            record.update(storageLayerIndex=index, modelLayerIndex=3 + index * 4)
            snapshot['records'].append(record)
        snapshot['refusals'] = {}
        report['attention_metadata']['status'] = 'captured'
        return report

    def test_original_control_passes(self):
        self.assertEqual(self.evaluate(), [])

    def test_literal_preview_path_cannot_replace_owned_copy(self):
        self.binding['commands'][0]['expected_observed_native_argv'][2] = self.plan['cells'][0]['native_argv'][2]
        self.assertIn('observed native argv differs after explicit owned input-copy substitution', self.evaluate())

    def test_input_byte_mutation_is_rejected(self):
        with (self.root / self.plan['cells'][0]['id'] / 'input.json').open('a') as file:
            file.write(' ')
        self.assertIn('input bytes changed', self.evaluate())

    def test_runtime_change_is_rejected(self):
        self.binding['artifacts']['radix-engine']['sha256'] = '0' * 64
        self.assertIn('observed runtime hash differs from reviewed probe', self.evaluate())

    def test_original_incomplete_capture_stays_failed(self):
        errors = self.evaluate(True)
        self.assertIn('attention metadata capture incomplete or refused', errors)
        self.assertIn('ten attention-owner identities not exact', errors)

    def test_synthetic_complete_metadata_exercises_success_branch(self):
        self.assertEqual(self.evaluate(True, self.synthetic_complete_trace()), [])

    def test_repeated_owner_is_rejected(self):
        report = self.synthetic_complete_trace()
        report['attention_metadata']['snapshot']['records'][9]['storageLayerIndex'] = 0
        self.assertIn('ten attention-owner identities not exact', self.evaluate(True, report))

    def test_selected_seed_mismatch_is_rejected(self):
        report = self.synthetic_complete_trace()
        report['attention_metadata']['snapshot']['seedToken'] += 1
        self.assertIn('attention selection does not match actual IDs', self.evaluate(True, report))

    def test_same_build_trajectory_change_is_rejected(self):
        report = self.synthetic_complete_trace()
        report['tenant_checks'][1]['token_ids'][4] += 1
        self.assertIn('tenant_checks:1 same-build trajectory changed', self.evaluate(True, report))


if __name__ == '__main__':
    unittest.main()
