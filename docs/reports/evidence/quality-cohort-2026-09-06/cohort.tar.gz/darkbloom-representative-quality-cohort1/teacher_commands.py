"""Existing teacher CLI argv builder, copied without changing its body."""
from pathlib import Path
ROOT = Path(__file__).resolve().parent

def command(artifact, model, cell, output):
    return [str(artifact / 'darkbloom'), 'benchmark', '--config', str(output / 'provider.toml'), '--model', model['model_id'],
            '--kv-backend', cell['backend'], '--teacher-forced-input', str(ROOT / model['input'])]
