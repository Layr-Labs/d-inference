from pathlib import Path
import hashlib,json,shlex,subprocess,sys,time
local=Path('/tmp/darkbloom-final-fleet-smoke2');plan=json.loads((local/'plan.json').read_text());label,backend,cache=sys.argv[1:4];model=next(m for m in plan['models'] if m['label']==label);assert backend in ('paged','contiguous');assert cache in ('on','off');suffix=sys.argv[4] if len(sys.argv)>4 else '';assert all(c.isalnum() or c=='-' for c in suffix);cell=f'{label}-{backend}-cache-{cache}-b1-smoke2'+('-'+suffix if suffix else '');out=local/'results'/cell;out.mkdir(parents=True,exist_ok=False);remote='/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-smoke1';pkg=remote+'/payload';ssh=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99'];command=['python3',remote+'/wrapper-fix1/run_radix_engine.py','--binary',pkg+'/bin/radix-engine','--model-directory',model['directory'],'--input',remote+'/smoke2-inputs/'+label+'.json','--output',remote+'/runs/'+cell,'--cache',cache,'--mtp',model['mtp'],'--kv-backend',backend,'--cache-mode','ssd','--key-mode','ephemeral','--production-kv-grant','--expected-model-sha256',model['aggregate_sha256'],'--prompt-date',plan['prompt_date'],'--startup-timeout','240']
if model['assistant_required']:command+=['--assistant-directory',pkg+'/gemma-assistant-local-override1']
(out/'command.json').write_text(json.dumps({'command':command,'model':model,'scope':'B1 initial smoke; no repeated performance claim'},indent=2)+'\n');start=time.monotonic()
with (out/'ssh-run.log').open('w') as log:r=subprocess.run(ssh+[shlex.join(command)],stdout=log,stderr=subprocess.STDOUT)
(out/'execution.json').write_text(json.dumps({'exit_code':r.returncode,'seconds':time.monotonic()-start},indent=2)+'\n')
code='''from pathlib import Path
import hashlib,json
root=Path(ROOT);files={}
if root.exists():
 for p in sorted(root.iterdir()):
  if p.is_file():files[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
 cache=root/'prefix-cache';cache_files=[p for p in cache.rglob('*') if p.is_file()] if cache.exists() else []
 (root/'cache-file-summary.json').write_text(json.dumps({'file_count':len(cache_files),'bytes':sum(p.stat().st_size for p in cache_files)},indent=2)+'\\n')
print(json.dumps({'files':files,'exists':root.exists()},indent=2))
'''.replace('ROOT',repr(remote+'/runs/'+cell));check=subprocess.run(ssh+['python3 -'],input=code,text=True,capture_output=True);assert check.returncode==0,(check.stdout,check.stderr);inventory=json.loads(check.stdout);(out/'remote-files.json').write_text(check.stdout)
for name in list(inventory['files'])+(['cache-file-summary.json'] if inventory['exists'] else []):
 result=subprocess.run(['scp','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','gaj@100.124.35.99:'+remote+'/runs/'+cell+'/'+name,str(out/name)],capture_output=True,text=True);assert result.returncode==0,(name,result.stderr)
 if name in inventory['files']:assert hashlib.sha256((out/name).read_bytes()).hexdigest()==inventory['files'][name]['sha256'],name
summary={'cell':cell,'exit_code':r.returncode,'seconds':time.monotonic()-start,'artifact_dir':str(out)}
if (out/'report.json').exists():
 report=json.loads((out/'report.json').read_text());sys.path.insert(0,'/tmp/darkbloom-final-serving-build3/scripts');from radix_engine_evidence import report_errors
 errors=report_errors(report);(out/'integrity-verdict.json').write_text(json.dumps({'passed':not errors,'errors':errors},indent=2)+'\n');summary.update(status=report.get('status'),resolved_backend=report.get('resolved_backend'),error=report.get('error'),integrity_errors=errors,rows=[{k:row.get(k) for k in ['id','outcome','prompt_tokens','completion_tokens','cache_outcome','matched_tokens','saved_tokens','ttft_s','ssd_stage_disposition']} for row in report.get('rows',[])],cancelled={k:report.get('cancelled',{}).get(k) for k in ['outcome','finish','cache_outcome','matched_tokens','saved_tokens']})
print(json.dumps(summary,indent=2),flush=True);(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
files={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.rglob('*')) if p.is_file()};(out/'manifest.json').write_text(json.dumps({'scope':'Exact final source initial real-model smoke; raw failures retained','files':files},indent=2)+'\n');sys.exit(0 if r.returncode==0 and not summary.get('integrity_errors') else 1)
