# Canceled provider settlement source review

The outer SSE consumer can stop before the independent native event pump records its final authoritative cache adoption. Its terminal finalizer then wins with incomplete metadata. HTTP5 preserved this failure after seven positive Q38 SSD cases.

The candidate adds a request-scoped one-shot observation to the existing usage signal. It is armed synchronously before the pump is scheduled. The pump resolves it in defer, after native usage has invoked the lookup callback and after request resource retirement. Missing native terminal and shutdown resolve through existing teardown.

Only the partial-cancellation branch waits. It explicitly cancels the currently mapped native row using the already-owned bridge and exact profile identity, after the outer handler has classified cancellation. Earlier cancelIfOwned snapshot semantics are unchanged. Caller task cancellation does not bypass the required pump retirement. No elapsed-time polling or hit inference is added to serving code. Delivered output remains the billing floor; tail engine tokens are not added.

The full-handler regression uses a real concrete EngineV2, recurrent state, paged KV, an encrypted checkpoint produced by a normal native donor, authenticated scope and a real encrypted outer request/response. DEBUG-only barriers hold the actual native terminal, exposing which event happens first. The same test and neutral instrumentation run on baseline. A cold case rejects fabricated hits. Candidate lifecycle tests cover canceled consumers, native miss, closed event stream, shutdown, unarmed and already completed observations.

This freeze is source only. No compilation or test pass is claimed. The metadata agent owns the current local Swift lane. No binaries, model weights, config secrets, or key material are included.
