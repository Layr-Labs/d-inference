from pathlib import Path
import hashlib,json,shutil,stat,tarfile
OUT=Path('/tmp/darkbloom-connected-http6-q38-freeze1');OUT.mkdir(exist_ok=False);PAYLOAD=OUT/'payloads';PAYLOAD.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def item(p):return {'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(stat.S_IMODE(p.stat().st_mode))}
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
def cp(p,name):
 q=PAYLOAD/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);assert sha(q)==sha(p)
records=[]
def add(root,label,manifest_name='manifest.json',skip=()):
 mpath=root/manifest_name;manifest=json.loads(mpath.read_text());included=0;excluded=[]
 for name,row in manifest['files'].items():
  p=root/name;r=item(p);assert r['bytes']==row['bytes'] and r['sha256']==row['sha256'],p
  if 'mode' in row:assert int(r['mode'],8)==(int(row['mode'],8) if isinstance(row['mode'],str) else row['mode']),p
  if any(name==x or name.startswith(x+'/') for x in skip):excluded.append(name);continue
  cp(p,label+'/'+name);included+=1
 cp(mpath,label+'/'+manifest_name);records.append({'source':str(root),'label':label,'manifest_sha256':sha(mpath),'payloads_rehashed':len(manifest['files']),'payloads_included':included,'excluded':excluded})
raw=Path('/tmp/darkbloom-connected-http6-results')
for cell in ['qwen38-paged-off-b1','qwen38-paged-ssd-b1']:add(raw/cell,'raw/'+cell)
add(Path('/tmp/darkbloom-connected-http6-q38-analysis1'),'analysis')
add(Path('/tmp/darkbloom-connected-http6-transfer1'),'transfer')
add(Path('/tmp/darkbloom-connected-http6-execution-prep2'),'controller')
add(Path('/tmp/darkbloom-connected-http6-off-assessment1'),'off-independent-assessment')
add(Path('/tmp/darkbloom-connected-http6-controller-review-addendum1'),'controller-root-addendum')
add(Path('/tmp/darkbloom-connected-m5-bundle6-q38'),'package-proof','package-manifest.json',('connected-e2e.test','go-source'))
add(Path('/tmp/darkbloom-connected-http6-package-freeze1'),'package-freeze-proof')
for name in ['darkbloom-connected-http6-root-final-review1.json','darkbloom-connected-http6-root-controller-copy-review2.json','darkbloom-connected-http6-root-off-assessment1.json','darkbloom-connected-http6-off-cooled-readiness1.json','darkbloom-connected-http6-off-live-status1.json','darkbloom-connected-http6-off-live-status2.json','darkbloom-connected-http6-ssd-live-status1.json']:
 cp(Path('/tmp')/name,'root-and-readiness/'+name)
cp(Path('/tmp/darkbloom-connected-http5-q38-cancel-failure1/manifest.json'),'historical-http5-failed-manifest.json')
cp(Path(__file__),'freeze.py')
save(PAYLOAD/'source-correspondence.json',{'groups':records,'scope':'Raw strict 20-case HTTP6 pair and original off postflight thermal refusal retained. Frozen package rehashed in full; Go binary and 988 source/resource payloads intentionally excluded from this evidence archive, with complete identity/source manifests and primary root verification retained. Runtime binaries/metallib/weights/keys are not archived. Historical HTTP5 failure remains independently banked.'})
files={str(p.relative_to(PAYLOAD)):item(p) for p in sorted(PAYLOAD.rglob('*')) if p.is_file()}
save(OUT/'manifest.json',{'status':'STRICT_HTTP6_Q38_OFF_SSD_PAIR_PASS_WITH_OFF_POSTFLIGHT_READINESS_REFUSAL_RETAINED','files':files})
archive=OUT/'payloads.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name in sorted(files):tar.add(PAYLOAD/name,arcname=name,recursive=False)
summary={'manifest':item(OUT/'manifest.json'),'archive':item(archive),'payloads':len(files),'raw_off_manifest_sha256':sha(raw/'qwen38-paged-off-b1/manifest.json'),'raw_ssd_manifest_sha256':sha(raw/'qwen38-paged-ssd-b1/manifest.json'),'analysis_sha256':sha(Path('/tmp/darkbloom-connected-http6-q38-analysis1/analysis.json')),'scope':'Strict ten-case cache-off and SSD pair passed on one M5; original thermal readiness failure retained; not release/all-model/backend/decode acceptance.'}
save(OUT/'summary.json',summary);print(json.dumps(summary,indent=2))
