#!/usr/bin/env python3
"""Freeze the reviewed CPU-only HTTP5 package and verify archive modes."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path
import stat
import subprocess
import tarfile
import tempfile

BASE = Path('/tmp/darkbloom-connected-m5-bundle5')
OUT = Path(__file__).resolve().parent
ARCHIVE = Path('/tmp/darkbloom-connected-m5-bundle5.tar.gz')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2)+'\n')


def main():
    assert not (BASE/'package-manifest.json').exists()
    assert not ARCHIVE.exists()
    assert datetime.datetime.now(datetime.timezone.utc).date().isoformat() == '2026-09-06'
    assert sha(BASE/'reviews/bundle5-helper-root-review.json') == '64ae4684f01f0d29d7cc2e0f0c7bebc2906b82dabfe2e9398804167458f5b5a4'
    review = json.loads((BASE/'preparation/helper-review1/review.json').read_text())
    for name, item in review['changed_files'].items():
        assert sha(BASE/name) == item['after_sha256'], name
    assert json.loads((BASE/'bundle-plan.json').read_text())['expected_request_date_utc'] == '2026-09-06'
    assert json.loads((BASE/'tokenizer-plan.json').read_text())['status'] == 'passed'
    files = {}
    for path in sorted(BASE.rglob('*')):
        assert not path.is_symlink(), path
        if path.is_dir():
            continue
        assert stat.S_ISREG(path.stat().st_mode), path
        files[str(path.relative_to(BASE))] = {'sha256': sha(path), 'bytes': path.stat().st_size,
                                             'mode': stat.S_IMODE(path.stat().st_mode)}
    assert files['connected-e2e.test']['mode'] == 0o755
    manifest = {'schema': 5,
                'state': 'Frozen revision5 preparation; all twelve HTTP cells unrun; final root package review required before staging',
                'source_commit': '089d9ade3398b7660b9c0745ea17a8f584d11f9f',
                'date_utc': '2026-09-06',
                'remote_bundle_root': '/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http5',
                'go_test_binary_sha256': files['connected-e2e.test']['sha256'],
                'go_test_binary_mode': 0o755,
                'provider_cli_sha256': '7345c5b29369a8ff168b1230254c0a164a6ccc97a0fb0baca380475acda43363',
                'provider_source_commit': '82ce12db89e37492b387d2056eec646f04997e1f',
                'native_source_commit': '0103f2490730111cd3d9453f6cb7eb27a519cad3',
                'previous_package_archive_sha256': '4bdfef43ef976a5024afb0be567670b69b5f13a48d37c66fe8fbf51be1344ab8',
                'previous_package_manifest_sha256': '6547b2099ab603494de95fff68c73deb525690a21ba738c90103078525b198e1',
                'default_backend_rollout': 'pending; explicit paged validation inputs',
                'checks': {'python_tests_executed': 20, 'new_mode_test_functions': 4,
                           'cpu_prompt_plans': 6, 'exact_off_ssd_pairs': 6,
                           'go_source_resource_files_unchanged': 988,
                           'root_build_review': 'reviews/build8-root-review.json',
                           'root_helper_review': 'reviews/bundle5-helper-root-review.json',
                           'recovery_review': 'preparation/recovery-review1/manifest.json',
                           'date_delta': 'preparation/recovery-review1/recovery-validation.json'},
                'files': files}
    write(BASE/'package-manifest.json', manifest)
    commands = []

    def verify(cwd, label):
        argv = ['python3', '-B', 'verify_package.py']
        start = datetime.datetime.now(datetime.timezone.utc).isoformat()
        process = subprocess.run(argv, cwd=cwd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        (OUT/(label+'.stdout')).write_text(process.stdout)
        (OUT/(label+'.stderr')).write_text(process.stderr)
        commands.append({'argv': argv, 'cwd': str(cwd), 'started_utc': start,
                         'ended_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
                         'exit_code': process.returncode, 'stdout': label+'.stdout', 'stderr': label+'.stderr'})
        write(OUT/'commands.json', commands)
        assert process.returncode == 0, label
        assert json.loads(process.stdout)['verified_files'] == len(files)

    verify(BASE, 'local-verifier')
    with ARCHIVE.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w') as archive:
                for path in sorted(BASE.rglob('*')):
                    if path.is_file():
                        archive.add(path, arcname=str(path.relative_to(BASE)), recursive=False)
    archive_modes = {}
    with tarfile.open(ARCHIVE) as archive:
        members = archive.getmembers()
        assert len(members) == len(files)+1
        assert len(set(item.name for item in members)) == len(members)
        assert set(item.name for item in members) == set(files)|{'package-manifest.json'}
        for item in members:
            assert item.isfile()
            rel = Path(item.name)
            assert not rel.is_absolute() and '..' not in rel.parts
            actual = BASE/rel
            blob = archive.extractfile(item).read()
            assert hashlib.sha256(blob).hexdigest() == sha(actual), item.name
            assert len(blob) == actual.stat().st_size, item.name
            assert item.mode == stat.S_IMODE(actual.stat().st_mode), item.name
            if item.name in files:
                assert item.mode == files[item.name]['mode']
            archive_modes[item.name] = format(item.mode, '04o')
        assert archive_modes['connected-e2e.test'] == '0755'
        with tempfile.TemporaryDirectory(prefix='darkbloom-http5-extract-') as tmp:
            extracted = Path(tmp)
            archive.extractall(extracted, filter='data')
            verify(extracted, 'extracted-verifier')
            extracted_mode = stat.S_IMODE((extracted/'connected-e2e.test').stat().st_mode)
            assert extracted_mode == 0o755
    write(OUT/'archive-mode-proof.json', {'status': 'PASS', 'member_count': len(archive_modes),
          'all_member_types_sizes_hashes_and_modes_match': True, 'modes': archive_modes,
          'go_executable_local_mode': '0755', 'go_executable_archive_mode': '0755',
          'go_executable_extracted_mode': format(extracted_mode, '04o')})
    summary = {'status': 'PASS: frozen preparation, not HTTP execution',
               'package': str(BASE), 'package_manifest_sha256': sha(BASE/'package-manifest.json'),
               'package_payload_files': len(files), 'archive': str(ARCHIVE),
               'archive_sha256': sha(ARCHIVE), 'archive_bytes': ARCHIVE.stat().st_size,
               'archive_files': len(archive_modes), 'all_file_modes_checked': True,
               'go_executable_mode_local_archive_extracted': '0755',
               'expected_request_date_utc': '2026-09-06',
               'root_helper_review_sha256': sha(BASE/'reviews/bundle5-helper-root-review.json'),
               'recovery_review_sha256': sha(BASE/'preparation/recovery-review1/manifest.json'),
               'runtime_cli_sha256': manifest['provider_cli_sha256'],
               'HTTP_cells': 'all twelve unrun; root must review final package before M5 staging',
               'production_changes': False}
    write(OUT/'summary.json', summary)
    frozen = {str(path.relative_to(OUT)): {'sha256': sha(path), 'bytes': path.stat().st_size}
              for path in sorted(OUT.rglob('*')) if path.is_file()}
    write(OUT/'manifest.json', {'files': frozen})
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
