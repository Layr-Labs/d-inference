"""Foreground SSH control pipe for an already staged, reviewed Q38 pilot."""
import argparse
import json
import os
from pathlib import Path
import re
import selectors
import shlex
import signal
import subprocess
import sys
import time

from control_input import ControlInput, ControlLost
import pilot_core as core

SIGNALS = (signal.SIGTERM, signal.SIGHUP, signal.SIGINT)
PING_INTERVAL = 2
DEADLINE = 10980
CLEANUP_GRACE = 180


def ssh_command(host, identity, driver, activation, python):
    core.require(re.fullmatch(r"[A-Za-z0-9_.@:-]+", host) and not host.startswith("-"), "explicit SSH destination required")
    core.require(identity.is_absolute() and identity.is_file(), "absolute existing SSH identity required")
    core.require(all(filename.is_absolute() for filename in (driver, activation, python)), "absolute remote paths required")
    remote = "exec " + shlex.join([str(python), "-B", str(driver), "run", "--activation", str(activation)])
    return ["/usr/bin/ssh", "-T", "-F", "/dev/null", "-i", str(identity),
            "-o", "IdentitiesOnly=yes", "-o", "BatchMode=yes", "-o", "ForwardAgent=no",
            "-o", "ClearAllForwardings=yes", "-o", "ConnectTimeout=30", "-o", "ServerAliveInterval=5",
            "-o", "ServerAliveCountMax=3", "-o", "ControlMaster=no", "-o", "ControlPath=none", host, remote]


def relay(argv, output, control=None):
    caller = ControlInput(control if control is not None else sys.stdin.buffer, require_ping=False)
    process = None
    events = errors = None
    failure = None
    forced = False
    created = False
    selector = selectors.DefaultSelector()
    def interrupted(signum, frame):
        raise ControlLost("local foreground signal " + str(signum))
    handlers = {sig: signal.signal(sig, interrupted) for sig in SIGNALS}
    try:
        caller.poll()
        output.mkdir(mode=0o700)
        created = True
        core.write_new(output / "command.json", {"argv": argv, "external_ping_interval_s": PING_INTERVAL,
                       "local_stdin_eof_stops_remote": True, "no_staging_or_activation": True})
        events = (output / "remote.stdout").open("xb")
        errors = (output / "ssh.stderr").open("xb")
        caller.poll()
        process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                   stderr=errors, start_new_session=True)
        selector.register(process.stdout, selectors.EVENT_READ)
        started, last_ping = time.monotonic(), None
        while process.poll() is None:
            caller.poll()
            core.require(time.monotonic() - started < DEADLINE, "local foreground deadline expired")
            if last_ping is None or time.monotonic() - last_ping >= PING_INTERVAL:
                process.stdin.write(b'{"command":"ping"}\n'); process.stdin.flush()
                last_ping = time.monotonic()
            if selector.select(.1):
                block = os.read(process.stdout.fileno(), 65536)
                if block:
                    events.write(block); events.flush()
                    sys.stdout.buffer.write(block); sys.stdout.buffer.flush()
                else:
                    selector.unregister(process.stdout)
        process.wait(timeout=5)
    except Exception as error:
        failure = type(error).__name__ + ": " + str(error)
    finally:
        for sig in SIGNALS:
            signal.signal(sig, signal.SIG_IGN)
        try:
            if process is not None:
                try:
                    if process.poll() is None:
                        process.stdin.write(b'{"command":"stop"}\n'); process.stdin.flush()
                    process.stdin.close()
                except (BrokenPipeError, OSError):
                    pass
                deadline = time.monotonic() + CLEANUP_GRACE
                while process.poll() is None and time.monotonic() < deadline:
                    if selector.select(.1):
                        block = os.read(process.stdout.fileno(), 65536)
                        if block:
                            events.write(block); events.flush()
                        else:
                            selector.unregister(process.stdout)
                if process.poll() is None:
                    forced = True
                    os.killpg(process.pid, signal.SIGTERM)
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        os.killpg(process.pid, signal.SIGKILL); process.wait(timeout=10)
                events.write(process.stdout.read()); process.stdout.close()
            if events:
                events.close()
            if errors:
                errors.close()
            accepted = bool(process and process.returncode == 0 and not failure and not forced)
            if created:
                core.write_new(output / "terminal.json", {"accepted": accepted, "failure": failure,
                               "ssh_exit_code": process.returncode if process else None, "forced_local_cleanup": forced,
                               "remote_retirement_requires_remote_receipts": True, "gpu_ready": False,
                               "production_default_validated": False, "auto_http_validated": False})
        finally:
            selector.close(); caller.close()
            for sig, handler in handlers.items():
                signal.signal(sig, handler)
    if failure:
        print(failure, file=sys.stderr)
    return 0 if accepted else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", required=True)
    parser.add_argument("--identity", type=Path, required=True)
    parser.add_argument("--remote-driver", type=Path, required=True)
    parser.add_argument("--activation", type=Path, required=True)
    parser.add_argument("--remote-python", type=Path, default=Path("/usr/bin/python3"))
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    core.verify_driver()
    core.require(args.output.is_absolute() and not args.output.exists(), "new absolute controller output required")
    return relay(ssh_command(args.host, args.identity, args.remote_driver, args.activation, args.remote_python), args.output)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, KeyError, TypeError) as error:
        raise SystemExit("REFUSED: " + str(error))
