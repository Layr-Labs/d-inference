from pathlib import Path
import gzip,hashlib,json,re,shutil
out=Path('/tmp/darkbloom-receipt-diagnostic-provider-validation1');native=Path('/tmp/darkbloom-q36-logit-diagnostic-validation3/native');scratch=Path('/tmp/darkbloom-process-memory-telemetry-swift-validation1/build');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
assert json.loads((out/'baseline/verdict.json').read_text())['status']=='EXPECTED_REGRESSION_FAILURE'
assert json.loads((out/'candidate/verdict.json').read_text())['status']=='PASS'
for variant in ['baseline','candidate']:
 phase=out/variant;ws=phase/'workspace';known={}
 def add(path,digest,group):
  key=str(path.resolve());assert key not in known or known[key]['sha256']==digest;known[key]={'sha256':digest,'group':group}
 for filename,root,group in [('provider-source-manifest.json',ws,'provider')]:
  for name,digest in json.loads((phase/filename).read_text())['files'].items():add(root/name,digest,group)
 for filename,group in [('native-source-manifest.json','native'),('ancillary-package-manifest.json','ancillary')]:
  for name,digest in json.loads((out/filename).read_text())['files'].items():add(native/name,digest,group)
 deps=json.loads((out/'dependency-source-manifest.json').read_text())
 for key,digest in deps['files'].items():
  alias,name=key.split('/',1);add(Path(deps['repositories'][alias])/name,digest,'dependency')
 for name,digest in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():add(scratch/'checkouts/swift-jinja'/name,digest,'jinja')
 graph=gzip.decompress((phase/'actual-build-debug.yaml.gz').read_bytes()).decode();matches={};unmapped=[]
 for literal in sorted(set(re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',graph))):
  path=Path(literal);key=str(path.resolve())
  if key in known:assert sha(path)==known[key]['sha256'];matches[literal]={'resolved_frozen_source':key,**known[key]}
  elif key.startswith(str(ws.resolve())+'/') or key.startswith(str(native.resolve())+'/'):unmapped.append(literal)
 assert not unmapped,unmapped
 write(variant+'/all-owned-graph-source-proof.json',{'files':matches,'counts':{g:sum(row['group']==g for row in matches.values()) for g in ['provider','native','ancillary','dependency','jinja']},'unmapped_owned_source_paths':unmapped})
 for name in ['provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge+Submission.swift','provider-swift/Tests/ProviderCoreTests/EngineV2BridgeTests.swift']:
  target=phase/'changed-source'/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ws/name,target)
coverage=json.loads((out/'candidate/test-identifier-coverage.json').read_text());summaries={};case_lines=[]
for name in json.loads((out/'candidate/filters.json').read_text()):
 body=(out/'candidate'/(name+'.log')).read_text();summaries[name]=re.findall(r'Test run with [0-9]+ tests? in [0-9]+ suites? passed[^\n]*',body);case_lines += [line for line in body.splitlines() if 'Passing ' in line and 'arguments' in line]
write('validation-summary.json',{'status':'PASS_WITH_REPRODUCED_BASELINE_REGRESSION','baseline_test_functions':1,'baseline_expected_failures':['readyReceipts.count0 expected1 after submit','durable callback absent','received list empty expecteddurable512'],'candidate_unique_functions':coverage['unique_functions'],'candidate_executions_including_overlap':coverage['executed_functions_including_overlap'],'filters':14,'raw_summaries':summaries,'parameter_case_lines':case_lines,'new_receipt_functions':2,'failed_candidate_tests':0,'skipped_candidate_tests':0,'source_corrections':0,'runner_corrections':'resolved compiler graph symlink alias after successful baseline compile; resumed binary without rebuild','native_diagnostics':'nil in both baseline/candidate','real_models_run':False})
(out/'REVIEW.md').write_text('''# Receipt lifetime validation\n\nThe original successful-submit defer removes the complete-store ready receipt before the engine reaches terminal. The new real-engine gated-forward negative control reproduced readyReceipts.count 0 (expected 1), then the missing durable callback. Exact original provider source and candidate tests are preserved separately.\n\nThe reviewed six-line provider ownership fix passed both new tests and all 14 requested regression filters: 88 distinct test functions, 92 executions because four OuterPrefixCacheReceiptTests were selected twice by overlapping filters. No tests were weakened or skipped. Native diagnostics were present but unconfigured (nil). Tiny local model fixtures only; no downloaded models or network.\n\nThe successful baseline build was followed by a runner-only source-path assertion failure caused by the compiler naming native inputs through the workspace symlink. Original run.py, successful build, and runner-provenance-correction.json remain. run-resume.py resolves actual graph paths and reused the already successful baseline binary, then ran the negative control and candidate build/tests. All source hashes and complete owned compiler graph mappings are retained for each variant. No implementation correction occurred.\n\nThis validates receipt ownership lifecycle, cancellation, encrypted-store publication and the existing requested regressions. Real HTTP publication, numerical backend parity and release rollout remain separate gates.\n''')
files={}
for p in sorted(out.rglob('*')):
 if not p.is_file() or 'workspace' in p.relative_to(out).parts or '__pycache__' in p.relative_to(out).parts or p.name=='manifest.json':continue
 files[str(p.relative_to(out))]={'sha256':sha(p),'bytes':p.stat().st_size}
write('manifest.json',{'schema':1,'status':'PASS with intended baseline failure','files':files})
print(json.dumps({'manifest_sha256':sha(out/'manifest.json'),'payloads':len(files),'candidate_unique_functions':coverage['unique_functions']},indent=2))
