# Two-host source2: preserve full executable path in process discovery

One helper correction and one planted test extend source1. `observe()` now
splits ps output once into PID and complete comm, preserving spaces in executable
paths before taking the basename. The test plants a conflicting darkbloom path
with spaces, a separate explicitly owned PID, and an unrelated process; only the
conflicting PID is reported. All subprocess/telemetry/file calls are injected.

All 18 Python functions passed on this exact source. The 29 Go functions / 54
including subtests with the race detector from source1 remain explicitly carried
evidence: Go source is unchanged, with only the embedded Python string corrected.
Source1 and its original Darwin regression traceback remain immutable. No real
provider, model, Swift/GPU, remote, key, signing or production operation occurred.

Apply source1 plus this two-file delta, or copy the complete current worktree.
The source remains uncommitted pending root review.
