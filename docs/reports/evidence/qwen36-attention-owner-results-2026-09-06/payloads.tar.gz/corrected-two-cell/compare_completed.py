"""Report exact trajectories without treating earlier paged runs as this build."""
from pathlib import Path
import hashlib, json, struct

ROOT = Path(__file__).parent
OLD = Path('/tmp/darkbloom-q36-attention-metadata-execution1')
CONTROL = 'qwen36-contiguous-cache-off-mtp-off-trace-off'
TRACE = 'qwen36-contiguous-cache-off-mtp-off-trace-on'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def completed(r):
    return [(f'{g}/{i}',x) for g in ('rows','tenant_checks') for i,x in enumerate(r[g])] + [
        (g,r[g]) for g in ('cancel_donor','recovered')]

def comparison(left,right):
    out=[]
    for (name,a),(other,b) in zip(completed(left),completed(right)):
        assert name==other
        fields=('prompt_token_ids','token_ids','prompt_tokens','completion_tokens','finish','outcome')
        out.append({'row':name,'differences':[k for k in fields if a[k]!=b[k]],
                    'prompt_tokens':[a['prompt_tokens'],b['prompt_tokens']],
                    'output_tokens':[len(a['token_ids']),len(b['token_ids'])]})
    assert len(out)==7
    return {'completed_trajectories':out,'all_exact':all(not x['differences'] for x in out),
            'cancelled_counts':[len(r['cancelled']['token_ids']) for r in (left,right)],
            'cancelled_is_own_recovery_prefix':[r['cancelled']['token_ids']==r['recovered']['token_ids'][:len(r['cancelled']['token_ids'])] for r in (left,right)]}

def main():
    paths={k:ROOT/v/'report.json' for k,v in [('control',CONTROL),('trace',TRACE)]}
    reports={k:json.loads(v.read_text()) for k,v in paths.items()}
    historical=json.loads((OLD/CONTROL/'report.json').read_text())
    trace=reports['trace'];meta=trace['attention_metadata'];snap=meta['snapshot']
    logit=trace['logit_diagnostic']['snapshot']['records'][0]
    result={'scope':'Two corrected contiguous cells on the same bound c1530462 probe only. Historical controls are explicitly earlier-build evidence; no mixed-build quartet or performance/accuracy claim.',
            'same_build_trace_impact':comparison(reports['control'],trace),
            'earlier_build_contiguous_comparison':comparison(historical,reports['control']),
            'reports':{k:{'path':str(v),'sha256':sha(v)} for k,v in paths.items()},
            'attention':{'status':meta['status'],'expected_owners':snap['expectedOwnerCount'],
                         'selected_forwards':snap['selectedForwards'],'refusals':snap['refusals'],
                         'owners':[{'dense_owner':r['storageLayerIndex'],'model_layer':r['modelLayerIndex'],
                                    'queries':r['queries'],'incoming_keys':r['incomingKeys'],
                                    'incoming_values':r['incomingValues'],'storage':r['storage'],
                                    'kernel_output_dtype':r['kernelOutputDType'],'output':r['output'],
                                    'dispatch':r['dispatch'],'offset_before':r['offsetBefore'],
                                    'offset_after':r['offsetAfter']} for r in snap['records']]},
            'logit':{**logit,'float32_values':[struct.unpack('<f',struct.pack('<I',x))[0] for x in logit['valueBits']]},
            'status':'PASS' if all(json.loads((ROOT/c/'summary.json').read_text())['report_integrity_passed'] for c in (CONTROL,TRACE)) else 'FAILED'}
    assert result['same_build_trace_impact']['all_exact']
    assert all(result['same_build_trace_impact']['cancelled_is_own_recovery_prefix'])
    target=ROOT/'two-cell-comparison.json'
    assert not target.exists()
    target.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'path':str(target),'sha256':sha(target),'status':result['status'],
                      'same_build_exact':result['same_build_trace_impact']['all_exact'],
                      'historical_contiguous_exact':result['earlier_build_contiguous_comparison']['all_exact'],
                      'owner_count':len(snap['records']),'argmax':logit['argMaxID'],
                      'values':result['logit']['float32_values']},indent=2))

if __name__=='__main__':
    main()
