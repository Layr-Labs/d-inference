from pathlib import Path
import hashlib,json,stat

out=Path(__file__).resolve().parent
base=Path('/tmp/darkbloom-final-serving-build8/artifact')
expected=json.loads((out/'runtime-resource-inputs.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows={}
for name,row in expected.items():
    original=base/name;current=out/'artifact'/name
    assert stat.S_ISREG(original.lstat().st_mode) and stat.S_ISREG(current.lstat().st_mode)
    assert sha(original)==sha(current)==row['sha256']
    assert original.stat().st_size==current.stat().st_size==row['bytes']
    before=stat.S_IMODE(original.stat().st_mode);after=stat.S_IMODE(current.stat().st_mode)
    assert before==after,(name,oct(before),oct(after))
    rows[name]={'sha256':sha(current),'bytes':current.stat().st_size,'original_mode':oct(before),
                'artifact_mode':oct(after),'original_source':str(original),'matched':True}
(out/'final-resource-mode-proof.json').write_text(json.dumps({'all_six_match_original_bytes_size_modes':True,'files':rows},indent=2)+'\n')
print(json.dumps(rows,indent=2))
