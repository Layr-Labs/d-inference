"""Retain existing strict comparator results and separately audit serial idle gauges."""

from pathlib import Path
import argparse
import hashlib
import json
import sys

SCRIPTS = Path('/tmp/darkbloom-final-serving-build3/scripts')
sys.path.insert(0, str(SCRIPTS))
from compare_radix_engine import compare


def digest(path):
    data = Path(path).read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def controls(report):
    for i, row in enumerate(report.get('rows', [])):
        yield f'rows[{i}]', row
    for i, row in enumerate(report.get('tenant_checks', [])):
        yield f'tenant_checks[{i}]', row
    for key in ('warmup', 'cancel_donor', 'cancelled', 'recovered'):
        if report.get(key):
            yield key, report[key]


def idle_observation(location, metrics, shutdown=False):
    paths = {
        'capacity': ('active_requests', 'waiting_requests', 'kv_in_use_bytes', 'kv_reserved_bytes'),
        'paged_storage': ('live_page_bytes', 'reserved_page_bytes', 'committed_bytes', 'segment_count'),
        'process_memory': ('charged_bytes', 'materialized_bytes', 'unmaterialized_bytes', 'closing_owner_count'),
    }
    if shutdown:
        paths['process_memory'] += ('owner_count',)
    if metrics.get('ssd_cache') is not None:
        paths['ssd_cache'] = ('staged_bytes_in_use', 'write_host_bytes_in_use')
    fields = {f'{section}.{key}': metrics.get(section, {}).get(key)
              for section, keys in paths.items() for key in keys}
    failures = {key: value for key, value in fields.items() if type(value) is not int or value != 0}
    return {'location': location, 'observed': fields, 'nonzero_or_missing': failures,
            'zero_observed': not failures}


def summarize(root, report):
    observations = [idle_observation(location, row.get('metrics_after', {}))
                    for location, row in controls(report) if not row.get('batch_id')]
    observations.append(idle_observation('metrics_after_shutdown', report.get('metrics_after_shutdown', {}), True))
    rows = []
    for location, row in controls(report):
        before = row.get('metrics_before', {})
        after = row.get('metrics_after', {})
        rows.append({'location': location, **{key: row.get(key) for key in (
            'id', 'outcome', 'finish', 'prompt_tokens', 'completion_tokens', 'ttft_s',
            'elapsed_s', 'cache_outcome', 'saved_tokens', 'matched_tokens', 'ssd_stage_disposition')},
            'stage_read_delta': after.get('ssd_cache', {}).get('stage_read_bytes', 0)
                - before.get('ssd_cache', {}).get('stage_read_bytes', 0),
            'mtp_rounds_delta': after.get('mtp', {}).get('rounds', 0)
                - before.get('mtp', {}).get('rounds', 0)})
    metadata = json.loads((root / 'metadata.json').read_text())
    return {'status': report.get('status'), 'model': report.get('model'),
            'verified_model_hash': report.get('verified_model_hash'),
            'runtime_identity': report.get('runtime_identity'), 'backend': report.get('resolved_backend'),
            'backend_fallback': report.get('backend_fallback'), 'mtp': report.get('mtp'),
            'assistant_identity': report.get('metrics_loaded', {}).get('assistant_identity'),
            'production_grant': report.get('production_grant'),
            'cache_mode': report.get('metrics_loaded', {}).get('cache_mode'),
            'entry_gpu_temp_c': metadata.get('entry_gpu_temp_c'),
            'rows': rows, 'idle_observations': observations,
            'all_serial_idle_gauges_zero': all(item['zero_observed'] for item in observations),
            'idle_scope': 'Immediate serial snapshots only; stale nonzero gauges remain failures pending a coherent snapshot rerun.'}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('baseline', type=Path)
    parser.add_argument('candidate', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    reports = [json.loads((root / 'report.json').read_text()) for root in (args.baseline, args.candidate)]
    verdict = compare(reports[0], reports[1], expect_hits=True, axis='cache')
    (args.output / 'strict-comparator-verdict.json').write_text(json.dumps(verdict, indent=2) + '\n')
    observations = {'scope': 'One ordered exact-artifact paged B1 cache-off/SSD pair; no repeated performance, HTTP, persistent restart, or release acceptance claim.',
                    'baseline': summarize(args.baseline, reports[0]),
                    'candidate': summarize(args.candidate, reports[1])}
    (args.output / 'observations.json').write_text(json.dumps(observations, indent=2) + '\n')
    files = [Path(__file__), SCRIPTS / 'compare_radix_engine.py', SCRIPTS / 'radix_engine_evidence.py']
    for root in (args.baseline, args.candidate):
        manifest = json.loads((root / 'manifest.json').read_text())
        for name, expected in manifest['files'].items():
            path = root / name
            assert digest(path) == expected, path
        files += sorted(path for path in root.rglob('*') if path.is_file())
    files += sorted(path for path in args.output.iterdir() if path.is_file())
    manifest = {'scope': observations['scope'], 'files': {str(path): digest(path) for path in files}}
    (args.output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'strict_comparator': verdict['passed'], 'errors': verdict['errors'],
                      'all_serial_idle_gauges_zero': {key: observations[key]['all_serial_idle_gauges_zero']
                                                     for key in ('baseline', 'candidate')},
                      'manifest': str(args.output / 'manifest.json'),
                      'manifest_sha256': digest(args.output / 'manifest.json')['sha256']}, indent=2))


if __name__ == '__main__':
    main()
