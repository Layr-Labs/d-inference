GPT B2 retained pilot: bounded raw evidence capsule

The strict backend comparison passes; the strict cache comparison fails. Both cache-off arms already have two different per-row trajectories. All twelve measured prompts are token-identical; the 128-token outputs form two vectors (five A rows, seven B rows). Cached repeat b0 matches all b1 outputs, but that does not establish restore correctness or authorize accepting another baseline row. The cache gate remains failed.

Read SOURCE-AUDIT.md and trajectory-analysis.json for the independent full-vector and chunk-timing audit. token-emissions.csv contains all1536 emitted output tokens with reported chunk and batch-relative coordinates. Emission timing and cohort-level width totals do not identify the forward selecting token3. The root cross-row audit is included as an independent check.

Run `python3 -B verify_capsule.py` for byte verification and the unchanged strict comparisons. It performs no model execution. To recompute the trajectory tables outside this immutable capsule, run `python3 -B analyze_trajectories.py --evidence raw --output /tmp/gpt-b2-reanalysis`.

raw/ retains the three reports, metadata, inputs, logs/telemetry, model identity before/after audits, entry/command/lifecycle receipts, source/runtime manifests and comparison results. audit-sources/ contains twelve exact source files bound to the historical runtime commits. frozen-evaluator/ contains the exact Plan3 runner, lifecycle/key helpers, comparison and evidence validators; these were separate from the repository runner at runtime parent682. The initial controller's pending-comparison stop and its non-rerunning continuation are retained.

EXCLUSIONS.json explicitly inventories omitted payloads. Runtime binaries, model weights, checkpoint ciphertext and key material are excluded. The original1.57GB archive and all131 extracted raw files/cache payloads remain unchanged locally. Hash-only references to excluded payloads remain in the original evidence manifest. Included raw reports/logs preserve owned test paths and timestamps. This capsule is prepared for review; nothing has been published.
