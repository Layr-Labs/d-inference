from pathlib import Path
import json,re,subprocess,time
exec(Path('/tmp/darkbloom-allocator-footprint-foundation1/verify.py').read_text())
(out/'source-verified-before-cpp.json').write_text(json.dumps(verify(),indent=2)+'\n');results=[]
def run(name,cmd,test=False):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=repos['mlx'],stdout=log,stderr=subprocess.STDOUT)
 body=(out/(name+'.log')).read_text();valid=not test or bool(re.search(r'test cases:\s+1\s+\|\s+1 passed\s+\|\s+0 failed',body));entry={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'selected_count_verified':valid};results.append(entry);(out/'cpp-execution.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:v for k,v in entry.items() if k!='command'}),flush=True)
 if r.returncode or not valid:raise SystemExit(r.returncode or 1)
for backend,metal in [('cpu','OFF'),('metal','ON')]:
 build=out/('build-'+backend)
 run(backend+'-configure',['cmake','-S',str(out/'cpp-project'),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.0','-DCMAKE_EXPORT_COMPILE_COMMANDS=ON','-DMLX_BUILD_METAL='+metal,'-DMLX_BUILD_CPU=ON','-DMLX_BUILD_CUDA=OFF','-DFETCHCONTENT_SOURCE_DIR_METAL_CPP='+str(repos['swift']/'Source/Cmlx/metal-cpp'),'-DFETCHCONTENT_SOURCE_DIR_DOCTEST=/tmp/darkbloom-mlx-memory-snapshot-validation1/build-cpu/_deps/doctest-src','-DFETCHCONTENT_SOURCE_DIR_FMT=/tmp/darkbloom-mlx-memory-snapshot-validation1/build-cpu/_deps/fmt-src'])
 run(backend+'-build',['cmake','--build',str(build),'--target','footprint_tests','--parallel','4'])
 for name,case in [('bounds','allocation footprint bounds fresh and cached buffer owners'),('prediction','allocation prediction does not change allocator counters'),('cache-regression','test cached allocation keeps capacity')]:run(backend+'-'+name,[str(build/'footprint_tests'),'--test-case='+case,'--no-skip=true'],test=True)
(out/'source-verified-after-cpp.json').write_text(json.dumps(verify(),indent=2)+'\n');print('CPP PASSED AND SOURCE VERIFIED',flush=True)
