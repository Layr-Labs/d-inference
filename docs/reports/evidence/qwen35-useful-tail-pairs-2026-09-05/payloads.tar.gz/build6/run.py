from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,time
out=Path('/tmp/darkbloom-final-serving-build6');old=Path('/tmp/darkbloom-final-serving-build5');ws=out/'workspace';scratch=Path('/tmp/darkbloom-final-serving-build1/build')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();info=json.loads((out/'integration.json').read_text());env=os.environ.copy();env.update(info['environment'])
def write(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
def verify():
 provider=json.loads((out/'provider-source-manifest.json').read_text());native=json.loads((out/'native-source-manifest.json').read_text());deps=json.loads((out/'dependency-source-manifest.json').read_text());harness=json.loads((out/'compile-source-manifest.json').read_text())
 for name,digest in provider['files'].items():assert sha(ws/name)==digest,name
 for name in provider['deleted_files']:assert not (ws/name).exists(),name
 for name,digest in native['files'].items():assert sha(ws/'libs/mlx-swift-lm'/name)==digest,name
 for key,digest in deps['files'].items():
  alias,name=key.split('/',1);assert sha(Path(deps['repositories'][alias])/name)==digest,key
 for name,digest in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():assert sha(scratch/'checkouts/swift-jinja'/name)==digest,name
 for name,row in harness['files'].items():assert sha(out/name)==row['sha256'],name
 return {'provider_inputs':len(provider['files']),'native_inputs':len(native['files']),'dependency_inputs':len(deps['files']),'jinja_inputs':27,'harness_inputs':len(harness['files']),'no_drift':True,'source_delta':'Reviewed two-file native useful-tail candidate only; identical build5 provider and harness.'}
write('source-verified-before.json',verify())
command=['swift','build','-c','release','--scratch-path',str(scratch),'--jobs','4','--disable-automatic-resolution','--product','radix-engine'];started=time.monotonic()
with (out/'build.log').open('w') as log:p=subprocess.run(command,cwd=out/'radix-engine',env=env,stdout=log,stderr=subprocess.STDOUT)
result={'command':command,'cwd':str(out/'radix-engine'),'seconds':time.monotonic()-started,'exit_code':p.returncode};write('execution.json',result);print(json.dumps(result),flush=True)
write('source-verified-after.json',verify());graph=scratch/'release.yaml';text=graph.read_text();(out/'actual-build-graph.yaml.gz').write_bytes(gzip.compress(graph.read_bytes(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'actual-package-state.json');assert p.returncode==0
expected=[ws/'provider-swift/Sources/ProviderCore/Inference/EngineV2Factory+BenchmarkSession.swift',ws/'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/MTP/EngineLoopV2+MTPPlanning.swift',ws/'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVSegments.swift',ws/'libs/mlx-swift/Source/MLX/AllocationFootprint.swift',ws/'libs/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp',out/'radix-engine/Sources/radix-engine/BenchmarkIdleObservation.swift'];rows=[]
for path in expected:
 aliases=[str(path),str(path.resolve()),str(path).replace('/tmp/','/private/tmp/',1),str(path.resolve()).replace('/private/tmp/','/tmp/',1)];actual=next((Path(x) for x in aliases if x in text),None);assert actual is not None,str(path);assert actual.resolve()==path.resolve();rows.append({'actual_compile_path':str(actual),'resolved_frozen_source':str(path.resolve()),'sha256':sha(path)})
assert '/checkouts/mlx-swift/Source/' not in text
write('actual-compiler-source-proof.json',{'paths':rows,'remote_mlx_compile_source_absent':True,'primary_source_excluded':True})
artifact=out/'artifact';artifact.mkdir();shutil.copy2(scratch/'arm64-apple-macosx/release/radix-engine',artifact/'radix-engine')
previous=json.loads((old/'artifact-manifest.json').read_text())
for name,row in previous['files'].items():
 assert sha(old/'artifact'/name)==row['sha256'],name
 if name=='radix-engine':continue
 target=artifact/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/'artifact'/name,target)
files={str(p.relative_to(artifact)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(artifact.rglob('*')) if p.is_file()}
write('artifact-manifest.json',{'scope':'Distinct useful-tail probe. Use this same binary for both arms of new normal-MTP pairs. Six runtime resources remain identical to build5. Existing CLI was not rebuilt and does not include this native policy change.','files':files,'baseline_probe':previous['files']['radix-engine'],'cli_rebuilt':False})
(out/'radix-engine-dylibs.txt').write_text(subprocess.check_output(['otool','-L',str(artifact/'radix-engine')],text=True));write('source-verified-final.json',verify());print('USEFUL-TAIL SERVING PROBE PASS '+files['radix-engine']['sha256'],flush=True)
