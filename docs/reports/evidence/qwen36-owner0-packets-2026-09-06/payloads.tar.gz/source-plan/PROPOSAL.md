First actual Qwen3.6 attention packet experiment

This is a source-checked, runtime-unbound draft for four diagnostic cells. It does not authorize remote execution. Root reviews the final artifact binding; the actual-logit agent owns M5. Use exactly committed parent98103b397/native dcf39f6b, including cancellation settlement and bounded packet capture, excluding namespace. No serving defaults, model configuration, query precision, weights, input body, sampler, MTP, or generation limit change.

Run order and owner choice

1. New-build contiguous control, all three diagnostics absent.
2. New-build paged control, all three diagnostics absent.
3. Same-build contiguous capture, packet owner0/model layer3 at request2/output62, with the existing logit and all-owner metadata flags at62.
4. Same-build paged capture with exactly the same diagnostic selection.

Owner0 is the first full-attention owner, model layer3 after the initial recurrent layers. It can reveal query/incoming-KV or stored-history divergence before later full-attention owners amplify it. It is not the model's first layer. Both controls finish before either capture, and each capture requires its own backend's successful control. A later owner9/model39 capture or bounded owner search requires a separately reviewed successor plan; it is not an automatic extra cell here.

Inputs and execution prerequisites

The retained input is byte-identical to the September6 metadata experiment, SHA256 4fb1ebf2b8a4b9b29be3388da3613398c8c7b6f768ca8bac11636a8928dd570e. The current wrapper's date-pinning serialization was exercised locally and produces the same hash/72,677 bytes. The two original requests retain max_tokens128 and every request field. The expected selected trajectory remains 5,523 prompt tokens and 83 generated tokens; no truncation/teacher forcing is introduced to reach index62.

Before every cell, bind the final optimized probe SHA, regular0755 executable mode, six byte/size/mode-identical runtime resources, wrapper/analyzer sources from981, actual verified model aggregate d932e96b00404b0575fff47e2dac8ed113056b3f22d0040c3c8d3f9ef25b09ed, and actual input bytes. The model aggregate is distinct from the executable hash. Rehash the staged bundle before opening the model. Preserve the package/build/CLI provenance separately; this experiment runs the probe only.

Require a fresh root, explicit sole M5 ownership, GPU temperature≤42°C, load1≤4 and at least100GiB free. Abort or cool using the reviewed execution controller if those guards fail. No keychain, daemon, alias or production changes. Cache remains off, MTP off, B1, SSD serving construction, explicit ephemeral key, production KV grant. The input date is UTC2026-09-06; after rollover, preserve this draft and create a fresh date successor with an explicit delta and new controls. The wrapper alone validates date syntax and does not enforce wall-clock equality; the eventual execution controller must enforce this guard. `plan.json` contains parsed wrapper and actual post-date-pin native argv. No launcher is supplied by this draft.

Required trajectory and lifecycle checks

Use the unchanged `radix_engine_evidence.report_errors` on every complete report. Preserve every error and each failed/partial run; process exit0 alone is insufficient. Require the requested/resolved backend exact, no fallback, B1/MTPoff/cacheoff, verified input/model identities, normal cleanup, no live request/staging/pages after retirement/shutdown, no resident prefix retention, and the existing tenant/donor/cancellation/recovery invariants. Compare the same-build control with its captured arm: all seven completed trajectories (two main rows, three tenant rows, cancellation donor and recovery) must match complete prompt/token IDs, termination and counts exactly. Partial cancellation timing can change the number of emitted tokens; each canceled sequence must remain a nonempty prefix of its own completed recovery, with the unchanged cancellation and idle-cleanup assertions. Record any count difference; do not claim exact canceled-prefix length parity.

The selected first main row must still have 5,523 prompt IDs, 83 generated IDs, clean stop and expected seed token11346 at token_ids[61]. Compare both new controls against the retained pre-capture trajectories; report any drift and do not silently substitute an altered trajectory. Run the unchanged strict contiguous→paged comparator on the new controls and preserve its actual verdict. The prior divergence at index62 (1928 versus6829) is context, not an accepted numeric tolerance. Before attributing this selected decision, require same prompt IDs and first62 generated IDs across the new controls. Reconcile each captured snapshot seed with actual token_ids[61] and target with token_ids[62]; do not hardcode a successful target.

The logit record must be one confirmed request2/index62 B1 ordinary decode or chained_decode decision, with matching seed/target/offset and no invalid or omitted records. All-owner metadata must contain ten distinct dense owners0…9 mapped to model layers3,7,…39, one successful selected forward, no refusals and confirmed outcome. Its phase and selected identity must agree with logits. A constructed, failed, canceled or discarded step is not an actual confirmed decision.

Raw packet identity and lifetime checks

Require report.attention_packet.status=captured, evaluation_status=completed and its packet_sha256 to match the actual packet descriptor. The packet lives in report.attention-packet under that cell root. Preserve its private0700 directory and exactly eight regular files: packet.json, attention-metadata.json and the six declared tensors. Reject traversal, symlink escapes, extra or duplicate tensor files, partial descriptors, unsupported geometry, incorrect modes, malformed hashes and byte-budget violations before interpreting numbers. The analyzer enforces regular path/length/hash/shape/native-format bounds; the controller additionally checks the exact fresh directory inventory and report binding.

Load with the banked `attention_packet.packet.load_packet` and retain raw failure output. Require v1, metadata recordIndex0, expectedOwnerCount1, exactly one record, configured and recorded request2/output62, dense storageLayerIndex0 and original modelLayerIndex3. This private one-owner snapshot is intentionally distinct from the all-ten-owner metadata snapshot. Require selectedForwards1, forwardSucceeded=true, sampleOutcome=confirmed, no refusals, record batchIndex0/batchSize1/inputWidth1, ordinary decode/chained_decode, no shared KV/bidirectional/MTP/sinks/softcap/spans, visible [0,5585), offset5584→5585, and finite positive FP32 scale with exact scaleBits1031798784 (0.0625).

The packet's actual modelID, verified model aggregate and input SHA must equal the report's authenticated loaded/input identities, and backend must equal that cell. Require exact Q/output shape[1,16,1,256], incomingKV[1,2,1,256] and storedKV[1,2,5585,256]. Observe every original native dtype; do not narrow Q or assume BF16. Graph-construction strides describe observed lazy tensors only; packedStrides describe the exported chronological [B,H,T,D] payload. Validate each native little-endian shape/stride/byte count/hash and exactly six names. Total raw data≤32MiB and each JSON≤256KiB. Conservative FP32 reservation is22,913,024 bytes; all-BF16 payload would be11,456,512 bytes. Larger or unsupported selections refuse explicitly; this diagnostic bound is not a serving context limit.

The packet record must agree with the selected all-owner metadata record on observed Q/incomingKV/storage/output metadata, scale, layer indices, offset, phase and actual dispatch. At this T the paged dispatch is expected segmented; contiguous reports contiguous_sdpa. These labels do not identify every internal native SDPA kernel. Reconcile confirmation and seed/target across all three diagnostics. Record any refusal as incomplete evidence, never reconstruct missing bytes.

Numerical analysis and what it proves

Run the banked CPU analyzer on each frozen packet, using the same retained analyzer source and recorded Python/NumPy versions. Retain fresh analysis outputs and stderr, exact input/metadata/tensor hashes, per-head/global L-infinity/RMSE/relative-L2, intermediate/tensor nonfinite counts, outward-dtype rounded reference and optional separately labeled narrower-Q counterfactual. Require status=analyzed with no inconclusiveReasons and zero bitwise mismatches between the stored last row and incoming K/V before interpreting reference statistics. Analyzed is not a numerical pass.

From the runner directory the offline command is:

```
python3 -B -m attention_packet /LOCAL_FROZEN_CELL/report.attention-packet/packet.json --output /NEW_ANALYSIS.json
```

Compare cross-backend native tensor shapes/dtypes/scale and bytes before comparing outputs. Report bitwise mismatched elements separately for original Q, incoming K/V, complete stored K/V and returned output; report head/token/channel locations and nonfinite values without dumping unbounded arrays. If Q or stored K/V differ, each arm's reference explains only that arm. Equal emitted prefixes do not establish equal hidden/recurrent state or attention inputs.

The source-grounded hypothesis is that pinned MLX's two-pass vector SDPA can retain unnormalized partials in T: the host allocates intermediate(q.dtype()), and sdpa_vector_2pass_1/1_gqa writes static_cast<T> through device T*, then the merge reads T. The paged segmented implementation retains FP32 partials until final output. Thus all-BF16 observed inputs do not exclude different internal partial rounding. `hypothesis-source/` preserves the exact local MLX/paged sources and hashes. This is a hypothesis, not the cause established by metadata or by these two independent trajectories. Do not emulate MLX rounding merely to force token parity or change production query dtype.

A coherent same-input actual native-SDPA versus actual-paged replay, alongside the original-Q FP32 reference, remains required to attribute operator error. It must feed the exact same captured Q and chronological K/V into both genuine implementations with identical scale/geometry and preserve all outputs; neither a Python imitation of native rounding nor comparison of different model states supplies that proof. This draft has no such replay seam and makes no replay claim. Likewise, exported stored history may share a gather/decode layout fault: a separately captured incoming-KV history mirror is needed for independent long-history storage proof. Captured tail equality alone is insufficient.

After these four cells, stop and review the observed inputs, trajectory perturbation and descriptive error. Preserve all failures and unsupported packets. No diagnostic timing, analyzer status, successful artifact build or single-owner capture is a release-readiness or speedup claim.
