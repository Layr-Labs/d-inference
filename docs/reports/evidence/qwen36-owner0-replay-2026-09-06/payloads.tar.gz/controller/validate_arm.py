"""Bounded per-arm transport checks; complete interpretation belongs to collect()."""
from pathlib import Path

from attention_packet.files import (MAX_JSON_BYTES, MAX_TENSOR_BYTES, digest,
                                    hashed_file, parse_json, payload_path,
                                    read_bounded, require, sha256)
from attention_packet.packet import tensor_descriptor
from attention_replay.transfer import ARMS, DISPATCH


def validate_arm(arm_root, arm, left_packet, right_packet, transfer, transfer_sha):
    """Check one received arm without repeating the banked three-arm collector.

    Packets and transfer were admitted by the reviewed plan before execution.
    This receipt proves bounded payload identity only; page placement, full KV
    identity, nonfinite values and both original-output comparisons remain for
    final collection. Independent arms may run before that interpretation.
    """
    require(arm in ARMS, "unknown replay arm")
    digest(transfer_sha, "transfer SHA256")
    require(transfer.get("packetSHA256") == left_packet.packet_sha256,
            "transfer packet identity mismatch")
    root = Path(arm_root).resolve(strict=True)
    used = set()
    raw_result = read_bounded(payload_path(root, "result.json", used), MAX_JSON_BYTES)
    result = parse_json(raw_result)
    require(result.get("schema") == "darkbloom.attention-replay-result.v1"
            and result.get("inputSHA256") == transfer_sha and result.get("arm") == arm,
            "replay result input or arm identity mismatch")
    require(result.get("dispatch") == DISPATCH[arm], "replay dispatch mismatch")
    require(result.get("geometry") == transfer["geometry"], "replay geometry mismatch")
    descriptors = result.get("tensors")
    expected = {"output"} if arm == "nativeSDPA" else {"output", "storedKeys", "storedValues"}
    require(isinstance(descriptors, dict) and set(descriptors) == expected,
            "incomplete replay tensor result")
    require(sum(tensor_descriptor(d) for d in descriptors.values()) <= MAX_TENSOR_BYTES,
            "replay result exceeds native byte budget")
    for name, descriptor in descriptors.items():
        source = left_packet.tensors["queries" if name == "output" else name].descriptor
        require(descriptor["dtype"] == source["dtype"] and descriptor["shape"] == source["shape"],
                "replay result tensor shape or dtype mismatch")
        hashed_file(root, descriptor, used, MAX_TENSOR_BYTES)
    return {"schema": "darkbloom.attention-replay-arm-integrity.v1", "status": "analyzed",
            "inconclusiveReasons": [], "arm": arm, "inputSHA256": transfer_sha,
            "resultSHA256": sha256(raw_result),
            "packetSHA256": {"contiguous": left_packet.packet_sha256,
                             "paged": right_packet.packet_sha256},
            "tensors": descriptors, "requiresFinalCollection": True,
            "scope": "Bounded result and payload hashes only; no numerical or storage conclusion."}
