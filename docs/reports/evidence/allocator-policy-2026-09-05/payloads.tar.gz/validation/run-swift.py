from pathlib import Path
import gzip,json,re,shutil,subprocess,time
exec(Path('/tmp/darkbloom-allocator-footprint-policy-validation1/verify.py').read_text())
scratch=Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift');package=repos['swift'];(out/'source-verified-before-swift.json').write_text(json.dumps(verify(),indent=2)+'\n');results=[]
def run(name,cmd,test=False):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=package,stdout=log,stderr=subprocess.STDOUT)
 log=(out/(name+'.log')).read_text();valid=not test or (bool(re.search(r'Executed 6 tests, with 0 failures',log)) and not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped',log,re.M));e={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'selected_count_verified':valid};results.append(e);(out/'swift-execution.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:v for k,v in e.items() if k!='command'}),flush=True)
 if r.returncode or not valid:raise SystemExit(r.returncode or 1)
run('swift-build',['swift','build','--scratch-path',str(scratch),'--build-tests','--jobs','4','--disable-automatic-resolution'])
graph=(scratch/'debug.yaml').read_text();paths=[package/'Source/MLX/AllocationFootprint.swift',repos['mlx']/'mlx/backend/metal/allocator.cpp',repos['mlx-c']/'mlx/c/array.cpp',package/'Tests/MLXTests/AllocationFootprintTests.swift']
for p in paths:assert str(p) in graph or str(p.resolve()) in graph,p
assert str(root/'libs/mlx-swift/Source/MLX/AllocationFootprint.swift') not in graph
(out/'swift-actual-build-graph.yaml.gz').write_bytes(gzip.compress(graph.encode(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'swift-actual-package-state.json')
(out/'swift-compiler-source-proof.json').write_text(json.dumps({'paths':[str(p) for p in paths],'graph_lines':[x for x in graph.splitlines() if 'AllocationFootprint.swift' in x or 'mlx/backend/metal/allocator.cpp' in x or 'mlx/c/array.cpp' in x]},indent=2)+'\n')
lib=root/'provider-swift/.build/arm64-apple-macosx/debug/mlx.metallib';debug=scratch/'arm64-apple-macosx/debug';bundle=debug/'mlx-swiftPackageTests.xctest/Contents/MacOS';assert bundle.is_dir();targets=[debug/'mlx.metallib',bundle/'mlx.metallib']
for p in targets:shutil.copy2(lib,p)
(out/'swift-metallib-placement.json').write_text(json.dumps({'source':str(lib),'sha256':sha(lib),'destinations':[str(p) for p in targets],'kernel_sources_unchanged_by_footprint_candidate':True},indent=2)+'\n')
run('swift-identifiers',['swift','test','list','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution'])
run('swift-footprint',['swift','test','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution','--filter','AllocationFootprintTests'],test=True)
(out/'source-verified-after-swift.json').write_text(json.dumps(verify(),indent=2)+'\n');(out/'swift-actual-build-graph-after.yaml.gz').write_bytes(gzip.compress((scratch/'debug.yaml').read_bytes(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'swift-actual-package-state-after.json');print('SWIFT FOOTPRINT PASSED AND SOURCE VERIFIED',flush=True)
