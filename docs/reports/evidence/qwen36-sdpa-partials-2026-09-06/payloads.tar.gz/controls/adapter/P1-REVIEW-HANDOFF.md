# P1 repair handoff for independent re-review

September 6, 2026. **SOURCE-ONLY FIXES; RE-REVIEW REQUIRED; NO REPLAY AUTHORIZATION.**

Reviewer: Avicenna, `01a077d0-0df1-7543-a29b-0094e529ad1b`.
The rejected driver, original manifest, test logs, and receipts are preserved
in `history/failed-avicenna-01a077d0/`. No original candidate, Main build
source/binary, original packaging failure, or completed build receipt was
modified by this work.

## P1: owner death and forced cleanup

`ownership.py`, `leased.py`, and `adapter.py` now separate native ownership
from the owner's terminal receipt. The owner publishes the child birth and
PID/PGID immediately on its started event. The foreground independently
checks PID/birth/PGID/parent and atomically records `native-ownership.json`.
The child cannot exec the native binary until its registration has received
a matching foreground permit. The foreground retains the identity in memory
as well as on disk and always performs independent fallback retirement,
including after owner death, forced owner cleanup, or owner-cleanup errors.

Fallback uses the vetted B4 birth/PGID reuse refusal and bounded TERM/KILL
pattern. `fallback-retirement.json` must prove the registered group absent;
successful interpretation also cross-checks native PID/PGID/birth. No owner
terminal receipt, missing group proof, or previous successful arm can waive
this requirement or start a successor.

CPU tests include abrupt owner `_exit` while its native stand-in lives,
forced termination of a noncooperating owner, PID reuse refusal without a
foreign signal, caller EOF/expiry/stop/malformed input, interruption, native
deadline, and split native stdout/stderr. These use harmless Python children,
not either attention-replay binary or a model/GPU workload.

## P1: raw proof and actual Git-base verification

Top-level `evidence_manifest` must bind the full Main manifest before any
replay can start. `evidence.py` recomputes the **complete exact** selection in
`RAW-EVIDENCE-CONTRACT.json`, including raw release graphs, all compiler and
owned-step logs, original attempt1 records, full retained Metal trees, every
Swift compiler `.d`, actual inventory helper source/executable and output,
and twelve full Git-base tree dumps. Altered raw gzip bytes fail even if
their uncompressed content and every derived JSON/status field are unchanged.
Omitted or extra selected files also fail.

The recorded Git dumps must equal read-only `git ls-tree` output at the exact
pinned revisions. For every tracked file, the adapter checks the exact base
file set and blob/mode, recomputes its live Git-blob SHA and source identity,
and verifies the overlay marker against that actual result. A false
`overlay=false`, incomplete source list, changed Git dump, or changed
nonoverlay source cannot pass by updating a derived JSON flag. Known core
overlays remain explicitly overlaid on fab0, not mislabeled clean at fab0.

The raw Swift graph must match its retained origin and source entries; the
raw Metal API output must match full derived functions/device/architecture
and the hashed helper files. Per-arm runtime review records also bind
`evidence_manifest_sha256`, in addition to artifact and source manifests.
Main's outer approval binds the entire activation payload.

The Git/evidence refusal tests use materialized CPU source fixtures and a
mocked Git-tree reader. They do not certify Main's actual source tree or
artifacts; independent review and the actual verifier must do that before
execution.

## Main's frozen evidence contract

Compatibility: dependency proofs need only `resolved_lock` and
`actual_checkouts`. The adapter ignores any optional `all_exact_and_clean`
flag and independently requires a nonempty unique exact package set, matching
revisions, and empty dirty-status strings. No field is added to Main's frozen
evidence. A new refusal test covers missing/extra packages, wrong revisions,
dirty checkouts, and empty proofs.

The inventory contract is unchanged from the one Main used to freeze
`ROOT103/replay-evidence-manifest.json`. Main reported SHA-256
`900f7cc8a895bd3fcf6372a7f21a89258de9bc14b316bd1f8cad278534e3dfed`,
468692 bytes and 2137 entries. This is a reported identity, not a claim that
this agent downloaded or checked those M5 bytes. **No re-freeze or rebuild is
requested.** This adapter still leaves the evidence descriptor and all
runtime/host/approval/handoff bindings null until Main binds reviewed outputs.

The baseline's completed host/Metal builds and four original step receipts
remain accepted build evidence, not replay evidence. Packaging only actual
SwiftPM bundles is compatible: the adapter takes the exact artifact manifest
file set and does not require unused provider bundles. Actual
MTLLibrary.functionNames plus architecture are required; selected strings
alone are not accepted. `applegpu_g17s` implies 128 blocks for this packet.

## Re-review entry points

Run normal and optimized CPU tests with bytecode writes disabled; each has
41 tests. Final logs are `cpu-tests-p1-compat-final.log` and
`cpu-tests-p1-compat-optimized.log`; the previous 40-test logs remain preserved.
`adapter.py validate` without a separate binding must still refuse UNBOUND.
The current code/document manifest and hashes are in `manifest.json`; the
final driver SHA and test-log identities are in `validation-p1.json`.

Do not launch until independent re-review, Main's actual artifact/proof
binding, and a fresh caller-controlled replay handoff. Execution scope stays
exactly two sequential nativeSDPA arms, separate stdout/stderr, 180 seconds
per exec/native stage, baseline capture equality before a descriptive
variant, no tolerance/model-quality PASS. No D64/D128 GQA fix or serving
attribution is included.
