from pathlib import Path
import gzip,hashlib,json,os,re,shutil,stat
OUT=Path(__file__).resolve().parent;INFO=json.loads((OUT/'integration.json').read_text())
SCRATCH=Path(INFO['scratch']);NATIVE=Path(INFO['native']);HARNESS=Path(INFO['harness'])
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as s:
  for b in iter(lambda:s.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def tracked(root):return {str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file() and not any(x in {'.build','.swiftpm','__pycache__'} for x in p.relative_to(root).parts)}
KNOWN={}
for label,root in [('native',NATIVE),('harness',HARNESS)]:
 for name,digest in json.loads((OUT/(label+'-source-manifest.json')).read_text())['files'].items():KNOWN[str((root/name).resolve())]={'sha256':digest,'group':label}
deps=json.loads((OUT/'dependency-source-manifest.json').read_text())
for name,digest in deps['files'].items():
 alias,relative=name.split('/',1);KNOWN[str((Path(deps['repositories'][alias])/relative).resolve())]={'sha256':digest,'group':'dependency'}
for name,digest in json.loads((OUT/'jinja-source-manifest.json').read_text())['files'].items():KNOWN[str((SCRATCH/'checkouts/swift-jinja'/name).resolve())]={'sha256':digest,'group':'jinja'}
def verify():
 if (OUT/'preparation-manifest.json').exists():
  for name,row in json.loads((OUT/'preparation-manifest.json').read_text())['files'].items():
   p=OUT/name;assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'] and oct(stat.S_IMODE(p.stat().st_mode))==row['mode'],name
 for label,root in [('native',NATIVE),('harness',HARNESS)]:assert tracked(root)==json.loads((OUT/(label+'-source-manifest.json')).read_text())['files'],label
 for name,row in KNOWN.items():assert sha(Path(name))==row['sha256'],name
 for name,digest in json.loads((OUT/'package-resolution-inputs.json').read_text()).items():assert sha(OUT/name)==digest,name
 for name,row in json.loads((OUT/'runtime-resource-inputs.json').read_text()).items():
  p=Path(INFO['resource_origin'])/name;assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'] and oct(stat.S_IMODE(p.stat().st_mode))==row['mode'],name
 return {'no_drift':True,'counts':{g:sum(x['group']==g for x in KNOWN.values()) for g in ['native','harness','dependency','jinja']}}
def save_graph(label):
 for name in ['release.yaml','workspace-state.json']:
  p=SCRATCH/name
  if p.exists():(OUT/(label+'-'+name+('.gz' if name.endswith('yaml') else ''))).write_bytes(gzip.compress(p.read_bytes(),mtime=0) if name.endswith('yaml') else p.read_bytes())
def graph_proof():
 body=(SCRATCH/'release.yaml').read_text();rows={};unmapped=[]
 roots=[NATIVE.resolve(),HARNESS.resolve(),(Path(INFO['workspace'])/'libs/mlx-swift').resolve()]
 for literal in sorted(set(re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',body))):
  p=Path(literal);key=str(p.resolve())
  if key in KNOWN:
   assert sha(p)==KNOWN[key]['sha256'];rows[literal]={'resolved':key,**KNOWN[key]}
  elif any(key.startswith(str(root)+'/') for root in roots):unmapped.append(literal)
 assert not unmapped,unmapped
 assert '/checkouts/mlx-swift/Source/' not in body and '/Users/gaj/Documents/DarkbloomDev/wt/' not in body and '/ProviderCore.build/' not in body
 for name in ['CBv2AttentionReplay.swift','CBv2AttentionReplay+Paged.swift','AttentionReplayMain.swift','ReplayIO.swift','ReplayTransfer.swift']:
  assert any(p.endswith('/'+name) for p in rows),name
 write('actual-compiler-source-proof.json',{'files':rows,'unmapped_owned_sources':unmapped,'scope':'Actual declared compiler graph references and source hashes; no claim that every graph entry is linked into the selected executable.'})
def artifact():
 release=SCRATCH/'arm64-apple-macosx/release';dest=OUT/'artifact';dest.mkdir()
 src=release/'attention-replay';assert stat.S_ISREG(src.lstat().st_mode) and stat.S_IMODE(src.stat().st_mode)==0o755 and os.access(src,os.X_OK)
 shutil.copy2(src,dest/src.name);proof={}
 for name,row in json.loads((OUT/'runtime-resource-inputs.json').read_text()).items():
  # The paged kernel comes from this actual build. Other unchanged runtime
  # inputs are copied by hash from the reviewed build8 resource freeze.
  origin=release/name if name=='mlx-swift-lm_MLXLMCommon.bundle/pagedattention.metal' else Path(INFO['resource_origin'])/name
  assert sha(origin)==row['sha256'] and origin.stat().st_size==row['bytes'] and oct(stat.S_IMODE(origin.stat().st_mode))==row['mode'],name
  target=dest/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(origin,target)
  proof[name]={'source':str(origin),'sha256':sha(target),'bytes':target.stat().st_size,'mode':oct(stat.S_IMODE(target.stat().st_mode))}
 write('runtime-resource-proof.json',proof)
 files={str(p.relative_to(dest)):{'sha256':sha(p),'bytes':p.stat().st_size,'mode':oct(stat.S_IMODE(p.stat().st_mode))} for p in sorted(dest.rglob('*')) if p.is_file()}
 assert len(files)==7
 write('artifact-manifest.json',{'parent_commit':INFO['parent_commit'],'native_commit':INFO['native_commit'],'files':files,'scope':'Optimized standalone replay plus six exact resources; no model/packet numerical execution result'})
 return dest/'attention-replay'
