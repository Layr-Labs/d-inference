from pathlib import Path
import gzip,hashlib,json,re,shutil

out=Path('/tmp/darkbloom-q36-logit-diagnostic-validation3');native=out/'native'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
results=json.loads((out/'execution.json').read_text())
assert len(results)==14 and all(r['exit_code']==0 and r['nonzero_no_skips'] for r in results)
identifiers=[line.strip() for line in (out/'identifiers.log').read_text().splitlines() if line.startswith('MLXLMTests.')]
selected={}
for name in json.loads((out/'filters.json').read_text()):
 ids=[i for i in identifiers if name in i];body=(out/(name+'.log')).read_text()
 swift=[int(x) for x in re.findall(r'Test run with (\d+) tests?',body)]
 xct=[int(x) for x in re.findall(r'Executed (\d+) tests?, with 0 failures',body)]
 count=max(swift+xct+[0]);assert count==len(ids)>0,(name,count,len(ids))
 assert not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',body,re.M)
 parameterized=[int(x) for x in re.findall(r'✔ Test .* with (\d+) test cases passed',body)]
 selected[name]={'identifiers':ids,'test_functions':count,'expanded_test_cases':count+sum(x-1 for x in parameterized),'log_sha256':sha(out/(name+'.log')),'framework':'XCTest' if max(xct+[0]) else 'Swift Testing'}
unique={i for suite in selected.values() for i in suite['identifiers']}
assert len(unique)==sum(s['test_functions'] for s in selected.values())==139
body=(out/'CBv2QwenMTPIntegrationTests.log').read_text()
assert 'mode → .rectangular' in body and 'mode → .serialTarget' in body
assert '"actual MTP diagnostic separates rejected history without another target forward" with 2 test cases passed' in body
write('selected-identifiers.json',selected)
known={}
for name in ['native-source-manifest.json','ancillary-package-manifest.json']:
 for path,digest in json.loads((out/name).read_text())['files'].items():known[str((native/path).resolve())]={'group':'native' if name.startswith('native') else 'ancillary','sha256':digest}
deps=json.loads((out/'dependency-source-manifest.json').read_text())
for key,digest in deps['files'].items():
 alias,path=key.split('/',1);known[str((Path(deps['repositories'][alias])/path).resolve())]={'group':'dependency','sha256':digest}
scratch=Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift')
for path,digest in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():known[str((scratch/'checkouts/swift-jinja'/path).resolve())]={'group':'jinja','sha256':digest}
text=gzip.decompress((out/'actual-build-debug.yaml.gz').read_bytes()).decode();matched={};unknown=[]
for path in re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',text):
 p=Path(path);resolved=str(p.resolve());row=known.get(resolved)
 if row:
  assert sha(p)==row['sha256'],path;matched[path]={'resolved_source':resolved,**row}
 elif resolved.startswith(str(native.resolve())+'/'):unknown.append(path)
assert not unknown,unknown
write('all-owned-graph-source-proof.json',{'counts':{g:sum(r['group']==g for r in matched.values()) for g in ['native','ancillary','dependency','jinja']},'files':matched,'unmapped_native_source_paths':unknown,'scope':'Actual compiler graph paths matched against frozen source hashes; selected test execution recorded independently.'})
owned=json.loads((out/'native-source-manifest.json').read_text())['candidate_changes']
for path,row in owned.items():
 assert sha(native/path)==row['after_sha256'];p=out/'owned'/path;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(native/path,p)
write('verdict.json',{'status':'PASS_NATIVE_DIAGNOSTIC_AND_REGRESSION_TESTS','test_functions':139,'expanded_test_cases':sum(s['expanded_test_cases'] for s in selected.values()),'new_diagnostic_functions':8,'new_diagnostic_expanded_cases':9,'failed':0,'skipped':0,'native_inputs':484,'ancillary_package_inputs':405,'dependency_inputs':1356,'jinja_inputs':27,'source_correction':'One missing try inside a new Testing macro; all implementation/harness bytes unchanged from reviewed freeze1','build_seconds':results[0]['seconds'],'real_models_run':False,'provider_receipt_fix_included':False,'benchmark_tests_run':False,'next':'Separate reviewed provider receipt regression controls, benchmark unit build, then distinct release probe/CLI only after combined review.'})
files={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.relative_to(out).parts[0]!='native' and p.name!='manifest.json'}
write('manifest.json',{'schema':1,'status':'PASS_NATIVE_DIAGNOSTIC_AND_REGRESSION_TESTS','files':files,'test_binary':json.loads((out/'test-binary.json').read_text())})
for path,row in files.items():assert sha(out/path)==row['sha256']
print(json.dumps({'manifest':str(out/'manifest.json'),'sha256':sha(out/'manifest.json'),'payloads':len(files),'verdict':json.loads((out/'verdict.json').read_text())},indent=2))
