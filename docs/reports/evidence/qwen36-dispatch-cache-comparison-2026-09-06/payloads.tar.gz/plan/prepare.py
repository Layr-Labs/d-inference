"""Matched repeated paged controls; candidate runtime remains explicitly unbound."""
from pathlib import Path
import copy
import hashlib
import json
import shutil

ROOT=Path(__file__).resolve().parent
OLD=Path('/tmp/darkbloom-q36-attention-packet-plan1')
REMOTE='/Users/gaj/autoresearch/radix-prefix-cache/090-q36-paged-plan-cache-comparison1'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
def copy_file(path,relative):
    target=ROOT/relative;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(path,target)


def main():
    old=json.loads((OLD/'plan.json').read_text())
    source=next(c for c in old['cells']if c['id']=='qwen36-paged-control')
    for path in sorted((OLD/'runner').iterdir()):
        if path.is_file():copy_file(path,'runner/'+path.name)
    copy_file(OLD/'inputs/qwen36.json','inputs/qwen36.json')
    copy_file(OLD/'manifest.json','provenance/packet-source-plan-manifest.json')
    copy_file(Path('/tmp/darkbloom-generic-qat-release-probe1/artifact-manifest.json'),'provenance/baseline-artifacts.json')
    copy_file(Path('/tmp/darkbloom-generic-qat-release-probe-root-final-review1.json'),'provenance/baseline-root-review.json')
    input_sha=sha(ROOT/'inputs/qwen36.json')
    assert input_sha=='4fb1ebf2b8a4b9b29be3388da3613398c8c7b6f768ca8bac11636a8928dd570e'
    cells=[]
    for mode in ['off','on']:
        for repeat in [1,2,3]:
            order=['baseline','candidate']if repeat!=2 else ['candidate','baseline']
            for variant in order:
                name=f'qwen36-paged-mtp-{mode}-{variant}-rep{repeat}'
                argv=copy.deepcopy(source['argv'])
                argv=[x.replace(old['remote_root']+'/',REMOTE+'/')if x.startswith(old['remote_root']+'/')else x for x in argv]
                argv[argv.index('--binary')+1]=REMOTE+'/runtime/'+variant+'/radix-engine'
                argv[argv.index('--output')+1]=REMOTE+'/runs/'+name
                argv[argv.index('--mtp')+1]=mode
                argv[argv.index('--trial')+1]=str(repeat)
                native=copy.deepcopy(source['native_argv_after_date_pin'])
                native=[x.replace(old['remote_root']+'/',REMOTE+'/')if x.startswith(old['remote_root']+'/')else x for x in native]
                native[0]=REMOTE+'/runtime/'+variant+'/radix-engine'
                native[2]=REMOTE+'/runs/'+name+'/input.json';native[3]=REMOTE+'/runs/'+name+'/report.json'
                native[native.index('mtp-off')]='mtp-'+mode
                assert not any('diagnostic' in x or 'packet-'in x for x in argv)
                cells.append({'id':name,'variant':variant,'mtp':mode,'repeat':repeat,'backend':'paged',
                              'argv':argv,'expected_observed_native_argv':native})
    historical=json.loads(Path('/tmp/darkbloom-q36-attention-packet-execution1/qwen36-paged-control/report.json').read_text())
    plan={'scope':'Three matched old/new repeats per MTP mode, paged/cache-off/B1/normal KV grant, all diagnostics off. Whole-token correctness and descriptive timing are separate.',
        'state':'SOURCE_ONLY_CANDIDATE_UNBOUND','remote_root':REMOTE,'prompt_date_utc':'2026-09-06',
        'input_sha256':input_sha,'cells':cells,'baseline_binary_sha256':'3de3086d924e38893c31583f47309f3345733364956e0972287fa1ef7a6966c7',
        'baseline_parent':'6790dea1c7044ca336cd6383aac7e6d27afb7359','baseline_native':'b01e1af06902c82e22227bf923447cc71c47b148',
        'candidate':'Pending final optimized source/artifact binding; require exact provider/runner/native source correspondence and same six resource bytes.',
        'source_delta_expectation':'Provider and model runner match baseline; two unused standalone replay SPI files are additive, then four production cache paths plus two tests. Await exact built graph delta.',
        'historical_mtp_off_prompt_tokens':5523,'historical_mtp_off_token_ids':historical['rows'][0]['token_ids'],
        'historical_mtp_off_common_prefix_62':historical['rows'][0]['token_ids'][:62],
        'correctness':['Unchanged native report integrity oracle, exact requested/resolved paged backend with no fallback, exact input/model/runtime/argv/date/grant/cache/MTP mode.',
            'Compare all seven completed trajectories between old/new within each repeat and between repeats of each mode: exact prompt/output IDs, counts, finish and outcome.',
            'Canceled output remains a prefix of its own recovery; original tenant and terminal checks remain enforced.',
            'MTP-off historical trajectory is an explicit separate control. Normal-MTP is compared within its own newly observed matched controls, with no assumption it equals MTP-off.',
            'Unexpected execution/integrity or paired token failure stops dependent claims and preserves evidence. Existing cross-backend strict failures stay unchanged.'],
        'timing':['No logit/attention/packet diagnostics. Retain native first-token, complete output timing and raw chunk timestamps for both main rows.',
            'Primary descriptive repeat summary uses the second cache-off main row per fresh model process; report first-row measurements separately.',
            'Report each paired delta and median/range across three pairs; alternating second-pair order reduces one-way ordering bias without claiming statistical certainty.',
            'Report time from first delivered chunk to delivery of identical prefix up to62 tokens separately from full-output rate. For MTP, retain chunk boundaries and mark a chunk that straddles that prefix.',
            'Full delivered decode rate uses (N-1)/(last token delivery minus first token delivery) only for exact equal complete outputs; whole fixture/runtime initialization time is separate.',
            'Three repeats on one host/B1 are bounded engineering measurements, not broad fleet or model-quality acceptance.'],
        'lifecycle':'Use existing reviewed serial model wrapper; original idle/GPU<=42C/load1<=4/free>100GiB entry guards, exact runtime/model preflight, immutable output roots and preserved failures; no default/config/key/daemon changes.'}
    write(ROOT/'plan.json',plan)
    write(ROOT/'source-delta-check.json',{'base_cell':source['id'],'cells':12,'input_bytes_unchanged':True,
        'allowed_wrapper_deltas':['owned runner/binary/output/input paths','explicit MTP mode','trial metadata'],
        'allowed_native_deltas':['owned binary/input/report paths','explicit MTP mode'],
        'diagnostics_enabled':False,'candidate_bound':False,'remote_calls':0})
    files={str(p.relative_to(ROOT)):{'sha256':sha(p),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777)}
           for p in sorted(ROOT.rglob('*'))if p.is_file()}
    write(ROOT/'manifest.json',{'scope':plan['scope'],'files':files})
    print(json.dumps({'cells':12,'payloads':len(files),'manifest_sha256':sha(ROOT/'manifest.json'),'input_sha256':input_sha},indent=2))


if __name__=='__main__':main()
