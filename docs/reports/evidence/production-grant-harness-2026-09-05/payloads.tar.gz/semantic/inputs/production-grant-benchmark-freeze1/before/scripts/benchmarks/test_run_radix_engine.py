import contextlib
import io
import unittest

from run_radix_engine import arguments, probe_command


class EngineInvocationTests(unittest.TestCase):
    base = ["--binary", "/binary with spaces", "--model-directory", "/model",
            "--input", "/input.json", "--output", "/evidence"]

    def test_default_remains_compatible_with_archived_serial_binary(self):
        args = arguments(self.base)
        self.assertEqual(probe_command(args, "/result.json"),
                         ["/binary with spaces", "/model", "/input.json", "/result.json",
                          "cache-on", "mtp-off", "auto"])

    def test_concurrent_slot_grant_reaches_binary_after_key_mode(self):
        args = arguments(self.base + ["--concurrency", "4", "--kv-budget-gib", "24",
                                     "--cache-mode", "ssd", "--key-mode", "ephemeral",
                                     "--mtp", "on", "--kv-backend", "paged"])
        self.assertEqual(probe_command(args, "/result.json")[-7:],
                         ["paged", "ssd", "ephemeral-key", "--concurrency", "4",
                          "--kv-budget-gib", "24"])

    def test_invalid_concurrency_or_grant_is_rejected_before_host_work(self):
        for option in (["--concurrency", "0"], ["--concurrency", "8"],
                       ["--kv-budget-gib", "0"], ["--kv-budget-gib", "129"]):
            with self.subTest(option=option), contextlib.redirect_stderr(io.StringIO()):
                with self.assertRaises(SystemExit):
                    arguments(self.base + option)

    def test_ephemeral_key_requires_explicit_ssd_mode(self):
        with contextlib.redirect_stderr(io.StringIO()), self.assertRaises(SystemExit):
            arguments(self.base + ["--key-mode", "ephemeral"])


if __name__ == "__main__":
    unittest.main()
