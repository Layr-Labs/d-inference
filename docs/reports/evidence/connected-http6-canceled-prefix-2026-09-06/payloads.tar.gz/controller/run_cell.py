from common import *
import remote_scripts as code
import time

def main():
 cell,review_sha=sys.argv[1:];assert cell in CELLS
 summary,binding=frozen_inputs()
 output=REMOTE+'/runs/'+cell+'-run';local=Path('/tmp/darkbloom-connected-http6-results')/cell
 if cell==CELLS[1]:
  previous=local.parent/CELLS[0]
  manifest=json.loads((previous/'manifest.json').read_text())
  for name,record in manifest['files'].items():assert item(previous/name)==record,name
  assert not strict_cell(json.loads((previous/'launch.json').read_text()),json.loads((previous/'evidence/report.json').read_text()),CELLS[0])
 local.mkdir(parents=True,exist_ok=False)
 constants={'remote':REMOTE,'output':output,'review_sha':review_sha,'manifest_sha':summary['manifest']['sha256'],'binding_sha':summary['binding']['sha256']}
 exit_code=1
 try:
  ownership(local,'ownership-before')
  run(local,SSH+['python3 -B -'],'run-precheck',render(code.CHECK,constants))
  command=ENV+[PYTHON,'-B',REMOTE+'/run_connected_fixture.py','run','--cell',cell]
  expected=json.loads((PACKAGE/'execution-plan.json').read_text())['wrapper_argv_preview'][CELLS.index(cell)]
  assert command==expected,(command,expected)
  save(local/'command.json',{'command':command,'scope':'Exact HTTP6 cancellation + packet CLI. Ten original cases; cache pair only, no backend/release/persistent acceptance.'})
  started=time.monotonic()
  with (local/'ssh-run.log').open('x') as log:
   child=subprocess.Popen(SSH+[shlex.join(command)],stdout=log,stderr=subprocess.STDOUT)
   save(local/'live-handle.json',{'local_ssh_pid':child.pid,'remote_launch_path':output+'/launch.json','cell':cell})
   result=child.wait()
  save(local/'execution.json',{'exit_code':result,'seconds':time.monotonic()-started})
  # On transport interruption, require terminal remote launch state before collecting.
  inventory=run(local,SSH+['python3 -B -'],'remote-inventory',render(code.INVENTORY,constants))
  save(local/'remote-inventory.json',json.loads(inventory))
  for name,record in json.loads(inventory)['files'].items():
   target=local/name;target.parent.mkdir(parents=True,exist_ok=True)
   run(local,SCP+['gaj@100.124.35.99:'+output+'/'+name,str(target)],'collect-'+name.replace('/','-'))
   assert target.stat().st_size==record['bytes'] and sha(target)==record['sha256'],name
  ownership(local,'ownership-after')
  launch=json.loads((local/'launch.json').read_text());report=json.loads((local/'evidence/report.json').read_text())
  errors=strict_cell(launch,report,cell)
  if result:errors.append('remote command exit '+str(result))
  save(local/'strict-cell.json',{'passed':not errors,'errors':errors,'scope':'Exact current input/runtime and all ten original Go cases passed; separate unchanged comparator required for pair.'})
  exit_code=int(bool(errors))
 finally:freeze(local,'Raw HTTP6 cell with failures/unrun retained; no pair or release claim.')
 print(json.dumps({'cell':cell,'exit_code':exit_code,'local':str(local),'manifest_sha256':sha(local/'manifest.json')},indent=2));sys.exit(exit_code)
if __name__=='__main__':main()
