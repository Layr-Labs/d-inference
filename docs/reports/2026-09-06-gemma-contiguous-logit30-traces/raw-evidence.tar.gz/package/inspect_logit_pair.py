"""Offline interpretation only; lifecycle validation stays with the reviewed controller."""
from pathlib import Path
import argparse
import hashlib
import json
import math
import struct
import sys

ROOT=Path(__file__).resolve().parent
BASE=ROOT
sys.path.insert(0,str(ROOT))
sys.path.insert(0,str(ROOT/'runner'))
from control_validation import trajectories
from compare_radix_engine import mismatch

POSITION=30
CANDIDATES=[795,735]

def require(condition,message):
    if not condition:raise ValueError(message)

def f32(bits):
    require(type(bits) is int and 0<=bits<=0xffffffff,'invalid Float32 bits')
    value=struct.unpack('<f',struct.pack('<I',bits))[0]
    require(math.isfinite(value),'nonfinite observed score')
    return value

def counters(row):
    before=row['metrics_before'].get('mtp',{})
    after=row['metrics_after'].get('mtp',{})
    keys=['rounds','rectangular_rounds','serial_rounds','proposed_tokens','accepted_tokens','emitted_tokens','seed_steps']
    result={key:after.get(key,0)-before.get(key,0) for key in keys}
    for key in ['depth_selections','controller_fallbacks']:
        a,b=after.get(key,{}),before.get(key,{})
        result[key]={k:a.get(k,0)-b.get(k,0) for k in sorted(a.keys()|b.keys()) if a.get(k,0)-b.get(k,0)}
    result['verification_mode']=after.get('verification_mode')
    result['max_rectangular_tokens']=after.get('max_rectangular_tokens')
    return result

def inspect(report,control,mode):
    expected=795 if mode=='off' else 735
    left,right=trajectories(control),trajectories(report)
    require(len(left)==len(right)==7,'seven complete trajectories required')
    for (label,a),(other,b) in zip(left,right):
        require(label==other and not mismatch(a,b) and a.get('prompt_render_date')==b.get('prompt_render_date'),f'trace changed trajectory {label}')
    for before,after in zip(control['rows'],report['rows']):
        require(counters(before)==counters(after),'trace changed verifier counters')
    main=report['rows'][0]
    require(main['prompt_tokens']==5418 and len(main['token_ids'])==61 and main['finish']=='stop','wrong bound main request')
    require(main['token_ids'][POSITION]==expected,'wrong frozen boundary token')
    diagnostic=report.get('logit_diagnostic',{})
    require(diagnostic.get('status')=='captured','diagnostic inconclusive or missing')
    snapshot=diagnostic['snapshot'];config=snapshot['configuration']
    require(config=={'requestID':2,'outputIndex':POSITION,'candidateIDs':CANDIDATES,'maximumRecords':8},'configuration drift')
    require(snapshot['omittedRecords']==0 and snapshot['invalidVocabularyRecords']==0,'omitted or invalid vocabulary records')
    records=snapshot['records']
    require(snapshot['reservedRecords']==len(records) and 1<=len(records)<=8,'incomplete bounded record drain')
    selected=[r for r in records if r['outcome']=='confirmed']
    require(len(selected)==1,'need exactly one confirmed decision; other outcomes remain separate')
    rec=selected[0]
    require(rec['requestID']==2 and rec['outputIndex']==POSITION,'wrong decision identity')
    require(rec['batchIndex']==0 and rec['batchSize']==1,'not B1')
    require(rec['backend'].split('.')[-1]=='CBv2ContiguousKVBackend','wrong backend')
    require(rec['candidateIDs']==CANDIDATES and rec['vocabularySize']>max(CANDIDATES),'candidate identity drift')
    require(rec['nanCount']==rec['infiniteCount']==0,'nonfinite logits')
    column,base=rec['column'],rec['outputBase']
    require(base==POSITION-column and base>0,'invalid output base')
    require(rec['verificationWidth']==rec['draftDepth']+1 and 0<=column<rec['verificationWidth'],'invalid verify column')
    require(column<rec['confirmedWidth'] and column<=rec['acceptedDrafts'],'selected column is not confirmed')
    require(rec['cacheOffset']+column==main['prompt_tokens']+POSITION-1,'effective cache position mismatch')
    require([rec['seedToken']]+rec['draftPrefix']==main['token_ids'][base-1:POSITION],'causal input-token prefix mismatch')
    if mode=='off':
        require(rec['phase'] in ['decode','chained_decode','plain'] and rec['verificationWidth']==1,'wrong ordinary phase/width')
    else:
        require(rec['phase']=='rectangular_verify' and rec['verificationWidth']==2,'wrong automatic phase/width')
    require(rec['targetToken']==rec['argMaxID']==expected,'target/argmax/emitted disagreement')
    require(len(rec['topTwoIDs'])==2 and rec['topTwoIDs'][0]==rec['argMaxID'],'top-two/argmax disagreement')
    require(len(rec['valueBits'])==5,'wrong compact value packet')
    values=[f32(x) for x in rec['valueBits']]
    require(values[0]==values[1] and values[1]>=values[2],'top-score inconsistency')
    require(values[0]==values[3+CANDIDATES.index(expected)],'candidate and argmax score mismatch')
    delta=values[3]-values[4]
    require(delta>=0 if mode=='off' else delta<=0,'candidate score ordering contradicts argmax')
    return {'trace_output_parity_all_seven':True,'verifier_counter_parity':True,'record':rec,
            'argmax_logit':values[0],'top_two_logits':values[1:3],'top_two_gap':values[1]-values[2],
            'candidate_logits':dict(zip(map(str,CANDIDATES),values[3:])),
            'score_795_minus_735':delta,'causal_input_ids': [rec['seedToken']]+rec['draftPrefix'],
            'effective_position':rec['cacheOffset']+column,
            'full_target_input_ids':None,'pre_forward_state_equality':'UNOBSERVED',
            'other_records':[r for r in records if r is not rec]}

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--ordinary',type=Path,required=True);parser.add_argument('--automatic',type=Path,required=True);parser.add_argument('--output',type=Path,required=True);args=parser.parse_args()
    controls={mode:json.loads((BASE/'controls'/mode/'report.json').read_text()) for mode in ['off','automatic']}
    result={mode:inspect(json.loads(path.read_text()),controls[mode],mode) for mode,path in [('off',args.ordinary),('automatic',args.automatic)]}
    result['input_report_sha256']={mode:hashlib.sha256(path.read_bytes()).hexdigest() for mode,path in [('off',args.ordinary),('automatic',args.automatic)]}
    result['verifier_correctness']='FAILED: automatic differs from ordinary at index 30 in the frozen controls.'
    result['causal_conclusion']='Not established by these traces: same scalar position and causal token prefix do not prove the same KV contents or hidden state.'
    args.output.write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
if __name__=='__main__':main()
