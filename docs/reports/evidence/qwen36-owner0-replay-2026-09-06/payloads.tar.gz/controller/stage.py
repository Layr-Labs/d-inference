"""Create one isolated root, then copy exact reviewed source, input and runtime bytes."""
from pathlib import Path
import json
import sys
import tarfile

from common import (BINDING, PLAN, RESULTS, file_record, load_binding, remote, seal,
                    send, sha, write)
import remote_sources as snippets


def main():
    assert len(sys.argv) == 2, 'Pass the exact reviewed runtime-binding SHA256'
    binding, plan = load_binding(sys.argv[1])
    RESULTS.mkdir(exist_ok=False)
    local = RESULTS/'staging'; local.mkdir()
    configuration = {'remote_root': plan['remote_root'], 'binding_sha256': sha(BINDING)}
    try:
        files = json.loads((PLAN/'manifest.json').read_text())['files']
        files['manifest.json'] = file_record(PLAN/'manifest.json')
        archive = local/'plan-package.tar.gz'
        with tarfile.open(archive, 'x:gz') as tar:
            for name in sorted(files): tar.add(PLAN/name, arcname=name, recursive=False)
        write(local/'package-files.json', files)
        remote(local, 'entry-readiness', snippets.READINESS, {'entry': True})
        remote(local, 'create', snippets.CREATE, configuration)
        send(local, 'send-package', archive, plan['remote_root']+'/plan-package.tar.gz')
        remote(local, 'extract', snippets.EXTRACT,
               {**configuration, 'files': files, 'archive_sha256': sha(archive)})
        send(local, 'send-binding', BINDING, plan['remote_root']+'/runtime-binding.json')
        send(local, 'send-binary', Path(binding['artifact_root'])/'attention-replay',
             plan['remote_root']+'/runtime/attention-replay')
        remote(local, 'populate', snippets.POPULATE, {**configuration,
            'resources_source': '/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact'})
        remote(local, 'verify', snippets.VERIFY + '\nprint(json.dumps({"verified":True,"artifacts":len(binding["artifacts"]),"input_sha256":binding["input_sha256"]}))\n', configuration)
        write(local/'summary.json', {'status': 'PASS', 'runtime_sha256': binding['artifacts']['attention-replay']['sha256'],
                                    'binding_sha256': sha(BINDING), 'operator_invoked': False})
    except Exception as error:
        write(local/'summary.json', {'status': 'FAIL', 'error': type(error).__name__ + ': ' + str(error)})
        raise
    finally:
        seal(local)
    print((local/'summary.json').read_text(), flush=True)


if __name__ == '__main__': main()
