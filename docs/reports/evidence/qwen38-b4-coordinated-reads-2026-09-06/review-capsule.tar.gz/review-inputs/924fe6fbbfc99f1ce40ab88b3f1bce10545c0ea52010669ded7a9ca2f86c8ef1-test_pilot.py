import copy
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

import pilot
import pilot_core as core

ROOT = Path(__file__).resolve().parents[1]
FROZEN = Path("/private/tmp/darkbloom-qwen38-b4-plan1")
WORK = ROOT / "test-work"


def json_file(filename, value):
    filename.parent.mkdir(parents=True, exist_ok=True)
    filename.write_text(json.dumps(value) + "\n")
    return {"path": str(filename), "sha256": core.sha(filename)}


class SandboxTest(unittest.TestCase):
    def setUp(self):
        WORK.mkdir(exist_ok=True)
        self.temporary = tempfile.TemporaryDirectory(dir=WORK)
        self.directory = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()


class ReviewTests(SandboxTest):
    @classmethod
    def setUpClass(cls):
        cls.scoped = core.plan_module(FROZEN)
        cls.plan, cls.matrix = cls.scoped.load_plan()

    def fixture(self):
        directory = self.directory
        pins = core.read(ROOT / "source-pins.json")
        workspace = directory / "workspace"; workspace.mkdir()
        source = {"source": pins, "repositories": [{"name": name, "commit": commit, "relative_path": name}
                                                   for name, commit in pins.items()],
                  "files": {name: {"file.txt": {"sha256": "not-read-here"}} for name in pins}}
        source_record = json_file(directory / "source.json", source)
        runtime = directory / "artifact"; runtime.mkdir()
        names = self.matrix.RESOURCE_NAMES | {"radix-engine"}
        records = {name: json_file(runtime / name, {"cpu": name}) for name in names}
        artifacts = {name: {key: core.stable_file(record["path"])[key] for key in ("sha256", "bytes", "mode")}
                     for name, record in records.items()}
        artifact = {"source": pins, "files": artifacts, "M5_built": True,
                    "canonical_swiftpm_build": True, "manual_object_link": False}
        artifact_record = json_file(directory / "artifact.json", artifact)
        runtime_review = json_file(directory / "runtime-review.json", {"artifact_manifest_sha256": artifact_record["sha256"]})
        controller = json_file(directory / "controller-review.json", {
            "status": "QWEN_PILOT_CONTROLLER_REVIEWED", "driver_manifest_sha256": core.sha(ROOT / "manifest.json"),
            "only_cells": core.CELLS, "exclusive_host_id": "m5"})
        binding = {"reviewed_cell_ids": core.CELLS, "runtime_source_manifest": source_record,
                   "source_workspace": str(workspace), "artifact_manifest": artifact_record,
                   "binary": records["radix-engine"], "resources": {name: records[name] for name in self.matrix.RESOURCE_NAMES},
                   "runtime_review": runtime_review, "results_root": str(directory / "attempt/results")}
        binding["source_review"] = json_file(directory / "source-review.json", {"cpu_fixture": True})
        binding_path = directory / "binding.json"; json_file(binding_path, binding)
        ack_path = directory / "ack.json"
        json_file(ack_path, {"status": "QWEN_EXECUTION_AUTHORIZED", "review_id": "CPU ROOT fixture",
                           "binding_sha256": core.sha(binding_path), "only_cells": core.CELLS,
                           "host_id": "m5", "owned_controller_review": controller})
        return binding, binding_path, ack_path

    def test_candidate_activation_refuses_without_creating_attempt(self):
        with self.assertRaisesRegex(ValueError, "unbound"):
            core.activate(FROZEN, ROOT / "m5.candidate.json", self.directory / "missing-ack.json",
                          self.directory / "attempt", self.directory / "activation.json")
        self.assertFalse((self.directory / "attempt").exists())
        self.assertFalse((self.directory / "activation.json").exists())

    def test_new_signed_source_runtime_extension_passes_only_exact_scope(self):
        binding, filename, ack = self.fixture()
        with patch.object(self.scoped, "verified_binding", return_value=binding):
            self.assertEqual(core.context(FROZEN, filename, ack)[3], binding)
            for changed in (core.CELLS[:2], core.CELLS + ["qwen35-retained-b2-r1-paged-cache-off"],
                            [name.replace("qwen38", "gpt-oss-20b") for name in core.CELLS], list(reversed(core.CELLS))):
                binding["reviewed_cell_ids"] = changed
                with self.subTest(changed=changed), self.assertRaisesRegex(ValueError, "exact three"):
                    core.context(FROZEN, filename, ack)

    def test_activation_is_nonlaunching_and_verifies_again(self):
        binding, filename, ack = self.fixture()
        output = self.directory / "activation.json"
        with patch.object(self.scoped, "verified_binding", return_value=binding):
            value = core.activate(FROZEN, filename, ack, self.directory / "attempt", output)
            verified, _ = core.verify_activation(output, core.sha(output))
            self.assertEqual(value, verified)
            self.assertFalse(value["gpu_ready"])
            self.assertFalse((self.directory / "attempt").exists())
            with self.assertRaises(FileExistsError):
                core.activate(FROZEN, filename, ack, self.directory / "attempt", output)

    def test_old_source_and_runtime_manifest_refused(self):
        binding, filename, ack = self.fixture()
        with patch.object(self.scoped, "verified_binding", return_value=binding):
            source = core.read(binding["runtime_source_manifest"]["path"])
            source["source"]["parent"] = "0" * 40
            binding["runtime_source_manifest"] = json_file(self.directory / "wrong-source.json", source)
            with self.assertRaisesRegex(ValueError, "source selection"):
                core.context(FROZEN, filename, ack)

    def test_runtime_resource_and_review_drift_refused(self):
        binding, filename, ack = self.fixture()
        with patch.object(self.scoped, "verified_binding", return_value=binding):
            resource = Path(binding["binary"]["path"]); resource.write_text("changed binary")
            with self.assertRaisesRegex(ValueError, "identity drift"):
                core.context(FROZEN, filename, ack)

    def test_ack_cannot_expand_or_change_driver_review(self):
        binding, filename, ack = self.fixture()
        with patch.object(self.scoped, "verified_binding", return_value=binding):
            value = core.read(ack); value["only_cells"].append("gemma-4-26b-retained-b2-r1-paged-cache-off")
            json_file(ack, value)
            with self.assertRaisesRegex(ValueError, "ACK"):
                core.context(FROZEN, filename, ack)

    def test_same_bytes_replaced_dependency_refused(self):
        filename = self.directory / "config.json"; filename.write_text("{}")
        identity = core.stable_file(filename)
        substitute = self.directory / "new.json"; substitute.write_bytes(filename.read_bytes()); substitute.replace(filename)
        activation = self.directory / "activation.json"
        json_file(activation, {"schema": 1, "only_cells": core.CELLS, "gpu_ready": False,
                              "dependencies": {str(filename): identity}})
        with self.assertRaisesRegex(ValueError, "dependency changed"):
            core.verify_activation(activation)

    def test_mutation_during_full_hash_refused(self):
        filename = self.directory / "payload"; filename.write_bytes(b"x" * (2 << 20))
        count = 0
        def checkpoint():
            nonlocal count
            count += 1
            if count == 2:
                with filename.open("ab") as stream:
                    stream.write(b"changed")
        with self.assertRaisesRegex(ValueError, "changed during audit"):
            core.stable_file(filename, checkpoint=checkpoint)

    def test_model_inventory_and_extra_config_refused(self):
        snapshot = self.directory / "model"; snapshot.mkdir()
        (snapshot / "weights.safetensors").write_bytes(b"cpu-only-fake-weights")
        identity = core.stable_file(snapshot / "weights.safetensors")
        json_file(self.directory / "model.json", {"files": [{"path": "weights.safetensors",
                   "size_bytes": identity["bytes"], "sha256": identity["sha256"]}]})
        plan = {"models": [{"label": "qwen38", "model_id": "exact-cpu-model", "manifest": "model.json", "aggregate_sha256": "fixture"}]}
        binding = {"models": {"qwen38": {"directory": str(snapshot)}}}
        self.assertEqual(len(core.audit_model(self.directory, plan, binding)["files"]), 1)
        json_file(snapshot / "override-config.json", {})
        with self.assertRaisesRegex(ValueError, "unmanifested"):
            core.audit_model(self.directory, plan, binding)

    def test_source_dirty_or_file_mutation_refused(self):
        workspace = self.directory / "workspace"; workspace.mkdir()
        source_file = workspace / "source.swift"; source_file.write_text("cpu fixture")
        source = {"source": {"parent": core.SOURCE["parent"]}, "repositories": [
            {"name": "parent", "commit": core.SOURCE["parent"], "relative_path": "."}],
            "files": {"parent": {"source.swift": core.stable_file(source_file)}}}
        binding = {"source_workspace": str(workspace), "runtime_source_manifest": json_file(self.directory / "source.json", source)}
        with patch.object(core.subprocess, "check_output", side_effect=[core.SOURCE["parent"], " M source.swift"]):
            with self.assertRaisesRegex(ValueError, "source/config drift"):
                core.audit_sources(binding)
        source_file.write_text("changed")
        with patch.object(core.subprocess, "check_output", side_effect=[core.SOURCE["parent"], ""]):
            with self.assertRaisesRegex(ValueError, "identity drift"):
                core.audit_sources(binding)

    def test_frozen_payload_and_helpers_unchanged(self):
        provenance = core.read(ROOT / "provenance.json")
        self.assertEqual({str(filename.relative_to(FROZEN)): core.sha(filename) for filename in FROZEN.rglob("*") if filename.is_file()},
                         provenance["frozen_files"])
        for name, expected in provenance["helper_sources"].items():
            self.assertEqual(core.sha(ROOT / name), expected)


class EvidenceTests(SandboxTest):
    def test_lossless_archive_and_no_overwrite(self):
        json_file(self.directory / "report.json", {"token_ids": [101, 999, 102], "finish": "length"})
        (self.directory / "telemetry.log").write_bytes(b"raw\x00telemetry\n")
        before = {filename.name: filename.read_bytes() for filename in self.directory.iterdir()}
        self.assertEqual(core.seal(self.directory), 2)
        with tarfile.open(self.directory / "evidence.tar.gz") as archive:
            for name, raw in before.items():
                self.assertEqual(archive.extractfile(name).read(), raw)
        self.assertEqual((self.directory / "report.json").stat().st_mode & 0o222, 0)
        with self.assertRaises(FileExistsError):
            core.seal(self.directory)

    def test_mutation_during_collection_cannot_seal(self):
        filename = self.directory / "tokens.json"; filename.write_text("[1,2,3]")
        original = tarfile.TarFile.add
        def mutate(archive, name, *args, **kwargs):
            result = original(archive, name, *args, **kwargs)
            if str(name).endswith("tokens.json"):
                filename.write_text("[1,2,4]")
            return result
        with patch.object(tarfile.TarFile, "add", mutate):
            with self.assertRaisesRegex(ValueError, "archive hash differs"):
                core.seal(self.directory)

    def test_unexpected_model_processes_and_host_never_auto_ready(self):
        import owner_helper
        macmon = json_file(self.directory / "macmon", {"cpu": True})
        binding = {"macmon": macmon, "results_root": str(self.directory / "results"), "min_free_bytes": 100 * (1 << 30)}
        observation = {"hardware_model": "Mac17,6", "memory_bytes": 137438953472,
                       "gpu_temperature_c": 30, "load1": 1, "free_bytes": 200 * (1 << 30),
                       "unexpected_processes": [], "owned_processes": []}
        for index, (key, value) in enumerate((("gpu_temperature_c", 43), ("load1", 5),
                                            ("hardware_model", "Mac15,11"), ("unexpected_processes", [123]))):
            changed = dict(observation); changed[key] = value
            with patch.object(owner_helper, "observe", return_value=changed), \
                 patch.object(core.shutil, "disk_usage", return_value=shutil._ntuple_diskusage(10**12, 0, 10**12)):
                with self.assertRaisesRegex(ValueError, "entry refused"):
                    core.entry(binding, self.directory / (str(index) + ".json"), timeout=0)

    def test_stat_drift_after_audit_refuses_before_launch(self):
        filename = self.directory / "config.json"; filename.write_text("before")
        audited = {"source": {"config": core.stable_file(filename)}}
        filename.write_text("after")
        with self.assertRaisesRegex(ValueError, "changed after audit"):
            core.require_stable_stats(audited)

    def test_completed_output_cannot_be_replaced(self):
        result = self.directory / "results" / core.CELLS[0]
        json_file(result / "report.json", {"token_ids": [1, 2, 3]})
        json_file(self.directory / "steps/1/cell-results.json", {"cell": core.CELLS[0], "files": core.audit_tree(result)})
        core.verify_completed(self.directory)
        json_file(result / "report.json", {"token_ids": [1, 2, 4]})
        with self.assertRaisesRegex(ValueError, "baseline replacement"):
            core.verify_completed(self.directory)

    def test_orphan_retains_and_seals_partial_failure(self):
        json_file(self.directory / "controller.json", {"pid": 999999, "birth": "gone"})
        (self.directory / "partial.log").write_bytes(b"partial original output")
        with patch.object(pilot, "birth", return_value=None):
            self.assertTrue(pilot.finish_orphan(self.directory))
        self.assertFalse(core.read(self.directory / "terminal.json")["accepted"])
        self.assertTrue((self.directory / "evidence.tar.gz").is_file())


class WorkerTests(SandboxTest):
    def exercise(self, fail_prefix=None, audit_drift=False):
        scoped = core.plan_module(FROZEN)
        plan, matrix = scoped.load_plan()
        (self.directory / "steps").mkdir()
        json_file(self.directory / "supervisor.json", {"pid": os.getppid(), "birth": pilot.birth(os.getppid())})
        json_file(self.directory / "caller-lease.json", {"requires_external_pings": True, "alive": True,
                   "lease_seconds": 30, "last_ping_unix": time.time()})
        activation = {"run_root": str(self.directory), "plan_root": str(FROZEN), "ack": "cpu-fixture-ack"}
        binding = {"results_root": str(self.directory / "results"), "binary": {"path": "cpu-only-native"},
                   "macmon": {"path": "cpu-only-macmon"}}
        context = (scoped, plan, matrix, binding, {})
        def fake_command(plan, matrix, binding, cell_id, ack):
            return [sys.executable, "-B", str(FROZEN / "runner/run_radix_engine.py"), cell_id]
        launched = []
        def fake_execute(argv, step, allowed):
            cell_id = argv[-1]; launched.append(cell_id)
            json_file(Path(binding["results_root"]) / cell_id / "report.json", {"cpu_fixture": True})
            return 0
        def fake_collect(plan, matrix, binding, cells):
            passed = len(cells) != fail_prefix
            return {"completed_prefix_gates_passed": passed, "all_selected_supported_cells_accepted": passed and len(cells) == 3,
                    "comparisons": [{}] * (len(cells) - 1)}
        audits = [{"fixture": 1}, {"fixture": 2}] if audit_drift else None
        with patch.object(core, "verify_activation", return_value=(activation, context)), \
             patch.object(core, "audit_all", side_effect=audits, return_value={"fixture": 1}), \
             patch.object(core, "entry"), patch.object(scoped, "command", side_effect=fake_command), \
             patch.object(pilot, "execute_cell", side_effect=fake_execute), \
             patch.object(scoped, "collect", side_effect=fake_collect):
            status = pilot.worker(self.directory / "activation.json", "cpu-fixture")
        return status, launched

    def test_fresh_three_cell_order_no_history_reuse(self):
        status, launched = self.exercise()
        self.assertEqual(status, 0)
        self.assertEqual(launched, core.CELLS)
        for index in range(1, 4):
            self.assertEqual(len(core.read(self.directory / "steps" / str(index) / "verdict.json")["comparisons"]), index - 1)

    def test_backend_failure_blocks_cache_cell(self):
        status, launched = self.exercise(fail_prefix=2)
        self.assertEqual(status, 1)
        self.assertEqual(launched, core.CELLS[:2])
        self.assertFalse((self.directory / "steps/3").exists())

    def test_first_cell_failure_blocks_both_dependent_arms(self):
        status, launched = self.exercise(fail_prefix=1)
        self.assertEqual(status, 1)
        self.assertEqual(launched, core.CELLS[:1])

    def test_cache_failure_remains_failed(self):
        status, launched = self.exercise(fail_prefix=3)
        self.assertEqual(status, 1)
        self.assertEqual(launched, core.CELLS)
        self.assertFalse(core.read(self.directory / "worker-verdict.json")["accepted"])

    def test_postrun_model_source_drift_stops_following_cells(self):
        status, launched = self.exercise(audit_drift=True)
        self.assertEqual(status, 1)
        self.assertEqual(launched, core.CELLS[:1])


class ForegroundTests(SandboxTest):
    def exercise(self, scenario, deadline):
        activation = {"run_root": str(self.directory / "attempt"), "dependencies": {}}
        activation_path = self.directory / "activation.json"; json_file(activation_path, activation)
        original_popen = subprocess.Popen
        def fake_owned(argv, **kwargs):
            if "_owned" in argv:
                argv = [sys.executable, "-B", str(ROOT / "tests/cpu_child.py"), "supervise", activation["run_root"], scenario, "30", "60"]
            return original_popen(argv, **kwargs)
        with patch.object(core, "verify_activation", return_value=(activation, None)), \
             patch.object(core, "snapshot_reviews"), patch.object(pilot.subprocess, "Popen", side_effect=fake_owned), \
             patch.object(pilot, "TOTAL_DEADLINE", deadline):
            reader, writer = os.pipe()
            stop = threading.Event()
            def feed():
                try:
                    while not stop.is_set():
                        os.write(writer, b'{"command":"ping"}\n')
                        stop.wait(.05)
                except BrokenPipeError:
                    pass
            thread = threading.Thread(target=feed); thread.start()
            try:
                with os.fdopen(reader, "rb") as control:
                    status = pilot.run(activation_path, control)
            finally:
                stop.set(); thread.join(); os.close(writer)
        return status, Path(activation["run_root"])

    def test_foreground_pings_completion_and_full_collection(self):
        status, run_root = self.exercise("complete", 10)
        self.assertEqual(status, 0)
        self.assertTrue(core.read(run_root / "collection-receipt.json")["verified"])

    def test_foreground_deadline_cleans_and_retains_failure(self):
        status, run_root = self.exercise("payload", -59)
        self.assertEqual(status, 1)
        self.assertFalse(core.read(run_root / "terminal.json")["accepted"])
        self.assertTrue(core.read(run_root / "foreground-retirement.json")["complete"])
        self.assertTrue((run_root / "evidence.tar.gz").exists())


class OwnershipTests(SandboxTest):
    def start(self, scenario="payload", lease=1.2, deadline=10, stdin=None):
        argv = [sys.executable, "-B", str(ROOT / "tests/cpu_child.py"), "supervise", str(self.directory),
                scenario, str(lease), str(deadline)]
        process = subprocess.Popen(argv, stdin=subprocess.PIPE if stdin is None else stdin,
                                   stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
        self.addCleanup(self.cleanup_process, process)
        return process

    def cleanup_process(self, process):
        if process.poll() is None:
            process.terminate()
            try:
                process.wait(timeout=15)
            except subprocess.TimeoutExpired:
                process.kill(); process.wait(timeout=10)
        for stream in (process.stdin, process.stdout, process.stderr):
            if stream:
                stream.close()

    def wait_child(self, process):
        deadline = time.monotonic() + 5
        while not (self.directory / "cpu-child.json").exists():
            if process.poll() is not None:
                self.fail(process.stderr.read().decode())
            if time.monotonic() >= deadline:
                self.fail("CPU child fixture did not start")
            time.sleep(.02)

    def assert_retired(self, process):
        process.wait(timeout=20)
        cleanup = core.read(self.directory / "detached-retirement.json")
        self.assertTrue(cleanup["complete"], cleanup)
        self.assertTrue(all(row["group_absent"] for row in cleanup["groups"]))
        self.assertFalse(core.read(self.directory / "supervisor-terminal.json")["accepted"])
        if (self.directory / "cpu-child.json").exists():
            self.assertFalse(pilot.group_present(core.read(self.directory / "cpu-child.json")["pid"]))

    def test_normal_owned_cpu_completion(self):
        process = self.start("complete")
        process.stdin.write(b'{"command":"ping"}\n'); process.stdin.flush()
        process.wait(timeout=10)
        self.assertEqual(process.returncode, 0, process.stderr.read())
        self.assertTrue(core.read(self.directory / "supervisor-terminal.json")["accepted"])

    def test_eof_retires_detached_native_fixture(self):
        process = self.start(); self.wait_child(process); process.stdin.close()
        self.assert_retired(process)

    def test_stop_retires_detached_native_fixture(self):
        process = self.start(); self.wait_child(process)
        process.stdin.write(b'{"command":"stop"}\n'); process.stdin.flush()
        self.assert_retired(process)

    def test_lease_expiry_retires_detached_native_fixture(self):
        process = self.start(); self.wait_child(process)
        self.assert_retired(process)
        self.assertIn("lease expired", core.read(self.directory / "supervisor-terminal.json")["owner"]["failure"])

    def test_deadline_retires_even_with_pings(self):
        process = self.start(lease=3, deadline=.6); self.wait_child(process)
        while process.poll() is None:
            try:
                process.stdin.write(b'{"command":"ping"}\n'); process.stdin.flush()
            except BrokenPipeError:
                break
            time.sleep(.1)
        self.assert_retired(process)
        self.assertIn("deadline expired", core.read(self.directory / "supervisor-terminal.json")["owner"]["failure"])

    def test_signal_retires_owned_groups(self):
        process = self.start(); self.wait_child(process); process.send_signal(signal.SIGTERM)
        self.assert_retired(process)

    def test_hangup_retires_owned_groups(self):
        process = self.start(); self.wait_child(process); process.send_signal(signal.SIGHUP)
        self.assert_retired(process)

    def test_interrupt_retires_owned_groups(self):
        process = self.start(); self.wait_child(process); process.send_signal(signal.SIGINT)
        self.assert_retired(process)

    def test_prestart_stop_never_spawns(self):
        reader, writer = os.pipe()
        try:
            os.write(writer, b'{"command":"stop"}\n')
            process = self.start(stdin=reader); os.close(reader); reader = None
            self.assert_retired(process)
            self.assertFalse(core.read(self.directory / "supervisor-terminal.json")["owner"]["provider_started"])
        finally:
            if reader is not None:
                os.close(reader)
            os.close(writer)

    def test_pid_reuse_never_signals_foreign_group(self):
        with patch.object(pilot, "group_present", return_value=True), patch.object(pilot, "birth", return_value="new"), \
             patch.object(pilot.os, "killpg") as signal_group:
            with self.assertRaisesRegex(ValueError, "reused"):
                pilot.retire_known({"pid": 123456, "pgid": 123456, "birth": "old"})
            signal_group.assert_not_called()

    def test_permission_denied_group_probe_is_not_false_retirement(self):
        with patch.object(pilot.os, "killpg", side_effect=PermissionError("CPU zombie/foreign fixture")):
            self.assertTrue(pilot.group_present(123456))

    def test_forged_detached_parent_refused(self):
        step = self.directory / "steps/1"; step.mkdir(parents=True)
        json_file(step / "wrapper.json", {"pid": 123, "allowed_executables": [sys.executable]})
        (step / "children.jsonl").write_text(json.dumps({"event": "spawn", "pid": 456, "pgid": 456,
            "birth": "fixture", "parent_pid": 999, "argv": [sys.executable]}) + "\n")
        with patch.object(pilot, "retire_known") as retire:
            self.assertFalse(pilot.retire_detached(self.directory)["complete"])
            retire.assert_not_called()


if __name__ == "__main__":
    unittest.main()
