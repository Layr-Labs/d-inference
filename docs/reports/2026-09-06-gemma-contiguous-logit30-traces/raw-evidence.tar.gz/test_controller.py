import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'package'
sys.path.insert(0, str(PACKAGE))
import common
import remote_owner
import results
from control_validation import main_round_errors, MODES

class BindingTests(unittest.TestCase):
    def test_exact_retained_input_is_pinned_but_fallback_does_not_replace_an_existing_date(self):
        sys.path.insert(0, str(PACKAGE / 'runner'))
        from run_radix_engine import pin_prompt_date
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / 'input.json'
            pin_prompt_date(PACKAGE / 'inputs/input.json', output, '2026-09-06')
            self.assertEqual(output.read_bytes(), (PACKAGE / 'inputs/input.json').read_bytes())
            self.assertEqual(common.digest(output), '1abb54db891314531df0b6ddfbe3cc3418c29fd014133cdf3837133c9e9a3080')
            previous = ROOT / 'test-fixtures/old-date-input.json'
            pin_prompt_date(previous, output, '2026-09-06')
            self.assertEqual(output.read_bytes(), previous.read_bytes())
            self.assertEqual({row['request']['_darkbloom_prompt_date'] for row in common.read_json(output)['rows']}, {'2026-09-05'})

    def test_prepared_input_and_reference_dates_must_match_binding(self):
        binding = common.read_json(PACKAGE / 'binding.json')
        common.validate_prompt_dates(binding, PACKAGE)
        changed = dict(binding, prompt_date='2026-09-05')
        with self.assertRaisesRegex(ValueError, 'prompt date differs'):
            common.validate_prompt_dates(changed, PACKAGE)
        proof = common.read_json(ROOT / 'date-context-proof.json')
        reference = common.read_json(PACKAGE / 'inputs/reference-prompt-ids.json')
        self.assertEqual(len(proof['reference_reports']), 2)
        for row in proof['reference_reports']:
            original = common.read_json(Path(row['report']))
            self.assertEqual(original['input_sha256'], binding['input_sha256'])
            self.assertEqual([item['prompt_token_ids'] for item in original['rows']],
                             [item['prompt_token_ids'] for item in reference['rows']])
            self.assertEqual({item['prompt_render_date'] for item in original['rows']}, {'2026-09-06'})

    def test_complete_two_trace_package_validates_without_launch(self):
        binding = common.verify_package(common.digest(PACKAGE / 'manifest.json'), local=True)
        self.assertEqual(len(binding['cells']), 2)
        self.assertEqual(binding['profile']['MLX_GATHER_QMM_EXPERT_SLICES'], 'trust')

    def test_wrong_hash_still_refuses_under_optimized_python(self):
        code = 'import sys;sys.path.insert(0,' + repr(str(PACKAGE)) + ");from common import verify_package\ntry: verify_package('0'*64)\nexcept ValueError: print('REFUSED')\nelse: raise SystemExit(1)"
        result = subprocess.run([sys.executable, '-B', '-O', '-c', code], capture_output=True, text=True, timeout=10)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stdout.strip(), 'REFUSED')

    def test_runtime_mode_guard_uses_an_isolated_copy(self):
        binding = common.read_json(PACKAGE / 'binding.json')
        relative = 'swift-transformers_Hub.bundle/gpt2_tokenizer_config.json'
        source = Path(binding['local_runtime_source']) / relative
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / 'resource.json'
            path.write_bytes(source.read_bytes())
            path.chmod(0o644)
            common.check_file(path, binding['runtime']['files'][relative])
            path.chmod(0o600)
            with self.assertRaisesRegex(ValueError, 'identity differs'):
                common.check_file(path, binding['runtime']['files'][relative])

    def test_nonfinite_json_and_empty_predecessor_manifest_refuse(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root / 'value.json').write_text('{"timeout":NaN}')
            with self.assertRaises(ValueError): common.read_json(root / 'value.json')
            (root / 'manifest.json').write_text('{"files":{}}')
            with self.assertRaisesRegex(ValueError, 'incomplete predecessor'):
                results.verify_completed(root, {'id':'cell'}, {}, 'a'*64)

    def test_main_rows_cannot_borrow_warmup_rounds(self):
        for mode, (effective, selected, other) in MODES.items():
            before = {'active':True,'verification_mode':effective,'rounds':50,selected:50,other:0}
            after = dict(before, rounds=53);after[selected]=53
            row = {'id':'long-first','metrics_before':{'mtp':before},'metrics_after':{'mtp':after}}
            self.assertEqual(main_round_errors(row, mode), [])
            row['metrics_after'] = {'mtp':dict(before)}
            self.assertTrue(main_round_errors(row, mode))

    def test_space_containing_foreign_provider_path_is_not_missed(self):
        binding = common.read_json(PACKAGE / 'binding.json')
        def output(argv, **kwargs):
            if argv == ['ps','-axo','pid=,comm=']: return '777 /Applications/A Provider.app/Contents/MacOS/darkbloom\n'
            if argv == ['ps','-axo','pid=,args=']: return '777 /Applications/A Provider.app/Contents/MacOS/darkbloom start\n'
            if argv[-1] == 'hw.model': return binding['hardware_model']
            if argv[-1] == 'hw.memsize': return str(binding['memory_bytes'])
            raise AssertionError(argv)
        with patch.object(remote_owner.subprocess, 'check_output', side_effect=output), patch.object(remote_owner,'check_file'), patch.object(remote_owner,'read_temperature',return_value=25):
            with self.assertRaisesRegex(ValueError, 'foreign'):
                remote_owner.observation(binding)
            self.assertEqual(remote_owner.observation(binding, owned=(777,))['unexpected_processes'], [])

class DualGroupLifecycleTests(unittest.TestCase):
    def test_native_and_telemetry_groups_retire_on_natural_exit_and_term(self):
        for interrupt in [False, True, "eof", "lease"]:
            with self.subTest(interrupt=interrupt), tempfile.TemporaryDirectory() as directory:
                root = Path(directory).resolve();(root/'runs').mkdir();(root/'inputs').mkdir()
                (root/'inputs/input.json').write_text('{}')
                telemetry = root/'telemetry'
                telemetry.write_text('#!'+sys.executable+'\nimport time\nwhile True: print("{}",flush=True);time.sleep(.1)\n');telemetry.chmod(0o755)
                cell={'id':'cell','projection':False,'native_argv':[sys.executable,'-u','-c','import time;print("radix-model-ready",flush=True);time.sleep('+('300' if interrupt else '.2')+')']}
                binding={'state':'peer_reviewed','root':str(root),'cells':[cell],'profile':{},'macmon':{'path':str(telemetry)},'limits':{'startup_seconds':3,'lease_seconds':3,'native_seconds':5,'max_file_bytes':1<<20,'max_result_bytes':2<<20}}
                code='import sys;from pathlib import Path;sys.path.insert(0,'+repr(str(PACKAGE))+');import remote_owner as runner\n'
                code+='runner.ROOT=Path('+repr(str(root))+')\nrunner.snapshot=lambda *a,**k: {"passed":True}\n'
                code+='runner.result_errors=lambda *a,**k: []\n'
                code+='binding='+repr(binding)+'\nrunner.run_cell(binding,binding["cells"][0],"a"*64)\n'
                process=subprocess.Popen([sys.executable,'-B','-u','-c',code],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
                try:
                    first=json.loads(process.stdout.readline());self.assertEqual(first['event'],'started')
                    if interrupt is True: process.send_signal(signal.SIGTERM)
                    elif interrupt == 'eof': process.stdin.close();process.stdin = None
                    process.wait(timeout=8)
                    stdout,stderr=process.communicate(timeout=8)
                    self.assertEqual(process.returncode,0,stderr)
                    result=root/'runs/cell'
                    native=common.read_json(result/'terminal.json');meta=common.read_json(result/'metadata.json')
                    self.assertTrue(native['group_cleanup_complete'])
                    self.assertTrue(meta['telemetry_cleanup']['group_cleanup_complete'])
                    if interrupt: self.assertIsNotNone(native['failure'])
                    else:
                        self.assertEqual(native['exit_code'],0)
                        self.assertIsNone(native['failure'])
                    for pid in [native['pid'],meta['telemetry_cleanup']['pgid']]:
                        with self.assertRaises(ProcessLookupError): os.killpg(pid,0)
                finally:
                    if process.poll() is None: process.kill();process.wait(timeout=5)

if __name__ == '__main__': unittest.main()
