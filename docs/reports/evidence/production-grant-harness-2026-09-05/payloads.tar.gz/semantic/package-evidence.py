from pathlib import Path
import difflib,json,re,subprocess,tarfile
script=Path('/tmp/darkbloom-production-grant-harness-validation1/run.py').read_text();exec(script.split("assert (policy / 'manifest.json').exists()")[0]);assert (out/'source-verified-after.json').exists();verified=verify()
execution=json.loads((out/'execution.json').read_text());groups=json.loads((out/'filters.json').read_text());assert len(execution)==len(groups)+2
ids=[s for s in (out/'identifiers.log').read_text().splitlines() if s.startswith('ProviderCoreTests.')];selected={};summaries={};failures={}
for name,filters in groups.items():
 body=(out/(name+'.log')).read_text();row=next(x for x in execution if x['name']==name)
 if row['exit_code'] or not row['nonzero_and_no_skips']:
  failures[name]=[s for s in body.splitlines() if 'recorded an issue' in s or '✘' in s or ': error:' in s or 'Fatal error' in s or 'failed' in s.lower()];continue
 sw=re.findall(r'Test run with (\d+) tests?',body);swift=int(sw[-1]) if sw else 0;xc=max(map(int,re.findall(r'Executed (\d+) tests?',body)),default=0);extra=sum(int(n)-1 for n in re.findall(r'with (\d+) test cases passed',body));matches=[s for s in ids if any(f in s for f in filters)];assert len(matches)==swift+xc,(name,len(matches),swift+xc)
 assert not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test|recorded an issue|[✘]',body,re.M),name
 selected[name]=sorted(matches);summaries[name]={'functions':swift+xc,'cases':swift+xc+extra,'failures':0,'skips':0}
unique=sorted(set(s for g in selected.values() for s in g));assert len(unique)==sum(v['functions'] for v in summaries.values());(out/'selected-identifiers.json').write_text(json.dumps({'passed_by_group':selected,'unique_passed_identifiers':unique},indent=2)+'\n')
owned=json.loads((out/'owned-manifest.json').read_text())['files']
with tarfile.open(out/'owned-source.tar.gz','w:gz') as archive:
 for path,h in sorted(owned.items()):
  p=workspace/path;assert sha(p)==h;archive.add(p,arcname=path)
delta=json.loads((out/'harness-owned-manifest.json').read_text());baseline=Path(delta['baseline_workspace']);assert sha(Path(delta['baseline_manifest']))==delta['baseline_manifest_sha256'];patch='';changed={}
with tarfile.open(out/'harness-before-source.tar.gz','w:gz') as archive:
 for path,h in sorted(delta['files'].items()):
  previous=baseline/path;current=workspace/path;assert (sha(current) if current.exists() else None)==h,path
  before=previous.read_text() if previous.exists() else '';after=current.read_text() if current.exists() else ''
  if previous.exists():archive.add(previous,arcname=path)
  assert before!=after,path
  changed[path]={'before_sha256':sha(previous) if previous.exists() else None,'after_sha256':h}
  patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+path if previous.exists() else '/dev/null',tofile='b/'+path if current.exists() else '/dev/null'))
path=out/'harness-after-capacity.patch';path.write_text(patch);numstat=subprocess.check_output(['git','apply','--numstat',str(path)],cwd=workspace,text=True);assert sorted(s.split('\t')[-1] for s in numstat.splitlines())==sorted(changed)
# Check against the immutable baseline without changing it.
subprocess.run(['git','apply','--check',str(path)],cwd=baseline,check=True)
(out/'incremental-owned-manifest.json').write_text(json.dumps({'baseline':str(baseline),'baseline_manifest_sha256':delta['baseline_manifest_sha256'],'count':len(changed),'files':changed,'patch_sha256':sha(path)},indent=2)+'\n')
verdict={'status':'pass' if not failures else 'failed','provider_worktree_base':'69a75de82813beaf753fbbb4891c3b3261b63600','delta_baseline':str(baseline),'native_source':str(native),'native_evidence_sha256':sha(native.parent/'manifest.json'),'policy_evidence':str(policy/'manifest.json'),'policy_evidence_sha256':sha(policy/'manifest.json'),'build_seconds_reported':float(re.findall(r'Build complete! \(([0-9.]+)s\)',(out/'build.log').read_text())[-1]),'passed_unique_functions':len(unique),'passed_unique_cases':sum(v['cases'] for v in summaries.values()),'by_group':summaries,'failure_details':failures,'source_verified':verified,'owned_source_count':len(owned),'incremental_paths':len(changed), 'scope':'Benchmark production-grant SPI and provider benchmark-session semantic regressions. Exact standalone benchmark source frozen for subsequent release compilation.', 'limits':['This gate executes the focused Swift provider benchmark suites; standalone radix-engine release compilation and final full-size models remain pending.','Prior capacity/native/allocator evidence is linked, not rerun by this focused benchmark-source gate.','Python37 checks were performed by source agent/root on exactly verified frozen script bytes; separate raw log retained under inputs.','No HTTP, persistent-key restart, latency or fleet capacity claim from these tests.']}

(out/'evidence-lineage.json').write_text(json.dumps({'capacity_provider_pass':{'path':delta['baseline_manifest'],'sha256':delta['baseline_manifest_sha256']},'native_pass':{'path':str(native.parent/'manifest.json'),'sha256':sha(native.parent/'manifest.json')},'accepted_harness_source':{'path':'/tmp/darkbloom-production-grant-benchmark/freeze1/manifest.json','sha256':sha(Path('/tmp/darkbloom-production-grant-benchmark/freeze1/manifest.json'))}},indent=2)+'\n')
(out/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n');(out/'environment.txt').write_text(subprocess.check_output(['swift','--version'],text=True,stderr=subprocess.STDOUT)+subprocess.check_output(['sw_vers'],text=True)+subprocess.check_output(['uname','-a'],text=True))
files={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and 'workspace' not in p.relative_to(out).parts and p.name not in ['manifest.json','partial-manifest.json']};(out/'manifest.json').write_text(json.dumps({'scope':verdict['scope'],'files':files},indent=2)+'\n');print(json.dumps({'status':verdict['status'],'functions':len(unique),'cases':verdict['passed_unique_cases'],'failed_groups':list(failures),'payloads':len(files),'manifest_sha256':sha(out/'manifest.json')},indent=2))
