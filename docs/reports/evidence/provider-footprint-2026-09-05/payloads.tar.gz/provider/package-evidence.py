from pathlib import Path
import difflib, json, re, subprocess, tarfile

script = Path('/tmp/darkbloom-footprint-provider-validation1/run.py').read_text()
exec(script.split("assert (policy / 'manifest.json').exists()")[0])
assert (out / 'source-verified-after.json').exists()
assert verify()['no_drift']
execution = json.loads((out / 'execution.json').read_text())
assert len(execution) == 9 and all(row['exit_code'] == 0 and row['nonzero_and_no_skips'] for row in execution)
ids = [s for s in (out / 'identifiers.log').read_text().splitlines() if s.startswith('ProviderCoreTests.')]
groups = json.loads((out / 'filters.json').read_text())
selected, summaries = {}, {}
for name, filters in groups.items():
    body = (out / (name + '.log')).read_text()
    swift = int(re.findall(r'Test run with (\d+) tests?', body)[-1])
    xc = max(map(int, re.findall(r'Executed (\d+) tests?', body)), default=0)
    extra = sum(int(n)-1 for n in re.findall(r'with (\d+) test cases passed', body))
    matches = [s for s in ids if any(f in s for f in filters)]
    assert len(matches) == swift + xc, (name, len(matches), swift + xc)
    assert not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test|recorded an issue|[✘]', body, re.M)
    selected[name] = sorted(matches)
    summaries[name] = {'functions': swift + xc, 'cases': swift + xc + extra, 'failures': 0, 'skips': 0}
unique = sorted(set(s for group in selected.values() for s in group))
assert len(unique) == sum(v['functions'] for v in summaries.values())
assert summaries['real-native-isolated']['functions'] == 2
(out / 'selected-identifiers.json').write_text(json.dumps({'by_group': selected, 'unique_identifiers': unique}, indent=2) + '\n')
owned = json.loads((out / 'owned-manifest.json').read_text())['files']
patch = ''
with tarfile.open(out / 'owned-source.tar.gz', 'w:gz') as archive:
    for path in sorted(owned):
        p = workspace / path
        assert sha(p) == owned[path]
        archive.add(p, arcname=path)
        prior = root / path
        before = prior.read_text() if prior.exists() else ''
        patch += ''.join(difflib.unified_diff(before.splitlines(True), p.read_text().splitlines(True), fromfile='a/' + path if prior.exists() else '/dev/null', tofile='b/' + path))
(out / 'provider-against-banked.patch').write_text(patch)
subprocess.run(['git', 'apply', '--check', str(out / 'provider-against-banked.patch')], cwd=root, check=True)
numstat = subprocess.check_output(['git', 'apply', '--numstat', str(out / 'provider-against-banked.patch')], cwd=root, text=True)
assert sorted(line.split('\t')[-1] for line in numstat.splitlines()) == sorted(owned)
(out / 'bankable-patch.json').write_text(json.dumps({'sha256': sha(out / 'provider-against-banked.patch'), 'paths': sorted(owned), 'apply_check_passed': True}, indent=2) + '\n')
body = (out / 'real-native-isolated.log').read_text()
observations = {'memory': [], 'footprint': []}
for line in body.splitlines():
    if not line.startswith(('native-memory ', 'native-footprint ')):
        continue
    values = {}
    for part in line.split()[1:]:
        key, value = part.split('=', 1)
        values[key] = int(value) if value.isdigit() else value
    observations['memory' if line.startswith('native-memory ') else 'footprint'].append(values)
(out / 'real-allocator-observations.json').write_text(json.dumps(observations, indent=2) + '\n')
verdict = {
    'status': 'pass', 'provider_worktree_base': '69a75de82813beaf753fbbb4891c3b3261b63600',
    'source_equivalent_current_parent_before_overlay': '055a76364b7952ee409598f7443ff6b92eec0ecb',
    'native_commit': 'a486a55d032deae001190bf9795ece1cb3d9a609',
    'policy_evidence': '/tmp/darkbloom-allocator-footprint-policy-validation1/manifest.json',
    'policy_evidence_sha256': sha(policy / 'manifest.json'),
    'build_seconds_reported': float(re.findall(r'Build complete! \(([0-9.]+)s\)', (out / 'build.log').read_text())[-1]),
    'unique_functions': len(unique), 'unique_cases': sum(v['cases'] for v in summaries.values()),
    'by_group': summaries, 'source_verified': verify(),
    'real_allocator_proof': 'Native Admission/PagedKVBackend and actual provider owner reserve163837 before first buffer eval, then settle C=M81920 actual allocator backing bytes. Competing4096 charge exact fits at the pre-eval and settled boundaries; +1 is refused. A24576-logical-byte alias retains32768 actual allocator bytes after coverage/charge retirement; final alias drop releases32768 and competitor can reuse the capacity. Coherent real U is never synthesized.',
    'limits': ['Pre-evaluation cap is temporarily constrained at the observation boundary, then restored to unbounded before allocation. This does not establish a continuously constrained whole-graph/factory/scratch envelope.', 'OS availability is deliberately non-binding; this is allocator/native/provider ownership proof, not platform pressure testing.', 'Real2 suite executes in its own test process; all other selected groups also run in separate processes.', 'No full native codec/provider29/historical union or requested fleet-size model tested here; no rollout/default/performance claim.', 'Lookup change behavior is tested; no SSD lookup timing claim. Go/TypeScript telemetry changes have separate root-owned evidence.'],
}
(out / 'verdict.json').write_text(json.dumps(verdict, indent=2) + '\n')
(out / 'environment.txt').write_text(subprocess.check_output(['swift', '--version'], text=True, stderr=subprocess.STDOUT) + subprocess.check_output(['sw_vers'], text=True) + subprocess.check_output(['uname', '-a'], text=True))
files = {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file() and p.name != 'manifest.json'}
(out / 'manifest.json').write_text(json.dumps({'scope': 'Provider allocator footprint telemetry, bounded SSD candidate lookup and actual native/provider allocator ownership oracle over accepted foundation and policy. Exact7 Swift plus canonical JSON source archive; controlled-cap scope and real process measurements explicit.', 'files': files}, indent=2) + '\n')
print(json.dumps({'functions': len(unique), 'cases': verdict['unique_cases'], 'payloads': len(files), 'manifest_sha256': sha(out / 'manifest.json')}, indent=2))
