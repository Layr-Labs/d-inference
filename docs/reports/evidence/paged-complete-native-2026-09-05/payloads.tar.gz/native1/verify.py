from pathlib import Path
import hashlib,json,subprocess
out=Path('/tmp/darkbloom-checkpoint-native-validation1');package=out/'native';root=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated');dep=Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
 native=json.loads((out/'native-source-manifest.json').read_text());owned=json.loads((out/'owned-manifest.json').read_text());deps=json.loads((out/'dependency-source-manifest.json').read_text())
 for p,h in native['files'].items():assert sha(package/p)==h,p
 for p,h in owned['files'].items():assert sha(package/p)==h,p
 for key,h in deps['files'].items():alias,p=key.split('/',1);assert sha(Path(deps['repositories'][alias])/p)==h,key
 assert sha(package/'Package.swift')==sha(out/'native-Package.swift.validation')
 assert sha(package/'Package.resolved')==sha(out/'native-Package.resolved')
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=package,text=True).strip()==native['base']
 return {'native_inputs':len(native['files']),'owned_inputs':len(owned['files']),'dependency_inputs':len(deps['files']),'no_drift':True,'mutable_primary_excluded':True}
