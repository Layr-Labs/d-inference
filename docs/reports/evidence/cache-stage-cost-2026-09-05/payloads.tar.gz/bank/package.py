from pathlib import Path
import collections
import gzip
import hashlib
import io
import json
import subprocess
import tarfile

root = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
freeze = Path('/tmp/darkbloom-cache-routing-ttft-audit/freeze1')
checks = Path('/tmp/darkbloom-cache-routing-root-validation1')
digest = lambda data: hashlib.sha256(data).hexdigest()
source = json.loads((freeze / 'manifest.json').read_text())
counts = collections.Counter()
for line in (checks / 'focused-race.jsonl').read_text().splitlines():
    event = json.loads(line)
    if 'Test' in event and event['Action'] in ('pass', 'fail', 'skip'):
        counts[('subtest_' if '/' in event['Test'] else 'function_') + event['Action']] += 1
assert counts['function_pass'] == 101 and not counts['function_fail'] and not counts['function_skip']
assert json.loads((checks / 'command.json').read_text())['exit_code'] == 0
(checks / 'results.json').write_text(json.dumps(dict(counts), indent=2) + '\n')
for relative, sha in source['source_files'].items():
    if relative != 'CHANGELOG.md':
        assert digest((root / relative).read_bytes()) == sha
integration = {
    'parent_base': '1a9c78d8432adf4ee080881637ab3740b4ad648b',
    'source_manifest_sha256': digest((freeze / 'manifest.json').read_bytes()),
    'exact_go_paths': {p: h for p, h in source['source_files'].items() if p.startswith('coordinator/')},
    'source_review': 'Signed stage adjustment, positive benefit caps, finite guards, cost-sum preservation and penalty-only ranking reviewed. No production correction after frozen tests.',
    'documentation_merge': 'Apply canonical bodies unchanged, restamp to current parent, insert the changelog entry alongside earlier banked milestones.',
    'combined_root_race': dict(counts),
}
payloads = {}
for relative, sha in source['artifact_files'].items():
    data = (freeze / relative).read_bytes()
    assert digest(data) == sha
    payloads['freeze/' + relative] = data
payloads['freeze/manifest.json'] = (freeze / 'manifest.json').read_bytes()
for path in sorted(checks.iterdir()):
    if path.is_file():
        payloads['root-validation/' + path.name] = path.read_bytes()
payloads['bank/integration.json'] = (json.dumps(integration, indent=2) + '\n').encode()
payloads['bank/package.py'] = Path(__file__).read_bytes()
evidence = root / 'docs/reports/evidence/cache-stage-cost-2026-09-05'
evidence.mkdir(parents=True, exist_ok=True)
archive = evidence / 'payloads.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w') as tar:
            for name, data in sorted(payloads.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                tar.addfile(entry, io.BytesIO(data))
manifest = {
    'schema': 1,
    'scope': 'Signed coordinator cache service cost; no model, network latency or rollout measurement.',
    'integration': integration,
    'tests': source['test_results'],
    'benchmark_method': source['benchmark_results']['method'],
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes())},
    'entries': [{'path': name, 'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(payloads.items())],
}
manifest_path = evidence / 'manifest.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
with tarfile.open(archive, 'r:gz') as tar:
    assert {entry.name for entry in tar.getmembers()} == set(payloads)
    for name, data in payloads.items():
        assert tar.extractfile(name).read() == data
manifest_hash = digest(manifest_path.read_bytes())
archive_hash = manifest['archive']['sha256']

for relative in ['docs/architecture/cache-aware-routing.md', 'docs/architecture/routing.md']:
    path = root / relative
    path.write_text(path.read_text().replace('commit `69a75de82`', 'commit `1a9c78d84`', 1))
changelog = root / 'CHANGELOG.md'
text = changelog.read_text()
anchor = '## Unreleased — paged attention foundation\n'
assert text.count(anchor) == 1
text = text.replace(anchor, anchor + '\n- Include excess SSD restore time in coordinator routing costs, so an expensive cache holder can lose to a faster cold peer. Preserve useful-hit discounts, full-request admission and positive-benefit telemetry.\n', 1)
changelog.write_text(text)
report = root / 'docs/reports/2026-09-05-cache-stage-cost.md'
report.write_text(f'''# Coordinator cache restore cost

> Last updated: 2026-09-05 · commit `1a9c78d84`

Routing now includes an SSD restore that costs more than the prefill it saves.
Previously that hint was discarded and the provider kept its cold score, even
though the provider would still attempt the restore. The signed adjustment lets
a cold peer win when its estimated service cost is lower.

## Behavior

An actual Prepare/Lookup/Ready/Reserve fixture advertises a 4,096-token checkpoint
on a provider estimated at 5,000 prefill tokens/s, with a 900 ms restore. For a
4,352-token request, its prefill-related cost becomes 951.2 ms instead of the
cold 870.4 ms. A cold peer at 4,800 tokens/s costs 906.667 ms and wins. These are
deterministic scheduler estimates, not model or network timing measurements.

`cacheServiceCost` applies the same prefill weighting to either sign. Benefits
retain their optional discount caps; excess restore cost increases `ThisReqMs`.
Stage cost is counted once. Queue, decode, backlog, health, full-request memory
admission and normal TTFT gates remain intact. An expensive holder remains
eligible when it is the only usable provider. Live hint adjustments use minimum
adjusted cost; pools without adjustments retain existing load spreading.

`RoutingDecision` and its debug log expose signed estimated savings and the
cache tier. Existing aggregate savings telemetry remains positive-benefit-only;
it must not be interpreted as net cache performance.

## Verification

| Scope | Result |
|---|---|
| Isolated registry/API/protocol packages | 2,563 top-level tests and 1,517 subtests pass; two existing opt-in skips |
| Isolated focused race checks | 95 top-level tests and 173 subtests pass |
| Final new fixtures on unchanged baseline | Four top-level functions and seven subtests fail as expected |
| Integrated cost and footprint race checks | {counts['function_pass']} top-level tests and {counts['subtest_pass']} subtests pass; zero skip/failure |

The broader isolated run skips `TestPerfE2E_ChatCompletions` and
`TestVerifyProviderViaMDM_TimeoutTransient`. Evidence preserves initial fixture
mistakes, corrected baseline failures and successful final candidate runs.
Seven Go files are copied unchanged from the tested source. Documentation and
the changelog merge alongside the earlier allocator milestones.

Five 200 ms microbenchmark samples per revision on the shared Apple M3 Max
show the cost helper near 49 ns/op with zero allocations. The 350-provider
selector's observed median increased by 209 ns for cold pools and 68.3 ns for
cache pools. The hint index is unchanged and retains 1,166 allocations in its
bounded fixture. These diagnostic samples establish no routing speedup or
statistical latency result; some baseline index samples overlapped API tests.

## Evidence and limits

The [manifest](evidence/cache-stage-cost-2026-09-05/manifest.json)
(SHA-256 `{manifest_hash}`) records {len(payloads)} verified
payloads. The [archive](evidence/cache-stage-cost-2026-09-05/payloads.tar.gz)
has SHA-256 `{archive_hash}`. The source freeze is
`e2b9817404fd662a372c578f4eb8648afa9e97048e7b651d59ecbdccd59c017f`.

No provider execution, cache wire contract, rollout default or live configuration
changed. Concurrent Prepare/reconfiguration ownership is a separate active fix.
Current scoring and telemetry semantics are in
[cache-aware routing](../architecture/cache-aware-routing.md#candidate-scoring).
''')
index = root / 'docs/reports/README.md'
text = index.read_text().replace('commit `055a76364`', 'commit `1a9c78d84`', 1)
anchor = '- [Provider allocator accounting and SSD lookup]'
assert anchor in text
text = text.replace(anchor, '- [Coordinator cache restore cost](2026-09-05-cache-stage-cost.md) — signed restore overhead, cross-machine selection, unchanged admission and diagnostic microbenchmarks.\n' + anchor, 1)
index.write_text(text)
print(json.dumps({'manifest_sha256': manifest_hash, 'archive_sha256': archive_hash, 'payloads': len(payloads), 'archive_bytes': archive.stat().st_size, 'root_counts': dict(counts)}, indent=2))
