# Native checkpoint adoption: source review freeze 2

Status: unvalidated source, not a tested commit or serving integration.

Base is committed native 326d9a27a9227e1636a7a584687193d425f0b4b0. The isolated
worktree HEAD stays 02acd0e52 with all newer mechanical files reconciled exactly
from 326d9a27a9; adoption.patch is the eleven-path delta against 326d9a27a9.
Primary native worktree has not been edited. No Swift/Metal/model builds run.

Interface:

- AdmissionV2.reserveCheckpointStage(targetBytes:auxiliaryBytes:scratchBytes:)
  creates a generation-scoped UUID identity under this Admission. Stage state
  is explicit; a zero destination cannot disguise repeated consumption.
- CBv2PagedCheckpointFrame(storage:auxiliary:lease:) is constructed only after
  successful authenticated filling. It checks native target plan bytes and
  exact auxiliary nbytes. Its locked consume empties the closeable handle before
  engine work. This mechanical owner is internal, not an eligibility token.
- PagedKVPool.importCheckpoint(_:admission:requestID:layerKinds:maximumTokens:)
  consumes that frame, plans rebased imported M page ranges and only missing
  full-N growth against existing committed usable backing, transfers the typed
  destination charge, privately prepares missing buffers, then publishes all
  groups and prepared exclusive row tables in one grant epoch check.
- CBv2BackendPhysicalLease.transferCheckpoint synchronizes its retained floor
  with the same Admission transaction and validates exact Admission identity.
- CBv2CheckpointAdoptionReservation must commit or explicitly roll back after
  owners drain; deinit cannot refund before arrays are destroyed.
- CBv2PagedCheckpointAdoption owns active rows/auxiliary plus request charge.
  Its release follows native row retirement, clears aux, then releases Admission.
  Engine/codec integration must transfer this ownership at the real request
  retirement boundary; no integration currently invokes this helper.

Same-engine process accounting must observe the complete prospective Admission
charge at the transfer mutation. Stage scratch stays in its transient entry,
while native destination bytes alone become target floor and active auxiliary
state. No provider or process materialization credit is inferred here. The later
process adapter must use native evaluated-owner proof for M and withdraw coverage
before any alias release. No callback runs under grant publication.

Failure order: empty frame -> reserve exact destination conversion -> prepare ->
grant refusal/allocation error -> discard uninstalled rows, prepared wrappers,
private staged arrays and auxiliary -> drop residual stage scratch -> observe
failure boundary (test only) -> roll back request nominal and private floor.
Live groups remain unchanged until the nonthrowing publication swap.

Tests added (14 cases, NOT RUN): at-cap same-buffer transfer with another owner;
+1 physical refusal and rollback; explicit zero-byte stage single consumption;
foreign physical Admission rejection; auxiliary shortfall; BF16/FP16/FP32 raw-bit
attachment and partial-frontier append; old free backing reuse with zero new
native allocations; two-group allocation and grant epoch failures with weak
alias checks before floor refund; concurrent frame close/consume; repeated close; detached/reused sampling ID;
incompatible layer count and changed kind geometry/mapping before pool mutation.

Limits: CompleteCheckpointCodec/EngineLoopV2 not wired; no recurrent/MTP restore
oracle, no window import/export, no process ledger adapter/materialization,
no real-model or performance claims, no default/rollout changes. The existing
owning-full/Qwen codec guards remain intact.

Freeze 2 replaces the active result's plain request-ID refund with a UUID owner
check. Ordinary releaseAll/unreserve-to-zero/detach remove that marker, so stale
result retirement cannot release a successor after ID reuse. It also validates
immutable destination layer kinds and dtype-table bounds before indexing.
