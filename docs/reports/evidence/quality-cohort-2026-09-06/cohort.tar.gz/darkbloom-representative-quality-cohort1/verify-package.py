#!/usr/bin/env python3
"""Verify the frozen package inventory against an out-of-band manifest SHA."""
import argparse
from pathlib import Path
from cohort_common import checked, digest, read_json, require

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--expected-sha256', required=True)
args = parser.parse_args()
root = Path(__file__).resolve().parent
manifest = root/'manifest.json'
require(digest(manifest) == args.expected_sha256, 'manifest SHA differs')
value = read_json(manifest)
for relative, facts in value['files'].items():
    checked(root, dict(facts, path=relative))
print('Frozen package inventory verified:', len(value['files']), 'files')
