"""Pinned local inputs and JSON-rendered, compile-checked remote transport."""
from pathlib import Path
import hashlib
import json
import stat
import subprocess

HERE = Path(__file__).resolve().parent
PLAN = Path('/tmp/darkbloom-q36-owner0-replay-plan1')
RESULTS = Path('/tmp/darkbloom-q36-owner0-replay-results1')
BINDING = Path('/tmp/darkbloom-q36-owner0-replay-runtime-binding1.json')
OPTIONS = ['-i', '/Users/gaj/.ssh/darkbloom_testbox', '-o', 'IdentitiesOnly=yes',
           '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15',
           '-o', 'ServerAliveInterval=15', '-o', 'ServerAliveCountMax=4']
HOST = 'gaj@100.124.35.99'
SSH = ['ssh'] + OPTIONS + [HOST]


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as source:
        for chunk in iter(lambda: source.read(1 << 20), b''): digest.update(chunk)
    return digest.hexdigest()


def write(path, value): path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def file_record(path):
    info = path.lstat()
    assert stat.S_ISREG(info.st_mode) and not path.is_symlink(), str(path)
    return {'sha256': sha(path), 'bytes': info.st_size, 'mode': oct(stat.S_IMODE(info.st_mode))}


def verify_file(path, row):
    assert file_record(path) == row, str(path)


def verify_manifest(root, name, digest):
    path = root/name
    assert sha(path) == digest, str(path)
    for name, row in json.loads(path.read_text())['files'].items(): verify_file(root/name, row)


def load_binding(digest):
    assert sha(BINDING) == digest, 'Explicit reviewed binding differs'
    binding = json.loads(BINDING.read_text())
    verify_manifest(PLAN, 'manifest.json', binding['plan_manifest_sha256'])
    verify_manifest(HERE, 'preparation-manifest.json', binding['controller_manifest_sha256'])
    assert binding['plan_manifest_sha256'] == '9426b686f02cbd3719d0efadb3b879121cc6105d896de5d9f30a35a1d1385c6d'
    plan = json.loads((PLAN/'plan.json').read_text())
    assert binding['remote_root'] == plan['remote_root']
    assert binding['commands'] == plan['arms']
    assert binding['input_sha256'] == plan['input_sha256'] == sha(PLAN/'input.json')
    assert set(binding['artifacts']) == {'attention-replay', 'mlx.metallib',
        'mlx-swift-lm_MLXLMCommon.bundle/pagedattention.metal',
        'swift-crypto_Crypto.bundle/PrivacyInfo.xcprivacy', 'swift-nio_NIOPosix.bundle/PrivacyInfo.xcprivacy',
        'swift-transformers_Hub.bundle/gpt2_tokenizer_config.json',
        'swift-transformers_Hub.bundle/t5_tokenizer_config.json'}
    for name, row in binding['artifacts'].items(): verify_file(Path(binding['artifact_root'])/name, row)
    for row in binding['reviews'].values(): assert sha(Path(row['path'])) == row['sha256']
    return binding, plan


def render(code, values):
    rendered = 'import json\nC=json.loads(' + repr(json.dumps(values)) + ')\n' + code
    compile(rendered, '<remote-json-rendered>', 'exec')
    return rendered


def remote(local, name, code, values):
    rendered = render(code, values)
    (local/(name+'-rendered.py')).write_text(rendered)
    with (local/(name+'.stdout')).open('x') as output, (local/(name+'.stderr')).open('x') as error:
        result = subprocess.run(SSH + ['python3 -B -'], input=rendered, text=True,
                                stdout=output, stderr=error, timeout=240)
    assert result.returncode == 0, 'Remote step failed; preserved evidence: ' + name
    return json.loads((local/(name+'.stdout')).read_text())


def send(local, name, source, target):
    result = subprocess.run(['scp', '-p'] + OPTIONS + [str(source), HOST + ':' + target],
                            text=True, capture_output=True, timeout=240)
    (local/(name+'.stdout')).write_text(result.stdout); (local/(name+'.stderr')).write_text(result.stderr)
    assert result.returncode == 0, 'Transfer failed: ' + name


def seal(local):
    write(local/'manifest.json', {'files': {str(p.relative_to(local)): file_record(p)
        for p in sorted(local.rglob('*')) if p.is_file() and p.name != 'manifest.json'}})
