from pathlib import Path
import difflib,gzip,hashlib,json,re,shutil,subprocess,tarfile
out=Path('/tmp/darkbloom-paged-runtime-validation6');root=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated');scratch=Path('/tmp/darkbloom-paged-runtime-validation1/build');native=out/'package'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert (out/'source-verified-after.json').exists()
execution=json.loads((out/'execution.json').read_text());assert len(execution['results'])==26 and all(x['exit_code']==0 for x in execution['results'])
ids=[s for s in (out/'identifiers.log').read_text().splitlines() if s.startswith('MLXLMTests.')];summaries={};selected={}
for name in json.loads((out/'filters.json').read_text()):
 log=(out/(name+'.log')).read_text();swift=int(re.findall(r'Test run with (\d+) tests?',log)[-1]);xc=max(map(int,re.findall(r'Executed (\d+) tests?',log)),default=0);extra=sum(int(n)-1 for n in re.findall(r'with (\d+) test cases passed',log));func=swift+xc;cases=func+extra
 assert func>0 and not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test|recorded an issue|[✘]',log,re.M),name
 matching=[s for s in ids if name in s]
 if name=='CBv2PagedBackendTests':matching +=[s for s in ids if 'CBv2PagedSpeculativeRowTests/' in s]
 if name=='CBv2PagedPrefixReuse':matching +=[s for s in ids if 'CBv2PrefixReusePagedFrozenFullTests/' in s]
 assert len(matching)==func,(name,len(matching),func)
 selected[name]=sorted(matching);summaries[name]={'functions':func,'actual_cases':cases,'swift_testing_functions':swift,'xctest_functions':xc,'parameterized_case_extra':extra,'failures':0,'skips':0}
unique=sorted(set(i for group in selected.values() for i in group));assert len(unique)==sum(v['functions'] for v in summaries.values()),'Unexpected duplicated filters'
prior_ids=set(s for s in Path('/tmp/darkbloom-native-process-memory-validation1/identifiers.log').read_text().splitlines() if s.startswith('MLXLMTests.'))
added=sorted(set(ids)-prior_ids);removed=sorted(prior_ids-set(ids));assert not removed,removed;assert len(added)==7,added
(out/'selected-identifiers.json').write_text(json.dumps({'by_filter':selected,'unique_identifiers':unique,'new_identifiers_vs_banked_native':added,'removed_identifiers_vs_banked_native':removed,'note':'SwiftPM filters also select source filenames: CBv2PagedBackendTests includes 8 speculative-row functions; CBv2PagedPrefixReuse includes CBv2PrefixReusePagedFrozenFullTests. No selected function is repeated across the final24 filters. Tiny Qwen fault XCTest has two internal injected scenarios, counted as one framework function/case.'},indent=2)+'\n')
graph=(scratch/'debug.yaml').read_text();dep=root/'libs/mlx-swift';assert str(dep/'Source/MLX/Memory.swift') in graph and '/checkouts/mlx-swift/Source/' not in graph;assert str((native/'Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVWriteValidation.swift').resolve()) in graph
(out/'actual-build-graph-after.yaml.gz').write_bytes(gzip.compress(graph.encode(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'actual-package-state-after.json')
verdict={'status':'pass','baseline_parent':'da05f883d2d8ab54e77d980e34afa094c42c22d5','baseline_native':'f93134e537c594f6b5c69fb08115062c205cf655','build_seconds_reported':float(re.findall(r'Build complete! \(([0-9.]+)s\)',(out/'build.log').read_text())[-1]),'filter_groups':24,'by_filter':summaries,'unique_test_functions':len(unique),'unique_actual_test_cases':sum(s['actual_cases'] for s in summaries.values()),'new_runtime_functions':7,'new_runtime_actual_cases':19,'failures':0,'skips':0,'candidate_native_source_inputs_unchanged_before_after':453,'primary_native_source_inputs_unchanged_before_after':451,'owned_source_inputs_unchanged_before_after':32,'dependency_source_inputs_unchanged_before_after':1353,'primary_manifest_unchanged':True,'isolated_package_overlay':'Only Package.swift dependency switches to exact local eafd98a MLX; all compile paths verified before and after test filters. Scratch reused from validation1; actual native paths point to validation5. Primary runtime source unchanged.','source_corrections':json.loads((out/'runtime-owned-merged-manifest.json').read_text())['source_corrections'],'limits':['Tiny deterministic Qwen dense/MoE models, normal MTP/rollback/cancel and dtype fault recovery are exercised; no requested fleet-size model has been validated in this slice.','No production factory enablement, SSD codec integration, runtime default changes, release approval, latency/speedup measurement or performance claim.','Runtime validates native post-projection K/V dtype before writes and retires faulted cohorts before sampling; these tests do not independently prove allocator-footprint admission or provider U+sum(C-M) arithmetic.','Healthy host fence/snapshot overhead has not been measured.']}
assert summaries['CBv2PagedRuntimeDType']['actual_cases']==18
(out/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
for src,name in [(native/'Package.swift','validation-Package.swift'),(root/'libs/mlx-swift-lm/Package.swift','primary-Package.swift'),(native/'Package.resolved','validation-Package.resolved'),(root/'scripts/run-nested-suite.sh','run-nested-suite.sh')]:shutil.copy2(src,out/name)
(out/'environment.txt').write_text(subprocess.check_output(['swift','--version'],text=True,stderr=subprocess.STDOUT)+subprocess.check_output(['sw_vers'],text=True)+subprocess.check_output(['uname','-a'],text=True))
exe=scratch/'arm64-apple-macosx/debug/mlx-swift-lmPackageTests.xctest/Contents/MacOS/mlx-swift-lmPackageTests';(out/'test-binary.json').write_text(json.dumps({'path':str(exe),'bytes':exe.stat().st_size,'sha256':sha(exe)},indent=2)+'\n')
owned=json.loads((out/'runtime-owned-merged-manifest.json').read_text())['files'];patch=''
with tarfile.open(out/'runtime-owned-source.tar.gz','w:gz') as archive:
 for path in sorted(owned):
  assert sha(native/path)==owned[path];archive.add(native/path,arcname=path)
  prior=root/'libs/mlx-swift-lm'/path;before=prior.read_text() if prior.exists() else '';after=(native/path).read_text()
  patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+path if prior.exists() else '/dev/null',tofile='b/'+path))
(out/'runtime-against-banked-native.patch').write_text(patch)
failures={}
for n in range(1,6):
 p=Path(f'/tmp/darkbloom-paged-runtime-validation{n}/manifest.json');failures[str(p)]={'sha256':sha(p),'status':'preserved failed attempt; not accepted validation'}
(out/'prior-failure-manifests.json').write_text(json.dumps(failures,indent=2)+'\n')
files={p.name:{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file() and p.name!='manifest.json'}
(out/'manifest.json').write_text(json.dumps({'scope':'Native paged runtime dtype protection over banked adoption/process ownership, with preserved compile/fixture correction history. Owned exact source archive included; other selected code/test and dependency hashes recorded in source manifests. Excludes scratch artifacts.','files':files},indent=2)+'\n')
print(json.dumps({'functions':len(unique),'actual_cases':verdict['unique_actual_test_cases'],'build_seconds':verdict['build_seconds_reported'],'payloads':len(files),'manifest_sha256':sha(out/'manifest.json')},indent=2))
