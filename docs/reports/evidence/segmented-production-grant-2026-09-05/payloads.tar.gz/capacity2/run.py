from pathlib import Path
import gzip, hashlib, json, re, shutil, subprocess, time

out = Path('/tmp/darkbloom-segmented-grant-provider-validation2')
workspace = out / 'workspace'
package = workspace / 'provider-swift'
native = (workspace / 'libs/mlx-swift-lm').resolve()
policy = Path('/tmp/darkbloom-allocator-footprint-policy-validation1')
dep = policy / 'deps/mlx-swift'
scratch = Path('/tmp/darkbloom-process-memory-telemetry-swift-validation1/build')
root = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def verify():
    provider = json.loads((out / 'provider-source-manifest.json').read_text())
    for path in provider.get('deleted_files', {}):
        assert not (workspace / path).exists(), path
    for path, expected in provider['files'].items():
        assert sha(workspace / path) == expected, path
    ns = json.loads((out / 'native-source-manifest.json').read_text())
    for path, expected in ns['files'].items():
        assert sha(native / path) == expected, path
    deps = json.loads((out / 'dependency-source-manifest.json').read_text())
    for key, expected in deps['files'].items():
        alias, path = key.split('/', 1)
        assert sha(Path(deps['repositories'][alias]) / path) == expected, key
    for filename in ['owned-manifest.json', 'fixture-input-manifest.json']:
        for path, expected in json.loads((out / filename).read_text())['files'].items():
            assert sha(workspace / path) == expected, path
    assert sha(package / 'Package.swift') == sha(out / 'provider-Package.swift.validation')
    assert sha(package / 'Package.resolved') == sha(out / 'provider-Package.resolved')
    assert sha(native / 'Package.swift') == sha(out / 'native-Package.swift.validation')
    assert sha(native / 'Package.resolved') == sha(out / 'native-Package.resolved')
    for row in json.loads((policy / 'integration.json').read_text())['repositories']:
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=row['path'], text=True).strip() == row['base']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=workspace, text=True).strip() == '69a75de82813beaf753fbbb4891c3b3261b63600'
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=native, text=True).strip() == json.loads((out / 'native-source-manifest.json').read_text())['base']
    jinja = json.loads((out / 'jinja-source-manifest.json').read_text())
    for path, expected in jinja['files'].items():
        assert sha(scratch / 'checkouts/swift-jinja' / path) == expected, path
    return {'provider_inputs': len(provider['files']), 'native_inputs': len(ns['files']), 'dependency_inputs': len(deps['files']), 'owned_inputs': len(json.loads((out / 'owned-manifest.json').read_text())['files']), 'jinja_inputs': len(jinja['files']), 'no_drift': True, 'mutable_primary_excluded_during_root_bank': True}

assert (policy / 'manifest.json').exists(), 'Policy C++ and Swift evidence must be frozen first.'
shutil.copy2(Path('/tmp/darkbloom-process-memory-telemetry-swift-validation4/jinja-source-manifest.json'), out / 'jinja-source-manifest.json')
(out / 'source-verified-before.json').write_text(json.dumps(verify(), indent=2) + '\n')
groups = json.loads((out / 'filters.json').read_text())
results = []

def run(name, command, test=False):
    start = time.monotonic()
    with (out / (name + '.log')).open('w') as log:
        process = subprocess.run(command, cwd=package, stdout=log, stderr=subprocess.STDOUT)
    body = (out / (name + '.log')).read_text()
    valid = not test or (bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test', body)) and not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test', body, re.M))
    row = {'name': name, 'command': command, 'exit_code': process.returncode, 'seconds': time.monotonic()-start, 'nonzero_and_no_skips': valid}
    results.append(row)
    (out / 'execution.json').write_text(json.dumps(results, indent=2) + '\n')
    print(json.dumps({key: value for key, value in row.items() if key != 'command'}), flush=True)
    if (process.returncode or not valid) and not test:
        raise SystemExit(process.returncode or 1)

run('build', ['swift', 'build', '--scratch-path', str(scratch), '--build-tests', '--jobs', '4', '--disable-automatic-resolution'])
graph = (scratch / 'debug.yaml').read_text()
paths = [dep / 'Source/MLX/AllocationFootprint.swift', dep / 'Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp', dep / 'Source/Cmlx/mlx-c/mlx/c/memory.cpp', package / 'Tests/ProviderCoreTests/ProcessMemoryNativeIntegrationTests.swift', package / 'Sources/ProviderCore/KVCacheSSD/SSDHybridCheckpointStore+Read.swift']
matched = []
for path in paths:
    match = next((p for p in [path, path.resolve()] if str(p) in graph), None)
    assert match is not None, path
    matched.append(str(match))
suffix = 'Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVSegments.swift'
match = next((p for p in [native / suffix, native.resolve() / suffix, workspace / 'libs/mlx-swift-lm' / suffix, workspace.resolve() / 'libs/mlx-swift-lm' / suffix] if str(p) in graph), None)
assert match is not None and match.resolve() == (native / suffix).resolve()
matched.append(str(match))
assert '/checkouts/mlx-swift/Source/' not in graph
assert str(root / 'provider-swift/Sources/ProviderCore/Inference/GlobalKVCacheBudget.swift') not in graph
(out / 'actual-build-graph.yaml.gz').write_bytes(gzip.compress(graph.encode(), mtime=0))
shutil.copy2(scratch / 'workspace-state.json', out / 'actual-package-state.json')
(out / 'actual-compiler-source-proof.json').write_text(json.dumps({'matched_actual_paths': matched, 'remote_mlx_compile_source_absent': True, 'primary_provider_compile_source_absent': True}, indent=2) + '\n')
debug = scratch / 'arm64-apple-macosx/debug'
bundle = debug / 'DarkbloomProviderPackageTests.xctest/Contents/MacOS'
assert bundle.is_dir()
lib = root / 'provider-swift/.build/arm64-apple-macosx/debug/mlx.metallib'
for target in [debug / 'mlx.metallib', bundle / 'mlx.metallib']:
    shutil.copy2(lib, target)
(out / 'metallib-placement.json').write_text(json.dumps({'source': str(lib), 'sha256': sha(lib), 'destinations': [str(debug / 'mlx.metallib'), str(bundle / 'mlx.metallib')], 'kernel_sources_unchanged': True}, indent=2) + '\n')
binary = bundle / 'DarkbloomProviderPackageTests'
(out / 'test-binary.json').write_text(json.dumps({'path': str(binary), 'sha256': sha(binary), 'bytes': binary.stat().st_size}, indent=2) + '\n')
run('identifiers', ['swift', 'test', 'list', '--skip-build', '--scratch-path', str(scratch), '--disable-automatic-resolution'])
for name, filters in groups.items():
    run(name, ['swift', 'test', '--skip-build', '--scratch-path', str(scratch), '--disable-automatic-resolution', '--filter', '|'.join(filters)], test=True)
(out / 'source-verified-after.json').write_text(json.dumps(verify(), indent=2) + '\n')
(out / 'actual-build-graph-after.yaml.gz').write_bytes(gzip.compress((scratch / 'debug.yaml').read_bytes(), mtime=0))
shutil.copy2(scratch / 'workspace-state.json', out / 'actual-package-state-after.json')
assert sha(binary) == json.loads((out / 'test-binary.json').read_text())['sha256']
failed = [r for r in results if r['exit_code'] or not r['nonzero_and_no_skips']]
print('PROVIDER SOURCE AND BINARY VERIFIED; FAILED FILTERS=' + str(len(failed)), flush=True)
raise SystemExit(bool(failed))
