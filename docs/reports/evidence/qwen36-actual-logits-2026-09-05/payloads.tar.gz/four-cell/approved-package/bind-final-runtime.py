from pathlib import Path
import json,hashlib,shutil,tarfile,sys
old=Path('/tmp/darkbloom-q36-actual-logits-plan2');root=Path('/tmp/darkbloom-q36-actual-logits-plan3');root.mkdir(exist_ok=False);package=root/'package';shutil.copytree(old/'package',package)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def add(src,rel):
 p=package/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,p)
build=Path('/tmp/darkbloom-final-serving-build8');assert digest(build/'manifest.json')=='2f54714f9d4e788710fe5cdd7103e723676c5666e239898750fd14936dccbe98';assert digest(build/'artifact-manifest.json')=='1dd03934e5d5cf9a960c68484100aa4ad02b7f742cfe4996a10abbfd3d664541';artifacts=json.loads((build/'artifact-manifest.json').read_text())
for name,item in artifacts['files'].items():
 p=build/'artifact'/name;assert p.stat().st_size==item['bytes'] and digest(p)==item['sha256']
for name in ['manifest.json','artifact-manifest.json','validation-handoff.json']:add(build/name,'runtime-proof/'+name)
plan=json.loads((package/'plan.json').read_text());plan['state']='source_argv_and_final_runtime_bound_root_launch_review_pending';runtime=plan['runtime_requirement'];runtime['binary_sha256']=artifacts['files']['radix-engine']['sha256'];runtime['binary_bytes']=artifacts['files']['radix-engine']['bytes'];runtime['artifact_manifest_sha256']=digest(build/'artifact-manifest.json');runtime['build_manifest_sha256']=digest(build/'manifest.json');runtime['resources']={name:{**item,'path':'/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact/'+name} for name,item in artifacts['files'].items() if name not in ('darkbloom','radix-engine')};runtime['blocking_reason']='Exact final build8 bytes are bound. Root runtime/package/launch review remains mandatory; approval recorded separately without changing this freeze.'
prior=Path('/tmp/darkbloom-q36-backend-mtp-off-diagnostic1');historical={}
for backend in ('contiguous','paged'):
 for name in ('report.json','metadata.json','input.json'):add(prior/backend/name,'historical-build6/'+backend+'/'+name)
 historical[backend]={'report':'historical-build6/'+backend+'/report.json','report_sha256':digest(prior/backend/'report.json'),'metadata_sha256':digest(prior/backend/'metadata.json'),'prepared_input_sha256':digest(prior/backend/'input.json'),'scope':'Earlier build6 MTP-off diagnostic, retained separately; comparison required but cannot replace same-build uninstrumented controls.'}
plan['historical_controls']=historical
for index,backend in [(0,'contiguous'),(2,'paged')]:
 for cell in plan['cells'][index:index+2]:
  plan['required_comparisons'].append({'axis':'historical_trajectory','historical_report':historical[backend]['report'],'candidate':cell['id'],'required':'Compare entire first-main emitted token trajectory and exact prompt IDs with retained build6 same-backend control; keep any mismatch and do not substitute historical timing or runtime acceptance.'})
plan['selected_diagnostic']['preserve_records']='Retain all raw records and Float32 valueBits even when status is inconclusive; root independently decodes values and checks contexts.'
plan['required_comparisons'][0]['required']='Compare exact full emitted trajectory and prompt IDs of traced versus uninstrumented first-main rows on this same build, plus existing integrity/tenant/cancel/recovery controls.';plan['required_comparisons'][1]['required']=plan['required_comparisons'][0]['required']
(package/'plan.json').write_text(json.dumps(plan,indent=2)+'\n');sys.dont_write_bytecode=True;sys.path.insert(0,str(package/'runner'));import run_radix_engine as wrapper
prepared=package/'cpu-prepared-input.json';wrapper.pin_prompt_date(package/'inputs/qwen36.json',prepared,'2026-09-05');assert prepared.read_bytes()==(prior/'contiguous/input.json').read_bytes()==(prior/'paged/input.json').read_bytes()
(package/'runtime-binding-validation.json').write_text(json.dumps({'passed':True,'model_or_m5_operations':False,'exact_final_runtime_files_verified':len(artifacts['files']),'prepared_input_bytes_equal_both_historical_controls':True,'prepared_input_sha256':digest(prepared),'plan2_plan_sha256':digest(old/'package/plan.json'),'argv_unchanged':plan['cells']==json.loads((old/'package/plan.json').read_text())['cells'],'runtime_or_launch_approval_claimed':False},indent=2)+'\n')
readme=package/'README.md';readme.write_text(readme.read_text().replace('Build8 runtime hashes and root launch review are pending.','Final build8 runtime hashes are now bound in plan.json. Root runtime/package/launch review is pending.').replace('until a separate reviewed runtime binding and the reviewed diagnostic comparator are present','until root runtime/package/launch approval and the reviewed diagnostic comparator are present'))
add('/tmp/bind-q36-actual-logits-plan3.py','bind-final-runtime.py')
files={str(p.relative_to(package)):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(package.rglob('*')) if p.is_file() and p.name!='package-manifest.json'};(package/'package-manifest.json').write_text(json.dumps({'scope':plan['scope'],'state':plan['state'],'files':files},indent=2)+'\n');archive=root/'package.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(package.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(package)),recursive=False)
freeze={'scope':'Exact source/argv/input/build8 runtime bound; root review required, no model or M5 operations. Earlier source-only drafts remain preserved.','package':str(package),'payloads':len(files),'package_manifest_sha256':digest(package/'package-manifest.json'),'plan_sha256':digest(package/'plan.json'),'archive':str(archive),'archive_sha256':digest(archive),'archive_bytes':archive.stat().st_size};(root/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n');print(json.dumps(freeze,indent=2))
