"""Integrity checks for the existing direct benchmark's schema-2 evidence."""

import math


def digest(value):
    return isinstance(value, str) and len(value) == 64 and all(c in "0123456789abcdef" for c in value)


def memory_errors(memory):
    required = ("cap_bytes", "activation_reserve_bytes", "active_bytes", "cache_bytes",
                "charged_bytes", "materialized_bytes", "unmaterialized_bytes", "remaining_bytes",
                "commitment_debt_bytes", "owner_count", "closing_owner_count", "policy_epoch",
                "generation", "sample_seq")
    if not isinstance(memory, dict) or any(type(memory.get(key)) is not int or memory[key] < 0 for key in required):
        return ["missing_or_invalid_process_memory"]
    if memory["charged_bytes"] < memory["materialized_bytes"] or (
        memory["charged_bytes"] - memory["materialized_bytes"] != memory["unmaterialized_bytes"]
    ) or memory["closing_owner_count"] > memory["owner_count"]:
        return ["inconsistent_process_ownership"]
    available = memory.get("system_available_bytes")
    cap_free = max(0, memory["cap_bytes"] - memory["active_bytes"] - memory["cache_bytes"])
    if available is not None and (type(available) is not int or available < 0):
        return ["invalid_system_available_bytes"]
    headroom = max(0, min(cap_free, available if available is not None else cap_free)
                   - memory["activation_reserve_bytes"])
    outstanding = memory["unmaterialized_bytes"]
    if (memory["remaining_bytes"] != max(0, headroom - outstanding)
            or memory["commitment_debt_bytes"] != max(0, outstanding - headroom)):
        return ["inconsistent_process_headroom"]
    return []


def decode_timing_errors(row):
    """Reconstruct measured decode work from raw chunks, including MTP chunks."""
    chunks = [chunk for chunk in row.get("chunks", []) if chunk.get("tokens")]
    if not chunks:
        return ["missing_decode_chunks"]
    first_count = len(chunks[0]["tokens"])
    after_first = sum(len(chunk["tokens"]) for chunk in chunks[1:])
    span = chunks[-1]["elapsed_s"] - chunks[0]["elapsed_s"]
    expected = after_first / span if span > 0 else 0
    observed = row.get("decode_tps")
    if (row.get("first_delta_token_count") != first_count
            or row.get("decode_tokens_after_first_delta") != after_first
            or type(observed) not in (int, float)
            or not math.isclose(observed, expected, rel_tol=1e-6, abs_tol=1e-6)):
        return ["decode_timing_inconsistent_with_chunks"]
    return []


def report_errors(report):
    """Do not promote incomplete cells or legacy reports into final evidence."""
    if report.get("schema", 1) < 2:
        return []
    errors = []
    if report.get("status") != "completed":
        errors.append({"incomplete_run": report.get("status"), "error": report.get("error")})
        return errors
    rows = report.get("rows", [])
    if not rows or any(row.get("outcome") != "completed" for row in rows):
        errors.append({"incomplete_request_cells": True})
    if report.get("warmup", {}).get("outcome") != "completed":
        errors.append({"warmup_not_completed": True})
    identity = report.get("runtime_identity", {})
    if report.get("cache_mode_requested") == "ssd":
        if (not digest(report.get("verified_model_hash")) or not digest(report.get("input_sha256"))
                or not all(identity.get(key) for key in ("normalization", "renderer", "tokenizer"))
                or not all(digest(identity.get(key)) for key in ("binary_sha256", "metallib_sha256"))):
            errors.append({"missing_artifact_identity": True})
    if report.get("expected_model_sha256") and report["expected_model_sha256"] != report.get("verified_model_hash"):
        errors.append({"pinned_model_mismatch": True})
    controls = report.get("tenant_checks", []) + [report.get("cancelled", {}), report.get("recovered", {})]
    probes = rows + controls
    for row in probes:
        if row.get("outcome") not in ("completed", "cancelled"):
            errors.append({"id": row.get("id"), "incomplete_control_cell": row.get("outcome")})
            continue
        chunks = row.get("chunks", [])
        if [token for chunk in chunks for token in chunk.get("tokens", [])] != row.get("token_ids"):
            errors.append({"id": row.get("id"), "chunk_token_ids_inconsistent": True})
        for reason in decode_timing_errors(row):
            errors.append({"id": row.get("id"), reason: True})
        if row.get("prompt_tokens") != len(row.get("prompt_token_ids", [])):
            errors.append({"id": row.get("id"), "prompt_token_count_inconsistent": True})
        if report.get("cache_mode_requested") == "ssd" and not row.get("prompt_render_date"):
            errors.append({"id": row.get("id"), "missing_request_owned_date": True})
    observations = []
    for row in probes:
        for moment in ("metrics_before", "metrics_after"):
            observations.append((row.get("id"), moment, row.get(moment, {}), not row.get("batch_id") and moment == "metrics_after"))
    for batch in report.get("batches", []):
        observations.append((batch.get("id"), "metrics_after_batch", batch.get("metrics_after_batch", {}), True))
        observations.extend((batch.get("id"), "capacity_sample", sample, False)
                            for sample in batch.get("capacity_samples", []))
    observations.extend(("run", key, report.get(key, {}), key == "metrics_after_shutdown")
                        for key in ("metrics_loaded", "metrics_after_shutdown"))
    if report.get("cache_mode_requested") == "ssd":
        for owner, moment, metrics, idle in observations:
            for reason in memory_errors(metrics.get("process_memory")):
                errors.append({"id": owner, "moment": moment, reason: True})
            if report.get("resolved_backend") == "paged" and (
                moment in ("metrics_after", "metrics_after_batch") or "paged_storage" in metrics
            ):
                storage = metrics.get("paged_storage", {})
                if any(type(storage.get(key)) is not int or storage[key] < 0
                       for key in ("allocator_padding_bytes", "last_allocation_allowance_bytes")):
                    errors.append({"id": owner, "moment": moment, "missing_allocator_footprint": True})
            ssd = metrics.get("ssd_cache")
            if ssd is not None:
                if any(type(ssd.get(key)) is not int or ssd[key] < 0 for key in
                       ("write_host_bytes_in_use", "peak_write_host_bytes", "write_host_capacity_refusals")):
                    errors.append({"id": owner, "moment": moment, "missing_write_host_evidence": True})
                elif idle and ssd["write_host_bytes_in_use"] != 0:
                    errors.append({"id": owner, "moment": moment, "idle_write_host_not_released": True})
    if report.get("mtp", "").startswith("on"):
        assistant = report.get("metrics_loaded", {}).get("assistant_identity", {})
        if report.get("cache_mode_requested") == "ssd" and (not assistant or assistant.get("source") in (None, "none")):
            errors.append({"missing_assistant_identity": True})
        # Batching can skip individual rows under the ordinary MTP policy;
        # prove actual rounds somewhere in the non-warmup workload.
        rounds = sum(max(0, row.get("metrics_after", {}).get("mtp", {}).get("rounds", 0)
                        - row.get("metrics_before", {}).get("mtp", {}).get("rounds", 0)) for row in probes)
        if rounds == 0:
            errors.append({"requested_mtp_never_verified": True})
    return errors
