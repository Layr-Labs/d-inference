from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import sys
import time

SOURCE = Path('/tmp/darkbloom-q36-attention-owner-identity-plan1')
OUT = Path('/tmp/darkbloom-q36-attention-owner-identity-execution1')
BINDING = Path('/tmp/darkbloom-q36-attention-owner-identity-runtime-binding1.json')
OPTIONS = ['-i', '/Users/gaj/.ssh/darkbloom_testbox', '-o', 'IdentitiesOnly=yes',
           '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15']
HOST = 'gaj@100.124.35.99'
SSH = ['ssh'] + OPTIONS + [HOST]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def remote(local, name, code):
    result = subprocess.run(SSH + ['python3 -B -'], input=code, text=True, capture_output=True)
    (local / (name + '.stdout')).write_text(result.stdout)
    (local / (name + '.stderr')).write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    return json.loads(result.stdout)


def main():
    sys.dont_write_bytecode = True
    assert sha(OUT / 'preflight.py') == '8ba55ca6f113442ee6740ed8ff2a505c80ff4130e2a8d0da412a8165c5fe6516'
    assert sha(SOURCE / 'manifest.json') == 'ab6907c6e6d2efed1fbe56f0b0168964713fa95022d1783ca3b8aa00f2a29a48'
    assert sha(BINDING) == '03bba023c5a22459469ee33bff351732a7adb4c3ab2d104d90d586a7f25f6377'
    plan = json.loads((SOURCE / 'plan.json').read_text())
    binding = json.loads(BINDING.read_text())
    assert sha(Path(binding['review'])) == binding['review_sha256']
    assert len(plan['cells']) == 2 and all(c['backend'] == 'contiguous' for c in plan['cells'])
    chosen = next(cell for cell in plan['cells'] if cell['id'] == sys.argv[1])
    if chosen['trace']:
        prior = json.loads((OUT / plan['cells'][0]['id'] / 'summary.json').read_text())
        assert prior['report_integrity_passed'], 'Do not run trace after a failed control'
        prior_root = OUT / plan['cells'][0]['id']
        for name, item in json.loads((prior_root / 'manifest.json').read_text())['files'].items():
            path = prior_root / name
            assert path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], name
    bound_command = next(c for c in binding['commands'] if c['cell'] == chosen['id'])
    assert bound_command['wrapper_argv'] == chosen['argv']
    command = chosen['argv']
    local = OUT / chosen['id']
    local.mkdir(exist_ok=False)
    (local / 'command.json').write_text(json.dumps(chosen, indent=2) + '\n')
    (local / 'expected-native-command.json').write_text(json.dumps(bound_command, indent=2) + '\n')
    check = subprocess.run(['python3', '-B', str(OUT / 'preflight.py'),
                            str(local / 'ownership-before.json')], text=True, capture_output=True)
    (local / 'ownership-before.log').write_text(check.stdout + check.stderr)
    assert check.returncode == 0, check.stdout + check.stderr
    output = command[command.index('--output') + 1]
    code = '''from pathlib import Path
import datetime,hashlib,json,shutil
root=Path(ROOT);assert not Path(OUTPUT).exists()
date=datetime.datetime.now(datetime.timezone.utc).date().isoformat();assert date=='2026-09-06'
assert hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()=='ab6907c6e6d2efed1fbe56f0b0168964713fa95022d1783ca3b8aa00f2a29a48'
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()=='03bba023c5a22459469ee33bff351732a7adb4c3ab2d104d90d586a7f25f6377'
binding=json.loads((root/'runtime-binding.json').read_text())
assert hashlib.sha256((root/'runtime-root-review.json').read_bytes()).hexdigest()==binding['review_sha256']
inventory=json.loads((root/'manifest.json').read_text())['files']
for name,item in inventory.items():
 p=root/name;assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
 assert p.stat().st_mode&0o777==int(item['mode'],8)
runtime={}
for name,item in binding['artifacts'].items():
 p=root/'runtime'/name;assert p.stat().st_size==item['bytes'] and p.stat().st_mode&0o777==int(item['mode'],8)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'];runtime[name]=item
plan=json.loads((root/'plan.json').read_text());selected=next(c for c in plan['cells'] if c['id']==CELL)
assert selected['argv']==ARGV
free=shutil.disk_usage(root).free;assert free>plan['execution_guards']['min_free_bytes']
print(json.dumps({'utc_date':date,'free_bytes':free,'runtime':runtime,'cell':CELL,'fresh_output_root':True},indent=2))
'''.replace('ROOT', repr(plan['remote_root'])).replace('OUTPUT', repr(output)).replace('CELL', repr(chosen['id'])).replace('ARGV', repr(command))
    remote(local, 'runtime-precheck', code)
    started = time.monotonic()
    with (local / 'ssh-run.log').open('x') as log:
        run = subprocess.run(SSH + [shlex.join(command)], stdout=log, stderr=subprocess.STDOUT)
    (local / 'execution.json').write_text(json.dumps({'exit_code':run.returncode,'seconds':time.monotonic()-started,'scope':plan['scope']},indent=2)+'\n')
    inventory = remote(local, 'remote-inventory', '''from pathlib import Path
import hashlib,json
root=Path(OUTPUT);files={}
if root.exists():
 for p in sorted(root.iterdir()):
  if p.is_file() and not p.is_symlink():files[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'root':str(root),'files':files},indent=2))
'''.replace('OUTPUT', repr(output)))
    for name, item in inventory['files'].items():
        assert name and all(c.isalnum() or c in '.-_' for c in name)
        result = subprocess.run(['scp'] + OPTIONS + [HOST + ':' + output + '/' + name,str(local/name)],text=True,capture_output=True)
        assert result.returncode == 0, result.stderr
        assert (local/name).stat().st_size == item['bytes'] and sha(local/name) == item['sha256']
    summary = {'cell':chosen['id'],'exit_code':run.returncode,'trace':chosen['trace'],
               'scope':'Two same-build corrected contiguous controls only; old paged evidence remains original-build. No performance or numerical acceptance waiver'}
    errors = []
    if (local/'report.json').exists():
        sys.path.insert(0,str(SOURCE/'runner'))
        from radix_engine_evidence import report_errors
        report=json.loads((local/'report.json').read_text())
        errors=report_errors(report)
        from strict_results import result_errors
        errors += result_errors(local, chosen, plan, binding, report, OUT)
        metadata=report.get('attention_metadata')
        if chosen['trace']:
            if not isinstance(metadata,dict) or metadata.get('status')!='captured':
                errors.append('selected metadata forward was not captured')
        elif metadata is not None:
            errors.append('uninstrumented control unexpectedly emitted attention metadata')
        summary.update(report_integrity_passed=not errors,errors=errors,
                       attention_metadata_status=(metadata or {}).get('status'),
                       logit_diagnostic_status=(report.get('logit_diagnostic') or {}).get('status'))
    else:
        errors=['report missing'];summary['errors']=errors
    (local/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
    files={str(p.relative_to(local)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(local.rglob('*')) if p.is_file()}
    (local/'manifest.json').write_text(json.dumps({'scope':summary['scope'],'files':files},indent=2,sort_keys=True)+'\n')
    print(json.dumps({**summary,'manifest_sha256':sha(local/'manifest.json')},indent=2),flush=True)
    raise SystemExit(run.returncode or (1 if errors else 0))


if __name__ == '__main__':
    main()
