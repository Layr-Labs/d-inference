"""Pure evidence checks for the four actual Q36 control/capture cells."""
import hashlib
import json
from pathlib import Path


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def result_errors(local, cell, plan, binding, report, output_root):
    errors = []

    def require(condition, message):
        if not condition:
            errors.append(message)

    try:
        meta = json.loads((local / 'metadata.json').read_text())
        expected = next(c for c in binding['commands'] if c['cell'] == cell['id'])
        require(meta['command'] == expected['expected_observed_native_argv'],
                'observed native argv differs after explicit owned input-copy substitution')
        require(meta['source_input_sha256'] == plan['source_input_sha256'] and meta['input_sha256'] == plan['actual_wrapper_input_sha256']
                and digest(local / 'input.json') == plan['actual_wrapper_input_sha256'], 'input bytes changed')
        require(meta['binary_sha256'] == binding['artifacts']['radix-engine']['sha256'],
                'observed runtime hash differs from reviewed probe')
        require(meta['exit_code'] == 0 and meta['status'] == 'completed',
                'native process did not complete successfully')
        require(report['requested_backend'] == report['resolved_backend'] == cell['backend']
                and report['backend_fallback'] is None, 'requested backend/fallback mismatch')
        require(report['cache_requested'] is False and report['max_concurrent_requests'] == 1,
                'cache or concurrency mismatch')
        require(report['cache_mode_requested'] == 'ssd' and report['key_mode_requested'] == 'ephemeral'
                and report['kv_grant_mode'] == 'production_single_slot'
                and report['mtp'].startswith('off;'), 'requested execution mode mismatch')
        require(report['expected_model_sha256'] == report['verified_model_hash'] == plan['model_sha256'],
                'model artifact hash mismatch')
        require(report['input_sha256'] == plan['actual_wrapper_input_sha256'], 'report input hash mismatch')
        rows = report['rows']
        require(len(rows[0]['token_ids']) == 83 and rows[0]['token_ids'][61] == 11346,
                'selected 83-token trajectory/seed changed')
        require(len(rows) == 2 and all(row['prompt_tokens'] == 5523 for row in rows),
                'main prompt identity/count mismatch')
        for row in rows:
            require(row['cache_outcome'] == 'disabled', 'cache-off main row adopted cache')
            require(row['prompt_render_date'] == plan['prompt_date_utc'], 'main prompt date mismatch')
        canceled, recovered = report['cancelled'], report['recovered']
        require(canceled['token_ids'] == recovered['token_ids'][:len(canceled['token_ids'])],
                'canceled output is not its own recovery prefix')
        if not cell['capture']:
            require(report.get('attention_metadata') is None and report.get('logit_diagnostic') is None and report.get('attention_packet') is None,
                    'uninstrumented control emitted diagnostics')
            prior = json.loads((Path(__file__).parent/'prior-controls'/(cell['backend']+'.json')).read_text())
            fields = ['prompt_token_ids','token_ids','prompt_tokens','completion_tokens','finish','outcome']
            for group in ['rows','tenant_checks','cancel_donor','recovered']:
                a = prior[group] if isinstance(prior[group],list) else [prior[group]]
                b = report[group] if isinstance(report[group],list) else [report[group]]
                require(len(a) == len(b) and all(all(x[k] == y[k] for k in fields) for x,y in zip(a,b)),
                        'prior uninstrumented completed trajectory changed: '+group)
            return errors

        control_cell = next(c for c in plan['cells'] if c['backend'] == cell['backend'] and not c['capture'])
        control_path = output_root / control_cell['id'] / 'report.json'
        control = json.loads(control_path.read_text())
        fields = ['prompt_token_ids', 'token_ids', 'prompt_tokens', 'completion_tokens', 'finish', 'outcome']
        for group in ['rows', 'tenant_checks', 'cancel_donor', 'recovered']:
            left = control[group] if isinstance(control[group], list) else [control[group]]
            right = report[group] if isinstance(report[group], list) else [report[group]]
            require(len(left) == len(right), group + ' row membership changed')
            for index, (a, b) in enumerate(zip(left, right)):
                require(all(a[key] == b[key] for key in fields),
                        group + ':' + str(index) + ' same-build trajectory changed')
        require(control['cancelled']['token_ids'] == control['recovered']['token_ids'][
            :len(control['cancelled']['token_ids'])], 'control cancellation is not recovery prefix')

        attention = report['attention_metadata']
        snapshot = attention['snapshot']
        config = snapshot['configuration']
        require(attention['status'] == 'captured' and snapshot['expectedOwnerCount'] == 10
                and snapshot['selectedForwards'] == 1 and snapshot['forwardSucceeded'] is True
                and snapshot['sampleOutcome'] == 'confirmed' and snapshot['refusals'] == {},
                'attention metadata capture incomplete or refused')
        tokens = rows[0]['token_ids']
        target = tokens[62]
        require(config['requestID'] == 2 and config['outputIndex'] == 62
                and snapshot['seedToken'] == tokens[61] == 11346
                and snapshot['targetToken'] == target, 'attention selection does not match actual IDs')
        records = snapshot['records']
        pairs = sorted((r['storageLayerIndex'], r['modelLayerIndex']) for r in records)
        require(pairs == [(i, 3 + 4 * i) for i in range(10)], 'ten attention-owner identities not exact')
        for record in records:
            require(record['requestID'] == 2 and record['outputIndex'] == 62
                    and record['phase'] in ['decode', 'chained_decode'] and record['batchSize'] == 1
                    and record['batchIndex'] == 0 and record['inputWidth'] == 1
                    and record['offsetBefore'] == 5584 and record['offsetAfter'] == 5585
                    and record['dispatch'] == ('contiguous_sdpa' if cell['backend'] == 'contiguous' else 'paged_segmented_decode'), 'attention owner forward geometry mismatch')
            for key in ['queries', 'incomingKeys', 'incomingValues', 'output']:
                require(isinstance(record[key]['dtype'], str) and bool(record[key]['dtype'])
                        and isinstance(record[key]['shape'], list), 'missing tensor metadata: ' + key)
            require(isinstance(record['kernelOutputDType'], str) and bool(record['kernelOutputDType']),
                    'missing kernel output dtype')
            require(bool(record['storage']) and all(isinstance(v['dtype'], str) and bool(v['dtype'])
                    for v in record['storage'].values()), 'missing native KV storage dtype')

        require(all(r['phase'] == records[0]['phase'] for r in records), 'all-owner selected phase differs')
        logits = report['logit_diagnostic']
        require(logits['status'] == 'captured' and len(logits['snapshot']['records']) == 1,
                'selected logit capture missing or ambiguous')
        require(logits['snapshot']['invalidVocabularyRecords'] == 0 and logits['snapshot']['omittedRecords'] == 0,
                'logit record omitted or vocabulary invalid')
        logit = logits['snapshot']['records'][0]
        require(logit['requestID'] == 2 and logit['outputIndex'] == 62
                and logit['outputBase'] == 62 and logit['phase'] == records[0]['phase']
                and logit['cacheOffset'] == 5584 and logit['batchSize'] == 1
                and logit['batchIndex'] == 0 and logit['column'] == 0
                and logit['confirmedWidth'] == logit['verificationWidth'] == 1
                and logit['draftDepth'] == logit['acceptedDrafts'] == 0
                and logit['draftPrefix'] == [] and logit['outcome'] == 'confirmed'
                and logit['seedToken'] == snapshot['seedToken']
                and logit['targetToken'] == logit['argMaxID'] == target
                and logit['candidateIDs'] == [1928, 6829], 'logit selection/geometry mismatch')
        require(logit['nanCount'] == logit['infiniteCount'] == 0,
                'selected logits contain non-finite values')
    except (OSError, ValueError, KeyError, TypeError, IndexError, AttributeError) as error:
        errors.append('malformed or incomplete strict evidence: ' + type(error).__name__)
    return errors
