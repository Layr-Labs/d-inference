from pathlib import Path
import ast,difflib,hashlib,json,shutil,subprocess
out=Path(__file__).resolve().parent
candidate=Path('/Users/gaj/Documents/DarkbloomDev/wt/q36-attention-metadata-diagnostic')
source=Path('/tmp/darkbloom-q36-attention-metadata-source1')
staged=Path('/tmp/darkbloom-q36-attention-metadata-harness-validation1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
assert not (out/'manifest.json').exists()
review=json.loads((source/'review.json').read_text());changes={};patch=[]
paths=['scripts/benchmarks/radix-engine/Tests/RadixEngineBenchmarkTests/BenchmarkAttentionMetadataOptionsTests.swift','scripts/benchmarks/test_run_radix_engine.py']
for name in paths:
 before=source/'source/parent'/name;after=candidate/name
 assert sha(before)==review['source_files']['parent'][name]['after_sha256'],name
 changes[name]={'before_sha256':sha(before),'after_sha256':sha(after)}
 for directory,p in [('before',before),('after',after)]:
  target=out/directory/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
 patch.append(''.join(difflib.unified_diff(before.read_text().splitlines(keepends=True),after.read_text().splitlines(keepends=True),fromfile='a/'+name,tofile='b/'+name)))
(out/'test-only.patch').write_text(''.join(patch))
commands=[['python3','-B','-m','unittest','-v','test_run_radix_engine.py'],['git','diff','--check']]
results=[]
for index,command in enumerate(commands):
 cwd=candidate/'scripts/benchmarks' if index==0 else candidate
 with (out/('python-wrapper-tests.log' if index==0 else 'diff-check.log')).open('x') as log:r=subprocess.run(command,cwd=cwd,stdout=log,stderr=subprocess.STDOUT)
 results.append({'command':command,'cwd':str(cwd),'exit_code':r.returncode});assert r.returncode==0
ast.parse((candidate/paths[1]).read_text(),feature_version=(3,9))
assert 'Ran 12 tests' in (out/'python-wrapper-tests.log').read_text()
write('results.json',results)
write('review.json',{'scope':'Two test-only additions verify simultaneous metadata and logit diagnostic flags for contiguous and paged B1 MTP-off serving commands. No native, harness option parser, wrapper implementation or runtime changes.','source1_manifest_sha256':sha(source/'manifest.json'),'root_source_review_sha256':sha(Path('/tmp/darkbloom-q36-attention-metadata-root-source-review.json')),'source_files':changes,'python_tests':12,'swift_test_status':'Not run at this test-only source freeze; isolated harness validation follows.','python_39_ast_parse':'pass'})
files={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
write('manifest.json',{'schema':1,'status':'TEST_ONLY_SOURCE_DELTA','files':files})
# Preserve prepared staging before applying the test delta, then update exact inputs.
for name in ['harness-source-manifest.json','integration.json']:shutil.copy2(staged/name,staged/('prepared-before-test-delta-'+name))
name=paths[0];target=staged/'radix-engine/Tests/RadixEngineBenchmarkTests/BenchmarkAttentionMetadataOptionsTests.swift';assert sha(target)==changes[name]['before_sha256'];shutil.copy2(candidate/name,target)
hm=json.loads((staged/'harness-source-manifest.json').read_text());hm['files'][str(target.relative_to(staged))]=sha(target);hm['parent_candidate_changes'][name]['after_sha256']=sha(target)
# The wrapper is part of the candidate source union although not a Swift compile input.
hm['parent_candidate_changes'][paths[1]]['after_sha256']=changes[paths[1]]['after_sha256']
hm['test_only_delta_manifest_sha256']=sha(out/'manifest.json')
(staged/'harness-source-manifest.json').write_text(json.dumps(hm,indent=2)+'\n')
info=json.loads((staged/'integration.json').read_text());info['test_only_delta_manifest']=str(out/'manifest.json');info['test_only_delta_manifest_sha256']=sha(out/'manifest.json');info['status']='Prepared exact source union plus combined-options test-only delta; no benchmark Swift process started'
(staged/'integration.json').write_text(json.dumps(info,indent=2)+'\n')
print(json.dumps({'manifest':str(out/'manifest.json'),'sha256':sha(out/'manifest.json'),'payloads':len(files),'python_tests':12,'changes':changes},indent=2))
