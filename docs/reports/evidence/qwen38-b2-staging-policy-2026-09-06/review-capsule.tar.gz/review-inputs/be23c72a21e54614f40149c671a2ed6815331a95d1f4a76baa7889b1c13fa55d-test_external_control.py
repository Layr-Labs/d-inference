import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

from control_input import ControlInput, ControlLost
import pilot
import pilot_core as core
import ssh_controller

ROOT = Path(__file__).resolve().parents[1]
WORK = ROOT / "test-work"


class ControlTests(unittest.TestCase):
    def setUp(self):
        reader, self.writer = os.pipe()
        self.reader = os.fdopen(reader, "rb")
        self.control = ControlInput(self.reader, lease=.5)

    def tearDown(self):
        self.control.close(); self.reader.close()
        if self.writer is not None:
            os.close(self.writer)

    def test_only_external_complete_ping_renews(self):
        os.write(self.writer, b'{"command":"pi')
        self.assertEqual(self.control.poll(), b"")
        self.assertIsNone(self.control.last_ping)
        os.write(self.writer, b'ng"}\n')
        self.assertEqual(self.control.poll(), b'{"command":"ping"}\n')
        self.assertEqual(self.control.pings, 1)

    def test_eof_after_buffered_ping_still_refuses(self):
        os.write(self.writer, b'{"command":"ping"}\n'); os.close(self.writer); self.writer = None
        with self.assertRaisesRegex(ControlLost, "EOF"):
            self.control.wait_for_ping()

    def test_missing_initial_ping_expires(self):
        self.control.started -= 1
        with self.assertRaisesRegex(ControlLost, "lease expired"):
            self.control.poll()

    def test_stop_refuses(self):
        os.write(self.writer, b'{"command":"stop"}\n')
        with self.assertRaisesRegex(ControlLost, "requested stop"):
            self.control.poll()

    def test_unknown_and_extra_fields_do_not_renew(self):
        os.write(self.writer, b'{"command":"ping","grant":true}\n')
        with self.assertRaisesRegex(ControlLost, "only exact"):
            self.control.poll()
        self.assertIsNone(self.control.last_ping)

    def test_oversized_incomplete_frame_refuses(self):
        os.write(self.writer, b"x" * 4097)
        with self.assertRaisesRegex(ControlLost, "frame exceeds"):
            self.control.poll()

    def test_lease_cannot_exceed_thirty_seconds(self):
        with self.assertRaisesRegex(ValueError, "30 seconds"):
            ControlInput(self.reader, lease=31)


class CallerProcessTests(unittest.TestCase):
    def setUp(self):
        WORK.mkdir(exist_ok=True)
        self.temporary = tempfile.TemporaryDirectory(dir=WORK)
        self.root = Path(self.temporary.name)
        self.process = None

    def tearDown(self):
        if self.process:
            if self.process.poll() is None:
                try:
                    self.process.stdin.close()
                except OSError:
                    pass
                try:
                    self.process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    self.process.terminate(); self.process.wait(timeout=15)
            for stream in (self.process.stdin, self.process.stdout, self.process.stderr):
                if stream:
                    stream.close()
        self.temporary.cleanup()

    def start(self, mode="outer", scenario="sequence"):
        argv = [sys.executable, "-B", str(ROOT / "tests/cpu_child.py"), mode, str(self.root), scenario]
        if mode == "outer":
            argv.append(".6")
        self.process = subprocess.Popen(argv, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                        start_new_session=True)
        return self.process

    def wait_child(self, externally_ping):
        deadline = time.monotonic() + 6
        while not (self.root / "attempt/cpu-child.json").exists():
            if self.process.poll() is not None:
                self.fail(self.process.stderr.read().decode())
            if time.monotonic() >= deadline:
                self.fail("CPU outer fixture did not launch its harmless first child")
            if externally_ping:
                self.process.stdin.write(b'{"command":"ping"}\n'); self.process.stdin.flush()
            time.sleep(.05)

    def assert_outer_retired(self, reason):
        self.process.wait(timeout=15)
        self.assertNotEqual(self.process.returncode, 0)
        root = self.root / "attempt"
        terminal = core.read(root / "terminal.json")
        self.assertFalse(terminal["accepted"])
        self.assertIn(reason, terminal["failure"])
        self.assertFalse(core.read(root / "caller-lease.json")["alive"])
        self.assertTrue(core.read(root / "foreground-retirement.json")["complete"])
        self.assertTrue(core.read(root / "detached-retirement.json")["complete"])
        child = core.read(root / "cpu-child.json")
        self.assertFalse(pilot.group_present(child["pid"]))
        self.assertFalse((root / "successor-started.json").exists())
        self.assertFalse((root / "steps/2").exists())
        self.assertTrue((root / "evidence.tar.gz").exists())

    def test_outer_caller_eof_with_stdout_open_stops_and_no_successor(self):
        self.start(); self.wait_child(externally_ping=True)
        self.process.stdin.close()
        self.assertFalse(self.process.stdout.closed)
        self.assert_outer_retired("external caller stdin EOF")
        self.assertTrue(core.read(self.root / "attempt/supervisor-terminal.json")["owner"]["stop_requested"])

    def test_outer_caller_lease_expiry_stops_before_inner_lease_and_no_successor(self):
        self.start(); self.wait_child(externally_ping=True)
        self.assert_outer_retired("external caller lease expired")
        owner = core.read(self.root / "attempt/supervisor-terminal.json")["owner"]
        self.assertLess(owner["seconds"], 15)
        self.assertTrue(owner["stop_requested"])

    def test_outer_external_stop_stops_and_no_successor(self):
        self.start(); self.wait_child(externally_ping=True)
        self.process.stdin.write(b'{"command":"stop"}\n'); self.process.stdin.flush()
        self.assert_outer_retired("external caller requested stop")

    def test_outer_signal_stops_owned_supervision(self):
        self.start(); self.wait_child(externally_ping=True)
        self.process.send_signal(signal.SIGTERM)
        self.assert_outer_retired("foreground controller signal")

    def test_outer_no_initial_ping_or_eof_never_launches(self):
        self.start(); self.process.stdin.close()
        self.process.wait(timeout=5)
        self.assertNotEqual(self.process.returncode, 0)
        self.assertFalse((self.root / "attempt").exists())

    def test_outer_no_initial_ping_expires_without_launch(self):
        self.start(); self.process.wait(timeout=5)
        self.assertIn("external caller lease expired", self.process.stderr.read().decode())
        self.assertFalse((self.root / "attempt").exists())

    def test_local_controller_eof_closes_real_external_pipe_without_ssh_hangup(self):
        self.start(mode="relay"); self.wait_child(externally_ping=False)
        self.process.stdin.close()
        self.assert_outer_retired("external caller requested stop")
        local = core.read(self.root / "local-controller/terminal.json")
        self.assertIn("external caller stdin EOF", local["failure"])
        self.assertFalse(local["forced_local_cleanup"])

    def test_local_controller_signal_closes_real_external_pipe(self):
        self.start(mode="relay"); self.wait_child(externally_ping=False)
        self.process.send_signal(signal.SIGINT)
        self.assert_outer_retired("external caller requested stop")
        local = core.read(self.root / "local-controller/terminal.json")
        self.assertIn("local foreground signal", local["failure"])
        self.assertFalse(local["forced_local_cleanup"])

    def test_local_controller_supplies_pings_for_normal_completion(self):
        self.start(mode="relay", scenario="complete")
        self.process.wait(timeout=10)
        self.assertEqual(self.process.returncode, 0, self.process.stderr.read())
        self.assertTrue(core.read(self.root / "attempt/terminal.json")["accepted"])
        self.assertTrue(core.read(self.root / "local-controller/terminal.json")["accepted"])


class GuardTests(unittest.TestCase):
    def setUp(self):
        WORK.mkdir(exist_ok=True)
        self.temporary = tempfile.TemporaryDirectory(dir=WORK)
        self.root = Path(self.temporary.name)

    def tearDown(self):
        self.temporary.cleanup()

    def test_default_remote_run_refuses_regular_unleased_stdin(self):
        filename = self.root / "stdin.json"; filename.write_text('{"command":"ping"}\n')
        with filename.open("rb") as control, patch.object(core, "verify_activation") as verify:
            with self.assertRaisesRegex(ControlLost, "pipe/socket"):
                pilot.run(self.root / "unbound.json", control)
            verify.assert_not_called()

    def test_worker_refuses_successor_on_stopped_or_expired_caller(self):
        for alive, age in ((False, 0), (True, 31)):
            (self.root / "caller-lease.json").write_text(json.dumps({"alive": alive, "requires_external_pings": True,
                "last_ping_unix": time.time() - age, "lease_seconds": 30}))
            with self.assertRaisesRegex(ValueError, "no successor"):
                pilot.require_caller_live(self.root)

    def test_worker_does_not_compare_process_local_monotonic_epochs(self):
        (self.root / "caller-lease.json").write_text(json.dumps({"alive": True, "requires_external_pings": True,
            "last_ping_monotonic": 2.2, "last_ping_unix": time.time(), "lease_seconds": 30}))
        with patch.object(pilot.time, "monotonic", return_value=99999):
            pilot.require_caller_live(self.root)

    def test_ssh_command_preserves_stdin_and_uses_no_pty(self):
        identity = self.root / "identity"; identity.write_text("CPU placeholder; never used by ssh")
        command = ssh_controller.ssh_command("gaj@m5", identity, Path("/M5/pilot.py"), Path("/M5/activation.json"), Path("/usr/bin/python3"))
        self.assertEqual(command[0], "/usr/bin/ssh")
        self.assertIn("-T", command)
        self.assertNotIn("-n", command)
        self.assertNotIn("-f", command)
        self.assertEqual(command[-1], "exec /usr/bin/python3 -B /M5/pilot.py run --activation /M5/activation.json")

    def test_local_prestart_eof_never_launches_ssh(self):
        reader, writer = os.pipe(); os.close(writer)
        with os.fdopen(reader, "rb") as control, patch.object(ssh_controller.subprocess, "Popen") as launch:
            self.assertEqual(ssh_controller.relay(["must-not-execute-ssh"], self.root / "output", control), 1)
            launch.assert_not_called()
        self.assertFalse((self.root / "output").exists())

    def test_failed_review_version_preserved_exactly(self):
        history = ROOT / "history/failed-review-90f18f4a"
        self.assertEqual(core.sha(history / "manifest.json"), "90f18f4a6814c162f6ca04b29387d8ea579a09cae2c4a552e6220b9e8bddc956")
        for relative, expected in core.read(history / "manifest.json")["files"].items():
            self.assertEqual(core.sha(history / relative), expected["sha256"])
        self.assertEqual(core.read(history / "ROOT-REVIEW-FAILURE.json")["state"], "REJECTED_DO_NOT_EXECUTE")


if __name__ == "__main__":
    unittest.main()
