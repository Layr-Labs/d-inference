from pathlib import Path

from common import checked_file, digest, local_path, read_json, require


def runtime_files(binding):
    runtime = binding.get('runtime')
    require(isinstance(runtime, dict), 'Runtime artifact remains unbound; no execution is permitted')
    supplied = Path(runtime['artifact_root'])
    require(supplied.is_dir() and not supplied.is_symlink(), 'real runtime directory required')
    artifact = supplied.resolve(strict=True)
    source = Path(runtime['source_manifest'])
    checked_file(source, runtime['source_manifest_identity'])
    require(digest(source) == runtime['source_manifest_sha256'], 'runtime source manifest changed')
    manifest = read_json(source)
    require(manifest['files'] == runtime['files'] and manifest['source'] == runtime['source'], 'runtime source/file binding differs')
    require(runtime['files']['mlx.metallib']['sha256'] == binding['required_metallib_sha256'], 'required metallib differs')
    require(runtime['files']['darkbloom']['mode'] == 0o755, 'CLI executable mode must be 0755')
    actual = set()
    for path in artifact.rglob('*'):
        require(not path.is_symlink(), 'runtime symlink refused: ' + str(path))
        require(path.is_dir() or path.is_file(), 'nonregular runtime entry')
        if path.is_file():
            actual.add(str(path.relative_to(artifact)))
    require(actual == set(runtime['files']), 'complete runtime file inventory required')
    for relative, expected in runtime['files'].items():
        require(expected['mode'] in (0o644, 0o755), 'canonical executable/resource modes required')
        checked_file(local_path(artifact, relative), expected)
    return artifact


def model_files(model):
    supplied = Path(model['model_directory'])
    require(supplied.is_dir() and not supplied.is_symlink(), 'real selected model directory required')
    target = supplied.resolve(strict=True)
    files = {}
    directories = []
    for path in sorted(target.rglob('*')):
        relative = str(path.relative_to(target))
        if path.is_dir():
            require(not path.is_symlink(), 'model directory symlinks are unsupported')
            directories.append(relative)
        else:
            require(path.is_file() and path.resolve(strict=True).is_file(), 'model input must resolve to a file')
            files[relative] = path.resolve(strict=True)
        require(len(files) + len(directories) <= 4096, 'model entry inventory exceeded bound')
    require('config.json' in files and any(Path(name).suffix == '.safetensors' for name in files), 'selected model files absent')
    return target, directories, files


def stage_snapshot(model, snapshot):
    target, directories, files = model_files(model)
    snapshot.mkdir(parents=True)
    for relative in directories:
        local_path(snapshot, relative).mkdir(parents=True, exist_ok=True)
    for relative, source in files.items():
        link = local_path(snapshot, relative)
        link.parent.mkdir(parents=True, exist_ok=True)
        link.symlink_to(source)
    return target


def validate_snapshot(model, snapshot):
    _, directories, files = model_files(model)
    require(snapshot.is_dir() and not snapshot.is_symlink(), 'real fixture snapshot required')
    actual = {str(path.relative_to(snapshot)) for path in snapshot.rglob('*')}
    require(actual == set(files) | set(directories), 'fixture snapshot inventory changed')
    for relative in directories:
        path = local_path(snapshot, relative)
        require(path.is_dir() and not path.is_symlink(), 'real fixture subdirectory required')
    for relative, source in files.items():
        path = local_path(snapshot, relative)
        require(path.is_symlink() and path.resolve(strict=True) == source, 'fixture file link changed')
