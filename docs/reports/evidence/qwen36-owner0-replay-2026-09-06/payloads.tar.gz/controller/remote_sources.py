"""Remote snippets have no model/configuration/key operations."""

READINESS = '''from pathlib import Path
import json,os,shutil,subprocess,time
processes=[]
for line in subprocess.check_output(['ps','-axo','pid=,ppid=,comm=,args='],text=True).splitlines():
 bits=line.strip().split(None,3)
 if len(bits)<3:continue
 markers=('Runner.Worker','benchctl measure-job','measure-job.sh','radix-engine','run_radix_engine.py','connected-e2e.test','run_connected_fixture.py','attention-replay')
 if any(marker in line for marker in markers) or Path(bits[2]).name=='darkbloom':
  processes.append({'pid':bits[0],'ppid':bits[1],'command':bits[2]})
temperature=json.loads(subprocess.check_output(['/Users/gaj/bench-runner/bin/macmon','pipe','-s','1','-i','200'],text=True,timeout=10).splitlines()[0])['temp']['gpu_temp_avg']
value={'unix_time':time.time(),'processes':processes,'gpu_temp_c':temperature,'load':os.getloadavg(),'free_bytes':shutil.disk_usage('/Users/gaj').free}
print(json.dumps(value,indent=2))
assert not processes
if C['entry']:
 assert temperature<=42 and value['load'][0]<=4 and value['free_bytes']>100*(1<<30)
'''

CREATE = '''from pathlib import Path
import json
root=Path(C['remote_root']);assert not root.exists() and not root.is_symlink()
root.mkdir(mode=0o700,exist_ok=False)
print(json.dumps({'fresh_root':str(root),'mode':oct(root.stat().st_mode&0o777)}))
'''

EXTRACT = '''from pathlib import Path
import hashlib,json,stat,tarfile
root=Path(C['remote_root']);archive=root/'plan-package.tar.gz';expected=C['files']
assert hashlib.sha256(archive.read_bytes()).hexdigest()==C['archive_sha256']
assert {p.name for p in root.iterdir()}=={'plan-package.tar.gz'}
target=root/'plan';target.mkdir(mode=0o700)
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert len(members)==len(expected) and {m.name for m in members}==set(expected)
 for member in members:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  row=expected[member.name];assert member.size==row['bytes'] and member.mode&0o777==int(row['mode'],8)
  raw=tar.extractfile(member).read();assert hashlib.sha256(raw).hexdigest()==row['sha256']
  dest=target/member.name;assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True)
  dest.write_bytes(raw);dest.chmod(int(row['mode'],8))
(root/'runtime').mkdir(mode=0o700);(root/'transfer').mkdir(mode=0o700);(root/'runs').mkdir(mode=0o700)
print(json.dumps({'package_files':len(expected),'archive_sha256':C['archive_sha256'],'operator_invoked':False}))
'''

VERIFY = '''from pathlib import Path
import hashlib,json,stat
root=Path(C['remote_root']);assert root.resolve()==root and not root.is_symlink()
def check(path,row):
 status=path.lstat();assert stat.S_ISREG(status.st_mode) and not path.is_symlink(),str(path)
 assert status.st_size==row['bytes'] and stat.S_IMODE(status.st_mode)==int(row['mode'],8),str(path)
 digest=hashlib.sha256()
 with path.open('rb') as file:
  for chunk in iter(lambda:file.read(1<<20),b''):digest.update(chunk)
 assert digest.hexdigest()==row['sha256'],str(path)
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()==C['binding_sha256']
binding=json.loads((root/'runtime-binding.json').read_text())
assert binding['remote_root']==str(root)
assert hashlib.sha256((root/'plan/manifest.json').read_bytes()).hexdigest()==binding['plan_manifest_sha256']
for name,row in json.loads((root/'plan/manifest.json').read_text())['files'].items():check(root/'plan'/name,row)
for name,row in binding['artifacts'].items():check(root/'runtime'/name,row)
assert {str(p.relative_to(root/'runtime'))for p in (root/'runtime').rglob('*')if p.is_file()}==set(binding['artifacts'])
mapping=json.loads((root/'plan/native-buffer-map.json').read_text())
for row in mapping.values():check(root/'transfer'/row['destination_file'],{k:row[k]for k in ('sha256','bytes','mode')})
assert {p.name for p in (root/'transfer').iterdir()}=={'input.json'}|{row['destination_file']for row in mapping.values()}
assert hashlib.sha256((root/'transfer/input.json').read_bytes()).hexdigest()==binding['input_sha256']
'''

POPULATE = '''from pathlib import Path
import hashlib,json,shutil,stat
root=Path(C['remote_root']);binding=json.loads((root/'runtime-binding.json').read_text())
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()==C['binding_sha256']
assert {p.name for p in (root/'runtime').iterdir()}=={'attention-replay'}
def verify_source(path,row):
 info=path.lstat();assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
 assert info.st_size==row['bytes'] and stat.S_IMODE(info.st_mode)==int(row['mode'],8)
 assert hashlib.sha256(path.read_bytes()).hexdigest()==row['sha256']
for name,row in binding['artifacts'].items():
 if name=='attention-replay':verify_source(root/'runtime'/name,row);continue
 source=Path(C['resources_source'])/name;verify_source(source,row)
 target=root/'runtime'/name;target.parent.mkdir(parents=True,exist_ok=True);assert not target.exists();shutil.copy2(source,target)
mapping=json.loads((root/'plan/native-buffer-map.json').read_text())
assert not list((root/'transfer').iterdir())
for row in mapping.values():
 source=Path(row['remote_source_root'])/row['source_file'];verify_source(source,row)
 target=root/'transfer'/row['destination_file'];shutil.copy2(source,target)
shutil.copy2(root/'plan/input.json',root/'transfer/input.json')
'''

EXECUTE = VERIFY + '''
import os,signal,subprocess,time
arm=C['arm'];command=next(x for x in binding['commands']if x['arm']==arm)
assert command['argv']==C['argv'] and command['timeout_seconds']==180
output=root/'runs'/arm;assert not output.exists()
execution=root/'runs'/(arm+'-execution.json');log=root/'runs'/(arm+'.log')
assert not execution.exists() and not log.exists()
start=time.monotonic();record={'arm':arm,'argv':command['argv'],'input_sha256':binding['input_sha256'],'binary_sha256':binding['artifacts']['attention-replay']['sha256'],'timeout_seconds':180,'exit_code':None,'failure':None};process=None
owned_signals=(signal.SIGHUP,signal.SIGTERM)
previous_handlers={sig:signal.getsignal(sig)for sig in owned_signals}
class OwnerInterrupted(RuntimeError):pass
def interrupt_owner(signum,frame):
 for sig in owned_signals:signal.signal(sig,signal.SIG_IGN)
 raise OwnerInterrupted('received signal '+str(signum))
for sig in owned_signals:signal.signal(sig,interrupt_owner)
try:
 with log.open('x') as stream:
  try:
   # The single-threaded owner cannot lose a freshly forked child before storing its PID.
   prior_mask=signal.pthread_sigmask(signal.SIG_BLOCK,owned_signals)
   try:
    process=subprocess.Popen(command['argv'],stdout=stream,stderr=subprocess.STDOUT,start_new_session=True,env={'HOME':'/Users/gaj','PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin'},preexec_fn=lambda:signal.pthread_sigmask(signal.SIG_SETMASK,prior_mask))
   finally:signal.pthread_sigmask(signal.SIG_SETMASK,prior_mask)
   record['pid']=process.pid;record['pgid']=os.getpgid(process.pid)
   execution.write_text(json.dumps(record,indent=2)+'\\n')
   record['exit_code']=process.wait(timeout=180)
  except Exception as error:record['failure']=type(error).__name__+': '+str(error)
  finally:
   for sig in owned_signals:signal.signal(sig,signal.SIG_IGN)
   if process is not None:
    record['pid']=process.pid;record['pgid']=process.pid
    if process.poll() is None:
     try:os.killpg(process.pid,signal.SIGKILL)
     except ProcessLookupError:pass
    record['exit_code']=process.wait(timeout=10)
finally:
 record['seconds']=time.monotonic()-start
 execution.write_text(json.dumps(record,indent=2)+'\\n')
 for sig,handler in previous_handlers.items():signal.signal(sig,handler)
print(json.dumps(record,indent=2))
'''

INVENTORY = '''from pathlib import Path
import hashlib,json,stat
root=Path(C['remote_root'])/'runs';arm=C['arm'];files={};total=0
paths=[root/(arm+'-execution.json'),root/(arm+'.log')]
if (root/arm).exists():
 assert not (root/arm).is_symlink()
 paths+=list((root/arm).iterdir())
for path in paths:
 if not path.exists():continue
 info=path.lstat();assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
 name=str(path.relative_to(root));assert not Path(name).is_absolute() and '..'not in Path(name).parts
 assert name in {arm+'-execution.json',arm+'.log',arm+'/result.json',arm+'/output.bin',arm+'/storedKeys.bin',arm+'/storedValues.bin'}
 assert info.st_size<=32*(1<<20);total+=info.st_size;assert total<=64*(1<<20)
 digest=hashlib.sha256()
 with path.open('rb')as stream:
  for chunk in iter(lambda:stream.read(1<<20),b''):digest.update(chunk)
 files[name]={'bytes':info.st_size,'sha256':digest.hexdigest(),'mode':oct(stat.S_IMODE(info.st_mode))}
print(json.dumps({'files':files,'total_bytes':total},indent=2))
'''
