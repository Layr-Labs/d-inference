from pathlib import Path
import hashlib,json,shutil,subprocess,tarfile,io,difflib
OUT=Path('/tmp/darkbloom-attention-operator-replay-swift-validation1');OUT.mkdir()
ROOT=Path('/Users/gaj/Documents/DarkbloomDev/wt/attention-operator-replay');NATIVE=ROOT/'libs/mlx-swift-lm'
PRIOR=Path('/tmp/darkbloom-persistent-test-namespace-swift-validation6');SOURCE1=Path('/tmp/darkbloom-attention-operator-replay-source1');SOURCE2=Path('/tmp/darkbloom-attention-operator-replay-source2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,v):(OUT/n).write_text(json.dumps(v,indent=2)+'\n')
def files(root):return {str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file() and not any(x in {'.build','.swiftpm','__pycache__'} for x in p.relative_to(root).parts)}
assert sha(SOURCE1/'manifest.json')=='5d6bf09548a158c557194b5f0d2045bc469c151f3225abd8e445469d023bcacf'
assert sha(SOURCE2/'manifest.json')=='5aa02ca89fd599253b18e759935fe616a6e42caf581fd51addcd11617419561e'
for item in json.loads((SOURCE1/'manifest.json').read_text())['files']:assert sha(SOURCE1/'payload'/item['path'])==item['sha256']
for name,h in json.loads((SOURCE2/'manifest.json').read_text())['files'].items():assert sha(SOURCE2/name)==h
workspace=OUT/'workspace';workspace.mkdir();libs=workspace/'libs';libs.mkdir();native=libs/'mlx-swift-lm';native.mkdir()
raw=subprocess.check_output(['git','archive','dcf39f6b43effaa2b483211c97d7d3a3e7c0269b'],cwd=NATIVE)
with tarfile.open(fileobj=io.BytesIO(raw)) as t:t.extractall(native,filter='data')
canonical=files(native);source_map=json.loads((SOURCE2/'source-map.json').read_text())
for row in source_map:
 if row['scope']=='native':src=NATIVE/row['path'];dest=native/row['path']
 elif row['path'].startswith('scripts/benchmarks/attention-replay/'):
  src=ROOT/row['path'];dest=workspace/row['path']
 else:continue
 assert sha(src)==row['sha256'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
mlx=Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift');(libs/'mlx-swift').symlink_to(mlx,target_is_directory=True)
p=native/'Package.swift';before=p.read_text();old='.package(url: "https://github.com/Layr-Labs/mlx-swift.git", branch: "main")';assert before.count(old)==1;after=before.replace(old,'.package(path: "'+str(mlx)+'")');p.write_text(after)
(OUT/'native-package-location-overlay.patch').write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='source/Package.swift',tofile='prepared/Package.swift')))
harness=workspace/'scripts/benchmarks/attention-replay'
for p in [native/'Package.resolved',harness/'Package.resolved']:shutil.copy2(PRIOR/'native/Package.resolved',p)
for name in ['dependency-source-manifest.json','jinja-source-manifest.json']:shutil.copy2(PRIOR/name,OUT/name)
shutil.copy2(PRIOR/'test_selection.py',OUT/'test_selection.py')
write('native-source-manifest.json',{'canonical':canonical,'files':files(native)})
write('harness-source-manifest.json',{'files':files(harness)})
write('source-map.json',source_map)
write('integration.json',{'workspace':str(workspace.resolve()),'native':str(native.resolve()),'harness':str(harness.resolve()),'scratch':'/tmp/darkbloom-process-memory-telemetry-swift-validation1/build','base_native':'dcf39f6b43effaa2b483211c97d7d3a3e7c0269b','source1_manifest_sha256':sha(SOURCE1/'manifest.json'),'source2_manifest_sha256':sha(SOURCE2/'manifest.json'),'metallib':'/tmp/darkbloom-final-serving-build8/artifact/mlx.metallib','metallib_sha256':'4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0','expected_functions':8,'expected_expanded_cases':29,'policy':'Standalone synthetic host/operator tests only; no model/key/signing/remote operations; jobs4 pinned dependencies, exact canonical IDs, stop on unexpected failure'})
shutil.copy2(Path(__file__),OUT/'prepare.py')
print(json.dumps({'prepared':str(OUT),'native_files':len(files(native)),'harness_files':len(files(harness))},indent=2))
