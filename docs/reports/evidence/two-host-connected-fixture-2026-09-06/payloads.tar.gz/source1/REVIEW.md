# Two-host connected fixture: source milestone 1

Base parent: `bd8dee80297f0d806b8f5c11bd204460536ca6f6`. Isolated worktree: `/Users/gaj/Documents/DarkbloomDev/wt/two-host-connected-fixture`.
No commit has been made. The native gitlink and all serving source are unchanged.

## Result and validation

The existing connected cache fixture can explicitly assign two providers to
independent hosts through the existing loopback relay. Local and owned-host
launchers share a pure launch description. The remote adapter carries typed
metadata over a single owned SSH connection with a loopback reverse tunnel;
authentication stays in private stdin/files. Account mapping fixes donor/holder
identity across registration order and reconnect. The first explicit-host scope
retains only the ordinary donor, repeat, tenant, continuation and original cases.

Actual CPU validation passed: 29 Go functions / 54 functions-plus-subtests across
two packages with the race detector, and 17 Python functions. There were no skips
or failures in the final selected Go run. The final Python log records all 17
functions passing. Source hashes were checked before and after validation. The
helper tests run harmless local Python children and inject filesystem/host calls;
Go tests inject SSH execution. No real provider, model, Swift/GPU, remote, key,
signing or production operations were performed.

## Review findings addressed

- Cleanup runs unconditionally before deferred assertions; failed start joins
  provider and suite cleanup failures rather than discarding them.
- Missing startup state is a typed retryable response. State and telemetry
  responses use monotonic request IDs; cancelled or late replies cannot become
  a newer request's evidence.
- Assistant paths must select explicitly manifested assistant bytes. Runtime,
  target and assistant hash/size substitutions are rejected before input IO.
- Standard HF snapshot links are permitted only within the selected snapshot or
  its own model blob store; runtime symlinks remain refused. Current exact-ID
  discovery must resolve to the selected snapshot; no alias or model repair.
- Stop/EOF/HUP/TERM/INT/lease/deadline cleanup retires the owned process group even
  after its direct leader exits. A real local leader-spawns-sleeper regression
  proves the retained descendant is gone. Terminal receipts survive cleanup
  exceptions and explicitly mark unconfirmed group cleanup.
- Initial testing of the group correction exposed Darwin returning EPERM from
  killpg(0) for an unreaped zombie. The exact initial traceback is preserved in
  `initial-darwin-zombie-failure.stderr`. The corrected helper reaps the direct
  child before probing and treats EPERM as present, never as absent. No old
  failure is relabeled as a pass.
- Entry cooling/load/storage gates remain required before every next measured
  request. Post-work cleanup checks process retirement and retains heat as an
  observation, avoiding the old false failure from a hot successful run.

The refactor pass moved local launch code out of suite.go and separated owned
startup transport, correlated control, host binding, pure launch spec and target
validation. `e2e/testbed/OWNED_HOSTS.md` describes the actual typed inputs,
source layout, lifecycle and unrun limitations.

## Remaining work and boundaries

Root source review/integration is next. Actual two-host model routing has not
run. It needs a reviewed inventory on both hosts, exact runtime/model/resource
manifests and fresh owned roots. Existing unentitled test-only trust and
Ephemeral SSD behavior are retained; this does not prove persistent restart or
attestation. Normal nil targets retain the existing local launcher. TTL,
eviction/capacity, reconnect workload, tools/vision/cancellation extensions are
not claimed by this bounded first two-host scope. Production routing/listeners,
model gates, memory guards, telemetry and default key state are not changed.
