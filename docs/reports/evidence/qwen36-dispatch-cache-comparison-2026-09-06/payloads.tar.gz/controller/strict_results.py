"""Whole-trajectory correctness for matched paged runtimes; timing is descriptive."""
import hashlib,json,math
FIELDS=['prompt_token_ids','token_ids','prompt_tokens','completion_tokens','finish','outcome']

def trajectories(report):
    result=[]
    for group in ['rows','tenant_checks','cancel_donor','recovered']:
        values=report[group] if isinstance(report[group],list) else [report[group]]
        result.extend((group+':'+str(i),{k:r[k]for k in FIELDS})for i,r in enumerate(values))
    if len(result)!=7:raise ValueError('seven completed trajectories required')
    return result

def matched_errors(left,right):
    a,b=trajectories(left),trajectories(right)
    return [x[0]+' matched complete trajectory changed' for x,y in zip(a,b) if x!=y]

def chunk_timing(row,prefix_count=62):
    chunks=row['chunks'];tokens=row['token_ids']
    assert chunks and all(c['tokens']for c in chunks)
    assert [t for c in chunks for t in c['tokens']]==tokens
    times=[c['elapsed_s']for c in chunks]
    assert all(isinstance(t,(int,float))and math.isfinite(t)and t>=0 for t in times)
    assert times==sorted(times)
    first=times[0];last=times[-1];nfirst=len(chunks[0]['tokens'])
    target=min(prefix_count,len(tokens));seen=0;selected=None
    for c in chunks:
        before=seen;seen+=len(c['tokens'])
        if selected is None and seen>=target:
            selected={'requested_tokens':target,'delivered_tokens_at_chunk':seen,'straddled':before<target<seen,'elapsed_s':c['elapsed_s'],'since_first_delivery_s':c['elapsed_s']-first}
    return {'tokens':len(tokens),'chunks':len(chunks),'first_chunk_tokens':nfirst,'first_delivery_s':first,'last_delivery_s':last,'after_first_chunk_tokens':len(tokens)-nfirst,'delivery_interval_s':last-first,'delivered_tokens_per_s':(len(tokens)-nfirst)/(last-first)if last>first else None,'prefix':selected,'native_ttft_s':row['ttft_s'],'native_elapsed_s':row['elapsed_s'],'native_decode_tps':row['decode_tps'],'terminal_tail_s':row['terminal_tail_s']}

def result_errors(local,cell,plan,binding,report,output_root):
    errors=[]
    def require(ok,message):
        if not ok:errors.append(message)
    try:
        meta=json.loads((local/'metadata.json').read_text())
        artifacts=binding['variants'][cell['variant']]['artifacts']
        expected=next(c for c in binding['commands']if c['cell']==cell['id'])
        require(meta['command']==expected['expected_observed_native_argv'],'native argv differs after explicit owned input-copy substitution')
        require(meta['source_input_sha256']==meta['input_sha256']==plan['input_sha256'] and hashlib.sha256((local/'input.json').read_bytes()).hexdigest()==plan['input_sha256'],'input bytes changed')
        require(meta['binary_sha256']==artifacts['radix-engine']['sha256'] and meta['exit_code']==0 and meta['status']=='completed','bound native runtime did not complete successfully')
        require(report['runtime_identity']['binary_sha256']==artifacts['radix-engine']['sha256'] and report['runtime_identity']['metallib_sha256']==artifacts['mlx.metallib']['sha256'],'native report runtime differs from bound artifacts')
        require(report['requested_backend']==report['resolved_backend']=='paged' and report['backend_fallback']is None,'backend/fallback mismatch')
        require(report['cache_requested']is False and report['max_concurrent_requests']==1 and report['cache_mode_requested']=='ssd' and report['key_mode_requested']=='ephemeral' and report['kv_grant_mode']=='production_single_slot' and report['mtp']=={'on':'on; production configured assistant','off':'off; no drafter supplied'}[cell['mtp']],'serving mode mismatch')
        require(report['expected_model_sha256']==report['verified_model_hash']==binding['model_sha256'] and report['input_sha256']==plan['input_sha256'],'model/input identity mismatch')
        require(len(report['rows'])==2 and all(r['prompt_tokens']==5523 and r['cache_outcome']=='disabled' and r['prompt_render_date']=='2026-09-06'for r in report['rows']),'main prompt/cache/date mismatch')
        require(report['cancelled']['token_ids']==report['recovered']['token_ids'][:len(report['cancelled']['token_ids'])],'canceled output is not its own recovery prefix')
        require(all(report.get(k)is None for k in ['attention_metadata','logit_diagnostic','attention_packet']),'uninstrumented control emitted diagnostics')
        trajectories(report)
        for r in report['rows']:chunk_timing(r)
        if cell['mtp']=='off':
            require(all(r['token_ids']==plan['historical_mtp_off_token_ids'] for r in report['rows']),'MTP-off historical main trajectory changed')
        prior=[c for c in plan['cells'][:plan['cells'].index(cell)] if c['mtp']==cell['mtp']]
        for other in prior:
            old=json.loads((output_root/other['id']/'report.json').read_text())
            errors.extend(other['id']+': '+e for e in matched_errors(old,report))
    except (OSError,ValueError,KeyError,TypeError,IndexError,AttributeError,AssertionError):
        errors.append('malformed or incomplete strict evidence')
    return errors
