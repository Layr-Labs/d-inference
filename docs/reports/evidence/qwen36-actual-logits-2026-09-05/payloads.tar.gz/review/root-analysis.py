from pathlib import Path
import hashlib
import json
import struct
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, '/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated/scripts/benchmarks')
from radix_engine_evidence import report_errors
from compare_radix_engine import compare, mismatch

root = Path('/tmp/darkbloom-q36-actual-logits-execution1')
reports, digests = {}, {}
for backend in ['contiguous', 'paged']:
    for trace in ['off', 'on']:
        key = backend + '-' + trace
        directory = root / ('qwen36-' + backend + '-cache-off-mtp-off-trace-' + trace)
        manifest = json.loads((directory / 'manifest.json').read_text())
        for name, spec in manifest['files'].items():
            raw = (directory / name).read_bytes()
            assert hashlib.sha256(raw).hexdigest() == spec['sha256'], name
        report = json.loads((directory / 'report.json').read_text())
        assert not report_errors(report), key
        reports[key] = report
        digests[key] = hashlib.sha256((directory / 'manifest.json').read_bytes()).hexdigest()

trace_checks = {}
for backend in ['contiguous', 'paged']:
    before, after = reports[backend + '-off'], reports[backend + '-on']
    # The existing cache comparator requires off->on cache mode; trace impact
    # is a different comparison. Reuse its exact output mismatch primitive
    # after checking each report's unchanged integrity oracle and configuration.
    for key in ['model', 'mtp', 'kv_budget_bytes', 'schema', 'verified_model_hash',
                'input_sha256', 'runtime_identity', 'kv_grant_mode', 'production_grant',
                'cancellation_probe_version', 'cache_requested', 'cache_mode_requested',
                'key_mode_requested', 'requested_backend', 'resolved_backend',
                'backend_fallback', 'max_concurrent_requests']:
        assert before.get(key) == after.get(key), (backend, key)
    assert before['metrics_loaded'].get('assistant_identity') == after['metrics_loaded'].get('assistant_identity')
    for key in ['rows', 'tenant_checks']:
        assert len(before[key]) == len(after[key])
        for old, new in zip(before[key], after[key]):
            assert not mismatch(old, new), (backend, key)
            assert old.get('prompt_render_date') == new.get('prompt_render_date')
    for key in ['cancel_donor', 'recovered']:
        assert not mismatch(before[key], after[key]), (backend, key)
    assert [row['id'] for row in before['rows']] == [row['id'] for row in after['rows']]
    assert 'logit_diagnostic' not in before
    trace_checks[backend] = {'passed': True, 'scope': 'Identical configuration, main/tenant/donor/recovery outputs; each cancellation independently satisfies its strict prefix and retirement checks.'}
    for trace in ['off', 'on']:
        old = json.loads((Path('/tmp/darkbloom-q36-backend-mtp-off-diagnostic1') / backend / 'report.json').read_text())
        for previous, current in zip(old['rows'], reports[backend + '-' + trace]['rows']):
            assert not mismatch(previous, current)

records = {}
for backend in ['contiguous', 'paged']:
    report = reports[backend + '-on']
    diagnostic = report['logit_diagnostic']
    snapshot = diagnostic['snapshot']
    assert diagnostic['status'] == 'captured'
    assert snapshot['omittedRecords'] == snapshot['invalidVocabularyRecords'] == 0
    assert snapshot['configuration'] == {'candidateIDs': [1928, 6829], 'maximumRecords': 8, 'outputIndex': 62, 'requestID': 2}
    assert len(snapshot['records']) == 1
    record = snapshot['records'][0]
    assert record['outcome'] == 'confirmed' and record['requestID'] == 2 and record['outputIndex'] == 62
    assert record['nanCount'] == record['infiniteCount'] == 0
    values = [struct.unpack('<f', struct.pack('<I', value))[0] for value in record['valueBits']]
    assert len(values) == 5 and record['candidateIDs'] == [1928, 6829]
    row = report['rows'][0]
    assert record['targetToken'] == row['token_ids'][62] == record['argMaxID'] == record['topTwoIDs'][0]
    records[backend] = {'record': record, 'decoded_values': values,
                        'candidate_margin_1928_minus_6829': values[3] - values[4]}

left, right = reports['contiguous-on']['rows'][0], reports['paged-on']['rows'][0]
assert left['prompt_token_ids'] == right['prompt_token_ids']
assert left['token_ids'][:62] == right['token_ids'][:62]
for key in ['cacheOffset', 'seedToken', 'phase', 'batchSize', 'column', 'verificationWidth',
            'draftDepth', 'outputBase', 'logitDType', 'vocabularySize']:
    assert records['contiguous']['record'][key] == records['paged']['record'][key], key
backend_comparison = compare(reports['contiguous-off'], reports['paged-off'], axis='backend')
assert not backend_comparison['passed']
review = {
    'scope': 'Actual Q36 MTP-off first-divergence observations; no correctness waiver or performance claim',
    'verified_cell_manifests': digests,
    'same_build_trace_comparisons': trace_checks,
    'backend_comparison': backend_comparison,
    'both_backends_match_historical_all_main_rows': True,
    'prompt_and_62_preceding_generated_ids_match': True,
    'records': records,
    'limits': [
        'Actual logit dtype is measured; actual Q dtype is not.',
        'Same token history does not imply identical hidden states or cached KV.',
        'Compact candidate logits locate the decision change; they do not prove its numerical cause or which backend is more accurate.',
    ],
}
Path('/tmp/darkbloom-q36-actual-logits-root-analysis1.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps({'records': records, 'same_build_trace': trace_checks, 'common_prefix': 62}, indent=2))
