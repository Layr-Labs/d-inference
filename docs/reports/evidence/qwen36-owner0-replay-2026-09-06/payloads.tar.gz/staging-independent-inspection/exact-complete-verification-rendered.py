import json
C=json.loads('{"remote_root": "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1", "binding_sha256": "a04631ec25459596b98561910463c88e334ed0e059714def34f54cfca57ee4c8"}')
from pathlib import Path
import hashlib,json,stat
root=Path(C['remote_root']);assert root.resolve()==root and not root.is_symlink()
def check(path,row):
 status=path.lstat();assert stat.S_ISREG(status.st_mode) and not path.is_symlink(),str(path)
 assert status.st_size==row['bytes'] and stat.S_IMODE(status.st_mode)==int(row['mode'],8),str(path)
 digest=hashlib.sha256()
 with path.open('rb') as file:
  for chunk in iter(lambda:file.read(1<<20),b''):digest.update(chunk)
 assert digest.hexdigest()==row['sha256'],str(path)
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()==C['binding_sha256']
binding=json.loads((root/'runtime-binding.json').read_text())
assert binding['remote_root']==str(root)
assert hashlib.sha256((root/'plan/manifest.json').read_bytes()).hexdigest()==binding['plan_manifest_sha256']
for name,row in json.loads((root/'plan/manifest.json').read_text())['files'].items():check(root/'plan'/name,row)
for name,row in binding['artifacts'].items():check(root/'runtime'/name,row)
assert {str(p.relative_to(root/'runtime'))for p in (root/'runtime').rglob('*')if p.is_file()}==set(binding['artifacts'])
mapping=json.loads((root/'plan/native-buffer-map.json').read_text())
for row in mapping.values():check(root/'transfer'/row['destination_file'],{k:row[k]for k in ('sha256','bytes','mode')})
assert {p.name for p in (root/'transfer').iterdir()}=={'input.json'}|{row['destination_file']for row in mapping.values()}
assert hashlib.sha256((root/'transfer/input.json').read_bytes()).hexdigest()==binding['input_sha256']

print(json.dumps({"verified":True,"artifacts":len(binding["artifacts"]),"input_sha256":binding["input_sha256"]}))
