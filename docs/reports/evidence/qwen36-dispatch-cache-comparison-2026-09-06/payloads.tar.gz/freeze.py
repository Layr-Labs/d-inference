from pathlib import Path
import hashlib,json,shutil,tarfile
ROOT=Path(__file__).resolve().parent
PAYLOAD=ROOT/'payload'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def copy(source,name):
 assert source.is_file() and not source.is_symlink(),str(source)
 target=PAYLOAD/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
def group(source,name,manifest_name='manifest.json'):
 manifest=json.loads((source/manifest_name).read_text())
 for relative,row in manifest['files'].items():
  path=source/relative;assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes'],relative
  if 'mode'in row:assert oct(path.stat().st_mode&0o777)==row['mode']
  copy(path,name+'/'+relative)
 copy(source/manifest_name,name+'/'+manifest_name)
def main():
 plan=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-plan1');execution=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-execution1')
 cells=json.loads((plan/'plan.json').read_text())['cells']
 for c in cells:
  s=json.loads((execution/c['id']/'summary.json').read_text());assert s['exit_code']==0 and s['report_integrity_passed']
 PAYLOAD.mkdir()
 group(plan,'plan');group(execution,'controller','preparation-manifest.json')
 for c in cells:group(execution/c['id'],'raw/'+c['id'])
 for suffix,label in [('staging1','staging'),('transfer1','transfer'),('sequence1','original-sequence'),('sequence2','resumed-sequence'),('analysis1','analysis')]:
  source=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-'+suffix)
  for p in sorted(source.iterdir()):
   if p.is_file() and p.name!='plan-package.tar.gz':copy(p,label+'/'+p.name)
 group(Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-readiness-recovery1'),'entry-readiness-recovery')
 for n in ['darkbloom-q36-paged-plan-cache-comparison-binding1.json','darkbloom-q36-paged-plan-cache-comparison-remote-helper-tests1.log','darkbloom-q36-paged-plan-cache-comparison-remote-helper-tests2.log','darkbloom-q36-paged-plan-cache-comparison-final-postflight1.json','darkbloom-segment-dispatch-cache-root-release-final-review1.json','darkbloom-generic-qat-release-probe-root-final-review1.json','darkbloom-q36-paged-plan-cache-comparison-peer-review1.json']:
  copy(Path('/tmp')/n,'reviews/'+n)
 build=Path('/tmp/darkbloom-segment-dispatch-cache-release-probe2')
 for n in ['manifest.json','artifact-manifest.json','source-union.json','integration.json','cache-source-manifest.json','cache-source-proof.json','cache-validation-manifest.json','cache-validation-verdict.json','final-committed-correspondence.json','delta-from-generic-probe.json','native-source-manifest.json','provider-source-manifest.json','harness-source-manifest.json','runner-source-manifest.json','dependency-source-manifest.json','jinja-source-manifest.json','radix-engine-actual-release.yaml.gz','radix-engine-all-owned-graph-source-proof.json','radix-engine-runtime-resource-proof.json','final-resource-mode-proof.json','verdict.json','smoke-verdict.json','execution.json']:
  copy(build/n,'candidate-build/'+n)
 delta=json.loads((build/'delta-from-generic-probe.json').read_text())
 for n in delta['groups']['native']:
  p=build/'native'/n;assert sha(p)==delta['groups']['native'][n]['after_sha256'];copy(p,'candidate-source/'+n)
 for n in ['manifest.json','artifact-manifest.json','source-union.json']:
  copy(Path('/tmp/darkbloom-generic-qat-release-probe1')/n,'previous-banked-baseline/'+n)
 copy(Path(__file__),'freeze.py')
 files={str(p.relative_to(PAYLOAD)):{'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)}for p in sorted(PAYLOAD.rglob('*'))if p.is_file()}
 assert not any('__pycache__'in n for n in files)
 (ROOT/'manifest.json').write_text(json.dumps({'scope':'Twelve matched Q36 paged runtime cells and complete original evidence. Numerical correctness and descriptive timing separate; no binaries/resources/weights/keys.','files':files},indent=2)+'\n')
 with tarfile.open(ROOT/'payloads.tar.gz','x:gz')as tar:
  for n in sorted(files):tar.add(PAYLOAD/n,arcname=n,recursive=False)
 result={'payloads':len(files),'manifest_sha256':sha(ROOT/'manifest.json'),'archive_sha256':sha(ROOT/'payloads.tar.gz'),'archive_bytes':(ROOT/'payloads.tar.gz').stat().st_size}
 (ROOT/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
