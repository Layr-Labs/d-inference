from pathlib import Path
import ast, hashlib, json, shutil, subprocess, sys

OUT = Path(__file__).resolve().parent
PRIMARY = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
PRIOR = Path('/tmp/darkbloom-q36-attention-metadata-plan1')
BUILD = Path('/tmp/darkbloom-attention-packet-release-build1')
COMMIT = '98103b39741a48f9d47026be7393362318a2ab0a'
REMOTE = '/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1'
DAY = '2026-09-06'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value): (OUT/name).write_text(json.dumps(value, indent=2)+'\n')
def copy(source, name):
    destination = OUT/name; destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, destination)

prior_manifest = json.loads((PRIOR/'manifest.json').read_text())
for name, row in prior_manifest['files'].items():
    assert sha(PRIOR/name) == row['sha256'], name
for name in ['inputs/qwen36.json', 'model-manifest.json', 'manifest.json']:
    copy(PRIOR/name, name if name != 'manifest.json' else 'prior-metadata-plan-manifest.json')
assert sha(OUT/'inputs/qwen36.json') == '4fb1ebf2b8a4b9b29be3388da3613398c8c7b6f768ca8bac11636a8928dd570e'
inputs = json.loads((OUT/'inputs/qwen36.json').read_text())
assert len(inputs['rows']) == 2
assert all(row['request']['_darkbloom_prompt_date'] == DAY and row['request']['max_tokens'] == 128 for row in inputs['rows'])
for name in ['cpu-prompt-plan.json', 'cpu-responses/qwen36-current.json', 'cpu-responses/qwen36-predecessor.json']:
    copy(PRIOR/'date-proof'/name, 'date-proof/'+name)
source_rows = {}
paths = ['scripts/benchmarks/'+name for name in ['run_radix_engine.py', 'run_radix_http.py',
         'radix_engine_evidence.py', 'compare_radix_engine.py', 'test_run_radix_engine.py']]
paths += subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', COMMIT,
                                 'scripts/benchmarks/attention_packet'], cwd=PRIMARY, text=True).splitlines()
for name in paths:
    data = subprocess.check_output(['git', 'show', COMMIT+':'+name], cwd=PRIMARY)
    destination = OUT/'runner'/name.removeprefix('scripts/benchmarks/')
    destination.parent.mkdir(parents=True, exist_ok=True); destination.write_bytes(data)
    if destination.suffix == '.py': ast.parse(data, filename=name)
    source_rows[str(destination.relative_to(OUT))] = {'commit': COMMIT, 'git_path': name,
        'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
write('runner-source-correspondence.json', source_rows)
sys.dont_write_bytecode = True; sys.path.insert(0, str(OUT/'runner'))
import run_radix_engine as wrapper
wrapper.pin_prompt_date(OUT/'inputs/qwen36.json', OUT/'expected-wrapper-input.json', DAY)
assert json.loads((OUT/'expected-wrapper-input.json').read_text()) == inputs
prior = json.loads((PRIOR/'plan.json').read_text())
flags = ['--logit-diagnostic-position', '62', '--logit-diagnostic-candidates', '1928,6829',
         '--attention-metadata-position', '62', '--attention-packet-position', '62', '--attention-packet-layer', '0']
cells = []
for backend, capture in [('contiguous', False), ('paged', False), ('contiguous', True), ('paged', True)]:
    original = next(c for c in prior['cells'] if c['backend'] == backend and not c['trace'])
    name = 'qwen36-'+backend+'-'+('owner0-packet' if capture else 'control')
    argv = original['argv'].copy()
    i = next(i for i, arg in enumerate(argv) if arg.endswith('/run_radix_engine.py'))
    argv[i] = REMOTE+'/runner/run_radix_engine.py'
    for flag, value in [('--binary', REMOTE+'/runtime/radix-engine'), ('--input', REMOTE+'/inputs/qwen36.json'),
                        ('--output', REMOTE+'/runs/'+name), ('--prompt-date', DAY)]:
        argv[argv.index(flag)+1] = value
    if capture: argv += flags
    args = wrapper.arguments(argv[i+1:])
    assert args.attention_packet_position == (62 if capture else None)
    assert args.attention_packet_layer == (0 if capture else None)
    assert args.attention_metadata_position == (62 if capture else None)
    assert args.cache == args.mtp == 'off' and args.concurrency == 1 and args.production_kv_grant
    # The wrapper replaces --input with its date-pinned input before building native argv.
    args.input = REMOTE+'/runs/'+name+'/input.json'
    native = wrapper.probe_command(args, Path(args.output)/'report.json')
    cells.append({'id': name, 'backend': backend, 'capture': capture, 'argv': argv, 'native_argv_after_date_pin': native,
                  'packet_relative_path': 'report.attention-packet/packet.json' if capture else None})
for backend in ['contiguous', 'paged']:
    control, capture = [c for c in cells if c['backend'] == backend]
    left, right = control['argv'].copy(), capture['argv'][:-len(flags)]
    left[left.index('--output')+1] = right[right.index('--output')+1] = 'OUTPUT'
    assert left == right
# Preserve pinned source evidence for the hypothesis, not a rewritten/emulated kernel.
mlx = Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift/Source/Cmlx/mlx')
native = BUILD/'native'
hypothesis = {}
for name, path in [
    ('mlx-host-sdpa.cpp', mlx/'mlx/backend/metal/scaled_dot_product_attention.cpp'),
    ('mlx-sdpa-vector.h', mlx/'mlx/backend/metal/kernels/sdpa_vector.h'),
    ('pagedattention.metal', native/'Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/pagedattention.metal'),
]:
    copy(path, 'hypothesis-source/'+name)
    hypothesis[name] = {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}
write('hypothesis-source-identities.json', hypothesis)
copy(BUILD/'preparation-manifest.json', 'proposed-runtime-build-preparation-manifest.json')
model = prior['model_sha256']
write('plan.json', {
    'schema': 1, 'state': 'DRAFT_SOURCE_AND_ARGV_CHECKED_RUNTIME_UNBOUND',
    'scope': 'Four actual Q36 diagnostic cells only; strict trajectory, packet identity and descriptive numerical analysis. Not a release or speed gate.',
    'parent_commit': COMMIT, 'native_commit': 'dcf39f6b43effaa2b483211c97d7d3a3e7c0269b',
    'remote_root': REMOTE, 'prompt_date_utc': DAY, 'runtime_binding': None,
    'proposed_build_preparation_sha256': sha(BUILD/'preparation-manifest.json'),
    'source_input_sha256': sha(OUT/'inputs/qwen36.json'),
    'actual_wrapper_input_sha256': sha(OUT/'expected-wrapper-input.json'),
    'actual_wrapper_input_bytes': (OUT/'expected-wrapper-input.json').stat().st_size,
    'model_sha256': model,
    'selection': {'requestID': 2, 'outputIndex': 62, 'storageLayerIndex': 0, 'modelLayerIndex': 3,
                  'expectedPromptTokens': 5523, 'expectedGeneratedTokens': 83, 'expectedSeedToken': 11346,
                  'offsetBefore': 5584, 'offsetAfter': 5585, 'QShape': [1,16,1,256],
                  'incomingKVShape': [1,2,1,256], 'storedKVShape': [1,2,5585,256],
                  'scaleBits': 1031798784, 'dtype': 'Observe original runtime dtype; never coerce queries.',
                  'priorTargetsForContextOnly': {'contiguous': 1928, 'paged': 6829}},
    'cells': cells,
    'byte_budget': {'maximumTensorPayloadBytes': 33554432, 'maximumJSONBytes': 262144,
                   'conservativeFP32ReservationBytes': 4*(2*16*256+2*2*256+2*2*5585*256),
                   'ifAllBF16ActualPayloadBytes': 2*(2*16*256+2*2*256+2*2*5585*256)},
    'guards': {'plan_and_runtime_root_review_required': True, 'sole_M5_owner': 'actual_logit_milestone',
               'build_and_argument_smokes_must_pass': True, 'all_controls_before_capture': True,
               'same_build_per_backend_control_before_capture': True,
               'gpu_entry_max_c': 42, 'load1_max': 4, 'minimum_free_bytes': 100*1024**3,
               'fresh_roots_only': True, 'retain_failures_and_partial_packets': True,
               'maximum_cells': 4, 'date_rollover': 'Refuse after UTC2026-09-06; fresh input successor with explicit date delta and new control trajectories.',
               'no_key_daemon_alias_default_or_production_mutation': True},
    'required_evidence': 'PROPOSAL.md',
    'CPU_validation': {'argv_parsed': 4, 'only_diagnostic_flags_and_output_paths_differ_within_backend': True,
                       'wrapper_input_bytes_precomputed': True, 'models_run': False, 'Swift_started': False},
})
print(json.dumps({'cells':len(cells),'actual_input_sha256':sha(OUT/'expected-wrapper-input.json'),
                  'byte_budget':json.loads((OUT/'plan.json').read_text())['byte_budget'],'runtime_bound':False},indent=2))
