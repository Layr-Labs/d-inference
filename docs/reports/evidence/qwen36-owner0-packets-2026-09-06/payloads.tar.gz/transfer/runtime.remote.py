import json
C=json.loads('{"remote": "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1", "archive_sha": "f9824eba3447507da1670a7ca9c8c4243b14f25dbb789cbdb4fe8bd19cc4ac16", "manifest_sha": "21467d42b7e710d8303cb2690f79edb16d793241b919fa303d6acea888660fce", "review_sha": "bcef01db59932780e017de10bc6e3ed132f1a80fe6dbc6fd89659ef50cfce4cd", "binding_sha": "48cea7e3daa6fb0676ccc069891eb93170885d7ae85dc6540a155d4454df2cdc", "resources_copy_source": "/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact"}')
from pathlib import Path
import hashlib,json,os,shutil,stat
root=Path(C['remote']);binding_path=root/'runtime-binding.json'
assert hashlib.sha256(binding_path.read_bytes()).hexdigest()==C['binding_sha']
binding=json.loads(binding_path.read_text());target=root/'runtime';source=Path(C['resources_copy_source'])
def verify(p,item):
 info=p.lstat();assert stat.S_ISREG(info.st_mode) and not p.is_symlink()
 assert info.st_size==item['bytes'] and stat.S_IMODE(info.st_mode)==int(item['mode'],8),str(p)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],str(p)
assert {p.name for p in target.iterdir()}=={'radix-engine'}
verify(target/'radix-engine',binding['artifacts']['radix-engine'])
for name,item in binding['artifacts'].items():
 if name!='radix-engine':verify(source/name,item)
for name,item in binding['artifacts'].items():
 if name!='radix-engine':
  destination=target/name;destination.parent.mkdir(parents=True,exist_ok=True)
  assert not destination.exists();shutil.copy2(source/name,destination)
for name,item in binding['artifacts'].items():verify(target/name,item)
assert {str(p.relative_to(target)) for p in target.rglob('*') if p.is_file()}==set(binding['artifacts'])
assert os.access(target/'radix-engine',os.X_OK)
result={'status':'RUNTIME_VERIFIED','binding_sha256':C['binding_sha'],'files':binding['artifacts'],'runtime_root':str(target),'inference_launched':False}
(root/'runtime-transfer-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
