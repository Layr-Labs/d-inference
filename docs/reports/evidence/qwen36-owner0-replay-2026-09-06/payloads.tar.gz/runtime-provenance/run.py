"""Root-authorized build+parse smokes; launch only after explicit Swift handoff."""
import json,os,subprocess,sys,time
from build_proof import OUT,INFO,SCRATCH,HARNESS,sha,write,verify,save_graph,graph_proof,artifact
import smoke
assert sys.argv[1:]==['--execute-after-lane-handoff']
assert not (OUT/'execution.json').exists() and not (OUT/'artifact').exists(),'fresh build only'
write('source-verified-before.json',verify());env=os.environ.copy();env.update(INFO['environment'])
write('compile-environment.json',{k:v for k,v in env.items() if k in ['DEVELOPER_DIR','SDKROOT','SWIFT_EXEC','SWIFT_FLAGS','MACOSX_DEPLOYMENT_TARGET','ATTENTION_REPLAY_SOURCE_ROOT'] or k.startswith(('DARKBLOOM_CBV2_','MLX_'))})
(OUT/'toolchain.txt').write_text(subprocess.check_output(['swift','--version'],text=True))
(OUT/'hardware.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize'],text=True)+subprocess.check_output(['sw_vers'],text=True))
command=['swift','build','-c','release','--scratch-path',str(SCRATCH),'--jobs','4','--disable-automatic-resolution','--product','attention-replay']
save_graph('before');start=time.monotonic();write('live-run.json',{'state':'RUNNING','argv':command,'cwd':str(HARNESS)})
print(json.dumps({'state':'STARTING','argv':command}),flush=True)
try:
 with (OUT/'release.log').open('x') as log:r=subprocess.run(command,cwd=HARNESS,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'argv':command,'cwd':str(HARNESS),'exit_code':r.returncode,'seconds':time.monotonic()-start,'log_sha256':sha(OUT/'release.log')};write('execution.json',[row]);write('live-run.json',{'state':'TERMINAL',**row});print(json.dumps(row),flush=True)
 save_graph('actual');write('source-verified-postcompile.json',verify());assert r.returncode==0,'build failed; preserve attempt'
 graph_proof();binary=artifact();binary_hash=sha(binary)
 (OUT/'dylibs.txt').write_text(subprocess.check_output(['otool','-L',str(binary)],text=True))
 smoke.run(binary);assert sha(binary)==binary_hash
 write('verdict.json',{'status':'PASS','smokes':6,'scope':'Optimized standalone build and host refusal smokes only; no real packet/model/operator run'})
except BaseException as error:
 write('verdict.json',{'status':'FAIL','error':str(error)});raise
finally:
 write('source-verified-final.json',verify());save_graph('final')
