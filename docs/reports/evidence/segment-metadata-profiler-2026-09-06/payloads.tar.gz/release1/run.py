from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time
O=Path(__file__).resolve().parent
I=json.loads((O/'integration.json').read_text());V=Path(I['validation']);N=Path(I['native_package']);S=Path(I['scratch'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,j):(O/n).write_text(json.dumps(j,indent=2)+'\n')
known={}
for name,d in json.loads((O/'native-source-manifest.json').read_text())['files'].items():known[str((N/name).resolve())]={'group':'native','sha256':d}
d=json.loads((O/'dependency-source-manifest.json').read_text())
for name,digest in d['files'].items():
 alias,relative=name.split('/',1);known[str((Path(d['repositories'][alias])/relative).resolve())]={'group':'dependency','sha256':digest}
for name,digest in json.loads((O/'jinja-source-manifest.json').read_text())['files'].items():known[str((S/'checkouts/swift-jinja'/name).resolve())]={'group':'jinja','sha256':digest}
def verify():
 for name,row in known.items():assert sha(Path(name))==row['sha256'],name
 assert sha(Path(I['source_manifest']))==I['source_sha256']
 for name,row in json.loads((O/'preparation-manifest.json').read_text())['files'].items():assert sha(O/name)==row['sha256'],name
 return {'no_drift':True,'counts':{g:sum(r['group']==g for r in known.values())for g in ['native','dependency','jinja']}}
def graph(label):
 for name in ['release.yaml','workspace-state.json']:
  p=S/name
  if p.exists():(O/(label+'-'+name+('.gz'if name.endswith('yaml')else''))).write_bytes(gzip.compress(p.read_bytes(),mtime=0)if name.endswith('yaml')else p.read_bytes())
assert not (O/'execution.json').exists()
assert json.loads((V/'run-status.json').read_text())=={'failed':[],'all_filters_run':True}
for row in json.loads((V/'execution.json').read_text()):assert row['exit_code']==0 and row['nonzero_no_skips']
dump('source-before.json',verify());graph('before')
dump('environment.json',{k:v for k,v in os.environ.items()if k.startswith(('DARKBLOOM_','MLX_')) or k in ['DEVELOPER_DIR','SDKROOT','SWIFT_EXEC','SWIFT_FLAGS']})
(O/'toolchain.txt').write_text(subprocess.check_output(['swift','--version'],text=True))
(O/'hardware.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize','machdep.cpu.brand_string'],text=True)+subprocess.check_output(['sw_vers'],text=True))
command=['swift','build','-c','release','--scratch-path',str(S),'--jobs','4','--disable-automatic-resolution','--product','BenchSegmentedDecode']
start=time.monotonic()
with (O/'build.log').open('x')as log:r=subprocess.run(command,cwd=N,stdout=log,stderr=subprocess.STDOUT)
dump('execution.json',{'command':command,'cwd':str(N),'exit_code':r.returncode,'seconds':time.monotonic()-start});graph('actual');dump('source-after.json',verify())
assert r.returncode==0,'Preserved failed build; no stale artifact accepted'
body=(S/'release.yaml').read_text();matched={};unknown=[]
for literal in sorted(set(re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',body))):
 resolved=str(Path(literal).resolve())
 if resolved in known:matched[literal]=known[resolved]
 elif resolved.startswith(str(N.resolve())+'/'):unknown.append(literal)
assert not unknown and '/checkouts/mlx-swift/Source/'not in body and '/Users/gaj/Documents/DarkbloomDev/wt/'not in body
for suffix in ['/PagedDecodeProfiler+SegmentMetadata.swift','/Sources/BenchSegmentedDecode/main.swift','/PagedSegmentDispatchCache.swift','/PagedSegmentAttention.swift','/PagedLayerCache.swift']:
 assert any(p.endswith(suffix)for p in matched),suffix
dump('graph-source-proof.json',{'files':matched,'counts':{g:sum(r['group']==g for r in matched.values())for g in ['native','dependency','jinja']},'unmapped_owned':unknown,'remote_mlx_source_excluded':True,'scope':'Declared source graph references; not every graph target is linked into this selected executable.'})
a=O/'artifact';a.mkdir();release=S/'arm64-apple-macosx/release';binary=release/'BenchSegmentedDecode'
assert binary.is_file()and not binary.is_symlink()and binary.stat().st_mode&0o777==0o755
shutil.copy2(binary,a/binary.name)
for name,row in json.loads((O/'runtime-resource-inputs.json').read_text()).items():
 p=(Path('/tmp/darkbloom-final-serving-build8/artifact')if name=='mlx.metallib'else release)/name
 assert sha(p)==row['sha256']and p.stat().st_size==row['bytes']and p.stat().st_mode&0o777==int(row['mode'],8),name
 target=a/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,target)
dump('artifact-manifest.json',{'files':{str(p.relative_to(a)):{'sha256':sha(p),'bytes':p.stat().st_size,'mode':oct(p.stat().st_mode&0o777)}for p in sorted(a.rglob('*'))if p.is_file()},'source_manifest_sha256':I['source_sha256']})
(O/'dylibs.txt').write_text(subprocess.check_output(['otool','-L',str(a/'BenchSegmentedDecode')],text=True))
print(json.dumps({'build':'PASS','artifact':str(a),'binary_sha256':sha(a/'BenchSegmentedDecode')}),flush=True)
