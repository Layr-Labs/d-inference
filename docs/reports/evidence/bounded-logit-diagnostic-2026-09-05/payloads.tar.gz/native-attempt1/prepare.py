from pathlib import Path
import hashlib,json,shutil

out=Path('/tmp/darkbloom-q36-logit-diagnostic-validation1')
old=Path('/tmp/darkbloom-q35-mtp-useful-tail-validation1')
source=Path('/tmp/darkbloom-q36-logit-diagnostic-source/freeze1')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
assert sha(source/'manifest.json')=='755021fd3edda68aab97908c27e7b775d61153776e59970c0e8cb3d81ba702ff'
assert sha(old/'manifest.json')=='073c7d90589ba2425b3b98d9960a0fc8daafd3915ee461ea2251e86473e389cd'
for base in [old,source]:
 for name,row in json.loads((base/'manifest.json').read_text())['files'].items():assert sha(base/name)==row['sha256'],name
manifest=json.loads((old/'native-source-manifest.json').read_text())
package=out/'native';assert not package.exists();package.mkdir()
for name,digest in manifest['files'].items():
 assert sha(old/'native'/name)==digest,name
 target=package/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/'native'/name,target)
proof=json.loads((source/'source-proof.json').read_text())['native']
for name,row in proof['files'].items():
 target=package/name
 if row['before_sha256'] is not None:assert sha(target)==row['before_sha256'],name
 else:assert not target.exists(),name
 shutil.copy2(source/'files/native'/name,target)
 manifest['files'][name]=row['after_sha256'];assert sha(target)==row['after_sha256']
manifest['base']='a932d38cee0beca41ca1a0e71c1e867913a65353'
manifest['count']=len(manifest['files']);manifest['candidate_changes']=proof['files']
write('native-source-manifest.json',manifest)
for name in ['dependency-source-manifest.json','jinja-source-manifest.json','run-nested-suite.sh']:
 shutil.copy2(old/name,out/name)
shutil.copy2(old/'native/Package.resolved',package/'Package.resolved')
write('integration.json',{'source_manifest':str(source/'manifest.json'),'source_manifest_sha256':sha(source/'manifest.json'),'baseline_manifest':str(old/'manifest.json'),'baseline_manifest_sha256':sha(old/'manifest.json'),'native':str(package),'native_inputs':len(manifest['files']),'package_resolved_sha256':sha(package/'Package.resolved'),'package_compile_overlay_sha256':sha(package/'Package.swift'),'scratch':'/tmp/darkbloom-allocator-footprint-foundation1/build-swift','dependencies':'Unchanged pinned1356 + Jinja27 from prior native validation','primary_mutated':False,'provider_receipt_fix_included':False})
write('filters.json',['CBv2LogitDiagnosticTests','CBv2OrdinaryLogitDiagnosticTests','Qwen35MTPTopTwoTests','CBv2QwenMTPIntegrationTests','CBv2MTPOutputBudgetTests','CBv2MTPDepthControllerTests','CBv2MTPProbeCadenceTests','CBv2MTPCaptureVerifyTests','CBv2MTPRoundSmokeTests','CBv2MTPEngineParityTests','CBv2MTPKVStagingTests','CBv2MTPRectangularDegradeTests'])
print('Prepared exact diagnostic source; native inputs='+str(len(manifest['files'])))
