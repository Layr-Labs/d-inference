from pathlib import Path
import json, os, shutil, subprocess, sys, time
from build_proof import OUT, WS, INFO, SCRATCH, sha, write, verify, save_graph, graph_proof, copy_artifacts

assert len(sys.argv) == 2, 'Requires root review JSON and separately delivered sole Swift lane authorization.'
review = Path(sys.argv[1]); json.loads(review.read_text())
assert not (OUT/'execution.json').exists() and not (OUT/'artifact').exists(), 'Fresh build only; preserve failed attempts.'
write('source-verified-before.json', verify())
shutil.copy2(review, OUT/'root-release-union-approval.json')
write('authorization-input.json', {'review_path': str(review), 'sha256': sha(review),
      'scope': 'Root-reviewed exact981/native dcf dual-product union; explicit parent message releases sole Swift lane.'})
env = os.environ.copy(); env.update(INFO['environment'])
write('compile-environment.json', {k: v for k, v in env.items() if k in [
    'DEVELOPER_DIR', 'SDKROOT', 'SWIFT_EXEC', 'SWIFT_FLAGS', 'MACOSX_DEPLOYMENT_TARGET',
    'RADIX_SOURCE_ROOT', 'RADIX_CANDIDATE_BUILD'] or k.startswith(('DARKBLOOM_MTP_', 'MLX_'))})
(OUT/'toolchain.txt').write_text(subprocess.check_output(['swift', '--version'], text=True))
(OUT/'hardware.txt').write_text(subprocess.check_output(['sysctl', 'hw.model', 'hw.memsize'], text=True)
                              + subprocess.check_output(['sw_vers'], text=True))
(OUT/'artifact').mkdir()
executions = []
for product, package in [('radix-engine', OUT/'radix-engine'), ('darkbloom', WS/'provider-swift')]:
    write(product+'-source-verified-before.json', verify()); save_graph(product+'-before')
    command = ['swift', 'build', '-c', 'release', '--scratch-path', str(SCRATCH),
               '--jobs', '4', '--disable-automatic-resolution', '--product', product]
    write('live-run.json', {'product': product, 'command': command, 'cwd': str(package), 'state': 'RUNNING'})
    print(json.dumps({'state': 'STARTING', 'product': product, 'command': command}), flush=True)
    started = time.monotonic()
    with (OUT/(product+'-release.log')).open('x') as log:
        result = subprocess.run(command, cwd=package, env=env, stdout=log, stderr=subprocess.STDOUT)
    row = {'product': product, 'command': command, 'cwd': str(package),
           'seconds': time.monotonic()-started, 'exit_code': result.returncode}
    executions.append(row); write('execution.json', executions); write('live-run.json', {**row, 'state': 'TERMINAL'})
    print(json.dumps(row), flush=True)
    save_graph(product+('-actual' if result.returncode == 0 else '-failed'))
    write(product+'-source-verified-after.json', verify())
    assert result.returncode == 0, 'Build failed; no stale artifact copied or accepted.'
    graph_proof(product); copy_artifacts(product)
    (OUT/(product+'-dylibs.txt')).write_text(subprocess.check_output(['otool', '-L', str(OUT/'artifact'/product)], text=True))
write('source-verified-final.json', verify())
files = {str(p.relative_to(OUT/'artifact')): {'sha256': sha(p), 'bytes': p.stat().st_size,
         'mode': oct(p.stat().st_mode & 0o777)} for p in sorted((OUT/'artifact').rglob('*')) if p.is_file()}
assert len(files) == 8
write('artifact-manifest.json', {'parent_commit': INFO['parent_commit'], 'native_commit': INFO['native_commit'],
      'files': files, 'probe_rebuilt': True, 'cli_rebuilt': True,
      'scope': 'Two new release executables from the same committed union; six runtime resources identical to build8. No model/HTTP/numerical/performance result.'})
print('BOTH RELEASE PRODUCTS BUILT', flush=True)
