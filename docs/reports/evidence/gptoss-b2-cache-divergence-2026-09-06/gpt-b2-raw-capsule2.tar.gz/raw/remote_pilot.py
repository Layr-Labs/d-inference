from pathlib import Path
import hashlib,json,os,signal,subprocess,sys,threading,time
import owner_helper
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'plan'));import matrix_cells as matrix
from radix_forward_shapes import validate_packet
BINDING_PATH=ROOT/'m5.runtime-binding2.json';EXPECTED_BINDING='5bf49b1da4ca9f6d86f247806c41b08d131a77e77db0aa47466bcf7bed8d370d'
ACK_SHA='d5c2ca94ad8bd7dd401185944dcb76bcd2ec33dfff044eb13b977bde1ba329f4'
ENV={'HOME':str(Path.home()),'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','TMPDIR':'/private/tmp','PYTHONDONTWRITEBYTECODE':'1'}
EXECUTIONS=[];OUTPUT_LOCK=threading.Lock();ACTIVE_CELL=None
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,value):
 path=ROOT/name;temporary=path.with_suffix('.tmp');temporary.write_text(json.dumps(value,indent=2,allow_nan=False)+'\n');temporary.replace(path)
def emit(value):
 with OUTPUT_LOCK:print(json.dumps(value,allow_nan=False),flush=True)
def registry_rows(path):
 if not path.exists():return []
 return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]
def track(registry,stop,step):
 seen=0
 while not stop.is_set():
  try:rows=registry_rows(registry)
  except (OSError,ValueError):rows=[]
  for row in rows[seen:]:
   if row['event']=='spawn':
    value=dict(row,event='owned_child_started',cell=ACTIVE_CELL,step=step);emit(value);write('pilot-native-live.json',value)
   else:emit(dict(row,event='owned_child_exited',cell=ACTIVE_CELL,step=step))
  seen=max(seen,len(rows));stop.wait(.2)
def group_present(pgid):
 try:os.killpg(pgid,0);return True
 except ProcessLookupError:return False
def retire_remaining_children(registry):
 proof=[]
 for row in registry_rows(registry):
  if row['event']!='spawn':continue
  pgid=row['pgid'];result=dict(row,signals=[])
  if group_present(pgid):
   observed=subprocess.run(['/bin/ps','-p',str(row['pid']),'-o','lstart='],capture_output=True,text=True).stdout.strip()
   if not row['birth'] or observed!=row['birth']:raise RuntimeError('owned child identity cannot be reverified; preserve handles: '+str(pgid))
   if int(subprocess.check_output(['/bin/ps','-p',str(row['pid']),'-o','pgid='],text=True))!=pgid:raise RuntimeError('owned child group changed')
   for sig,seconds in [(signal.SIGTERM,5),(signal.SIGKILL,3)]:
    if not group_present(pgid):break
    os.killpg(pgid,sig);result['signals'].append(int(sig));deadline=time.monotonic()+seconds
    while group_present(pgid) and time.monotonic()<deadline:time.sleep(.05)
  result['group_absent']=not group_present(pgid);proof.append(result)
  if not result['group_absent']:raise RuntimeError('owned detached child group failed retirement: '+str(pgid))
 return proof
def command(name,argv,timeout,registry=None):
 step=ROOT/'steps'/name;step.mkdir(mode=0o700);stop=threading.Event();thread=None
 if registry is not None:
  assert registry.parent==step
  thread=threading.Thread(target=track,args=(registry,stop,name),daemon=True);thread.start()
 def event(value):
  event=dict(value,step=name,cell=ACTIVE_CELL,log=str(step/'provider.log'));emit(event)
  if value.get('event')=='started':write('pilot-live-step.json',event)
 try:record=owner_helper.run_owner(argv,ENV,step,sys.stdin.buffer,event,lease_seconds=30,deadline_seconds=timeout)
 finally:
  stop.set()
  if thread:thread.join(timeout=2)
 result=dict(record,step=name,cell=ACTIVE_CELL,argv=argv)
 if registry is not None:
  result['detached_children']=retire_remaining_children(registry)
  for row in result['detached_children']:
   if Path(row['argv'][0]).name=='radix-engine':result['native_pid']=row['pid']
 EXECUTIONS.append(result);write('pilot-executions.json',EXECUTIONS)
 if record['failure'] is not None or record['exit_code']!=0 or not record['group_cleanup_complete'] or record['stop_requested']:raise RuntimeError('owned step failed: '+name)
 return result
plan=matrix.load_plan();binding=matrix.verified_bindings(BINDING_PATH)
assert sha(BINDING_PATH)==EXPECTED_BINDING and sha(ROOT/'root-binding-ack.json')==ACK_SHA
ack=json.loads((ROOT/'root-binding-ack.json').read_text());assert ack['status']=='EXACT_BINDING_REVIEWED_AND_THREE_CELL_EXECUTION_AUTHORIZED' and ack['binding_sha256']==EXPECTED_BINDING
cells=[next(c for c in plan['cells'] if c['id']==name) for name in ack['only_cells']]
assert binding['reviewed_cell_ids']==ack['only_cells'] and len(cells)==3 and binding['host_id']=='m5'
assert not any(Path(binding['results_root']).iterdir());assert not (ROOT/'pilot-executions.json').exists()
write('pilot-controller-receipt.json',{'driver_pid':os.getpid(),'binding_sha256':EXPECTED_BINDING,'root_ack_sha256':ACK_SHA,'only_cells':ack['only_cells'],'M5_only':True,'M3_actions':False,'original_runner_sha256':sha(ROOT/'plan/runner/run_radix_engine.py'),'tracking_wrapper_sha256':sha(ROOT/'tracked_runner.py'),'measurement_arguments_or_timeouts_modified':False,'started_unix':time.time()})
try:
 for index,cell in enumerate(cells,1):
  ACTIVE_CELL=cell['id'];matrix.require_current_prompt_date(plan)
  before=ROOT/('cell-'+str(index)+'-model-before.json');after=ROOT/('cell-'+str(index)+'-model-after.json')
  command('pilot-'+str(index)+'-model-before',['/usr/bin/python3','-B',str(ROOT/'recheck_model.py'),str(before)],600)
  entry=ROOT/('cell-'+str(index)+'-entry.json');command('pilot-'+str(index)+'-entry',['/usr/bin/python3','-B',str(ROOT/'entry_gate.py'),str(entry)],650)
  raw=matrix.command(plan,binding,cell);script=str(ROOT/'plan/runner/run_radix_engine.py');position=raw.index(script)
  registry=ROOT/'steps'/('pilot-'+str(index)+'-run')/'children.jsonl';argv=raw[:position]+[str(ROOT/'tracked_runner.py'),str(registry)]+raw[position:]
  write('cell-'+str(index)+'-command.json',{'cell':cell['id'],'binding_sha256':EXPECTED_BINDING,'reviewed_runner_argv':raw,'executed_ownership_wrapper_argv':argv})
  failure=None
  try:run=command('pilot-'+str(index)+'-run',argv,1900,registry)
  except BaseException as error:failure=error
  command('pilot-'+str(index)+'-model-after',['/usr/bin/python3','-B',str(ROOT/'recheck_model.py'),str(after)],600)
  a,b=json.loads(before.read_text()),json.loads(after.read_text());assert a['files']==b['files'],'model identity changed across cell'
  if failure is not None:raise failure
  out=Path(binding['results_root'])/cell['id'];report=json.loads((out/'report.json').read_text());metadata=json.loads((out/'metadata.json').read_text())
  errors=matrix.cell_evidence_errors(plan,binding,cell,report,metadata)
  if metadata.get('matrix_binding_sha256')!=EXPECTED_BINDING:errors.append({'binding_hash_changed':True})
  if not matrix.required_width_observed(report,2):errors.append({'required_overlap_width_missing':True})
  widths=[]
  for batch in report.get('batches',[]):
   try:widths.append(dict(id=batch['id'],**validate_packet(batch.get('forward_shapes'),2)))
   except (ValueError,KeyError,TypeError) as error:widths.append({'id':batch.get('id'),'error':str(error)})
  write('cell-'+str(index)+'-validation.json',{'cell':cell['id'],'errors':errors,'actual_widths':widths,'production_grant':report.get('production_grant'),'model_identity_unchanged':True,'native_pid':run.get('native_pid')})
  if errors:raise RuntimeError('cell failed strict evidence gates: '+cell['id'])
  partial=matrix.collect(plan,binding,cells[:index]);write('pilot-comparison-through-'+str(index)+'.json',partial)
  if not partial['all_selected_supported_cells_accepted']:raise RuntimeError('strict dependent comparison failed after '+cell['id'])
  emit({'event':'cell_accepted','cell':cell['id'],'actual_widths':widths})
 final=matrix.collect(plan,binding,cells);write('pilot-triad-verdict.json',final)
 write('pilot-status.json',{'state':'THREE_CELL_PILOT_COMPLETE_EVIDENCE_REVIEW_REQUIRED','binding_sha256':EXPECTED_BINDING,'cells':ack['only_cells'],'all_selected_supported_cells_accepted':final['all_selected_supported_cells_accepted'],'actual_model_forward_widths_verified':final['actual_model_forward_widths_verified'],'matrix_expansion_performed':False,'physical_two_host_gate_closed':False})
except BaseException as error:
 write('pilot-status.json',{'state':'FAILED_RETAINED_DEPENDENT_ARMS_GATED','active_cell':ACTIVE_CELL,'error':type(error).__name__+': '+str(error),'binding_sha256':EXPECTED_BINDING,'no_automatic_rerun':True})
 try:write('pilot-partial-verdict.json',matrix.collect(plan,binding,cells))
 except BaseException as collect_error:write('pilot-collection-error.json',{'error':str(collect_error)})
 raise
