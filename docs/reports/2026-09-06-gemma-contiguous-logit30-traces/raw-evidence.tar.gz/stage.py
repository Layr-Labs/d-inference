"""Stage only an activated, reviewed controller package; reuse the frozen remote runtime."""
from pathlib import Path
import argparse,json,shlex,subprocess,sys,tarfile
ROOT=Path(__file__).resolve().parent
PACKAGE=ROOT/'package'
sys.path.insert(0,str(PACKAGE))
from common import digest,require,verify_package

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--check-only',action='store_true')
    args=parser.parse_args()
    binding=verify_package(args.manifest_sha256,PACKAGE,local=True)
    if args.check_only:
        print(json.dumps({'state':binding['state'],'cells':len(binding['cells']),'runtime_files_verified':8,'remote_called':False}));return
    require(binding.get('state')=='peer_reviewed','root review and hardware handoff required before staging')
    archive=ROOT/'stage-package.tar.gz'
    with tarfile.open(archive,'x:gz') as tar:
        for name in sorted(json.loads((PACKAGE/'manifest.json').read_text())['files']):
            tar.add(PACKAGE/name,arcname=name,recursive=False)
        tar.add(PACKAGE/'manifest.json',arcname='manifest.json',recursive=False)
    remote='''from pathlib import Path,PurePosixPath
import hashlib,json,shutil,sys,tarfile
root=Path(ROOT_VALUE)
if root.exists() or root.is_symlink():raise RuntimeError('fresh root required; inspect any partial stage, do not overwrite')
if root.parent.resolve()!=root.parent:raise RuntimeError('remote parent alias refused')
root.mkdir(mode=0o700)
seen=set();total=0
with tarfile.open(fileobj=sys.stdin.buffer,mode='r|gz') as archive:
 for member in archive:
  name=PurePosixPath(member.name)
  if name.is_absolute() or '..' in name.parts or not member.isfile() or member.name in seen:raise RuntimeError('unsafe package member')
  seen.add(member.name);total+=member.size
  if len(seen)>256 or member.size>64<<20 or total>128<<20:raise RuntimeError('package bound exceeded')
  target=root/member.name;target.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
  with archive.extractfile(member) as source,target.open('xb') as output:shutil.copyfileobj(source,output,1<<20)
  target.chmod(member.mode&0o777)
if hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()!=MANIFEST_VALUE:raise RuntimeError('manifest differs')
records=json.loads((root/'manifest.json').read_text())['files']
if seen!=set(records)|{'manifest.json'}:raise RuntimeError('package inventory differs')
sys.path.insert(0,str(root))
from common import verify_package,write_json
from remote_owner import host_identity
binding=verify_package(MANIFEST_VALUE)
if binding['state']!='peer_reviewed':raise RuntimeError('unreviewed activation')
result={'staged':True,'root':str(root),'manifest_sha256':MANIFEST_VALUE,'runtime_root':binding['runtime_root'],'runtime_files_verified':8,'host_identity':host_identity(binding),'model_started':False}
write_json(root/'stage-receipt.json',result)
print(json.dumps(result))
'''.replace('ROOT_VALUE',repr(binding['root'])).replace('MANIFEST_VALUE',repr(args.manifest_sha256))
    command=['ssh','-T','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','StrictHostKeyChecking=yes','-o','ConnectTimeout=30','-o','ServerAliveInterval=5','-o','ServerAliveCountMax=3',binding['host'],
             '/usr/bin/env -i HOME=/Users/gaj PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin PYTHONDONTWRITEBYTECODE=1 /Applications/Xcode.app/Contents/Developer/usr/bin/python3 -B -c '+shlex.quote(remote)]
    with archive.open('rb') as incoming,(ROOT/'stage.stdout').open('x') as stdout,(ROOT/'stage.stderr').open('x') as stderr:
        result=subprocess.run(command,stdin=incoming,stdout=stdout,stderr=stderr,timeout=180)
    require(result.returncode==0,'stage failed; retain receipts and inspect exact remote root before further action')
    print((ROOT/'stage.stdout').read_text())

if __name__=='__main__':main()
