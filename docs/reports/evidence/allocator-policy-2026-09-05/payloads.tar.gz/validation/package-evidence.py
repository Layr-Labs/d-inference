from pathlib import Path
import difflib, gzip, json, re, shutil, subprocess, tarfile

exec(Path('/tmp/darkbloom-allocator-footprint-policy-validation1/verify.py').read_text())
assert (out / 'source-verified-after-cpp.json').exists()
assert (out / 'source-verified-after-swift.json').exists()
assert verify()['no_drift']
cpp = json.loads((out / 'cpp-execution.json').read_text())
swift = json.loads((out / 'swift-execution.json').read_text())
assert len(cpp) == 12 and all(row['exit_code'] == 0 for row in cpp)
assert len(swift) == 3 and all(row['exit_code'] == 0 for row in swift)
log = (out / 'swift-footprint.log').read_text()
assert re.search(r'Executed 6 tests, with 0 failures', log)
identifiers = [s for s in (out / 'swift-identifiers.log').read_text().splitlines() if 'AllocationFootprintTests/' in s]
assert len(identifiers) == 6
(out / 'selected-identifiers.json').write_text(json.dumps({'swift': identifiers, 'cpp_per_backend': ['allocation footprint bounds fresh and cached buffer owners', 'allocation prediction does not change allocator counters', 'test cached allocation keeps capacity', 'detached allocation policies preserve backend size classes without exceptions']}, indent=2) + '\n')
owned = {}
manifest = json.loads((out / 'requested-policy-manifest.json').read_text())
foundation_repos = {'swift': Path('/tmp/darkbloom-allocator-footprint-foundation3/deps/mlx-swift'), 'mlx': Path('/tmp/darkbloom-allocator-footprint-foundation3/deps/mlx-swift/Source/Cmlx/mlx'), 'mlx-c': Path('/tmp/darkbloom-allocator-footprint-foundation3/deps/mlx-swift/Source/Cmlx/mlx-c')}
patches = {}
for row in manifest['repositories']:
    alias = row['name']
    patch = ''
    for item in row['files']:
        path = item['path']
        p = repos[alias] / path
        owned[alias + '/' + path] = sha(p)
        before = (foundation_repos[alias] / path).read_text()
        patch += ''.join(difflib.unified_diff(before.splitlines(True), p.read_text().splitlines(True), fromfile='a/' + path, tofile='b/' + path))
    target = out / (alias + '-after-accepted-foundation.patch')
    target.write_text(patch)
    subprocess.run(['git', 'apply', '--check', str(target)], cwd=foundation_repos[alias], check=True)
    numstat = subprocess.check_output(['git', 'apply', '--numstat', str(target)], cwd=foundation_repos[alias], text=True)
    actual = sorted(line.split('\t')[-1] for line in numstat.splitlines())
    assert actual == sorted(item['path'] for item in row['files'])
    patches[alias] = {'sha256': sha(target), 'exact_paths': actual, 'applies_to_frozen_accepted_foundation': True}
(out / 'policy-owned-manifest.json').write_text(json.dumps({'files': owned}, indent=2) + '\n')
(out / 'bankable-patches.json').write_text(json.dumps(patches, indent=2) + '\n')
with tarfile.open(out / 'policy-owned-source.tar.gz', 'w:gz') as archive:
    for key in sorted(owned):
        alias, path = key.split('/', 1)
        archive.add(repos[alias] / path, arcname=key)
build_records = {}
for backend in ('cpu', 'metal'):
    build = out / ('build-' + backend)
    for source, name in [(build / 'compile_commands.json', backend + '-actual-compile-commands.json.gz'), (build / 'CMakeCache.txt', backend + '-actual-cmake-cache.txt.gz')]:
        (out / name).write_bytes(gzip.compress(source.read_bytes(), mtime=0))
    binary = build / 'footprint_tests'
    build_records[backend] = {'binary': str(binary), 'binary_sha256': sha(binary), 'library_sha256': sha(build / 'mlx/libmlx.a')}
scratch = Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift')
binary = scratch / 'arm64-apple-macosx/debug/mlx-swiftPackageTests.xctest/Contents/MacOS/mlx-swiftPackageTests'
build_records['swift'] = {'binary': str(binary), 'binary_sha256': sha(binary)}
(out / 'build-binary-records.json').write_text(json.dumps(build_records, indent=2) + '\n')
verdict = {'status': 'pass', 'new_cpp_functions': 1, 'cpp_cases_each_backend': 4, 'cpp_backends': ['CPU', 'Metal'], 'new_swift_functions': 2, 'swift_functions': 6, 'swift_cases': 6, 'swift_build_seconds_reported': float(re.findall(r'Build complete! \(([0-9.]+)s\)', (out / 'swift-build.log').read_text())[-1]), 'source_verified': verify(), 'policy_owned_paths': 12, 'failure_count': 0, 'source_corrections': 'None beyond applying exact policy12 delta while preserving approved Foundation import and metadata test completion fences from foundation. Two merged Swift hashes explicitly recorded in integration.json.', 'baseline_foundation_parent': '2dcec357414cf59ec3347febb9f5ee655d89aae7', 'baseline_foundation_native': 'a486a55d032deae001190bf9795ece1cb3d9a609', 'limits': ['CUDA allocation backend is unexecuted; its pure parameterized sizing formula is exercised as data by the C++ policy test.', 'No native404 rerun in this policy-only gate; native behavior and real provider U/C/M integration are checked in the subsequent provider gate.', 'No real model, factory rollout, default change or latency claim.']}
(out / 'verdict.json').write_text(json.dumps(verdict, indent=2) + '\n')
files = {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file() and p.name != 'manifest.json'}
(out / 'manifest.json').write_text(json.dumps({'scope': 'Policy12 over accepted allocator foundation, exact unchanged source on CPU/Metal C++ and Swift gates. Native source frozen unchanged, not rebuilt by this gate.', 'files': files}, indent=2) + '\n')
print(json.dumps({'cpp_cases': 8, 'swift_cases': 6, 'payloads': len(files), 'manifest_sha256': sha(out / 'manifest.json')}, indent=2))
