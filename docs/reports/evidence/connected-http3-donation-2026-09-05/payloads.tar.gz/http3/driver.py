from pathlib import Path
import hashlib,json,shlex,subprocess,sys,time
cell=sys.argv[1];assert cell in ('qwen38-paged-off-b1','qwen38-paged-ssd-b1')
local=Path('/tmp/darkbloom-connected-http3-results')/cell;local.mkdir(parents=True,exist_ok=False)
remote='/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http3';output=remote+'/runs/'+cell+'-run'
ssh=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99']
command=['python3','-B',remote+'/run_connected_fixture.py','run','--cell',cell]
(local/'command.json').write_text(json.dumps({'command':command,'scope':'Revision3 real connected fixture; CLI7 native a932 matching build6 useful-tail policy; no backend parity or final-promotion claim'},indent=2)+'\n');start=time.monotonic()
with (local/'ssh-run.log').open('x') as log:result=subprocess.run(ssh+[shlex.join(command)],stdout=log,stderr=subprocess.STDOUT)
(local/'execution.json').write_text(json.dumps({'exit_code':result.returncode,'seconds':time.monotonic()-start},indent=2)+'\n')
code='''from pathlib import Path
import json,hashlib
root=Path(ROOT);names=['launch.json','connected.log','evidence/report.json'];files={}
for name in names:
 p=root/name
 if p.is_file():files[name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'root':str(root),'files':files},indent=2))
'''.replace('ROOT',repr(output))
r=subprocess.run(ssh+['python3 -'],input=code,text=True,capture_output=True);assert r.returncode==0,r.stderr;(local/'remote-inventory.json').write_text(r.stdout);inventory=json.loads(r.stdout)
for name,item in inventory['files'].items():
 p=local/name;p.parent.mkdir(parents=True,exist_ok=True)
 r=subprocess.run(['scp','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','gaj@100.124.35.99:'+output+'/'+name,str(p)],capture_output=True,text=True);assert r.returncode==0,r.stderr;assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
files={str(p.relative_to(local)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(local.rglob('*')) if p.is_file()}
(local/'manifest.json').write_text(json.dumps({'scope':'Raw revision3 connected cell, retain failure status; no inference from unrun companion','exit_code':result.returncode,'files':files},indent=2)+'\n')
print(json.dumps({'local':str(local),'exit_code':result.returncode,'files':len(files),'manifest_sha256':hashlib.sha256((local/'manifest.json').read_bytes()).hexdigest()},indent=2));sys.exit(result.returncode)
