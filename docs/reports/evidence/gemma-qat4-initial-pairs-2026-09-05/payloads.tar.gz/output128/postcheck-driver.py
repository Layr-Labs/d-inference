from pathlib import Path
import json,subprocess,sys,hashlib
budget=sys.argv[1];assert budget in ('32','128');out=Path('/tmp/darkbloom-qat-output'+budget+'-postcheck1');out.mkdir(exist_ok=False)
pre=subprocess.run(['python3','/tmp/darkbloom-fleet-smoke-continuation/preflight.py',str(out/'idle-preflight.json')],text=True,capture_output=True);(out/'idle-preflight.log').write_text(pre.stdout+pre.stderr);assert pre.returncode==0,pre.stdout+pre.stderr
code='''from pathlib import Path
import hashlib,json,shutil,time,datetime
root=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-gemma-qat-supplement1');binding=json.loads((root/'binding.json').read_text());proof=json.loads((root/'plan/source-inputs/m5-target-hash-proof.json').read_text());model=Path('/Users/gaj/.cache/huggingface/hub/models--gemma-4-26b-qat-4bit/snapshots/local');start=time.monotonic();verified=[]
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(8*1024*1024),b''):h.update(chunk)
 return h.hexdigest()
assert {p.name for p in model.iterdir() if p.is_file()}=={x['path'] for x in proof['files']}
for x in proof['files']:
 p=model/x['path'];actual=sha(p);assert actual==x['sha256'] and p.stat().st_size==x['bytes'];verified.append({'path':str(p),'sha256':actual,'bytes':p.stat().st_size})
runtime={}
for x in [binding['binary'],binding['wrapper']]+list(binding['resources'].values()):
 p=Path(x['path']);actual=sha(p);assert actual==x['sha256'];runtime[str(p)]=actual
assistant=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-smoke1/payload/gemma-assistant-local-override1');want={'config.json':'0cd54ff36e53a258532c5c1433bc44b88ba758cfe9b59bb4e6eecfd5453fabcf','model.safetensors':'3c4d43863abbbf455ec537c726eff7abeb88bb361e3ab23ff0d2d6006f620f74'};assert {p.name for p in assistant.iterdir()}==set(want)
for name,h in want.items():assert sha(assistant/name)==h
runs=root/'runs';usage=[]
for child in runs.iterdir():
 fs=[p.stat() for p in child.rglob('*') if p.is_file() and not p.is_symlink()];usage.append({'root':str(child),'regular_files':len(fs),'logical_bytes':sum(x.st_size for x in fs),'allocated_bytes':sum(x.st_blocks*512 for x in fs)})
free=shutil.disk_usage(root).free;assert free>binding['min_free_bytes']
print(json.dumps({'scope':'After completed pair at owned idle boundary; full target SHA, runtime and assistant unchanged. Retain all payloads.','date_utc':datetime.datetime.now(datetime.timezone.utc).date().isoformat(),'seconds':time.monotonic()-start,'model_files':verified,'model_aggregate_sha256':proof['aggregate_sha256'],'runtime_sha256':runtime,'assistant_sha256':want,'free_bytes':free,'run_payloads':usage},indent=2))
'''
ssh=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99'];r=subprocess.run(ssh+['python3 -B -'],input=code,text=True,capture_output=True);(out/'postcheck.json').write_text(r.stdout);(out/'postcheck.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr;print(r.stdout)
