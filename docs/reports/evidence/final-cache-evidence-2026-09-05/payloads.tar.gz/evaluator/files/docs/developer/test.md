# Test

> Last updated: 2026-09-05 · commit `1a4a4504b`

How to run the unit tests for each component, the end-to-end suite that boots a
real coordinator + Swift provider against ephemeral Postgres, and the docs
lint — and which CI workflow runs what. `make test` runs every unit suite plus
the docs lint locally; CI runs a subset per pull request (see the CI workflow
map: the console UI job lints and builds but does not run vitest, and the
benchmark-wrapper tests run only locally). The e2e suite needs an Apple Silicon
Mac with the test checkpoints cached.

## Prerequisites

- Toolchain from [build.md](build.md) (`mise install`, submodules, `cmake`).
- **Postgres 16** for the coordinator store tests and the e2e suite: either
  Docker (`postgres:16` image is pulled automatically by the testbed) or a
  native `postgres`/`initdb` on `PATH` (`brew install postgresql@16`, then
  `PATH="$(brew --prefix postgresql@16)/bin:$PATH"`). The testbed prefers
  Docker when `docker` is on `PATH` (`e2e/testbed/deps/postgres.go`,
  `PostgresLifecycle.Start`).
- **Hugging Face cache** with the e2e checkpoints:
  `mlx-community/gpt-oss-20b-MXFP4-Q8` (~12.1 GB, default testbed model),
  `mlx-community/gemma-4-26B-A4B-it-qat-4bit` (~14.5 GB, second model for
  multi-model suites), and `mlx-community/gemma-4-e2b-it-4bit` (exact-cache
  routing test). CI pins revisions `GPT_OSS_REVISION` /
  `EXACT_CACHE_MODEL_REVISION` in `.github/workflows/integration.yml`.
- `golangci-lint` v2.1.6 for the lint job
  (`go install github.com/golangci/golangci-lint/v2/cmd/golangci-lint@v2.1.6`;
  config in `.golangci.yml`).

## Steps

### 1. Run everything CI runs as unit tests

```bash
make test   # coordinator-test prompt-sidecar-test provider-test ui-test benchmark-wrapper-test docs-check
```

### 2. Coordinator (Go)

```bash
make coordinator-test                      # cd coordinator && go test ./...
# what CI runs (repo root, race detector, Postgres-backed store tests included):
DATABASE_URL='postgres://testbed:testbed@127.0.0.1:5432/testbed?sslmode=disable' \
  go test -race $(go list ./... | grep -v /e2e)
gofmt -l .                                 # must print nothing
golangci-lint run                          # .golangci.yml
```

Store tests that need Postgres skip themselves when `DATABASE_URL` is unset
(`coordinator/store/harness_test.go`, `testPostgresStore`); CI provides a
`postgres:16` service with user/password/db `testbed`. The pre-push hook runs
`go test $(go list ./... | grep -v /internal/api)` from `coordinator/` to skip
the slow WebSocket integration tests; run the full set before merging.

### 3. Prompt-contract sidecar (Rust)

```bash
make prompt-sidecar-format   # cargo fmt --all -- --check
make prompt-sidecar-check    # cargo check --locked --all-targets; cargo clippy --locked --all-targets -- -D warnings
make prompt-sidecar-test     # cargo test --locked --all-targets
```

CI additionally builds the static Linux binary through the Dockerfile stage
(`docker build --platform=linux/amd64 --target prompt-sidecar-builder -f coordinator/Dockerfile .`),
checks `file` reports `statically linked|static-pie linked`, and replays the
production prompt vectors against it with
`scripts/verify-prompt-sidecar-linux.sh <binary>`.

### 4. Provider (Swift) — unit tests with a source-matched metallib

```bash
make provider-test
# = cd provider-swift && swift build --build-tests
#   ./scripts/fetch-metallib.sh <bin-path>            (build mlx.metallib from libs/mlx-swift source)
#   cp mlx.metallib into every <bin-path>/*PackageTests.xctest/Contents/MacOS/
#   cd provider-swift && swift test --skip-build
```

The metallib staging is not optional: MLX loads `mlx.metallib` from beside the
running executable, and for tests the executable is the `.xctest` runner.
Without it kernel-backed tests fail or silently exercise a different kernel
set than production. To run a subset: `cd provider-swift && swift test
--skip-build --filter <Suite>` after `make provider-test` has staged the
metallib once.

**Nested `libs/mlx-swift-lm` suites.** The paged-KV correctness gates live in
the submodule, not in `provider-swift/`. Build them once, stage the metallib,
then run each suite through [`scripts/run-nested-suite.sh`](../../scripts/run-nested-suite.sh),
which fails when a suite executes zero tests or skips any (a bare
`swift test --filter` exits 0 on an empty run):

```bash
cd libs/mlx-swift-lm
swift package unedit --force mlx-swift >/dev/null 2>&1 || true
swift package edit --path ../mlx-swift mlx-swift      # use the local mlx-swift, not the remote branch
swift build --build-tests
../../scripts/fetch-metallib.sh "$PWD/.build/debug"            # stage mlx.metallib beside the nested test runner
for b in .build/debug/*PackageTests.xctest; do cp .build/debug/mlx.metallib "$b/Contents/MacOS/"; done
for suite in CBv2PagedSafetyTests CBv2PrefixCacheHasherTests CBv2PagedEligibilityTests \
             CBv2PagedBackendTests CBv2PagedKernelTests CBv2KVSharingParityTests; do
  ../../scripts/run-nested-suite.sh "$suite"
done
```

<a id="resident-prefix-benchmark-validation"></a>

#### Prefix-cache benchmark validation

The standalone scripts under [`scripts/benchmarks`](../../scripts/benchmarks/radix_prefix_cache.py)
retain complete requests, SSE events, token counts, cache evidence, and GPU
telemetry. Use a dedicated idle Mac with the model already downloaded. The
runner refuses concurrent ranked work and owns only its child processes.

```bash
python3 -m unittest discover -s scripts/benchmarks -p 'test_*.py'
python3 scripts/benchmarks/run_radix_http.py --binary /path/to/baseline/darkbloom \
  --output /path/to/new-baseline-run --mtp off --cache on
python3 scripts/benchmarks/run_radix_http.py --binary /path/to/candidate/darkbloom \
  --output /path/to/new-candidate-run --mtp off --cache on \
  --replay /path/to/new-baseline-run/http/report.json
python3 scripts/benchmarks/run_radix_engine.py --binary /path/to/radix-engine \
  --model-directory /path/to/pinned-model-snapshot \
  --input /path/to/new-baseline-run/http/report.json \
  --output /path/to/new-engine-run --cache on
python3 scripts/benchmarks/compare_radix_engine.py baseline-engine.json candidate-engine.json \
  --expect-cache-hits
```

Build each engine probe using the [pinned-worktree instructions](build.md#prefix-cache-benchmark-executable).
HTTP equality proves full text and token counts; the engine comparison checks
actual generated token IDs, clean termination, saved tokens, tenant separation,
and cancellation recovery. Compare MTP-on and MTP-off against their respective
baselines. A cache lookup with zero saved tokens does not demonstrate reuse.
For schema-2 reports, the default cache axis requires cache off then cache on,
with the same requested store/key modes and resolved backend. Every disabled
probe must report zero saved tokens and no hit. Use `--axis backend` for a
contiguous-to-paged pair with identical cache settings. Legacy report support
does not establish the current release gates (`compare_radix_engine.py`, `compare`).
Both runners accept `--mtp on` and `--kv-backend paged`; their defaults are MTP
off and backend auto. The current direct candidate defaults to `--cache-mode ssd`.
It uses the normal slot factory, production prompt/tool normalization, normal
MTP preparation and verified pre/post-load model identity. For an external
assistant, `--assistant-directory` supplies an exact flat artifact to the normal
offline verification funnel; it does not bypass target compatibility.
`--expected-model-sha256` pins the aggregate and `--prompt-date YYYY-MM-DD`
pins missing request-owned dates for paired runs. Raw media needs the HTTP path. It refuses requested MTP without an active driver,
a cache-on arm without a ready SSD store, and any resident-memory opt-in.
Start TTFT before `session.submit` so authenticated staging is included
(`EngineV2Factory+BenchmarkSession.swift`, `BenchmarkLoader.swift`).

For bounded concurrency, add `--concurrency 2` or `--concurrency 4` to the
engine runner. Each input is submitted as that many simultaneous requests;
reports retain every row, submission failure, batch duration, aggregate output
rate, and capacity/MLX-memory samples at 100 ms intervals. Compare with a cold
oracle from the same binary, concurrency, slot grant, model and MTP mode.
Choose the grant mode explicitly for the measurement. Use
`--production-kv-grant` for a single loaded model's full production grant, or
`--kv-budget-gib N` for an explicit envelope control. With neither flag the
historical explicit default remains 16 GiB. B1/B2/B4 changes request concurrency,
not the number of loaded model slots. Record the observed backend and capacity,
and reject a requested paged arm that falls back. The comparator rejects missing/failed batch rows and unobserved
concurrency in either arm. B4 identifies four submitted requests; the sampled
overlap check does not certify four simultaneously admitted sequences or a
continuous memory peak. It checks staged-memory release after the whole batch drains;
another active request may still own staging when an individual row ends.
These raw-engine batches exercise shared native admission for segmented storage;
they do not cover bridge dispatch, contiguous bridge reservations or HTTP framing.
When the native engine exposes `paged_storage`, before/after metrics and batch
samples retain its queue-captured grant, committed backing, reserved/live pages,
poison, slack, and over-grant bytes, plus segment and address-page counts.
Committed bytes measure physical backing; they are not the logical token limit.

For a production-grant run, add the flag to the existing candidate invocation:

```bash
python3 scripts/benchmarks/run_radix_engine.py --binary /path/to/final/radix-engine \
  --model-directory /path/to/exact-model \
  --input /path/to/pinned-http-report.json --output /path/to/new-run \
  --cache-mode ssd --key-mode persistent --cache on --kv-backend paged \
  --mtp on --concurrency 4 --production-kv-grant \
  --expected-model-sha256 "$MODEL_SHA256" --prompt-date 2026-09-05 --trial 1
```

Set `MODEL_SHA256` to the verified target aggregate. Keep the model's configured
MTP posture: use `--mtp off` for GPT-OSS; supply the verified
`--assistant-directory` for Gemma's normal assistant. Repeat with cache off,
contiguous storage and the other concurrency/trial values required by the plan,
using the same artifact and prompt date. The flag does not promote a different
artifact or silently disable MTP.

Verify `kv_grant_mode = "production_single_slot"` and the recorded
`production_grant`: hard/effective cap, operator reserve, cap fraction, loaded
target/assistant/total weights, activation reserve, zero RAM prefix allowance,
`slot_count = 1`, fleet budget and resulting grant. Require the actual engine
ceiling and shared process cap/reserve to agree with those inputs. The separate
`post_build_headroom_bytes` must pass the normal minimum serviceability gate;
a larger logical grant cannot waive insufficient live OS/activation headroom.
`post_load_maximum_kv_bytes` is the retained Memory.active diagnostic and an
explicit-mode guard only. Production mode uses loaded `SlotSizingSnapshot`
facts, not that allocator observation. See the
[grant mechanism](../architecture/hardware-support.md#kv-slot-grants).

Production mode is unavailable to resident reproduction, native-type-only probes
and callers injecting a multi-session budget. Co-resident tests must use the
real provider lifecycle or explicit grants with one shared process authority.
The comparator requires paired production-grant inputs to match and rejects
missing or inconsistent grant/headroom evidence (`radix_engine_evidence.py`,
`production_grant_errors`; `compare_radix_engine.py`, `compare`).

The candidate's `--native-kv-probe-only` mode requires cache-off, MTP-off and
concurrency one. Preserve its actual prefill/decode K/V observations before
selecting a paged native-type table. This target-only diagnostic does not prove
paged serving, MTP execution or prefix reuse; those require the normal benchmark
arms and their output oracle.

Record actual cache mode, key mode, stage time, saved tokens and idle reservation
counters. The session waits for pending refunds after a serial terminal. Its
normal construction, shared native ownership and SSD staging are real; the
raw-engine measurement omits bridge dispatch, contiguous bridge reservations,
HTTP framing and coordinator routing.
Schema-2 SSD acceptance requires zero request activity, live KV and reserved/live
pages after serial rows and complete batches. The idle admission charge may
equal retained free physical backing. Shutdown additionally requires zero
segments, committed backing and process owners/closing owners/C/M/unmaterialized
promises. Logical `address_pages`, model-weight memory, allocator cache and RSS
need not be zero (`radix_engine_evidence.py`, `retirement_errors`).
Keep a refusal when a terminal snapshot still contains old engine gauges;
terminal delivery alone is not a guarantee that those gauges have published.
Such a result lacks the idle observation required by this gate and must not be
silently relabeled as either a proved leak or a passing retirement measurement.
Local provider HTTP measurements cover bridge admission and framing. Coordinator
routing has separate Go regression coverage; an end-to-end routing claim requires
a live multi-provider run. Record source and artifact hashes with every result;
[the cache architecture](../architecture/prefix-cache.md) links retained validation
evidence.

Schema 2 writes an atomic initial report before loading, then preserves every
completed, failed, aborted or not-run cell. Raw token IDs, chunks, usage and
errors survive a failure; later cells stop. Use distinct invocations with
`--trial 1`, `--trial 2`, and `--trial 3` for independent process repetitions.
Each invocation uses a fresh payload root unless `--cache-directory` explicitly
selects one for a restart test. Retain binary/model/input hashes, request date,
assistant identity, actual backend, key mode, slot grant and concurrency.

The comparator defaults to `--axis cache`, which requires the same backend.
Use `--axis backend` for contiguous versus paged with cache enabled state and
other settings held fixed. Missing, failed, unmatched or unexercised required
cells fail comparison; a clean fast completion is not cancellation evidence.
The current direct harness records `cancellation_probe_version = 2`. It first
completes a donor in the exact cancellation scope in both compared arms. For
paged SSD cache-on, cancellation must then show a real hit, staged import,
positive matched/saved tokens and a fresh authenticated read-byte increase.
The cancelled output must match a prefix of the donor output, and recovery
must reproduce the full donor output. Keep an eligible long-prompt control;
a short prompt below cache policy thresholds cannot establish this restore
case. The completed donor remains reusable after cancellation. Version 1
reports establish cold cancellation only and cannot be compared as version 2
(`RadixBenchmark.swift`, `BenchmarkGeneration.swift`,
`radix_engine_evidence.py`, `cancellation_errors`).

Decode rate excludes every token in the first nonempty delta and divides the
remaining tokens by elapsed time between the first and last deltas. This avoids
counting a first MTP chunk as later decode work; reports retain both raw counts.
Batch samples also retain process commitments, materialized backing, other
allocator use, retirement debt, allocator padding and write-host ownership.
Sampling observations are not a continuous peak guarantee.

Keep evidence scopes separate. `SegmentedProductionGrantTests` exercises native
page/ring/dtype and normal Qwen MTP accounting in synthetic 36/64/128 GiB
memory envelopes; zero-page construction and pure accounting are not measured
model capacity. `BenchmarkProductionGrantTests` checks policy composition and
the separate live minimum gate. A source freeze documents unrun code; a compiled
test result proves only its exercised fixtures. Neither replaces exact-model
B1/B2/B4 serving, real admission boundaries, latency/memory observations or
co-resident load/unload runs. These changes leave `auto` on contiguous until the
release's real-model/default-promotion gates pass.

The Python runner binds all three isolated-cache controls together: it sets
`DARKBLOOM_PREFIX_CACHE_ALLOW_EPHEMERAL=1`, the owned
`DARKBLOOM_PREFIX_CACHE_TEST_ROOT`, and
`DARKBLOOM_PREFIX_CACHE_TEST_PERSISTENT_KEY=1` for persistent/default mode or
`0` for explicit ephemeral mode. These values override inherited test settings.
The root override is ignored without the affirmative isolation opt-in.

`--cache-mode ssd --key-mode persistent` is the SSD default and requires the
normal persistent KEK; `--key-mode ephemeral` is a non-restart test control.
Current SSD reports must prove the requested actual `metrics_loaded.key_mode`;
a missing or different mode fails the wrapper after preserving the report.
When invoking the executable directly, set the same environment controls as
well as the final `persistent-key` or `ephemeral-key` argument. That argument
controls acceptance and does not by itself select the key. Cache construction
refusal retains the exact pre-shutdown model status and evidence-source presence
in `EngineV2BenchmarkSession.Failure.ssdUnavailable`.

Assert persistent key mode, expected SSD mode and no resident bank for a restart
claim. Launch a fresh OS
process using the same binary/model,
identity settings, keys and payload root; an in-process `shutdown` is not a
restart or model-unload proof because the session/`Loaded` value can still own
`rawEngine`. Key bytes remain in the normal Secure Enclave/Keychain hierarchy,
never the payload root. Exact controls are in [the SSD reference](../reference/ssd-kv-cache.md#environment-variables).

Use `--cache-mode resident` only to reproduce earlier candidate artifacts.
That arm supplies a 1 GiB, 32-entry bank with two checkpoints per request, or
paged resident blocks on the explicit paged backend. Inspect `capacity_refusals`,
`retained_bytes`, `kv_compactions` and `kv_compaction_bytes` for long prompts.
Paged cancellation may leave finalized prefill blocks reusable; complete SSD
and hybrid-bank publication require natural donor termination. All arms require
exact recovery output. The comparator rejects observed cache-budget violations;
a latency-only plan reports no decode rate.
The historical [M5 baseline report](../reports/2026-09-05-radix-prefix-cache-baseline.md)
retains exact artifacts and measurement limits.

For the corresponding unit tests, use the native nested-suite procedure above
with `CBv2PagedPrefixBlockCacheTests`, `CBv2PagedPrefixLeakTests`,
`CBv2PagedPoolGuardTests`, `CBv2FirstTokenWorkProjectionTests`,
`CBv2FirstTokenDeadlineEngineTests`, `CBv2TokenRadixIndexTests`,
`CBv2HybridPrefixCacheTests`, `CBv2RecurrentStateTests`,
`CBv2CompleteCheckpointTests`, and `CBv2CompleteCheckpointEngineTests`. Filters name the
declared test types, which can differ from filenames; the replay-plan class is
`CBv2FrozenReplayPlanTests`. MTP checkpoint checks also use
`Qwen35MTPDraftTrimTests` and `CBv2QwenMTPIntegrationTests`. Provider integration
filters include `EngineV2BridgeTests`, `EngineV2KVBackendGateTests`,
`PrefixCacheReceiptTests`, `SSDPrefixCache`, `ResidentPrefixCacheEvidenceTests`,
`SSDNativePrefixBuilderTests`, `SSDHybridCheckpointStoreTests`, and
`SSDCheckpointStageReservationTests`.

**Prompt parity** — `./scripts/verify-prompt-parity.sh` proves the three
prompt-contract implementations agree on the same production vectors; the
procedure, its inputs and the regeneration flow are in
[step 9](#9-prompt-contract-parity-fixtures-and-vectors).

**Installer** — `./scripts/test-install-atomic.sh` exercises the atomic
install/replace path of `scripts/install.sh` in a temp dir (and runs
`scripts/sync-install-embed.sh check` first).

### 5. Console UI and Admin UI

```bash
make ui-test                     # cd console-ui && npm test  (vitest run)
make ui-lint                     # npx eslint src/
make ui-build                    # next build
cd admin-ui && npm test && npm run lint && npm run build
node --test landing/earn-calculator-core.test.js
```

### 6. Scripts and release integrity

```bash
make benchmark-wrapper-test        # python3 -m unittest discover -s gemma_contbatch/tests -t .   (in scripts/)
./scripts/check-release-version.sh # ProviderCore.version == coordinator LatestProviderVersion (see operations/provider-release.md)
./scripts/sync-install-embed.sh check   # coordinator/api/install.sh byte-identical to scripts/install.sh
./scripts/test-prod-env-refresh.sh      # deploy/gcp/prod/refresh-env.sh contract
./scripts/test-publish-model.sh         # scripts/publish-model.sh dry-run contract
```

The first three are CI job "Release Integrity".

### 7. Docs lint

```bash
make docs-check          # scripts/docs-check.sh — stamps, relative links, cited paths, orphans
make docs-stamp FILES="docs/developer/test.md"   # refresh a stamp after editing
```

### 8. End-to-end suite

The e2e package (`e2e/`, harness in `e2e/testbed/`) boots ephemeral Postgres,
a coordinator from the current tree, and one or more **real** `darkbloom`
provider processes serving MLX checkpoints, then drives the OpenAI-compatible
API. It is a Go test binary; run it from the repo root with `-p=1` (suites
share GPU/ports).

```bash
# Blocking lane as CI runs it (paged KV @ 8, engine-reported backend asserted):
DARKBLOOM_TESTBED_KV_BACKEND=paged DARKBLOOM_TESTBED_MAX_CONCURRENT=8 \
DARKBLOOM_TESTBED_EXPECT_KV_BACKEND=paged \
go test ./e2e/ -count=1 -v -timeout 25m -p=1 \
  -run 'TestIntegration|TestProfile' -skip '^TestIntegrationExactCacheRouting$'

# Default posture (no TOML written; .auto resolves contiguous as of v0.8.1):
DARKBLOOM_TESTBED_EXPECT_KV_BACKEND=contiguous \
go test ./e2e/ -count=1 -v -timeout 10m -p=1 -run '^TestIntegration_(NonStreaming|Streaming)Inference$'

make e2e-integration     # go test ./e2e/... -run TestIntegration -v   (no posture pins)
make e2e-benchmark       # go test ./e2e/... -run TestBenchmark -v
```

The harness builds the provider itself (`e2e/testbed/provider.go`,
`BuildProvider`): `swift build -c release` (or `TESTBED_PROVIDER_CONFIG=debug`)
and stages `mlx.metallib`, unless `DARKBLOOM_PROVIDER_BINARY` points at a
binary that already has `mlx.metallib` beside it.

| Env var | Read in | Effect |
|---|---|---|
| `DARKBLOOM_REPO_ROOT` | `e2e/testbed/suite.go` | Repo root (auto-detected from cwd when unset) |
| `DARKBLOOM_PROVIDER_BINARY` | `e2e/testbed/provider.go`, `e2e/mixed_version_test.go` | Use this provider binary instead of building; needs `mlx.metallib` beside it |
| `TESTBED_PROVIDER_CONFIG` | `e2e/testbed/provider.go` | `release` (default) or `debug` SwiftPM configuration for the built provider |
| `DARKBLOOM_TESTBED_MODEL` / `DARKBLOOM_TESTBED_MODEL_B` | `e2e/testbed/config.go` | Override the default (`mlx-community/gpt-oss-20b-MXFP4-Q8`) and secondary (`mlx-community/gemma-4-26B-A4B-it-qat-4bit`) checkpoints; must be CBv2-servable |
| `TESTBED_MODEL_ID` | `e2e/testbed/suite.go` | Per-suite model override |
| `DARKBLOOM_TESTBED_KV_BACKEND` | `e2e/testbed/config.go` (`ResolveKVBackend`) | `auto` / `paged` / `contiguous` written to the provider TOML as `engine_v2_kv_backend`; unset = provider default |
| `DARKBLOOM_TESTBED_MAX_CONCURRENT` | `e2e/testbed/config.go` (`ResolveMaxConcurrent`) | `engine_v2_max_concurrent`; unset = the provider default ([`../provider/cli-reference.md`](../provider/cli-reference.md#providertoml-keys-read-by-the-cli)); malformed value is a hard error |
| `DARKBLOOM_TESTBED_EXPECT_KV_BACKEND` | `e2e/testbed/kv_expectation.go` | Pre-warm every slot and fail unless the heartbeat's `kv_backend` equals this |
| `DARKBLOOM_CBV2_PAGED_KV` | `e2e/testbed/config.go` | Provider fleet kill switch; CI refuses to run the paged gate when it is set |
| `DARKBLOOM_PROMPT_SIDECAR_BINARY` | `e2e/exact_cache_routing_test.go` | Path to a built `promptsidecar` for exact-cache routing |
| `DARKBLOOM_EXACT_CACHE_TEST_MODEL` | `e2e/exact_cache_routing_test.go` | Override the exact-cache fixture (`mlx-community/gemma-4-e2b-it-4bit`) |
| `DARKBLOOM_MIXED_VERSION`, `DARKBLOOM_MIXED_VERSION_EXPECT` | `e2e/mixed_version_test.go` | Enable the released-v0.7.12 lane; required tier `artifact` (verify pinned digests) or `full` (boot the released provider — needs SIP enabled) |
| `DARKBLOOM_QWEN38_E2E`, `DARKBLOOM_QWEN38_MTP_PATH`, `DARKBLOOM_QWEN38_MTP_MANIFEST_PATH`, `DARKBLOOM_QWEN38_MTP_REVISION` | `e2e/integration_test.go` | Opt-in Qwen3.8 real-process tools/video lane with a local MTP build |
| `DARKBLOOM_FULL_NETWORK_SMOKE` | `e2e/integration_test.go` | Opt-in full-network multi-model routing smoke |
| `BENCHMARK_MD_PATH` | `e2e/benchmark_test.go` | Where `TestBenchmark*` writes the Markdown results table |

**Inventory** (`rg '^func Test' e2e/*.go` is authoritative):

| File | Tests |
|---|---|
| `e2e/integration_test.go` | `TestIntegration_NonStreamingInference`, `_StreamingInference`, `_GreedyDeterminism`, `_MultipleRequestsAccounting`, `_E2EEncryptionCorrectness`, `_BillingBalanceDeduction`, `_ProviderPayoutSplit`, `_InsufficientBalance`, `_InvalidModel`, `_StreamingContentValidation`, `_ConcurrentRequests`, `_AttestationHeaders`, `_SwiftProviderRealRoutingGates`, `_FullNetworkSingleSwiftProviderMultiModelRouting`, `_ReferralRewardDistribution`, `_Qwen38RealProcessToolsAndVideo`; plus `TestQwen38GatePolicy`, `TestQwen38ExpectedBuiltKVBackend` |
| `e2e/profile_test.go` | `TestProfile_SingleProviderNonStreaming`, `TestProfile_RequestProfilesRecorded` |
| `e2e/exact_cache_routing_test.go` | `TestIntegrationExactCacheRouting` (expected red on paged with the e2b fixture; informational step in CI) |
| `e2e/mixed_version_test.go` | `TestIntegrationMixedVersionReleasedV0712Provider`, `TestIntegrationMixedVersionGateContract` |
| `e2e/benchmark_test.go` | `TestBenchmark_SingleProviderStreaming`, `_SingleProviderNonStreaming`, `_MultiModelMultiProvider`, `_HighConcurrency`, `_QueueSaturation`, `_ManyUsers`, `_SingleModelScaling`, `_HeavyLoad_100Concurrent_10KB`; config tests `TestBenchmarkSuiteConfig*`, `TestBenchmarkControlSuiteIsIsolatedAndMatchesPosture`, `TestBenchmarkCapacitySaturationPolicy` |

### 9. Prompt-contract parity fixtures and vectors

`fixtures/prompt-contract/v1` is shared by the Rust, Go and Swift
prompt-contract tests: `contract_vectors.json` and `block_hash_vectors.json`
(identity and chain vectors), `corpus.json` (complete requests for tools, null
sanitization, Harmony and Gemma normalization, reasoning effort, Unicode, all
four endpoints, exact block multiples and long prompts),
`production_vectors.json` (per-model normalized bodies, token IDs and
boundaries) and `manifests/` (the catalog snapshot the vectors were generated
from). Production tokenizer/template/config artifacts are **not** in the
repository; the vectors are generated only from manifest-pinned,
coordinator-provisioned artifacts. What the vectors protect is explained in
[`../architecture/prompt-contract-sidecar.md`](../architecture/prompt-contract-sidecar.md#parity-fixtures-and-measured-latency).

The pinned inventory contains seven artifacts: the five release models and two
additional Gemma variants. All 14 shared cases run against every artifact,
producing 98 token-array comparisons. The common corpus uses histories and
reasoning settings accepted by each family; family-specific argument and
Harmony regressions remain in the provider's focused test suites.

**Run the gate** (what CI's Provider Tests job runs; needs Go, `cargo +1.88.0`,
Swift and `jq`):

```bash
./scripts/verify-prompt-parity.sh
```

The script, in order:

1. Replays the committed manifest snapshot through
   `go run ./cmd/promptfixtureinput --manifest-source-directory
   fixtures/prompt-contract/v1/manifests …` (from `coordinator/`), which
   downloads only the verified prompt artifacts into a temporary artifact root
   (override with `PROMPT_PARITY_ARTIFACT_ROOT`; artifacts come from
   `PROMPT_PARITY_CDN_URL`).
2. Regenerates the vectors with the Rust generator:

   ```bash
   cargo +1.88.0 run --locked --quiet \
     --manifest-path coordinator/promptsidecar/Cargo.toml \
     --bin prompt-fixtures -- \
     --manifest-directory "$MANIFEST_DIR" \
     --artifact-root "$ARTIFACT_ROOT" \
     --cases fixtures/prompt-contract/v1/corpus.json \
     --output "$WORK/production_vectors.json"
   ```

   `prompt-fixtures` (`coordinator/promptsidecar/src/bin/prompt-fixtures.rs`)
   also accepts one `--manifest <file>` per model instead of
   `--manifest-directory`. The corpus supplies a fixed request-owned UTC date;
   direct literal date calls use it in both renderers. Unsupported clock use
   is written with `cache_routing_eligible: false` and
   `ineligibility_reason: "dynamic_time"` and get no routable vectors.
3. `cmp`s the generated file byte-for-byte against
   `fixtures/prompt-contract/v1/production_vectors.json`.
4. Runs the three implementations against the same vectors: Swift
   `swift test --package-path provider-swift --filter ProductionPromptParityTests`
   (with `PROMPT_PARITY_REQUIRED=1`, `PROMPT_PARITY_VECTORS`,
   `PROMPT_PARITY_ARTIFACT_ROOT` set), Go
   `go test ./promptcontract -run TestProductionPlansConsumeSharedTokenVectors`,
   and Rust `--test shared_vectors production_plans_match_shared_token_vectors`
   plus `--test planner_fixture concurrent_cold_contract_load_is_singleflight`.
5. Builds the release `promptsidecar` and drives it through the real Go
   supervisor with `go run ./coordinator/cmd/promptsidecarloadproof`
   (`PROMPT_LOAD_PROOF_DURATION`, `PROMPT_LOAD_PROOF_QPS`,
   `PROMPT_LOAD_PROOF_MAX_RSS_MIB` tune the run), failing on any plan mismatch,
   timeout, overload, restart, child replacement or RSS escape.
   Preserve the reported cold-load, preload and warm-plan timing totals and
   counts alongside memory measurements. Compute means from totals and counts;
   histogram buckets are cumulative bounds, not exact latency quantiles. When
   comparing tokenizer ownership, use identical artifacts, vectors and proof
   binaries in both arms. A macOS RSS pass does not prove Linux's address-space
   limit; run `scripts/verify-prompt-sidecar-linux.sh` against the static musl
   binary before release.

**Regenerate the fixtures** after a catalog, normalisation, renderer or
tokenizer change:

```bash
PROMPT_PARITY_UPDATE=1 ./scripts/verify-prompt-parity.sh
```

This re-fetches every active public manifest from `PROMPT_PARITY_CATALOG_URL`
(default `https://api.darkbloom.dev/v1/models/catalog`), rewrites
`fixtures/prompt-contract/v1/manifests/` and `production_vectors.json`, then
runs the same parity tests against the new vectors. Commit both. Missing
models, artifacts or corpus cases and unrecognised template incompatibilities
fail the gate (`require_model_manifests`, `require_case_ids`); no fabricated
token IDs are accepted.

## CI workflow map

| Workflow | Trigger | Jobs (name → what runs) |
|---|---|---|
| [`.github/workflows/ci.yml`](../../.github/workflows/ci.yml) | push, PR | **Release Integrity** — `scripts/check-release-version.sh`, `scripts/sync-install-embed.sh check`, `scripts/test-prod-env-refresh.sh` · **Docs Lint** — `scripts/docs-check.sh` · **Coordinator Tests** — `go test -race $(go list ./... \| grep -v /e2e)` with `postgres:16` service + `gofmt -l .` · **Coordinator Lint** — `golangci-lint run` (v2.1.6) · **Prompt Sidecar Tests** — cargo fmt/check/clippy/test on Rust 1.88.0, static musl Docker stage, `verify-prompt-sidecar-linux.sh` · **Provider Tests** (macOS 12-vcpu) — `swift build --build-tests`, metallib staging, `swift test`, `verify-prompt-parity.sh`, six nested suites via `run-nested-suite.sh` (each its own step, `if: !cancelled()`), `test-install-atomic.sh` · **Swift Build + Cache** — release build of `darkbloom` + `darkbloom-fan-helper`, warms the SwiftPM cache · **Console UI Lint & Build** — Node 22, `npm ci`, `npx eslint src/`, `npm run build` |
| [`.github/workflows/integration.yml`](../../.github/workflows/integration.yml) | push to `master`/`main`, PR | **E2E Integration Tests** (macOS, 120 min budget): install Postgres 16, `swift build -c debug`, cargo sidecar build, metallib staging, HF snapshot downloads; lanes: paged @ 8 blocking gate (`TestIntegration\|TestProfile` minus exact-cache) → exact-cache routing paged @ 8 (expected red, `continue-on-error`) → default-posture smoke (`EXPECT_KV_BACKEND=contiguous`) → current coordinator vs released v0.7.12 provider (`scripts/fetch-v0712-provider.sh`, `DARKBLOOM_MIXED_VERSION_EXPECT=artifact`, fails unless `MIXED_VERSION_TIER_ARTIFACT_OK` appears) → released v0.7.12 coordinator (`git worktree add … v0.7.12`) vs candidate provider (`NonStreamingInference`, `StreamingInference`) |
| [`.github/workflows/benchmarks.yml`](../../.github/workflows/benchmarks.yml) | PR, gated by the `benchmarks` environment (manual approval) | **E2E Benchmarks** — `go test ./e2e/ -count=1 -v -timeout 40m -p=1 -run 'TestBenchmark'`, posts `BENCHMARK_MD_PATH` as a PR comment |
| [`.github/workflows/release-swift.yml`](../../.github/workflows/release-swift.yml) | tag `v*`, manual | Provider release; see [`../operations/provider-release.md`](../operations/provider-release.md) |
| [`.github/workflows/register-model.yml`](../../.github/workflows/register-model.yml) | manual | `POST /v1/admin/models/register`; see [`../operations/model-migration.md`](../operations/model-migration.md) |
| `.github/workflows/threat-model-review.yml`, `.github/workflows/claude.yml`, `.github/workflows/codex.yml` | PR / comment | Review automation; not test gates |

## Verify

- `make test` exits 0 and `docs-check` prints `N file(s) OK`.
- `swift test` output lists the `ProviderCore` suites **and** each nested suite
  step prints a non-zero executed count (the tripwire in `run-nested-suite.sh`).
- The e2e run logs `postgres started`, one `using configured provider binary`
  or provider build line per provider, and finishes with `ok  github.com/eigeninference/d-inference/e2e`.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| `DATABASE_URL not set — skipping PostgreSQL integration test` | store tests skipped | export `DATABASE_URL` to a Postgres 16 with a `testbed` database |
| `neither docker nor postgres found in PATH` | e2e cannot start Postgres | start Docker, or put `postgresql@16/bin` on `PATH` |
| `configured provider metallib not found beside binary` | `DARKBLOOM_PROVIDER_BINARY` set without `mlx.metallib` next to it | `./scripts/fetch-metallib.sh "$(dirname "$DARKBLOOM_PROVIDER_BINARY")"` |
| provider never registers a model in e2e | checkpoint not in the HF cache, or not CBv2-servable (`gpt_oss`/`gemma4` families only) | download the pinned snapshot; check `DARKBLOOM_TESTBED_MODEL` |
| nested suite step fails with "executed 0 tests" | swift-testing pass routed at an executable target / wrong filter | rebuild with `swift build --build-tests` in `libs/mlx-swift-lm`; keep suite names exact |
| paged gate fails immediately with `DARKBLOOM_CBV2_PAGED_KV=… is set` | kill switch in your shell | `unset DARKBLOOM_CBV2_PAGED_KV` |

## Related

- [build.md](build.md) — toolchain and build commands.
- [`../operations/provider-release.md`](../operations/provider-release.md) — release checks that also run in CI.
- [`../architecture/components/provider.md`](../architecture/components/provider.md) — what the provider does at runtime.
- [`../architecture/prompt-contract-sidecar.md`](../architecture/prompt-contract-sidecar.md) — what prompt parity protects.

## Connected coordinator/provider HTTP cache gate

`TestIntegrationConnectedCacheHTTP` extends the existing real-provider testbed with
an opt-in ten-case HTTP gate. It starts an isolated in-memory coordinator, two
normal authenticated provider WebSocket connections, and the real supervised Rust
prompt sidecar. Local API keys, provider tokens and the routing master key are
fresh fixture credentials. No production database, Privy, Stripe or deployment
secret is needed. Testbed trust overrides are explicit; this is not attestation or
persistent-key restart evidence. Two providers on one Mac establish connected
control-plane behavior, not independent-machine capacity or latency.

Prepare `DARKBLOOM_CONNECTED_CACHE_INPUT` as the JSON input described by
`connectedCacheInput` in `e2e/connected_cache_input_test.go`: exact target catalog
entry and immutable manifest, current artifact tuple, verified prompt artifact
directory, provider/metallib/sidecar paths and SHA-256 values, explicit backend,
`cache_mode` (`off` or `ssd`), normal MTP mode, authored text/tool fixtures and
per-slot concurrency. Gemma requires its verified flat assistant directory and
assistant catalog manifest; GPT-OSS uses MTP off and the three exact Qwen models
use MTP on. The normal production loader still verifies assistant compatibility.
Vision-configured artifacts require the original `landing/assets/cube-hero.png`
fixture and its pinned hash. The supplied text must tokenize to at least 2,048
tokens through the real sidecar, leaving room above the unchanged SSD hit floor.
No latest-snapshot discovery or artifact-name substitution occurs.

Use a dedicated idle host and the final prebuilt provider plus colocated runtime
resources and Rust sidecar. This gate never builds them. It requires an existing
canonical provider config, verifies its bytes remain unchanged, and refuses a
provider binary with keychain access-group entitlement. Runtime files are copied
into the new output directory; PID/state/local discovery/cache/temporary/guard
paths are isolated, automatic updates and restarts are disabled, and the two exact
retired telemetry queue files must be absent. It never removes or repairs a host
configuration or key. SSD uses an explicitly ephemeral test key and fresh per-process
roots; resident cache and unrelated memory/backend overrides must be unset.

```bash
DARKBLOOM_CONNECTED_CACHE_INPUT=/absolute/off.json \
DARKBLOOM_CONNECTED_CACHE_OUTPUT=/absolute/new-off-output \
  go test ./e2e -run '^TestIntegrationConnectedCacheHTTP$' -count=1 -timeout=45m
DARKBLOOM_CONNECTED_CACHE_INPUT=/absolute/ssd.json \
DARKBLOOM_CONNECTED_CACHE_OUTPUT=/absolute/new-ssd-output \
  go test ./e2e -run '^TestIntegrationConnectedCacheHTTP$' -count=1 -timeout=45m
python3 scripts/benchmarks/compare_connected_cache_http.py \
  /absolute/new-off-output/report.json /absolute/new-ssd-output/report.json \
  --output /absolute/connected-comparison.json
```

The pair must use the same final binary, exact artifacts, backend, normal MTP,
authored request bytes and coordinator-owned UTC date. The comparator checks
served content/reasoning, decoded tool arguments, finish and native/HTTP token
counts; timing-dependent cancellation partial lengths are retained separately.
The runner fences UTC rollover and preserves failed, running and unrun cells in
an atomically replaced partial JSON report. Keep the `go test` log beside it for
setup failures and interrupted process evidence.

A bounded transparent loopback relay records negotiation, checkpoint echo,
receipt positions, cancellation and typed terminal usage/profile without keys,
nonces, raw scopes, token-chain hashes or encrypted bodies. Actual coordinator
acceptance counters and existing scheduler decisions are checked separately.
A read/receipt alone cannot pass the native saved-token hit assertion. The cases
cover cold donation, repeat, tenant isolation, a continuation on another provider,
original-prefix routing, forced tools, supported vision remaining cold, restored
cancellation and recovery, and sidecar-unavailable cold serving. Loaded slots must
report the actual backend with no fallback, and terminal profiles must prove MTP.
Heartbeat memory/SSD read observations are snapshots, not per-request read-byte
measurements. Old-echo, expiry/eviction, reconnect, queued revocation and costly-hit
winner controls remain separate coordinator gates. This harness source and its
loopback fixtures do not themselves establish real-model results.

The helper checks run without Swift, Metal or model execution:

```bash
go test -race -short ./e2e/testbed ./e2e \
  -run 'TestProviderWire|TestProviderTOMLExplicit|TestConnected' -count=1
python3 -m unittest discover -s scripts/benchmarks \
  -p 'test_compare_connected_cache_http.py'
```
