// Copyright © 2026 Eigen Labs.

import CryptoKit

/// Shared key hierarchy for both encrypted SSD payload layouts. A test-only
/// ephemeral key is never persisted and cannot supply restart warmth.
struct SSDCacheKeyMaterial {
    let key: SymmetricKey
    let ephemeral: Bool

    enum Failure: Error {
        case persistentKeyUnavailable(any Error)
        case ephemeralKeyUnavailable
    }

    static func load(allowEphemeral: Bool, forceEphemeral: Bool) async throws -> Self {
        if !forceEphemeral {
            do {
                let enclave = try PersistentEnclaveKey.loadOrCreate()
                let kek = KVCacheKEK(
                    wrapper: SecureEnclaveKeyWrappingService(enclaveKey: enclave),
                    storage: KeychainWrappedKEKStorage())
                let key = try await kek.loadOrCreate()
                return Self(key: key, ephemeral: false)
            } catch {
                guard allowEphemeral else { throw Failure.persistentKeyUnavailable(error) }
            }
        }
        let kek = KVCacheKEK(
            wrapper: InMemoryKeyWrappingService(),
            storage: InMemoryWrappedKEKStorage(identifier: "ephemeral-ssd"))
        guard let key = try? await kek.loadOrCreate() else { throw Failure.ephemeralKeyUnavailable }
        return Self(key: key, ephemeral: true)
    }
}
