# Coherent idle benchmark observations (source-only candidate)

Base: `1a4a4504b82631f41029636280dc3b65e671b700`.
Worktree: `/Users/gaj/Documents/DarkbloomDev/wt/benchmark-coherent-idle`.

## Trigger and behavior

The immutable Qwen 3.6 5523-token cold smoke2 report captured five stale post-terminal engine gauge tuples while the shared process ledger had already retired C/M. Its immediately following pre-request snapshots show zero active/reservation at the same step count. The strict retirement evaluator correctly rejects that mixed-age observation. This patch adds a bounded read-only observation at known idle boundaries; it does not modify those reports, native scheduling, gauge publication, production cache policy, or the evaluation gates.

`BenchmarkMetrics.idleSnapshot` applies only to an actual production benchmark session (both cache-off and SSD-enabled arms). It samples complete immutable engine/session metric dictionaries until active/waiting/in-use and live/reserved pages are zero, admission reservation equals actual committed physical backing, and SSD stage/writer host reservations have drained. Shutdown additionally requires zero physical backing, segment count, and all five process owner/C/M/U fields. Normal idle allows reusable committed backing; logical address pages, model weights, MLX cache and process RSS are not required to vanish. Archived/resident reproduction keeps its existing snapshot semantics.

`BenchmarkIdleObservation.capture` uses `DispatchTime.uptimeNanoseconds` and `Task.yield()` with a five-second deadline, no sleep and no mutation API. Cancellation or reaching the deadline returns the final actual metrics plus a failed observation, even if an idle tuple arrives too late. It does not throw away diagnostic evidence. Each returned idle snapshot includes `idle_observation` with `status`, `shutdown`, `attempts`, `elapsed_s`, `timeout_s`, and `pending_retirement`.

Serial rows observe after stream terminal and existing `session.complete` cleanup. Their terminal token/count/finish evidence remains intact if observation times out; the row becomes failed and is persisted before the outer guard exits. Concurrent row generation explicitly sets `observeIdle: false`. Only after the entire batch task group finishes does the batch await idle. Batch row completions remain truthful and the report fails with the retained batch metrics if the batch observation fails. Shutdown failure retains the original failed observation rather than replacing it with a later successful retry.

## Timing

Request elapsed/TTFT/decode/end-of-cleanup timestamps are fixed before idle observation. Batch `ended` is captured immediately after all generation tasks finish, before cancelling/collecting the capacity sampler and before idle observation. Aggregate throughput excludes those observation steps. The wait is reported independently in `metrics_after.idle_observation.elapsed_s`, `metrics_after_batch.idle_observation.elapsed_s`, and `metrics_after_shutdown.idle_observation.elapsed_s`. The report timing scope documents this. Existing completion cleanup remains separately measured and is not hidden.

The reader awaits the already existing, non-I/O cache/ledger snapshot actor method; the deadline bounds repeated observation, not arbitrary blocking inside an externally changed snapshot implementation.

## Source review and tests

Seven changed paths: five existing harness/manifest paths, one focused pure observation helper, one focused test file. No provider/native/package dependency revision changes. `git diff --check` passes.

Eight new Swift test functions cover stale terminal gauges becoming idle without advancing engine steps; bounded timeout preserving the last stale sample; an idle tuple arriving at/after the deadline; cancellation; reusable physical backing with exact reservation; missing backing/live pages; shutdown owner/backing retirement with nonzero logical address/MLX residency; and stage/writer-host retirement for both backends.

The tests and modified standalone target are **not compiled or run**. Root owns the sole Swift/GPU lane and requested a source-only handoff. After applying the patch, the intended focused command from `scripts/benchmarks/radix-engine` is `RADIX_SOURCE_ROOT=<integrated-source-root> RADIX_CANDIDATE_BUILD=1 swift test --filter BenchmarkIdleObservationTests`, followed by the final standalone release build and fresh real-model pair. These tests do not replace the strict Python evaluator or real-model remeasurement.

No Swift/GPU/real-model pass is claimed by this freeze. No production changes, commits, pushes, signing, or external messages were performed.
