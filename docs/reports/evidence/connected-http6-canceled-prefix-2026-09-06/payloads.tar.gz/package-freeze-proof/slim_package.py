from pathlib import Path
import hashlib,json,shutil,stat,subprocess,sys,tarfile
base=Path('/tmp/darkbloom-connected-m5-bundle6-q38');prior=base.with_name(base.name+'-preparation-attempt1');old=base/'package-manifest.json'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def item(p):return {'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode),'sha256':sha(p)}
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
assert sha(old)=='5c63892b3d7afeadc118d21db2e0a50219dcf34044a69a355a21864e88d64407'
manifest=json.loads(old.read_text());excluded=[n for n in manifest['files'] if n.startswith('provenance/release-build/artifact/')];assert len(excluded)==8
assert not prior.exists();base.rename(prior);base.with_suffix('.tar.gz').rename(prior.with_suffix('.tar.gz'));base.mkdir()
for name,record in manifest['files'].items():
 if name in excluded:continue
 source=prior/name;target=base/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target);assert item(target)==record
out=Path('/tmp/darkbloom-connected-http6-package-freeze1');out.mkdir(exist_ok=False)
shutil.copy2(Path(__file__),out/'slim_package.py')
proof={'scope':'Exclude eight redundant release artifact copies from transport package; actual CLI runtime is separately bound/transferred. All remaining payload bytes/modes unchanged; no test rerun necessary.',
 'prior_manifest_sha256':sha(prior/'package-manifest.json'),'prior_package':str(prior),'excluded_artifacts':{k:manifest['files'][k] for k in excluded}}
save(out/'slim-proof.json',proof)
for p in out.iterdir():shutil.copy2(p,base/'preparation'/p.name)
manifest['files']={str(p.relative_to(base)):item(p) for p in sorted(base.rglob('*')) if p.is_file()};manifest['artifact_provenance']='All 98 release files were rehashed; 90 non-artifact proof files and original release manifest retained. Seven actual CLI runtime files bound separately; no redundant probe transfer.'
save(base/'package-manifest.json',manifest)
r=subprocess.run([sys.executable,'-B',str(base/'verify_package.py')],text=True,capture_output=True);assert r.returncode==0,r.stderr;(out/'package-verification.stdout').write_text(r.stdout)
archive=base.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as tar:
 for name in sorted(list(manifest['files'])+['package-manifest.json']):tar.add(base/name,arcname=name,recursive=False)
summary={'package':str(base),'manifest':item(base/'package-manifest.json'),'payloads':len(manifest['files']),'archive':dict(item(archive),path=str(archive)),
 'binding':item(base/'runtime-binding.json'),'paired_proof':item(base/'paired-input-validation.json'),'source_map':item(base/'final-source-correspondence.json'),'scope':'Final strict Q38 HTTP6 package pending root package/controller review; all 20 helper tests and one representative CPU prompt plan passed.'}
save(out/'summary.json',summary);save(out/'manifest.json',{'files':{p.name:item(p) for p in sorted(out.iterdir()) if p.is_file()}});print(json.dumps(summary,indent=2))
