from pathlib import Path
import gzip,hashlib,json,re,shutil
out=Path(__file__).resolve().parent;info=json.loads((out/'integration.json').read_text());ws=Path(info['workspace']);scratch=Path(info['scratch'])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
assert not (out/'manifest.json').exists()
results=json.loads((out/'execution.json').read_text());filters=json.loads((out/'filters.json').read_text());assert len(results)==len(filters)+2 and all(r['exit_code']==0 and r['nonzero_no_skips'] for r in results)
assert json.loads((out/'run-status.json').read_text())=={'failed':[],'all_filters_run':True}
identifiers=[line.strip() for line in (out/'identifiers.log').read_text().splitlines() if line.startswith('RadixEngineBenchmarkTests.')]
selected={}
for name in filters:
 ids=[i for i in identifiers if i.startswith('RadixEngineBenchmarkTests.'+name+'/')];body=(out/(name+'.log')).read_text()
 count=max([int(x) for x in re.findall(r'Test run with (\d+) tests?|Executed (\d+) tests?, with 0 failures',body) for x in x if x]+[0]);assert count==len(ids)>0,(name,count,len(ids))
 assert not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',body,re.M)
 selected[name]={'identifiers':ids,'test_functions':count,'log_sha256':sha(out/(name+'.log'))}
assert sum(s['test_functions'] for s in selected.values())==18
write('selected-identifiers.json',selected)
known={};counts={}
for name,root,group in [('provider-source-manifest.json',ws,'provider'),('native-source-manifest.json',ws/'libs/mlx-swift-lm','native'),('harness-source-manifest.json',out,'harness')]:
 files=json.loads((out/name).read_text())['files'];counts[group]=len(files)
 for p,digest in files.items():
  path=root/p;assert sha(path)==digest,p;known[str(path.resolve())]={'group':group,'sha256':digest}
deps=json.loads((out/'dependency-source-manifest.json').read_text());counts['dependency']=len(deps['files'])
for key,digest in deps['files'].items():
 alias,p=key.split('/',1);path=Path(deps['repositories'][alias])/p;assert sha(path)==digest,key;known[str(path.resolve())]={'group':'dependency','sha256':digest}
jinja=json.loads((out/'jinja-source-manifest.json').read_text());counts['jinja']=len(jinja['files'])
for p,digest in jinja['files'].items():
 path=scratch/'checkouts/swift-jinja'/p;assert sha(path)==digest,p;known[str(path.resolve())]={'group':'jinja','sha256':digest}
body=gzip.decompress((out/'actual-build-debug.yaml.gz').read_bytes()).decode();matched={};unknown=[]
roots=[str((ws/'provider-swift').resolve()),str((ws/'libs/mlx-swift-lm').resolve()),str((out/'radix-engine').resolve())]
for literal in sorted(set(re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',body))):
 p=Path(literal);key=str(p.resolve());row=known.get(key)
 if row:
  assert sha(p)==row['sha256'],literal;matched[literal]={'resolved_source':key,**row}
 elif any(key.startswith(root+'/') for root in roots):unknown.append(literal)
assert not unknown,unknown
assert '/checkouts/mlx-swift/Source/' not in body
write('all-owned-graph-source-proof.json',{'scope':'Declared SwiftPM build graph source references matched against frozen input hashes. This does not claim every graph entry links into the selected test product. Selected test executions and binary identity are recorded separately.','counts':{g:sum(r['group']==g for r in matched.values()) for g in counts},'files':matched,'unmapped_owned_source_paths':unknown,'remote_mlx_source_excluded':True,'dependency_identity':'SwiftPM reports local aliases with the same mlx-swift identity; all matched MLX source paths resolve to the same frozen pinned local dependency. An unused remote checkout is not compile identity evidence.'})
native=Path(info['native_validation']);assert (native/'manifest.json').is_file()
for p,row in json.loads((native/'manifest.json').read_text())['files'].items():assert sha(native/p)==row['sha256'],p
shutil.copy2(native/'manifest.json',out/'native-validation-manifest.json')
parent=json.loads((out/'harness-source-manifest.json').read_text())['parent_candidate_changes'];candidate=Path('/Users/gaj/Documents/DarkbloomDev/wt/q36-attention-packet-090')
for p,row in parent.items():
 source=candidate/p;assert sha(source)==row['after_sha256'],p;target=out/'owned'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)
write('verdict.json',{'status':'PASS_BENCHMARK_PACKET_METADATA_LOGIT_AND_IDLE_TESTS','test_functions':18,'packet_option_tests':2,'packet_export_tests':2,'metadata_option_tests':3,'existing_logit_option_tests':3,'existing_idle_observation_tests':8,'failed':0,'skipped':0,'inputs':counts,'source_scope':'Parent384c321aa/nativee972340 plus exact packet source1; no namespace/cancellation source included.','build_seconds':results[0]['seconds'],'source_corrections_during_validation':False,'real_models_run':False,'other_unintegrated_candidates_included':False,'next':'Root review; no optimized packet compile or real-model execution is implied.'})
files={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.relative_to(out).parts[0] not in ['workspace','radix-engine'] and p.name!='manifest.json'}
write('manifest.json',{'schema':1,'status':'PASS_BENCHMARK_PACKET_METADATA_LOGIT_AND_IDLE_TESTS','files':files,'test_binary':json.loads((out/'test-binary.json').read_text())})
for p,row in files.items():assert sha(out/p)==row['sha256']
print(json.dumps({'manifest':str(out/'manifest.json'),'sha256':sha(out/'manifest.json'),'payloads':len(files),'verdict':json.loads((out/'verdict.json').read_text())},indent=2))
