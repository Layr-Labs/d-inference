"""Redirect only the failed staging predecessor to its exact completed verification."""
from pathlib import Path
import json
import sys

HERE=Path(__file__).resolve().parent
sys.path.insert(0,'/tmp/darkbloom-q36-owner0-replay-execution1')
import common
import run_arm
from resume_stage import EXPECTED_BINDING,RESUME,validate_failure

ORIGINAL=run_arm.verify_previous


def verified_predecessor(root):
    if root!=common.RESULTS/'staging':return ORIGINAL(root)
    original=validate_failure(root)
    ORIGINAL(RESUME)
    completed=json.loads((RESUME/'summary.json').read_text())
    assert completed['binding_sha256']==EXPECTED_BINDING
    assert completed['original_staging_manifest_sha256']==original['original_staging_manifest_sha256']
    receipt=json.loads((RESUME/'complete-verification.stdout').read_text())
    assert receipt=={'status':'PASS','verified':True,'artifacts':7,
        'input_sha256':'17114f5243a9657bfcc3d4c7d1f3d9362bffeb744b1ceb5f815c321f0479d487','operator_invoked':False}


def main():
    assert len(sys.argv)==4,'Pass arm, unchanged runtime-binding SHA256 and reviewed resume-source manifest SHA256'
    assert sys.argv[2]==EXPECTED_BINDING
    common.verify_manifest(HERE,'manifest.json',sys.argv[3])
    invocation={'argv':list(sys.argv),'resume_source_manifest_sha256':sys.argv[3],
                'original_driver_sha256':common.sha(Path(run_arm.__file__))}
    directory=common.RESULTS/'resume-invocations';directory.mkdir(exist_ok=True)
    path=directory/(sys.argv[1]+'.json');assert not path.exists();common.write(path,invocation)
    sys.argv=sys.argv[:3]
    run_arm.verify_previous=verified_predecessor
    run_arm.main()


if __name__=='__main__':main()
