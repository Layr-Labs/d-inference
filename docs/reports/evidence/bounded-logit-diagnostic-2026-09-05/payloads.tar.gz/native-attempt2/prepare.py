from pathlib import Path
import hashlib,io,json,shutil,subprocess,tarfile

out=Path('/tmp/darkbloom-q36-logit-diagnostic-validation2')
old=Path('/tmp/darkbloom-q36-logit-diagnostic-validation1')
source=Path('/tmp/darkbloom-q36-logit-diagnostic-source/freeze1')
repo=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated/libs/mlx-swift-lm')
base='a932d38cee0beca41ca1a0e71c1e867913a65353'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for frozen in [old,source]:
 for name,row in json.loads((frozen/'manifest.json').read_text())['files'].items():assert sha(frozen/name)==row['sha256'],name
package=out/'native';assert not package.exists();package.mkdir()
archive=subprocess.check_output(['git','archive',base],cwd=repo)
with tarfile.open(fileobj=io.BytesIO(archive)) as archive:archive.extractall(package,filter='data')
for name in ['native-source-manifest.json','dependency-source-manifest.json','jinja-source-manifest.json','run-nested-suite.sh','filters.json']:
 shutil.copy2(old/name,out/name)
shutil.copy2(old/'native/Package.swift',package/'Package.swift')
shutil.copy2(old/'native/Package.resolved',package/'Package.resolved')
for name,row in json.loads((source/'source-proof.json').read_text())['native']['files'].items():
 p=package/name
 if row['before_sha256'] is not None:assert sha(p)==row['before_sha256'],name
 else:assert not p.exists(),name
 shutil.copy2(source/'files/native'/name,p)
owned=json.loads((out/'native-source-manifest.json').read_text())['files']
for name,digest in owned.items():assert sha(package/name)==digest,name
ancillary={str(p.relative_to(package)):sha(p) for p in sorted(package.rglob('*')) if p.is_file() and str(p.relative_to(package)) not in owned}
(out/'ancillary-package-manifest.json').write_text(json.dumps({'base':base,'files':ancillary},indent=2)+'\n')
info=json.loads((old/'integration.json').read_text());info['native']=str(package);info['preserved_setup_failure']={'manifest':str(old/'manifest.json'),'sha256':sha(old/'manifest.json')};info['ancillary_package_inputs']=len(ancillary)
(out/'integration.json').write_text(json.dumps(info,indent=2)+'\n')
run=(old/'run.py').read_text().replace("out=Path('/tmp/darkbloom-q36-logit-diagnostic-validation1')","out=Path('/tmp/darkbloom-q36-logit-diagnostic-validation2')")
needle=" for name,digest in native['files'].items():assert sha(package/name)==digest,name\n"
run=run.replace(needle,needle+" for name,digest in json.loads((out/'ancillary-package-manifest.json').read_text())['files'].items():assert sha(package/name)==digest,name\n",1)
(out/'run.py').write_text(run)
print('Prepared complete canonical package; owned='+str(len(owned))+' ancillary='+str(len(ancillary)))
