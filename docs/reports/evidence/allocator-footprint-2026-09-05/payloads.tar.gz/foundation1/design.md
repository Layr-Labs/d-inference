# Allocator footprint dependency/native integration

Status: approved source implementation direction; no builds/tests/banking.

Pinned dependency: mlx-swift eafd98a7c53c145ff40faa486c5f696b7104ae92;
MLX core 9b3f4d1ec6bd65314e06825658334e5788ee3167;
mlx-c 720953eff635e772d9f3d73e46942bc49fac04c3.
Dependency tree: wt/allocator-footprint-swift (nested MLX/mlx-c worktrees).
Native tree: wt/allocator-footprint-native, base eeece251 plus exact root process freeze1 source overlay; provenance in native-baseline/provenance.json.

## Dependency API

- Allocator-owned get_allocation_size_upper_bound(bytes): checked stateless metadata calculation. Metal applies VM-page normalization above a page and includes the strict cache-reuse ceiling; no-GPU uses the existing 4096 cache bucket policy without pretending libc overhead is part of MLX U. CUDA mirrors its existing scalar/power-of-two/page normalization. No buffer allocation, cache peek/claim, stream eval/wait, or change to reuse policy.
- C wrapper and throwing Swift Memory.allocationFootprintUpperBound(byteCount:) expose that prediction. It bounds one allocator backing only, not the whole zero-fill graph or model scratch.
- Non-evaluating array backing info reads existing array::buffer_size(), offset/data_size, row-contiguity and unique ownership only when available. C/Swift expose exact MLX-accounted bytes; unavailable returns nil. Metadata does not constitute an ownership grant. Native creates coverage only from its fresh exclusive full zero-storage owner; later rebases share that one coverage owner. No global before/after deltas.

## Native pricing and materialization

Logical page bytes and buffer offsets remain unchanged. Segment layout has distinct allocator-bound sizing; its aggregate enumerates actual binary segment classes before summing each allocator bound. Existing segment backing stores its measured allocator footprint. Growth/import plans use old exact P + upper bounds for new allocations, preserving shared free backing and full-N promises. Submit/deadline probes include allocator bounds alongside sentinel overhead.

- Ordinary growth: raise physical lease to complete bound before allocating; measure/credit each exclusive evaluated backing M while C covers the bound. Publish all groups with actual P and existing grant generation; then release physical lease downward to actual P. Existing CBv2BackendPhysicalLease.release(to:) / Admission downward mutation requires no new headroom grant.
- Checkpoint adoption: imported stage uses exact source backing P; reserve bound only for missing suffix. Keep unresolved CBv2CheckpointAdoptionReservation and its captured physical P unchanged through allocation/publication. Publish using actual P, commit the ticket, then lower the physical lease to actual P before returning active state. On any failure the original ticket still rolls back against the expected bound.
- Private checkpoint stage: plan reserves bounded native target bytes before allocation. Typed stage settlement is single-use, admission-generation-bound, downward-only and changes neither auxiliary nor scratch. After all destination arrays succeed, settle target to sum of actual segment backing footprints. Frame validation compares actual storage footprint with settled target, not plan upper bound. Stage transfer removes that exact target and retains scratch until close.
- Partial failures: coverage withdraws before owners/aliases drop; only then cancel the prepared floor/stage reservation. Settling never withdraws valid M and never refunds actual backing.

No ordinary allocator policy/default change. Temporary conservative slack is bounded per segment and will be observable as allocator padding and preparation allowance in native tests/telemetry. The 64 MiB production segment policy makes cache tolerance small; no exact-allocation bypass is added without measured regression.

## Owned source paths

Dependency: MLX memory.h + backend allocator implementations/common cache arithmetic; mlx-c memory/array wrappers + mirrored public/framework headers; Swift focused Memory/MLXArray footprint file and tests. Native: PagedKVSegments, PagedKVGroup, PagedKVPool+Segments, PagedKVPool+CheckpointImport, AdmissionCheckpointTransfer, AdmissionV2 narrow stage settle, Prefix/PagedCheckpointStorage and PagedCheckpointFrame, relevant tests and telemetry.

Codec17 freeze1 remains immutable. Follow-up codec integration must keep allocation-free plan.nativeDestinationBytes explicitly a bound and expose settled actual staged native destination bytes to provider legacy-envelope resize; shared mode remains host-only. Root owns IOLease capability follow-up separately.

## Implemented source checks and limits

The Swift backing query reports allocator bytes, data offset/elements, row-contiguity and instantaneous uniqueness. PagedKVSegmentBacking checks fresh full zero-storage geometry/uniqueness once, stores the footprint and keeps one owner across rebased wrappers. Reading the same buffer metadata through a view does not create coverage. The C++ prediction and cache reuse share the same inclusive checked bound helper, preserving the existing positive-size cache acceptance rule.

Private target settlement runs in PagedCheckpointFrame construction, after all target and auxiliary arrays exist but before a stage is exposed. Its lease lock precedes Admission; transfer captures target bytes before entering Admission, avoiding inversion. Both lease and Admission identity reject a second settlement, closed generation or already-transferred stage. An unchanged size still consumes the settlement exactly once.

Native gauges expose allocatorPaddingBytes and lastAllocationAllowanceBytes. slackBytes now counts usable logical free backing, excluding padding; provider/wire propagation needs a coordinated follow-up. The ordinary telemetry capture remains engine-owned and immutable between allocator captures.

New tests written: 4 Swift dependency methods, 2 C++ allocator cases, 8 native Swift Testing parameter cases. Existing native tests were adjusted to compare actual allocator footprints and preserve bound/refusal/rollback assertions instead of assuming logical size equals committed bytes. No tests, compilation, model execution, latency or tight-cap capacity evidence has been produced by this slice.

`git diff --check` passed in all four repositories. Runtime patch apply-check fails only at PagedKVPool.swift's declaration context due to the root process baseline's added memoryAdmission field; that file has no footprint delta, and remaining runtime hunks apply. Codec17 remains untouched. Recurrent/MTP/scratch footprint proof is still separate: codec17's auxiliary destinations use logical C pricing and no M coverage. The allocator bound prices one buffer, not arbitrary graph/input/scratch allocation.
