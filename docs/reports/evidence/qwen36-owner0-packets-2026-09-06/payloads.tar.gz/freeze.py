from pathlib import Path
import hashlib,json,os,shutil,stat,tarfile
OUT=Path('/tmp/darkbloom-q36-owner0-packet-four-cell-freeze1');OUT.mkdir(mode=0o700,exist_ok=False);PAYLOAD=OUT/'payloads';PAYLOAD.mkdir(mode=0o700)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def item(p):return {'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(stat.S_IMODE(p.stat().st_mode))}
def save(p,v):p.write_text(json.dumps(v,indent=2,sort_keys=True)+'\n')
directories={};groups=[]
def cp(p,name):
 q=PAYLOAD/name;q.parent.mkdir(parents=True,exist_ok=True)
 if p.parent.name=='report.attention-packet':q.parent.chmod(0o700);directories[str(q.parent.relative_to(PAYLOAD))]={'mode':'0o700'}
 shutil.copy2(p,q);assert item(q)==item(p)
def add(root,label,manifest_name='manifest.json',extras=()):
 mpath=root/manifest_name;manifest=json.loads(mpath.read_text())
 for name,row in manifest['files'].items():
  p=root/name;r=item(p);assert r['bytes']==row['bytes'] and r['sha256']==row['sha256']
  if 'mode' in row:assert int(r['mode'],8)==(int(row['mode'],8) if isinstance(row['mode'],str) else row['mode'])
  cp(p,label+'/'+name)
 cp(mpath,label+'/'+manifest_name)
 for name in extras:cp(root/name,label+'/'+name)
 groups.append({'source':str(root),'label':label,'manifest_sha256':sha(mpath),'payloads_verified':len(manifest['files'])})
base=Path('/tmp/darkbloom-q36-attention-packet-execution1')
for cell in ['qwen36-contiguous-control','qwen36-paged-control','qwen36-contiguous-owner0-packet','qwen36-paged-owner0-packet']:
 add(base/cell,'raw/'+cell,extras=('completion-receipt.json',))
add(Path('/tmp/darkbloom-q36-attention-packet-plan1'),'source-plan')
add(base,'controller','preparation-manifest.json',extras=('runtime-binding.json',))
add(Path('/tmp/darkbloom-q36-attention-packet-binding-prep1'),'runtime-binding-preparation')
add(Path('/tmp/darkbloom-q36-attention-packet-staging-prep1'),'staging-preparation')
add(Path('/tmp/darkbloom-q36-attention-packet-transfer1'),'transfer')
add(Path('/tmp/darkbloom-q36-owner0-packet-analysis1'),'analysis')
for name in ['darkbloom-attention-packet-root-release-review1.json','darkbloom-q36-attention-packet-root-controller-review1.json','darkbloom-q36-attention-packet-root-binding-review1.json','darkbloom-q36-attention-packet-root-staging-review1.json','darkbloom-q36-attention-packet-final-postflight1.json','darkbloom-q36-attention-packet-local-invocations3.json']:
 cp(Path('/tmp')/name,'reviews-and-runtime/'+name)
release=Path('/tmp/darkbloom-attention-packet-release-build1')
for name in ['manifest.json','artifact-manifest.json','source-union.json','verdict.json']:
 cp(release/name,'release-build-provenance/'+name)
for name in ['common.py','preflight.py']:
 cp(Path('/tmp/darkbloom-connected-http6-execution-prep2')/name,'shared-staging-transport/'+name)
cp(Path(__file__),'freeze.py')
save(PAYLOAD/'source-correspondence.json',{'groups':groups,'scope':'Four raw selected-owner model cells with original strict backend FAIL preserved, descriptive numerical analysis and exact reviewed source/runtime/transfer identity. Raw native activation packets are test evidence, not weights. Runtime executables/metallib/model weights/keys excluded; completed release-build identities reference separately banked build evidence. No model replay or release gate.'})
files={str(p.relative_to(PAYLOAD)):item(p) for p in sorted(PAYLOAD.rglob('*')) if p.is_file()}
assert len(directories)==2
save(OUT/'manifest.json',{'status':'FOUR_INTEGRITY_CELLS_PASS_STRICT_BACKEND_TOKENS_FAIL','directories':directories,'files':files})
archive=OUT/'payloads.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for name in sorted(directories):tar.add(PAYLOAD/name,arcname=name,recursive=False)
 for name in sorted(files):tar.add(PAYLOAD/name,arcname=name,recursive=False)
with tarfile.open(archive) as tar:
 members=tar.getmembers();assert len(members)==len(files)+2
 for m in members:
  if m.isdir():assert m.name in directories and m.mode==0o700
  else:assert m.isfile() and m.name in files and hashlib.sha256(tar.extractfile(m).read()).hexdigest()==files[m.name]['sha256']
summary={'manifest':item(OUT/'manifest.json'),'archive':item(archive),'regular_file_payloads':len(files),'private_packet_directories':len(directories),'archive_members':len(files)+len(directories),'analysis_sha256':sha(Path('/tmp/darkbloom-q36-owner0-packet-analysis1/analysis.json')),'scope':'Four integrity cells pass; backend token equality remains failed. Captured Q/K/V/scale equal, output786/4096 native elements differ; descriptive FP32 comparison only.'}
save(OUT/'summary.json',summary);print(json.dumps(summary,indent=2))
