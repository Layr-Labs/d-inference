from pathlib import Path
import hashlib,json,statistics,sys
OUT=Path(__file__).resolve().parent
EXEC=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-execution1')
PLAN=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-plan1')
sys.path.insert(0,str(EXEC))
from strict_results import chunk_timing,matched_errors

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads(p.read_text())
def distribution(values):return {'values':values,'median':statistics.median(values),'min':min(values),'max':max(values)}
def main():
 plan=load(PLAN/'plan.json');reports={};raw={};proof={}
 for cell in plan['cells']:
  root=EXEC/cell['id'];manifest=load(root/'manifest.json')
  for n,item in manifest['files'].items():
   p=root/n;assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256']
  s=load(root/'summary.json');assert s['exit_code']==0 and s['report_integrity_passed'] and not s['errors']
  r=load(root/'report.json');reports[cell['id']]=r
  raw[cell['id']]={'variant':cell['variant'],'mtp':cell['mtp'],'repeat':cell['repeat'],'first':chunk_timing(r['rows'][0]),'repeat_row':chunk_timing(r['rows'][1]),'whole_wrapper_s':load(root/'execution.json')['seconds']}
  proof[cell['id']]={'manifest_sha256':sha(root/'manifest.json'),'report_sha256':sha(root/'report.json')}
 modes={}
 for mode in ['off','on']:
  cells=[c for c in plan['cells']if c['mtp']==mode];reference=reports[cells[0]['id']]
  for c in cells:assert not matched_errors(reference,reports[c['id']])
  pairs=[]
  for repeat in [1,2,3]:
   selected={c['variant']:c for c in cells if c['repeat']==repeat};a=raw[selected['baseline']['id']];b=raw[selected['candidate']['id']]
   measures={}
   for row in ['first','repeat_row']:
    x,y=a[row],b[row]
    measures[row]={'baseline':x,'candidate':y,'ttft_saved_s':x['native_ttft_s']-y['native_ttft_s'],'full_delivery_interval_saved_s':x['delivery_interval_s']-y['delivery_interval_s'],'delivered_throughput_change_percent':100*(y['delivered_tokens_per_s']/x['delivered_tokens_per_s']-1),'prefix_interval_saved_s':x['prefix']['since_first_delivery_s']-y['prefix']['since_first_delivery_s']}
   pairs.append({'repeat':repeat,'order':[c['variant']for c in cells if c['repeat']==repeat],'rows':measures})
  summary={row:{field:distribution([p['rows'][row][field]for p in pairs])for field in ['ttft_saved_s','full_delivery_interval_saved_s','delivered_throughput_change_percent','prefix_interval_saved_s']}for row in ['first','repeat_row']}
  modes[mode]={'whole_trajectories_exact_all_six_cells':True,'prompt_tokens':reference['rows'][0]['prompt_tokens'],'completion_tokens':reference['rows'][0]['completion_tokens'],'pairs':pairs,'summary':summary}
 result={'scope':'Three matched pairs per MTP mode, same host/B1/paged/cache-off/diagnostics-off. Batch-aware delivery measurements, not per-token kernel timing or fleet acceptance.','primary_row':'repeat_row','timing_definition':'After-first-chunk delivered tokens divided by last-minus-first delivery time. Prefix crossing reports whole delivery chunk and marks straddles.','source_delta':'Provider/harness byte-identical; native four production cache paths/two tests plus two unused additive replay SPI paths. Resources identical.','plan_sha256':sha(PLAN/'manifest.json'),'source_proof':proof,'modes':modes,'raw':raw}
 (OUT/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({m:r['summary']['repeat_row']for m,r in modes.items()},indent=2))
if __name__=='__main__':main()
