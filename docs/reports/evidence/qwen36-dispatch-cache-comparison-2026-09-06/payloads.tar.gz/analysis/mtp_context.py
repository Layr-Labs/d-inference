"""Descriptive scheduling context; never changes the exact-output acceptance gate."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
EX=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-execution1')
plan=json.loads(Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-plan1/plan.json').read_text())
result={};identity=None
for cell in plan['cells']:
 if cell['mtp']!='on':continue
 p=EX/cell['id']/'report.json';r=json.loads(p.read_text());current=r['metrics_loaded']['assistant_identity']
 if identity is None:identity=current
 assert current==identity and current['source']=='inline'
 rows=[]
 for row in r['rows']:
  before=row['metrics_before']['mtp'];after=row['metrics_after']['mtp']
  delta={key:after[key]-before[key]for key in ['rounds','proposed_tokens','accepted_tokens','emitted_tokens','rectangular_rounds','serial_rounds','seed_steps']}
  delta['depth_selections']={key:after['depth_selections'].get(key,0)-before['depth_selections'].get(key,0)for key in sorted(set(before['depth_selections'])|set(after['depth_selections']))}
  rows.append({'id':row['id'],'chunk_count':len(row['chunks']),'chunk_token_counts':[len(c['tokens'])for c in row['chunks']],'mtp_delta':delta})
 result[cell['id']]={'report_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'rows':rows}
(ROOT/'mtp-context.json').write_text(json.dumps({'scope':'Observed adaptive MTP scheduling context for the six completed matched controls. No per-token kernel timing or attribution of scheduler variation.','assistant_identity':identity,'cells':result},indent=2)+'\n')
