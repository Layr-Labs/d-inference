import Foundation
import MLX
import MLXLMCommon

/// Offline measurement access to a real production slot. Raw events preserve
/// token IDs; HTTP framing and bridge admission timing are intentionally absent.
@_spi(Benchmarking)
public actor EngineV2BenchmarkSession {
    public struct Submission: Sendable {
        public let receiptID: CBv2RequestID
        public let events: AsyncStream<CBv2Event>
        public let stageMilliseconds: Double
        public let stageDisposition: String
    }

    public struct CacheSnapshot: Sendable {
        public let durableMode: String?
        public let keyMode: String?
        public let status: PrefixCacheModelStatus
        public let memoryEnabled: Bool
        public let recurrentBankBudgetBytes: Int
        public let engineKVCapacityBytes: Int
        public let physicalMemoryBytes: UInt64
        public let activationReserveBytes: UInt64
        public let postLoadMaximumKVBytes: UInt64
        public let checkpoints: SSDHybridCheckpointStats?
        public let attention: SSDPrefixCacheStats?
        public let processMemory: ProcessMemoryTelemetry?
        public let assistantIdentity: [String: String]
    }

    public enum Failure: Error {
        case invalidVerifiedWeightHash, invalidCapacity, mtpUnavailable
        case unexpectedEngine, unexpectedResidentCache, ssdUnavailable, persistentKeyUnavailable
        case closed, requestAlreadyActive, receiptIDsExhausted
    }

    /// Use for metric snapshots/cancellation only. Submit through this session
    /// so a checkpoint's unique receipt and staging lifetime remain paired.
    public nonisolated let rawEngine: EngineV2
    public nonisolated let backend: String
    public nonisolated let backendFallback: String?
    private let bundle: ProviderEngineBundle
    private let budget: GlobalKVCacheBudget
    private let assistantIdentity: [String: String]
    private var memorySampler = ProcessMemoryTelemetrySampler()
    private let memoryEnabled: Bool
    private let activationReserveBytes: UInt64
    private let postLoadMaximumKVBytes: UInt64
    private var nextReceipt: UInt64 = 1
    private var active: [CBv2RequestID: CBv2RequestID] = [:]
    private var closed = false

    fileprivate init(
        bundle: ProviderEngineBundle, engine: EngineV2,
        backend: String, fallback: String?, memoryEnabled: Bool,
        activationReserveBytes: UInt64, postLoadMaximumKVBytes: UInt64,
        budget: GlobalKVCacheBudget, assistantIdentity: [String: String]
    ) {
        self.bundle = bundle
        self.budget = budget
        self.assistantIdentity = assistantIdentity
        self.rawEngine = engine
        self.backend = backend
        self.backendFallback = fallback
        self.memoryEnabled = memoryEnabled
        self.activationReserveBytes = activationReserveBytes
        self.postLoadMaximumKVBytes = postLoadMaximumKVBytes
    }

    public func cacheSnapshot() -> CacheSnapshot {
        CacheSnapshot(
            durableMode: bundle.bridge.ssdHybridCheckpointStore != nil ? "ssd_complete"
                : bundle.bridge.ssdPrefixCache != nil ? "ssd_attention" : nil,
            keyMode: bundle.bridge.ssdHybridCheckpointStore.map { $0.usesEphemeralKey ? "ephemeral" : "persistent" },
            status: bundle.bridge.prefixCacheModelStatus(),
            memoryEnabled: memoryEnabled,
            recurrentBankBudgetBytes: rawEngine.hybridPrefixCache?.config.maximumBytes ?? 0,
            engineKVCapacityBytes: rawEngine.capacity().kvBytesCapacity,
            physicalMemoryBytes: ProcessInfo.processInfo.physicalMemory,
            activationReserveBytes: activationReserveBytes,
            postLoadMaximumKVBytes: postLoadMaximumKVBytes,
            checkpoints: bundle.bridge.ssdHybridCheckpointStore?.stats(),
            attention: bundle.bridge.ssdPrefixCache?.stats(),
            processMemory: memorySnapshot(), assistantIdentity: assistantIdentity)
    }

    /// Read the same coherent shared ledger used by this production slot.
    /// This benchmark-only capture never inspects mutable native pool state.
    public func memorySnapshot() -> ProcessMemoryTelemetry? {
        memorySampler.capture(budget.memoryHeadroomSnapshot())
    }

    /// Start the caller's TTFT clock BEFORE awaiting this method. It returns
    /// the engine's original stream after production SSD staging, without a
    /// relay task. Call complete(receiptID:) after fully draining that stream.
    public func submit(_ input: CBv2Request) async throws -> Submission {
        guard !closed else { throw Failure.closed }
        guard !active.values.contains(input.id) else { throw Failure.requestAlreadyActive }
        guard nextReceipt < UInt64.max else { throw Failure.receiptIDsExhausted }
        // Separate identity domain from deterministic sampling IDs. The maps
        // never treat a reused engine ID as ownership of an older submission.
        let receiptID = CBv2RequestID(nextReceipt)
        nextReceipt += 1
        active[receiptID] = input.id
        var request = input
        request.prefixCacheReceiptID = receiptID
        do {
            var stage: SSDPrefixCacheStageResult?
            if input.prefixCacheEnabled, input.multimodal == nil, input.positionState == nil {
                if let store = bundle.bridge.ssdHybridCheckpointStore {
                    let importRequest = request
                    stage = await store.stage(
                        requestID: receiptID, request: importRequest,
                        reserveReadScratch: { [rawEngine] in try rawEngine.reserveCompleteCheckpointReadScratch() }
                    ) { [rawEngine] in
                        try rawEngine.planCompleteCheckpointImport(manifest: $0, request: importRequest)
                    }
                } else if let store = bundle.bridge.ssdPrefixCache {
                    let resident = rawEngine.residentPrefixCandidate(for: request)
                    if resident == nil || store.estimatedPrefillTokensSaved(
                        promptTokens: input.promptTokens, cacheScope: input.cacheSalt ?? "")
                        > (resident?.prefillTokensSaved ?? 0) {
                        stage = await store.stage(
                            requestID: receiptID, promptTokens: input.promptTokens,
                            cacheScope: input.cacheSalt ?? "")
                    }
                }
            }
            try Task.checkCancellation()
            guard !closed else { throw Failure.closed }
            let events = try rawEngine.submit(request)
            return Submission(
                receiptID: receiptID, events: events,
                stageMilliseconds: stage?.stageMs ?? 0,
                stageDisposition: stage.map { Self.describe($0.disposition) } ?? "not_attempted")
        } catch {
            active.removeValue(forKey: receiptID)
            await retireStage(receiptID)
            throw error
        }
    }

    /// Caller drains the raw terminal first; this is the idempotent store
    /// backstop used by the production bridge's terminal pump as well.
    public func complete(receiptID: CBv2RequestID) async {
        guard active.removeValue(forKey: receiptID) != nil else { return }
        await retireStage(receiptID)
        // After a serial row, include the final actor-based refund in idle
        // metrics. An active concurrent row must not wait for another's stage.
        if active.isEmpty {
            await bundle.bridge.ssdHybridCheckpointStore?.activity.waitUntilDrained()
        }
    }

    private func retireStage(_ receiptID: CBv2RequestID) async {
        await bundle.bridge.ssdHybridCheckpointStore?.abandonStaging(requestID: receiptID)
        bundle.bridge.ssdHybridCheckpointStore?.discardReadyReceipt(requestID: receiptID)
        await bundle.bridge.ssdPrefixCache?.abandonStaging(requestID: receiptID)
        bundle.bridge.ssdPrefixCache?.discardReadyReceipt(requestID: receiptID)
    }

    public func shutdown() async {
        guard !closed else { return }
        closed = true
        await bundle.bridge.shutdown()
        active.removeAll()
        bundle.releaseAssistant()
    }

    private static func describe(_ disposition: SSDPrefixCacheStageDisposition) -> String {
        switch disposition {
        case .staged: "staged"
        case .missAbsent: "miss_absent"
        case .missCorrupt: "miss_corrupt"
        case .skippedCapacity: "skipped_capacity"
        case .skippedCost: "skipped_cost"
        case .skippedPolicy: "skipped_policy"
        }
    }
}

extension EngineV2Factory {
    /// Benchmark construction uses the normal slot factory and its identity,
    /// assistant and cache gates. The caller must compute fresh equal weight
    /// hashes before/after loading the container; passing the verified digest
    /// here avoids a redundant third model read. No assembly override is used.
    @_spi(Benchmarking)
    public static func makeBenchmarkSession(
        modelId: String, modelDirectory: URL, isVLM: Bool,
        container: ModelContainer, tokenizer: TokenizerHandle,
        verifiedWeightHash: String, kvBytesCapacity: Int,
        maxConcurrentRequests: Int = 1, mtpEnabled: Bool,
        assistantDirectory: URL? = nil,
        kvBudget: GlobalKVCacheBudget? = nil,
        kvBackendConfig: String = "auto",
        requirePersistentKey: Bool = true,
        environment: [String: String] = ProcessInfo.processInfo.environment
    ) async throws -> EngineV2BenchmarkSession {
        guard PrefixCachePolicy.checkpointIdentityHash(verifiedWeightHash) != nil else {
            throw EngineV2BenchmarkSession.Failure.invalidVerifiedWeightHash
        }
        guard kvBytesCapacity > 0, maxConcurrentRequests > 0 else {
            throw EngineV2BenchmarkSession.Failure.invalidCapacity
        }
        var effectiveEnvironment = environment
        if requirePersistentKey,
            let testRoot = environment["DARKBLOOM_PREFIX_CACHE_TEST_ROOT"], !testRoot.isEmpty
        {
            // Keep the isolated payload directory while exercising the normal
            // persistent KEK path. Verify the actual key mode below.
            effectiveEnvironment["DARKBLOOM_PREFIX_CACHE_TEST_PERSISTENT_KEY"] = "1"
        }
        struct Declaration: Decodable {
            let modelType: String?
            enum CodingKeys: String, CodingKey { case modelType = "model_type" }
        }
        let declaration = try JSONDecoder().decode(Declaration.self,
            from: Data(contentsOf: modelDirectory.appendingPathComponent("config.json")))
        let preparation = try await benchmarkAssistantPreparation(
            modelId: modelId, modelType: declaration.modelType, modelDirectory: modelDirectory,
            enabled: mtpEnabled, assistantDirectory: assistantDirectory, environment: effectiveEnvironment)
        let prepared = try await EngineV2SlotFactory.prepareProductionModel(
            modelId: modelId, isVLM: isVLM, modelDirectory: modelDirectory,
            container: container, specDecPreparation: preparation)
        guard !mtpEnabled || prepared.mtpStatus.active else {
            prepared.assistant?.release()
            throw EngineV2BenchmarkSession.Failure.mtpUnavailable
        }
        let sizing = await SlotSizingSnapshot.build(
            container: container, modelPath: modelDirectory, fallbackDefaultMaxTokens: 8192)
            .replacingAuxiliaryWeightBytes(prepared.assistantBytes)
        let reserve = UnifiedMemoryCap.resolvedActivationReserveBytes(
            env: effectiveEnvironment, modelIDs: [modelId])
        // A benchmark grant is a slot ceiling, not the host's physical RAM.
        // Use the same production cap and model-specific activation reserve;
        // all currently active MLX allocations conservatively count as loaded
        // weights here. Runtime shared-budget checks still apply to staging.
        let maximumKVBytes = UnifiedMemoryCap.kvBudgetBytes(
            residentWeightBytes: UInt64(Memory.activeMemory), activationReserveBytes: reserve)
        guard UInt64(kvBytesCapacity) <= maximumKVBytes else {
            prepared.assistant?.release()
            throw EngineV2BenchmarkSession.Failure.invalidCapacity
        }
        // The default belongs to one isolated session. Multi-session callers
        // must inject their single process authority, with a serving-set floor
        // covering every model they keep resident or draining.
        let budget = kvBudget ?? GlobalKVCacheBudget(activationReserveBytes: reserve)
        let bundle: ProviderEngineBundle
        do {
            bundle = try await EngineV2SlotFactory.makeProductionBundle(
                modelId: modelId, modelType: declaration.modelType, isVLM: isVLM,
                modelDirectory: modelDirectory, container: container, tokenizer: tokenizer,
                sizing: sizing, kvBytesCapacity: kvBytesCapacity,
                maxConcurrentRequests: maxConcurrentRequests, kvBudget: budget,
                activationReserveBytes: reserve, kvBackendConfig: kvBackendConfig,
                weightHash: verifiedWeightHash, specDecPreparation: preparation,
                preparedModel: prepared, environment: effectiveEnvironment)
        } catch {
            prepared.assistant?.release()
            throw error
        }
        guard let engine = await bundle.bridge.ownedEngine as? EngineV2 else {
            await bundle.bridge.shutdown()
            bundle.releaseAssistant()
            throw EngineV2BenchmarkSession.Failure.unexpectedEngine
        }
        guard !mtpEnabled || (bundle.mtpStatus.active && engine.mtpMetricsSnapshot() != nil) else {
            await bundle.bridge.shutdown()
            bundle.releaseAssistant()
            throw EngineV2BenchmarkSession.Failure.mtpUnavailable
        }
        guard !PrefixCachePolicy.isMemoryEnabled(environment: effectiveEnvironment),
            engine.hybridPrefixCache == nil else {
            await bundle.bridge.shutdown()
            bundle.releaseAssistant()
            throw EngineV2BenchmarkSession.Failure.unexpectedResidentCache
        }
        if PrefixCachePolicy.isEnabled(environment: effectiveEnvironment) {
            guard bundle.bridge.durablePrefixCacheEvidenceSource != nil,
                bundle.bridge.prefixCacheModelStatus().state == .ready else {
                await bundle.bridge.shutdown()
                bundle.releaseAssistant()
                throw EngineV2BenchmarkSession.Failure.ssdUnavailable
            }
        }
        if requirePersistentKey, bundle.bridge.ssdHybridCheckpointStore?.usesEphemeralKey == true {
            await bundle.bridge.shutdown()
            bundle.releaseAssistant()
            throw EngineV2BenchmarkSession.Failure.persistentKeyUnavailable
        }
        let backend = await bundle.bridge.kvBackendKind.rawValue
        let fallback = await bundle.bridge.kvBackendFallbackReason
        return EngineV2BenchmarkSession(
            bundle: bundle, engine: engine,
            backend: backend, fallback: fallback,
            memoryEnabled: PrefixCachePolicy.isMemoryEnabled(environment: effectiveEnvironment),
            activationReserveBytes: reserve, postLoadMaximumKVBytes: maximumKVBytes,
            budget: budget, assistantIdentity: benchmarkAssistantIdentity(preparation.artifact))
    }
}
