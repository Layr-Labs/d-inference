import copy
import hashlib
from pathlib import Path
import tempfile
import unittest

from run_connected_fixture import verify_local_assistant


class LocalAssistantTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.directory = Path(self.temporary.name).resolve()
        files = {'config.json': b'{}', 'model.safetensors': b'exact fixture weights'}
        manifest = {'model_id': 'assistant', 'files': []}
        for name, content in files.items():
            (self.directory/name).write_bytes(content)
            manifest['files'].append({'path': name, 'size_bytes': len(content),
                                     'sha256': hashlib.sha256(content).hexdigest()})
        self.data = {'artifact': {'model_id': 'target'},
                     'assistant_path': str(self.directory),
                     'catalog': [{'Entry': {'id': 'target'}, 'Manifest': {}},
                                 {'Entry': {'id': 'assistant'}, 'Manifest': manifest}]}

    def test_exact_override_uses_external_manifest(self):
        proof = verify_local_assistant(self.data)
        self.assertEqual(proof['path'], str(self.directory))
        self.assertEqual(set(proof['files']), {'config.json', 'model.safetensors'})
        self.assertIsNone(verify_local_assistant({'artifact': {'model_id': 'target'}}))

    def test_original_three_file_layout_is_rejected(self):
        (self.directory/'manifest.json').write_text('{}')
        with self.assertRaisesRegex(ValueError, 'exactly'):
            verify_local_assistant(self.data)

    def test_declared_override_weights_are_verified(self):
        weights = self.directory/'model.safetensors'
        original = weights.read_bytes()
        weights.write_bytes(b'x' * len(original))
        with self.assertRaisesRegex(ValueError, 'exact snapshot mismatch'):
            verify_local_assistant(self.data)

    def test_symlink_is_not_a_regular_override(self):
        weights = self.directory/'model.safetensors'
        original = weights.read_bytes()
        weights.unlink()
        external = self.directory.parent/(self.directory.name+'-external')
        external.write_bytes(original)
        self.addCleanup(external.unlink)
        weights.symlink_to(external)
        with self.assertRaisesRegex(ValueError, 'without symlinks'):
            verify_local_assistant(self.data)

    def test_missing_or_ambiguous_manifest_is_rejected(self):
        for catalog in [self.data['catalog'][:1],
                        self.data['catalog'] + [self.data['catalog'][1]]]:
            with self.subTest(catalog_count=len(catalog)):
                data = dict(self.data, catalog=catalog)
                with self.assertRaisesRegex(ValueError, 'one external'):
                    verify_local_assistant(data)

    def test_manifest_cannot_authorize_extra_non_engine_file(self):
        data = copy.deepcopy(self.data)
        data['catalog'][1]['Manifest']['files'].append(
            {'path': 'manifest.json', 'size_bytes': 2, 'sha256': hashlib.sha256(b'{}').hexdigest()})
        (self.directory/'manifest.json').write_bytes(b'{}')
        with self.assertRaisesRegex(ValueError, 'only config'):
            verify_local_assistant(data)


if __name__ == '__main__':
    unittest.main()
