from pathlib import Path
import hashlib,json,shutil,difflib
OUT=Path(__file__).resolve().parent
SOURCE=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-plan1')
OLD=Path('/tmp/darkbloom-qat-mtp-off-execution2')
BINDING=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-binding1.json')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,j):p.write_text(json.dumps(j,indent=2,sort_keys=True)+'\n')
plan=json.loads((SOURCE/'plan.json').read_text())
assert sha(SOURCE/'manifest.json')=='47b0c995470f246f01014947bf9d1d8f7d3857cee9976846aefde8a5908d2916'
variants={}; checked={}
for variant,root,expected in [('baseline',Path('/tmp/darkbloom-generic-qat-release-probe1'),'61672b2d984cfa5a26fe5febdd3b957122d3899e00394312c249a49482a65eba'),('candidate',Path('/tmp/darkbloom-segment-dispatch-cache-release-probe2'),'9819eebfe113da5b7267a5fbd9c7f3542954eca8c9d5ea48438260c340b53a05')]:
 assert sha(root/'manifest.json')==expected
 manifest=json.loads((root/'manifest.json').read_text())
 for name,item in manifest['files'].items():
  p=root/name;assert p.is_file() and not p.is_symlink()
  assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],name
  if 'mode'in item:assert p.stat().st_mode&0o777==int(item['mode'],8),name
 a=json.loads((root/'artifact-manifest.json').read_text())
 variants[variant]={'artifacts':a['files'],'local_artifact_root':str(root/'artifact'),'parent_commit':a['parent_commit'],'native_commit':a['native_commit'],'manifest_path':str(root/'manifest.json'),'manifest_sha256':expected}
 checked[variant]={'files':len(manifest['files']),'manifest_sha256':expected}
assert len(variants['candidate']['artifacts'])==len(variants['baseline']['artifacts'])==7
assert {k:v for k,v in variants['baseline']['artifacts'].items()if k!='radix-engine'}=={k:v for k,v in variants['candidate']['artifacts'].items()if k!='radix-engine'}
delta=Path('/tmp/darkbloom-segment-dispatch-cache-release-probe2/delta-from-generic-probe.json')
d=json.loads(delta.read_text());assert d['groups']['provider']==d['groups']['harness']=={}
assert len(d['groups']['native'])==8 and len(d['cache_candidate'])==6
review=OUT/'runtime-peer-check.json'
dump(review,{'status':'PASS','checked':checked,'six_resources_exact':True,'source_delta':{'path':str(delta),'sha256':sha(delta)},'scope':'Exact frozen build/artifact/source delta review; no new performance result.'})
b={'state':'runtime_bound_execution_review_pending','remote_root':plan['remote_root'],'plan_manifest_sha256':sha(SOURCE/'manifest.json'),'input_sha256':plan['input_sha256'],'model_sha256':plan['cells'][0]['argv'][-7], 'min_free_bytes':100*1024**3,'variants':variants,'review':str(review),'review_sha256':sha(review),'commands':[{'cell':c['id'],'wrapper_argv':c['argv'],'expected_observed_native_argv':c['expected_observed_native_argv'],'variant':c['variant']}for c in plan['cells']],'scope':plan['scope'],'timing_definition':'Post-first-chunk delivered tokens / (last delivery - first delivery); record batch sizes and complete/prefix timing separately.'}
b['model_sha256']=plan['cells'][0]['argv'][plan['cells'][0]['argv'].index('--expected-model-sha256')+1]
dump(BINDING,b)
shutil.copy2(OLD/'preflight.py',OUT/'preflight.py')
text=(OLD/'run_cell.py').read_text()
replacements={str(OLD):str(OUT),'/private/tmp/darkbloom-qat-mtp-off-plan1':str(SOURCE),'/tmp/darkbloom-qat-mtp-off-runtime-binding1.json':str(BINDING),'cff10f1a674c260d9a5a76ca0667d0697ae8f8050a42fb22734d5c217e2aa29d':sha(SOURCE/'manifest.json'),'799ef0bf52e46d0b5c6e7620c414a1602d41511ffc0ebd93c0fe412bce7c8e1f':sha(BINDING),"assert len(plan['cells']) == 2 and [c['backend'] for c in plan['cells']] == ['contiguous', 'paged']":"assert len(plan['cells']) == 12 and all(c['backend'] == 'paged' for c in plan['cells'])", "chosen['trace']":"False"}
for a,z in replacements.items():assert a in text,a;text=text.replace(a,z)
text=text.replace("for name,item in binding['artifacts'].items():\n p=root/'runtime'/name", "for name,item in binding['variants'][VARIANT]['artifacts'].items():\n p=root/'runtime'/VARIANT/name")
start=text.index("assistant=binding['assistant']")
end=text.index('free=shutil.disk_usage(root)',start)
text=text[:start]+text[end:]
text=text.replace("'assistant_verified':assistant,", "'variant':VARIANT,")
text=text.replace(".replace('ARGV', repr(command))", ".replace('ARGV', repr(command)).replace('VARIANT', repr(chosen['variant']))")
start=text.index("        if chosen['backend'] == 'paged':")
end=text.index("        metadata=report.get",start)
text=text[:start]+text[end:]
text=text.replace("'scope':'Two same-build QAT cache-off/B1/normal-grant MTP-off backend controls, no diagnostics. Determine whether full-token divergence persists outside verification; normal-MTP failure remains separate.'", "'scope':plan['scope']")
text=text.replace("'trace':False,", "'trace':False,'variant':chosen['variant'],'mtp':chosen['mtp'],")
text=text.replace("e64a8b6f565d2e93eb13655715b490e4cc39f85f53dd2241dca580e49ae61d52",sha(OUT/'strict_results.py'))
# Leave serial wrapper ownership and its timeout unchanged. Bound short transport calls use keepalives.
text=text.replace("'-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15'", "'-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', '-o', 'ServerAliveInterval=15', '-o', 'ServerAliveCountMax=4'")
text=text.replace("input=code, text=True, capture_output=True)","input=code, text=True, capture_output=True, timeout=120)")
start=text.index('        if False:')
end=text.index('        summary.update',start)
text=text[:start]+text[end:]
compile(text,'run_cell.py','exec');(OUT/'run_cell.py').write_text(text)
(OUT/'driver-delta.patch').write_text(''.join(difflib.unified_diff((OLD/'run_cell.py').read_text().splitlines(True),text.splitlines(True),fromfile='qat-mtp-off-execution2/run_cell.py',tofile='q36-comparison/run_cell.py')))
print(json.dumps({'binding_sha256':sha(BINDING),'builds_checked':checked},indent=2))
