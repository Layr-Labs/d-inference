# Cache routing generation ownership

The patch prevents stale plans, receipt metadata and routing costs from surviving configuration replacement or queued-attempt revocation. It preserves ordinary encrypted inference, deadlines, tenant/model/contract identity, current positive cache-credit limits, terminal receipt grace and existing rollout defaults. The source is validated in isolated worktrees and remains uncommitted for the root's milestone bank.

## Before

```mermaid
flowchart LR
  A[Sidecar plan] --> B[Mutable current tracker accessed repeatedly in Prepare]
  B --> C[Copy raw request cache fields into queued frame]
  C --> D[Send copied cache scope after configuration or cancellation changes]
  A --> E[Price a same-content holder from a replacement tracker]
```

## After

```mermaid
flowchart LR
  A[Capture configuration generation] --> B[Sidecar IO outside locks]
  B --> C[Validate plan generation]
  C --> D[Query matching generation and fence captured hints]
  D --> E[Prepare one tracker-bound owner]
  E --> F[Revalidate generation connection capability and request ticket]
  F --> G[Queue immutable owner]
  G --> H{Current at dequeue?}
  H -- yes --> I[Encrypted scoped cache request]
  H -- revoked --> J[Ordinary encrypted request with same deadline]
  I --> K[Terminal receipt grace on original owner]
```

## Ownership and locking

- Configuration revokes the old immutable generation under the registry lock, then drains the old tracker separately. Plans retain only the small generation identity, not tracker maps.
- Prepare snapshots one tracker under the registry lock. Nonce generation and boundary allocation run outside locks. Tracker insertion finishes before publication locks.
- Publication takes registry → provider → request locks; stale publication removes only its captured nonce after those locks are released.
- Forget/terminal take the request lock, release it, then clean up the original tracker. No request-lock → registry/provider/tracker nesting exists.
- Quarantine commits current-connection/capability validation and tracker invalidation under registry → provider → tracker order. The tracker performs no IO, registry callbacks or provider-lock acquisition.
- Dequeue only reads atomics and updates an atomic per-owner prepared/accepted/cold observation. JSON and socket IO take no registry/tracker lock. Already accepted writes remain excluded from ordinary latency calibration.
- Four dead duplicate PendingRequest cache wire fields and their setters were deleted. The immutable owner is the only dispatch source. LegacyCacheBustKey remains because protocol-0 encrypted request bodies still use it.

## Verification

Final isolated full Go run: 2568 top-level tests and 1524 subtests passed. Two pre-existing tests skipped: TestPerfE2E_ChatCompletions and TestVerifyProviderViaMDM_TimeoutTransient. Focused race: 154 top-level tests and 220 subtests passed. Combined race over parent a9eee787 plus the signed-cost fixture adjustment: 160 top-level tests and 240 subtests passed. All source hashes match review1. Documentation check passed 161 files; gofmt and git diff --check pass.

The earlier baseline fails all seven regression scenarios: two stale sidecar returns (same-key replacement/off) and five queued scope cases (replacement/off/Forget/terminal/disconnect). Normal sidecar completion and cancellation controls pass. Baseline fixtures omit only private-generation assertions unavailable in that older API.

Five 200ms microbenchmark samples on Go 1.25.0, darwin/arm64, Apple M3 Max: ordinary frame median 383.5 → 389.6 ns/op; prepared frame 505.5 → 515.0 ns/op. Both keep 3 allocations, with 448 and 640 bytes/op respectively. Candidate dequeue alone is 1.539/2.620/13.14 ns/op for ordinary/prepared/revoked cases and allocates zero bytes. These are small shared-host CPU measurements, not live network/model latency or a speedup claim.

## Read-only lifecycle audit

The production WebSocket handler allocates a fresh UUID for each connection (coordinator/api/provider.go:139) and refuses a second registration on that connection. Direct synthetic Registry ID reuse can let delayed, pre-existing tracker.disconnect(id) clear replacement cache metadata, including holder, attempt, sequence and quarantine records. The cleanup still operates on only the old Provider's pending map; exact Provider-pointer and nonce guards reject cross-connection receipts. This existing ID-reuse metadata-loss/reset case is outside this bounded slice; no global-lock tracker sweep was introduced.

Terminal PendingRequest objects are not reused for retry. dispatchWithReserver constructs a new UUID and PendingRequest for every primary, retained-plan retry/refresh and speculative backup. Queue dispatch uses its distinct queuePR only before first assignment; cancellation after assignment is terminal, not requeued. Promotion reuses a still-active backup, never the terminal loser. Relevant code: consumer.go:1034–1044, dispatch_plan_wiring.go:83, dispatch.go:1383, scheduler.go:3144.

## Integration

Apply source.patch on the later parent; do not overwrite whole older-base file snapshots. All Go hunks apply cleanly to a9eee787. Merge cache-aware-routing.md's freshness/context hunk while preserving the already banked signed-cost explanation. The banked cache_checkpoint_stage_cost_test.go needs the one-line integration/signed-cost-fixture-followup.patch so its synthetic plan has explicit current-generation provenance. The combined race run includes this exact adjustment. No primary worktree, Swift/Metal source or production configuration was changed.
