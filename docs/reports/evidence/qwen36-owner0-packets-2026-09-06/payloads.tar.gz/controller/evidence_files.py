"""Bounded source/evidence checks shared by controller and CPU fault tests."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import stat

sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def verify_manifest(root, expected_hash, name='manifest.json'):
    path = root/name
    assert sha(path) == expected_hash, 'manifest hash mismatch'
    for relative, row in json.loads(path.read_text())['files'].items():
        p = root/relative
        assert stat.S_ISREG(p.lstat().st_mode), relative
        assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], relative
        if 'mode' in row: assert oct(stat.S_IMODE(p.stat().st_mode)) == row['mode'], relative


def prior_cells(plan, chosen, output_root):
    for prior in plan['cells'][:plan['cells'].index(chosen)]:
        root = output_root/prior['id']
        summary = json.loads((root/'summary.json').read_text())
        assert summary['exit_code'] == 0 and summary['report_integrity_passed'], 'Prior failed or incomplete cell blocks successor'
        receipt = json.loads((root/'completion-receipt.json').read_text())
        verify_manifest(root, receipt['manifest_sha256'])


def remote_script(source, configuration):
    # One serialized constant, never substring replacement inside executable source.
    code = 'import json\nCONFIG = json.loads('+repr(json.dumps(configuration))+')\n'+source
    compile(code, '<rendered-remote-script>', 'exec')
    return code


def safe_download_name(name):
    parts = PurePosixPath(name).parts
    if len(parts) == 1:
        assert name in {'input.json', 'report.json', 'metadata.json', 'engine.log', 'telemetry.jsonl'}, name
    else:
        assert len(parts) == 2 and parts[0] == 'report.attention-packet', name
        assert parts[1] in {'packet.json', 'attention-metadata.json', 'queries.bin', 'incoming-keys.bin',
                           'incoming-values.bin', 'stored-keys.bin', 'stored-values.bin', 'output.bin'}, name
    return parts
