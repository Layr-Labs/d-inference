package testbed

import (
	"context"
	"crypto/rand"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"log/slog"
	"net"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/eigeninference/d-inference/coordinator/api"
	"github.com/eigeninference/d-inference/coordinator/billing"
	"github.com/eigeninference/d-inference/coordinator/payments"
	"github.com/eigeninference/d-inference/coordinator/protocol"
	"github.com/eigeninference/d-inference/coordinator/registry"
	"github.com/eigeninference/d-inference/coordinator/store"
	"github.com/eigeninference/d-inference/e2e/testbed/deps"
)

var ErrProviderIneligible = errors.New("provider lacks expected testbed capabilities")

type tcpListener struct {
	inner   net.Listener
	port    int
	baseURL string
}

func netListen() (*tcpListener, error) {
	inner, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		return nil, err
	}
	port := inner.Addr().(*net.TCPAddr).Port
	return &tcpListener{
		inner:   inner,
		port:    port,
		baseURL: "http://127.0.0.1:" + strconv.Itoa(port),
	}, nil
}

func execCommandContext(ctx context.Context, name string, args ...string) *exec.Cmd {
	return exec.CommandContext(ctx, name, args...)
}

type Suite struct {
	Ctx    context.Context
	Logger *slog.Logger
	Config SuiteConfig

	Pg          *deps.PostgresLifecycle
	PgStore     store.Store
	Coordinator *Coordinator
	Providers   []*Provider
	Users       []UserAccount

	// privacyMu guards privacyAtRegistration, written once during Start and
	// read afterwards from test goroutines.
	privacyMu sync.Mutex
	// privacyAtRegistration snapshots every provider's self-reported
	// privacy_capabilities block exactly as it arrived over the wire, taken
	// immediately BEFORE waitForProviderRegistration force-trusts the fleet.
	// Force-trust overwrites most of that block with synthetic `true`s and
	// materialises an empty one when the provider sent none, so an assertion
	// made on the live registry copy after Start cannot fail. Tests that need
	// the provider's actual claim read it through ReportedPrivacyCapabilities.
	// A key is present for every provider that registered; a nil value means
	// that provider reported no block at all.
	privacyAtRegistration map[string]*protocol.PrivacyCapabilities
	targetNonce           string
}

type Coordinator struct {
	Server   *api.Server
	Registry *registry.Registry
	baseURL  string
	port     int

	httpServer *http.Server
	cancel     context.CancelFunc
}

type Provider struct {
	Target     *ProviderTarget
	AccountID  string
	suiteNonce string
	owned      *ownedProvider

	BinaryPath    string
	Logger        *slog.Logger
	ProviderIndex int
	AuthDir       string
	// StateDir is a per-instance temp dir that holds the provider's
	// persisted state files (daemon-state.json, loaded-models.json).
	// Without it every testbed provider shares the real
	// ~/.darkbloom/loaded-models.json, so provider N+1 startup-preloads
	// (and self-tests) whatever provider N was serving — cross-test
	// state leakage that does not represent a fresh provider boot.
	StateDir string

	cmd    *os.Process
	cancel context.CancelFunc
	done   chan struct{}

	// generatedConfig holds the provider TOML this instance wrote into
	// StateDir. Every provider gets one so auto-update and auto-restart stay off;
	// KV-backend / concurrency keys remain optional within it.
	generatedConfig string
	// canonicalConfigExisted records whether ~/.config/darkbloom/provider.toml
	// was present at launch. The provider copies a --config file there when it
	// is missing; Stop undoes that copy so a testbed TOML never becomes the
	// machine's default config.
	canonicalConfigExisted bool
}

func NewSuite(cfg SuiteConfig) *Suite {
	logger := slog.New(slog.NewTextHandler(os.Stderr, &slog.HandlerOptions{Level: slog.LevelInfo}))

	if os.Getenv("DARKBLOOM_REPO_ROOT") == "" {
		if cwd, err := os.Getwd(); err == nil {
			if root, rootErr := findRepositoryRoot(cwd); rootErr == nil {
				_ = os.Setenv("DARKBLOOM_REPO_ROOT", root)
			}
		}
	}

	if len(cfg.ModelSpecs) == 0 {
		cfg.ModelSpecs = []ModelSpec{{ModelID: resolveModelID(""), NumProviders: 1}}
	}
	for i := range cfg.ModelSpecs {
		if len(cfg.ModelSpecs[i].ModelIDs) > 0 {
			for j := range cfg.ModelSpecs[i].ModelIDs {
				cfg.ModelSpecs[i].ModelIDs[j] = resolveModelID(cfg.ModelSpecs[i].ModelIDs[j])
			}
		} else {
			cfg.ModelSpecs[i].ModelID = resolveModelID(cfg.ModelSpecs[i].ModelID)
		}
		if cfg.ModelSpecs[i].NumProviders <= 0 {
			cfg.ModelSpecs[i].NumProviders = 1
		}
	}
	if cfg.NumUsers <= 0 {
		cfg.NumUsers = 1
	}
	if cfg.QueueCapacity <= 0 {
		cfg.QueueCapacity = 100
	}
	if cfg.QueueTimeout <= 0 {
		cfg.QueueTimeout = 120 * time.Second
	}
	if cfg.FirstContentDeadlineBase <= 0 {
		cfg.FirstContentDeadlineBase = ProductionFirstContentDeadlineBase
	}
	if cfg.SeedBalance <= 0 {
		cfg.SeedBalance = 100_000_000
	}

	return &Suite{
		Logger: logger,
		Config: cfg,
	}
}

func resolveModelID(modelID string) string {
	if modelID != "" {
		return modelID
	}
	if env := os.Getenv("TESTBED_MODEL_ID"); env != "" {
		return env
	}
	// v0.7.5 one-engine: only CBv2-adapted checkpoints are servable
	// (DefaultTestModelID — gpt-oss-20b unless DARKBLOOM_TESTBED_MODEL
	// overrides).
	return DefaultTestModelID()
}

func (s *Suite) PrimaryModelID() string {
	return s.Config.PrimaryModelID()
}

func (s *Suite) Start(ctx context.Context) (err error) {
	s.Ctx = ctx
	if err := validateProviderTargets(s.Config.ProviderTargets, s.Config.TotalProviders()); err != nil {
		return err
	}
	if s.Config.ProviderTargets != nil {
		if s.Config.ProviderRelay == nil || !s.Config.UseMemoryStore {
			return fmt.Errorf("owned targets require the loopback relay and isolated memory store")
		}
		if s.Config.PrefixCacheMode != "off" && s.Config.PrefixCacheMode != "ssd" {
			return fmt.Errorf("owned targets require explicit cache mode")
		}
		nonce := make([]byte, 16)
		if _, err := rand.Read(nonce); err != nil {
			return err
		}
		s.targetNonce = hex.EncodeToString(nonce)
	}

	defer func() {
		if err != nil {
			err = errors.Join(err, s.StopAndWait())
		}
	}()

	if err = s.startPostgres(); err != nil {
		return err
	}
	if err = s.createUserPool(); err != nil {
		return err
	}
	if err = s.startCoordinator(); err != nil {
		return err
	}
	if err = s.startProviders(); err != nil {
		return err
	}
	if err = s.waitForProviderRegistration(3 * time.Minute); err != nil {
		return err
	}
	// Built-backend assertion: when the lane declares an expected KV backend
	// (DARKBLOOM_TESTBED_EXPECT_KV_BACKEND or SuiteConfig.ExpectKVBackend),
	// refuse to come up until every provider slot proves the engine it
	// actually constructed matches. See kv_expectation.go.
	err = s.verifyKVBackendExpectation()
	return err
}

func (s *Suite) Stop() { _ = s.StopAndWait() }

func (s *Suite) StopAndWait() error {
	var result error
	for _, p := range s.Providers {
		result = errors.Join(result, p.StopAndWait())
	}
	if s.Config.ProviderRelay != nil {
		s.Config.ProviderRelay.Close()
	}
	if s.Coordinator != nil {
		result = errors.Join(result, s.Coordinator.Stop())
	}
	if s.Pg != nil {
		s.Pg.Stop()
	}
	return result
}

func (s *Suite) startPostgres() error {
	if s.Config.UseMemoryStore {
		s.PgStore = NewMemoryStore()
		if err := s.PgStore.Credit("admin", s.Config.SeedBalance, store.LedgerDeposit, "test-seed"); err != nil {
			return fmt.Errorf("seed memory balance: %w", err)
		}
		s.Logger.Info("using in-memory testbed store")
		return nil
	}

	s.Pg = deps.NewPostgresLifecycle(s.Logger, 0)
	if err := s.Pg.Start(s.Ctx); err != nil {
		return fmt.Errorf("postgres: %w", err)
	}
	s.Logger.Info("postgres started", "url", s.Pg.DatabaseURL)

	var err error
	s.PgStore, err = NewPostgresStore(s.Ctx, s.Pg.DatabaseURL)
	if err != nil {
		return fmt.Errorf("postgres store: %w", err)
	}
	if err := s.PgStore.Credit("admin", s.Config.SeedBalance, store.LedgerDeposit, "test-seed"); err != nil {
		return fmt.Errorf("seed balance: %w", err)
	}
	return nil
}

func (s *Suite) createUserPool() error {
	for i := 0; i < s.Config.NumUsers; i++ {
		accountID := fmt.Sprintf("testbed-user-%d", i)
		apiKey, err := s.PgStore.CreateKeyForAccount(accountID)
		if err != nil {
			return fmt.Errorf("create key for user %d: %w", i, err)
		}
		if err := s.PgStore.Credit(accountID, s.Config.SeedBalance, store.LedgerDeposit, "test-seed"); err != nil {
			return fmt.Errorf("credit user %d: %w", i, err)
		}
		s.Users = append(s.Users, UserAccount{
			AccountID: accountID,
			APIKey:    apiKey,
		})
	}
	s.Logger.Info("user pool created", "count", len(s.Users))
	return nil
}
func (s *Suite) startCoordinator() error {
	reg := registry.New(s.Logger)
	reg.MinTrustLevel = registry.TrustLevel(TrustNone)

	if len(s.Config.CatalogModels) == 0 {
		var catalog []registry.CatalogEntry
		for _, id := range s.Config.AllModelIDs() {
			catalog = append(catalog, registry.CatalogEntry{ID: id})
		}
		reg.SetModelCatalog(catalog)
	} else if err := seedCatalog(s.PgStore, s.Config.CatalogModels, s.Config.ModelAliases); err != nil {
		return err
	}

	srv := api.NewServer(reg, s.PgStore, api.ServerConfig{
		FirstContentDeadlineBase: s.Config.FirstContentDeadlineBase,
	}, s.Logger)
	if len(s.Config.CatalogModels) > 0 {
		srv.SyncModelCatalog()
	}
	srv.SetAdminKey("testbed-admin-key")
	srv.SetRuntimeManifest(&api.RuntimeManifest{})
	srv.SetChallengeInterval(1 * time.Hour)
	srv.SetSkipChallenge(true)
	srv.SetAllowDuplicateProviderSerialsForTesting(s.Config.ProviderTargets == nil)

	ledger := payments.NewLedger(s.PgStore)
	billingSvc := billing.NewService(s.PgStore, ledger, s.Logger, billing.Config{MockMode: true})
	srv.SetBilling(billingSvc)

	reg.SetQueue(registry.NewRequestQueue(s.Config.QueueCapacity, s.Config.QueueTimeout))

	s.Coordinator = &Coordinator{
		Server:   srv,
		Registry: reg,
	}

	return s.Coordinator.Start(s.Ctx, s.Logger)
}

func (s *Suite) startProviders() error {
	providerURL := s.Coordinator.BaseURL()
	if s.Config.ProviderRelay != nil {
		providerURL = s.Config.ProviderRelay.Start(providerURL)
	}
	var binaryPath string
	if s.Config.ProviderTargets == nil {
		var err error
		binaryPath, err = BuildProvider(s.Ctx, s.Logger)
		if err != nil {
			return fmt.Errorf("build provider: %w", err)
		}
	}

	providerIdx := 0
	for _, spec := range s.Config.ModelSpecs {
		modelIDs := spec.IDs()
		for j := 0; j < spec.NumProviders; j++ {
			if providerIdx > 0 {
				time.Sleep(500 * time.Millisecond)
			}
			p := &Provider{
				BinaryPath:    binaryPath,
				Logger:        s.Logger.With("provider_index", providerIdx, "models", strings.Join(modelIDs, ",")),
				ProviderIndex: providerIdx,
			}
			authDir, authTokenPath, err := s.prepareProviderAuth(providerIdx)
			if err != nil {
				return fmt.Errorf("prepare provider auth %d: %w", providerIdx, err)
			}
			p.AuthDir = authDir
			p.AccountID = fmt.Sprintf("testbed-provider-%d", providerIdx)
			if s.Config.ProviderTargets != nil {
				target := s.Config.ProviderTargets[providerIdx]
				p.Target = &target
				p.suiteNonce = s.targetNonce
			}
			if err := p.Start(s.Ctx, providerURL, ProviderConfig{
				ModelIDs:                   modelIDs,
				PrefixCacheMode:            s.Config.PrefixCacheMode,
				TrustLevel:                 TrustNone,
				MTPDrafterPath:             s.Config.MTPDrafterPath,
				MTPMode:                    s.Config.MTPMode,
				AuthTokenPath:              authTokenPath,
				EnableEphemeralPrefixCache: s.Config.EnableEphemeralPrefixCache,
				KVBackend:                  s.Config.KVBackend,
				MaxConcurrent:              s.Config.MaxConcurrent,
			}); err != nil {
				cleanupErr := p.StopAndWait()
				if cleanupErr == nil {
					_ = os.RemoveAll(authDir)
				}
				return errors.Join(fmt.Errorf("start provider %d (%s): %w", providerIdx, strings.Join(modelIDs, ","), err), cleanupErr)
			}
			s.Providers = append(s.Providers, p)
			providerIdx++
		}
	}
	return nil
}

func (s *Suite) prepareProviderAuth(providerIdx int) (string, string, error) {
	rawToken := fmt.Sprintf("testbed-provider-token-%d-%d", providerIdx, time.Now().UnixNano())
	tokenHash := sha256.Sum256([]byte(rawToken))
	accountID := fmt.Sprintf("testbed-provider-%d", providerIdx)
	if err := s.PgStore.CreateProviderToken(&store.ProviderToken{
		TokenHash: hex.EncodeToString(tokenHash[:]),
		AccountID: accountID,
		Label:     fmt.Sprintf("testbed-provider-%d", providerIdx),
		Active:    true,
		CreatedAt: time.Now(),
	}); err != nil {
		return "", "", err
	}

	authDir, err := os.MkdirTemp("", fmt.Sprintf("darkbloom-testbed-provider-%d-", providerIdx))
	if err != nil {
		return "", "", err
	}
	tokenDir := filepath.Join(authDir, ".darkbloom")
	if err := os.MkdirAll(tokenDir, 0700); err != nil {
		_ = os.RemoveAll(authDir)
		return "", "", err
	}
	authTokenPath := filepath.Join(tokenDir, "auth_token")
	if err := os.WriteFile(authTokenPath, []byte(rawToken+"\n"), 0600); err != nil {
		_ = os.RemoveAll(authDir)
		return "", "", err
	}
	return authDir, authTokenPath, nil
}

func (s *Suite) waitForProviderRegistration(timeout time.Duration) error {
	expectedCount := s.Config.TotalProviders()
	deadline := time.Now().Add(timeout)
	for time.Now().Before(deadline) {
		if s.Coordinator.Registry.ProviderCount() >= expectedCount {
			break
		}
		time.Sleep(1 * time.Second)
	}
	if s.Coordinator.Registry.ProviderCount() < expectedCount {
		return fmt.Errorf("only %d/%d providers registered after %v", s.Coordinator.Registry.ProviderCount(), expectedCount, timeout)
	}
	if _, err := s.BoundProviders(); err != nil {
		return err
	}
	s.Logger.Info("providers registered", "count", s.Coordinator.Registry.ProviderCount())

	time.Sleep(3 * time.Second)

	// Snapshot each provider's self-reported privacy_capabilities BEFORE the
	// force-trust mutation below overwrites it; see privacyAtRegistration.
	snapshot := make(map[string]*protocol.PrivacyCapabilities)
	var ineligible string
	var capabilityProviderIDs []string

	// Force-trust all providers and link them to a user account so the
	// payout destination check passes when billing is enabled. Capability-aware
	// suites first validate the registration's hardware and runtime claims,
	// then grant the stronger test trust required by protected catalog models.
	s.Coordinator.Registry.ForEachProvider(func(p *registry.Provider) {
		p.Mu().Lock()
		defer p.Mu().Unlock()
		if reported := p.PrivacyCapabilities; reported != nil {
			copied := *reported
			snapshot[p.ID] = &copied
		} else {
			snapshot[p.ID] = nil
		}
		if len(s.Config.ExpectedProviderCapabilities) > 0 {
			reported := make(map[string]struct{}, len(p.ReportedRuntimeCapabilities))
			for _, capability := range p.ReportedRuntimeCapabilities {
				reported[capability] = struct{}{}
			}
			for _, capability := range s.Config.ExpectedProviderCapabilities {
				if _, ok := reported[capability]; !ok && ineligible == "" {
					ineligible = fmt.Sprintf(
						"provider %s reported chip_family=%q and capabilities=%v; missing %q",
						p.ID, p.Hardware.ChipFamily, p.ReportedRuntimeCapabilities, capability)
				}
				if capability == registry.ProviderCapabilityAppleM5 &&
					p.Hardware.ChipFamily != "M5" && ineligible == "" {
					ineligible = fmt.Sprintf(
						"provider %s reported chip_family=%q, want M5",
						p.ID, p.Hardware.ChipFamily)
				}
			}
			metallibHash := p.TemplateHashes["mlx_metallib"]
			if metallibHash == "" && ineligible == "" {
				ineligible = fmt.Sprintf(
					"provider %s did not bind mlx_metallib in its registration", p.ID)
			}
			verified := p.AttestationResult
			if (verified == nil || !verified.Valid) && ineligible == "" {
				ineligible = fmt.Sprintf(
					"provider %s has no valid registration-verified attestation claims", p.ID)
			}
			if verified != nil && verified.Valid && ineligible == "" {
				if verified.ChipFamily != p.Hardware.ChipFamily {
					ineligible = fmt.Sprintf(
						"provider %s signed chip_family=%q but reported %q",
						p.ID, verified.ChipFamily, p.Hardware.ChipFamily)
				}
				signed := make(map[string]struct{}, len(verified.RuntimeCapabilities))
				for _, capability := range verified.RuntimeCapabilities {
					signed[capability] = struct{}{}
				}
				if len(signed) != len(reported) && ineligible == "" {
					ineligible = fmt.Sprintf(
						"provider %s signed capabilities=%v but reported %v",
						p.ID, verified.RuntimeCapabilities, p.ReportedRuntimeCapabilities)
				}
				for capability := range reported {
					if _, ok := signed[capability]; !ok && ineligible == "" {
						ineligible = fmt.Sprintf(
							"provider %s signed capabilities=%v but reported %v",
							p.ID, verified.RuntimeCapabilities, p.ReportedRuntimeCapabilities)
					}
				}
				if verified.MetallibHash != metallibHash && ineligible == "" {
					ineligible = fmt.Sprintf(
						"provider %s signed mlx_metallib=%q but reported %q",
						p.ID, verified.MetallibHash, metallibHash)
				}
			}
			if ineligible == "" {
				capabilityProviderIDs = append(capabilityProviderIDs, p.ID)
			}
		} else {
			p.TrustLevel = registry.TrustSelfSigned
		}
		p.Status = registry.StatusOnline
		p.ChallengeVerifiedSIP = true
		p.LastChallengeVerified = time.Now()
		p.FailedChallenges = 0
		p.RuntimeVerified = true
		p.RuntimeManifestChecked = true
		if p.PrivacyCapabilities == nil {
			p.PrivacyCapabilities = &protocol.PrivacyCapabilities{}
		}
		p.PrivacyCapabilities.TextBackendInprocess = true
		p.PrivacyCapabilities.TextProxyDisabled = true
		p.PrivacyCapabilities.PythonRuntimeLocked = true
		p.PrivacyCapabilities.DangerousModulesBlocked = true
		p.PrivacyCapabilities.AntiDebugEnabled = true
		p.PrivacyCapabilities.CoreDumpsDisabled = true
		p.PrivacyCapabilities.EnvScrubbed = true
		if p.AccountID == "" && len(s.Users) > 0 {
			p.AccountID = s.Users[0].AccountID
		}
	})
	if ineligible != "" {
		return fmt.Errorf("%w: %s", ErrProviderIneligible, ineligible)
	}
	for _, providerID := range capabilityProviderIDs {
		p := s.Coordinator.Registry.GetProvider(providerID)
		if p == nil {
			return fmt.Errorf("provider %s disconnected during capability admission", providerID)
		}
		p.SetAttested(true, registry.TrustHardware)
		p.SetFreshCodeAttested()
		p.Mu().Lock()
		p.RuntimeVerified = true
		p.RuntimeManifestChecked = true
		p.MetallibVerified = true
		p.Mu().Unlock()
		if err := s.Coordinator.Registry.ReconcileAttestedRuntimeCapabilities(providerID); err != nil {
			return fmt.Errorf("reconcile signed provider capabilities for %s: %w", providerID, err)
		}
		p.Mu().Lock()
		effective := append([]string(nil), p.RuntimeCapabilities...)
		p.Mu().Unlock()
		for _, required := range s.Config.ExpectedProviderCapabilities {
			found := false
			for _, capability := range effective {
				if capability == required {
					found = true
					break
				}
			}
			if !found {
				return fmt.Errorf(
					"signed capability reconciliation omitted %q for provider %s: %v",
					required, providerID, effective)
			}
		}
	}
	if len(s.Config.ExpectedProviderCapabilities) > 0 {
		models := s.Config.AllModelIDs()
		desired := make([]protocol.DesiredModelEntry, 0, len(models))
		covered := make(map[string]struct{}, len(s.Config.ModelAliases))
		for _, alias := range s.Config.ModelAliases {
			if !alias.Active {
				continue
			}
			desired = append(desired, protocol.DesiredModelEntry{
				ModelName: alias.AliasID, DesiredBuild: alias.DesiredBuild,
				PreviousBuild: alias.PreviousBuild,
			})
			covered[alias.DesiredBuild] = struct{}{}
			covered[alias.PreviousBuild] = struct{}{}
		}
		for _, model := range models {
			if _, ok := covered[model]; !ok {
				desired = append(desired, protocol.DesiredModelEntry{
					ModelName: model, DesiredBuild: model,
				})
			}
		}
		for _, providerID := range s.Coordinator.Registry.ProviderIDs() {
			if err := s.Coordinator.Registry.SendDesiredModels(providerID, desired); err != nil {
				return fmt.Errorf("refresh protected model inventory on provider %s: %w", providerID, err)
			}
		}
		deadline := time.Now().Add(60 * time.Second)
		for time.Now().Before(deadline) {
			snapshot := s.Coordinator.Registry.ModelProviderSnapshot()
			ready := true
			for _, model := range models {
				if snapshot[model] == 0 {
					ready = false
					break
				}
			}
			if ready {
				break
			}
			time.Sleep(250 * time.Millisecond)
		}
		snapshot := s.Coordinator.Registry.ModelProviderSnapshot()
		for _, model := range models {
			if snapshot[model] == 0 {
				return fmt.Errorf("protected model %q was not re-advertised after capability admission", model)
			}
		}
	}
	s.privacyMu.Lock()
	s.privacyAtRegistration = snapshot
	s.privacyMu.Unlock()
	s.Logger.Info("providers force-trusted for testing")

	return nil
}

// ReportedPrivacyCapabilities returns the privacy_capabilities block the
// given provider sent at registration, as captured before the testbed
// force-trusted the fleet. The returned pointer is a copy the caller may
// freely inspect; a nil block with ok==true means the provider registered
// and reported no privacy_capabilities at all, which is a real and
// distinguishable outcome. ok==false means no provider with that ID was
// present when the snapshot was taken.
//
// Assert against this, not against Registry state: the live registry copy
// has been overwritten with synthetic values by waitForProviderRegistration.
func (s *Suite) ReportedPrivacyCapabilities(providerID string) (*protocol.PrivacyCapabilities, bool) {
	s.privacyMu.Lock()
	defer s.privacyMu.Unlock()
	reported, ok := s.privacyAtRegistration[providerID]
	if !ok || reported == nil {
		return nil, ok
	}
	copied := *reported
	return &copied, true
}

func (c *Coordinator) Start(ctx context.Context, logger *slog.Logger) error {
	listener, err := netListen()
	if err != nil {
		return fmt.Errorf("listen: %w", err)
	}
	c.port = listener.port
	c.baseURL = listener.baseURL

	ctx, c.cancel = context.WithCancel(ctx)

	c.httpServer = &http.Server{
		Handler:      c.Server.Handler(),
		ReadTimeout:  10 * time.Second,
		WriteTimeout: 0,
		IdleTimeout:  120 * time.Second,
	}

	go func() {
		if err := c.httpServer.Serve(listener.inner); err != nil && err != http.ErrServerClosed {
			logger.Error("coordinator http server error", "error", err)
		}
	}()

	c.Registry.StartEvictionLoop(ctx, 1*time.Hour)
	logger.Info("test coordinator started", "port", c.port, "base_url", c.baseURL)
	return nil
}

func (c *Coordinator) BaseURL() string {
	return c.baseURL
}

func (c *Coordinator) Stop() error {
	if c.cancel != nil {
		c.cancel()
	}
	if c.httpServer != nil {
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		if err := c.httpServer.Shutdown(shutdownCtx); err != nil {
			return fmt.Errorf("coordinator shutdown: %w", err)
		}
	}
	return nil
}
