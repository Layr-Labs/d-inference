package api
import("encoding/json";"errors";"testing";"time";"github.com/eigeninference/d-inference/coordinator/protocol";"github.com/eigeninference/d-inference/coordinator/registry")
func TestProviderInferenceQueuedCacheRevocationKeepsOrdinaryInference(t *testing.T) {
	for _, revoke := range []string{"reconfigure", "off", "forget", "terminal", "disconnect"} {
		t.Run(revoke, func(t *testing.T) {
			reg, provider, pending := preparedCacheAttemptForTest(t)
			deadline := time.Now().Add(time.Second)
			pending.FirstContentDeadline = deadline
			builder := providerInferenceFrameBuilder("request", "ephemeral", "ciphertext", pending)
			switch revoke {
			case "reconfigure":
				configureCachePreparationTest(t, reg)
			case "off":
				if err := reg.ConfigureCacheRouting(registry.CacheRoutingConfig{Mode: registry.CacheRoutingOff, ActivationPct: 100}); err != nil {
					t.Fatal(err)
				}
			case "forget":
				reg.ForgetCacheAttempt(pending)
			case "terminal":
				reg.MarkCacheAttemptTerminal(pending)
			case "disconnect":
				provider.AddPending(pending)
				reg.Disconnect(provider.ID)
			}
			encoded, err := builder(deadline.Add(-350 * time.Millisecond))
			if err != nil {
				t.Fatal(err)
			}
			var message protocol.InferenceRequestMessage
			if err := json.Unmarshal(encoded, &message); err != nil {
				t.Fatal(err)
			}
			if message.RequestID != "request" || message.EncryptedBody == nil || message.EncryptedBody.Ciphertext != "ciphertext" || message.EncryptedBody.EphemeralPublicKey != "ephemeral" || message.FirstContentBudgetMS != 350 {
				t.Fatalf("revocation changed ordinary encrypted request: %+v", message)
			}
			if message.CacheScope != "" || message.CacheReceiptNonce != "" || message.PrefixCacheProtocol != 0 || message.CacheReceiptBoundaryMode != "" {
				t.Fatalf("revoked cache fields emitted at dequeue: %+v", message)
			}
			if pending.CacheRoutingParticipates() {
				t.Fatal("never-dispatched cache scope still excludes ordinary calibration")
			}
			if _, err := builder(deadline); !errors.Is(err, errFirstContentDeadlineAtWriter) {
				t.Fatalf("revocation weakened deadline rejection: %v", err)
			}
		})
	}
}
