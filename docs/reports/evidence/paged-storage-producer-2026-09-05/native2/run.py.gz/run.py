from pathlib import Path
import json, os, subprocess, time
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
native=root/'libs/mlx-swift-lm'
out=Path('/tmp/darkbloom-090-paged-telemetry-native2')
env=os.environ.copy();env['MLX_METALLIB_PATH']=str(root/'provider-swift/.build/arm64-apple-macosx/debug/mlx.metallib')
commands=[('build',['swift','build','--scratch-path','../../provider-swift/.build','--build-tests','--jobs','4','--disable-automatic-resolution'])]
for suite in ['CBv2PagedCheckpointStorageTests','CBv2PagedStorageTelemetryTests','CBv2PagedAdmissionTests','CBv2PagedGrantTests','CBv2PagedSegmentTests','CBv2KVResizeTests']:
 commands.append((suite,['../../scripts/run-nested-suite.sh',suite,'--scratch-path','../../provider-swift/.build','--disable-automatic-resolution']))
results=[]
for name,command in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log: result=subprocess.run(command,cwd=native,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':command,'cwd':str(native),'exit_code':result.returncode,'seconds':time.monotonic()-start})
 (out/'execution.json').write_text(json.dumps({'environment':{'MLX_METALLIB_PATH':env['MLX_METALLIB_PATH']},'results':results},indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
 if result.returncode: raise SystemExit(result.returncode)
