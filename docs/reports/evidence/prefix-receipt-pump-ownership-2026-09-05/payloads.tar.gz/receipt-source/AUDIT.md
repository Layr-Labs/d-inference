# HTTP3 Q38 SSD publication failure: successful submission cleaned up pump-owned resources

The failure is preserved. No HTTP/model retry, remote IO, primary edit, or diagnostic-tree edit was performed by this lane. Candidate source lives in `/Users/gaj/Documents/DarkbloomDev/wt/prefix-receipt-pump-ownership`, based on `c56e9b11a56dfa9291dbde58e324a7b0c9ec7e3b`. No commit or Swift test/build has been performed. `git diff --check` passes.

## Evidence

- Fleet freeze: `/tmp/darkbloom-connected-http3-q38-donation-failure1/manifest.json`, SHA `404e3eefdc6cfa209da236726a44225d11e030cea36d797a711316b3b1a67c67` (45 payloads). This audit copies the manifest and failed SSD report/log; original frozen artifacts remain unchanged.
- `cold_donor_a` completed normal MTP inference, HTTP200,64 output/reasoning tokens, actual prompt5545, checkpoint receipts negotiated. Lookup v2 reports an SSD miss. The cold subtest passed; parent assertion at `connected_cache_http_test.go:270` failed on SSDDonations0→0.
- Heartbeat DonationOutcomes.donated advanced0→1. Wire contains six events (two registrations, one request, one acceptance, lookup miss, terminal), dropped0, **no Ready receipt**. Holders remain0. Provider capability/epoch stayed unchanged across the row.
- The donor cache gauge is stale (sample_seq1, age12131ms); its files_written0/entries0 must not be used to contradict the later donation outcome. Normal existing testbed teardown removed provider StateDir; no cache index or provider log survived. Fleet performed no additional deletion.
- `EngineV2Bridge+Submission.swift` before SHA `7deec47104eff682000eed06562271d124022c0dab7a1d72c0641985710506d9` exactly matches the source manifest for the CLI7 used by HTTP3. This is not a diagnosis inferred from a different provider source version.

## Concrete ownership defect

`submitTokenized` registers a submission-specific complete-store Ready receipt at lines218–221. Its defer at234–239 discards resident proof, completes complete-store staging, and deletes the Ready receipt whenever `!retirementTransfer.isClaimed`.

`EngineV2RetirementTransfer` is an exceptional post-admission ownership handoff. It is claimed by `transferPreSubmitRetirement`, which protects resources while a rejected/cancelled committed generation retires. Successful submission instead calls nonthrowing `runPump` at634–643 and returns at651 without claiming that handoff. Therefore the defer immediately deletes the new receipt while the normal pump still owns the request.

Later native retirement commits durable files, releases donor KV and checkpoint aliases, calls `capture.reportPublication`, and only then delivers terminal (`EngineLoopV2.retire`, around3683–3690). The bridge's registered publication handler calls `SSDHybridCheckpointStore.publishReady`. That method's first guard requires the receipt entry (`SSDHybridCheckpointStore+Maintenance.swift:153`), which successful-return cleanup has already removed. The durable write can truthfully report donated1 while publication produces no callback or wire Ready. This exactly explains the observed distinction.

The intended normal cleanup already exists in `EngineV2Bridge+Events.swift:156–168`: staging/resident cleanup and Ready receipt retirement happen after the pump sees the engine terminal. Merely increasing the Go test wait or substituting heartbeat donations for accepted Ready receipts would conceal missing routing evidence. `settleCacheRoutingTelemetry` is a telemetry-quiescence wait, not proof of holder creation; the strict Ready/holder assertions should remain.

## Minimal candidate

Add `pumpOwnsPrefixResources`, initially false, to guard only the prefix-resource defer. Set it true immediately before nonthrowing `runPump`. This transfers responsibility to the already-existing pump terminal/teardown path. Exceptional `retirementTransfer`, pending provider IDs, pending engine IDs, mapped IDs, sampling, durable writes and Ready validation are unchanged.

Do **not** claim `retirementTransfer` on success: its other defers intentionally preserve pending resources for a detached exceptional owner, so reusing that flag would introduce unrelated lifecycle changes.

Production delta: seven lines. Two-file patch SHA `42302dd6f24abd9972e358031f6fc8c5746a82f3146a97d7d54e585f1e38707d`; exact before/after sources and hashes are retained here.

## Targeted validation plan

Two new tests in the existing bridge test file use a real EngineV2, real complete-checkpoint capture/retirement, encrypted SSD store, and tiny deterministic attention/recurrent tensors. A first-forward gate prevents the engine from reaching publication before submission returns. No large model or network fixture is introduced.

1. `readyAfterSubmitReturns`: inspect the real store receipt after return, then unblock the ordinary engine; require durable files, a Ready callback for512 tokens, receipt removal after terminal, and zero staged bytes. The old source necessarily fails the after-return receipt assertion and cannot deliver the callback.
2. `cancelAfterSubmitRetiresReceipt`: inspect the live receipt after return, cancel the blocked request, unblock, then require no Ready callback, receipt retirement and zero staged bytes.

These tests have not run yet. Root approved the source for focused validation in the benchmark agent's exclusive local Swift lane. Revision 2 only clarifies the ownership comment: the pump retains resources through engine terminal; each cache manages pending durable publication and receipt retention. Run the first test against the baseline production source as the negative control, then both tests against the candidate, plus existing rejected/atomic-cancel submission ownership tests. The new tests directly cover Ready lifetime and terminal cancellation; they do not claim a separate in-flight resident-proof or staged-import fixture. Those resources share the corrected defer, while their established pump/exceptional cleanup remains untouched.

After source/unit review and a distinct rebuilt CLI, repeat the original strict HTTP3 Q38 SSD cell with unchanged input. Require accepted Ready receipt/holder plus all existing cache-hit/route/output checks. No release or full connected-matrix success is claimed by this candidate.

## Revision relationship and regression handoff

Revision 1 remains immutable at `/tmp/darkbloom-prefix-receipt-pump-ownership1`, manifest SHA `33d2e59d576a9cb7cb4c2b0c92b91708500c527d38910697d890398d525b3f7e`. Its complete payload set was reverified before revision 2 was captured. This revision changes only the production comment relative to that candidate; tests are byte-identical. The two-file patch remains uncommitted and source-only.

Run the negative control with the new tests and the exact original production source: `EngineV2BridgePumpReceiptTests/readyAfterSubmitReturns` must fail at the after-return receipt count before forward is released. Then run the candidate suite and the existing `EngineV2SharedBudgetTests`, `EngineV2ErrorMappingTests`, `EngineV2CancellationTests`, `EngineV2LookupReceiptCoverageTests`, `EngineV2ShutdownTests`, `EngineV2HardeningTests`, complete `EngineProfileCancelTests.swift` and `EngineV2ResliceUnwindTests.swift` suites, `SSDHybridCheckpointStoreTests`, `PrefixCacheReceiptTests`, `OuterPrefixCacheReceiptTests`, `ResidentPrefixCacheEvidenceTests`, and `RetirementGateTests`. Use the current canonical provider package/build overlay; this isolated source worktree has no initialized native dependency. Record actual runner commands and results in a new validation artifact, not this frozen source candidate.
