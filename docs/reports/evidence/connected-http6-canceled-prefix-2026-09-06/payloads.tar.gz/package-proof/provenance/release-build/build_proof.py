from pathlib import Path
import gzip, hashlib, json, os, re, shutil, stat

OUT = Path(__file__).resolve().parent
WS = OUT/'workspace'
INFO = json.loads((OUT/'integration.json').read_text())
SCRATCH = Path(INFO['scratch'])
GROUPS = ['provider', 'native', 'harness', 'dependency', 'jinja']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2)+'\n')

def manifest_rows(manifest):
    rows = manifest['files']
    return [{'path': name, **row} for name, row in rows.items()] if isinstance(rows, dict) else rows

def verify_payloads(path, expected=None):
    if expected: assert sha(path) == expected, path
    for row in manifest_rows(json.loads(path.read_text())):
        p = path.parent/row['path']
        assert sha(p) == row['sha256'], p
        if 'bytes' in row: assert p.stat().st_size == row['bytes'], p
        if 'mode' in row: assert oct(stat.S_IMODE(p.stat().st_mode)) == row['mode'], p

KNOWN = {}
def add(p, digest, group):
    key = str(p.resolve())
    assert key not in KNOWN or KNOWN[key]['sha256'] == digest
    KNOWN[key] = {'sha256': digest, 'group': group}

for name, root, group in [('provider-source-manifest.json', WS, 'provider'),
                          ('native-source-manifest.json', OUT/'native', 'native'),
                          ('harness-source-manifest.json', OUT, 'harness')]:
    for p, digest in json.loads((OUT/name).read_text())['files'].items(): add(root/p, digest, group)
deps = json.loads((OUT/'dependency-source-manifest.json').read_text())
for name, digest in deps['files'].items():
    alias, p = name.split('/', 1)
    add(Path(deps['repositories'][alias])/p, digest, 'dependency')
for name, digest in json.loads((OUT/'jinja-source-manifest.json').read_text())['files'].items():
    add(SCRATCH/'checkouts/swift-jinja'/name, digest, 'jinja')

def verify():
    verify_payloads(OUT/'preparation-manifest.json')
    for name, row in KNOWN.items(): assert sha(Path(name)) == row['sha256'], name
    for name, row in json.loads((OUT/'package-resolution-inputs.json').read_text())['files'].items():
        assert sha(Path(name)) == row['sha256'], name
    for name, digest in INFO['source_freezes'].items(): verify_payloads(Path(name), digest)
    for key in ['banked_cancellation_manifest', 'banked_cancellation_archive']:
        assert sha(Path(INFO[key])) == INFO[key+'_sha256'], key
    for row in json.loads((OUT/'pinned-availability-api.json').read_text())['files'].values():
        assert sha(Path(row['path'])) == row['sha256']
    return {'no_drift': True, 'counts': {g: sum(r['group'] == g for r in KNOWN.values()) for g in GROUPS}}

def save_graph(label):
    for name in ['release.yaml', 'workspace-state.json']:
        path = SCRATCH/name
        if path.exists():
            target = OUT/(label+'-'+name+('.gz' if name.endswith('yaml') else ''))
            target.write_bytes(gzip.compress(path.read_bytes(), mtime=0) if name.endswith('yaml') else path.read_bytes())

def graph_proof(product):
    body = (SCRATCH/'release.yaml').read_text()
    rows, unmapped = {}, []
    roots = [(WS/'provider-swift').resolve(), (OUT/'native').resolve(),
             (WS/'libs/mlx-swift').resolve(), (OUT/'radix-engine').resolve()]
    for literal in sorted(set(re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"', body))):
        p = Path(literal); key = str(p.resolve())
        if key in KNOWN:
            assert sha(p) == KNOWN[key]['sha256']
            rows[literal] = {'resolved_frozen_source': key, **KNOWN[key]}
        elif any(key.startswith(str(root)+'/') for root in roots): unmapped.append(literal)
    assert not unmapped, unmapped
    assert '/checkouts/mlx-swift/Source/' not in body
    assert '/Users/gaj/Documents/DarkbloomDev/wt/' not in body
    required = ['CBv2AttentionPacket.swift', 'CBv2AttentionPacketCapture.swift',
                'CBv2AttentionPacketObservation.swift', 'EngineLoopV2+AttentionPacket.swift',
                'PagedAttentionPacket.swift', 'CBv2AttentionOwnerIdentity.swift',
                'EngineV2Bridge+Events.swift', 'EngineV2Bridge+Lifecycle.swift',
                'EngineV2Bridge+PrefixCache.swift', 'ProviderLoop+InferenceHandler.swift']
    if product == 'radix-engine': required += ['BenchmarkAttentionPacket.swift', 'BenchmarkOptions.swift']
    else: required += ['Darkbloom.swift']
    for name in required: assert any(p.endswith('/'+name) for p in rows), name
    availability = {}
    for name, row in json.loads((OUT/'pinned-availability-api.json').read_text())['files'].items():
        matching = [p for p in rows if str(Path(p).resolve()) == str(Path(row['path']).resolve())]
        if not name.endswith('/array.h'): assert matching, name
        availability[name] = {**row, 'declared_graph_references': matching,
                              'header_only_identity': name.endswith('/array.h')}
    write(product+'-availability-api-graph-proof.json', availability)
    write(product+'-all-owned-graph-source-proof.json', {
        'scope': 'Declared SwiftPM graph references match frozen source bytes. This does not claim every graph entry links into the selected product; command and link execution remain separately recorded.',
        'files': rows, 'counts': {g: sum(r['group'] == g for r in rows.values()) for g in GROUPS},
        'unmapped_owned_sources': unmapped, 'remote_mlx_source_excluded': True,
        'worktree_source_excluded': True,
    })

def executable(path):
    assert stat.S_ISREG(path.lstat().st_mode), path
    assert stat.S_IMODE(path.stat().st_mode) == 0o755 and os.access(path, os.X_OK), path
    return {'sha256': sha(path), 'bytes': path.stat().st_size, 'mode': '0o755', 'executable': True}

def copy_artifacts(product):
    release = SCRATCH/'arm64-apple-macosx/release'
    artifact = OUT/'artifact'
    executable(release/product)
    shutil.copy2(release/product, artifact/product)
    write(product+'-binary.json', executable(artifact/product))
    resources = json.loads((OUT/'runtime-resource-inputs.json').read_text())
    assert len(resources) == 6
    observed = {}
    for name, row in resources.items():
        origin = release/name if name != 'mlx.metallib' else Path('/tmp/darkbloom-final-serving-build8/artifact')/name
        assert sha(origin) == row['sha256'] and origin.stat().st_size == row['bytes'], name
        target = artifact/name; target.parent.mkdir(parents=True, exist_ok=True)
        if target.exists(): assert sha(target) == row['sha256']
        else: shutil.copy2(origin, target)
        observed[name] = {'sha256': sha(target), 'bytes': target.stat().st_size,
                          'mode': oct(stat.S_IMODE(target.stat().st_mode)), 'source': str(origin)}
    write(product+'-runtime-resource-proof.json', observed)
