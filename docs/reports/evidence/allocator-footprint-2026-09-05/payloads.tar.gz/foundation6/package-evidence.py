from pathlib import Path
import difflib, gzip, hashlib, json, re, shutil, subprocess, tarfile

exec(Path('/tmp/darkbloom-allocator-footprint-foundation6/verify.py').read_text())
assert (out / 'source-verified-after-native.json').exists()
assert verify()['no_drift']
execution = json.loads((out / 'native-execution.json').read_text())
assert len(execution) == 31 and all(row['exit_code'] == 0 and row['selected_count_verified'] for row in execution)
ids = [s for s in (out / 'native-identifiers.log').read_text().splitlines() if s.startswith('MLXLMTests.')]
selected, summaries = {}, {}
for name in json.loads((out / 'native-filters.json').read_text()):
    body = (out / (name + '.log')).read_text()
    swift = int(re.findall(r'Test run with (\d+) tests?', body)[-1])
    xc = max(map(int, re.findall(r'Executed (\d+) tests?', body)), default=0)
    extra = sum(int(n)-1 for n in re.findall(r'with (\d+) test cases passed', body))
    matches = [s for s in ids if name in s]
    if name == 'CBv2PagedBackendTests':
        matches += [s for s in ids if 'CBv2PagedSpeculativeRowTests/' in s]
    if name == 'CBv2PagedPrefixReuse':
        matches += [s for s in ids if 'CBv2PrefixReusePagedFrozenFullTests/' in s]
    assert len(matches) == swift + xc, (name, len(matches), swift + xc)
    assert not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test|recorded an issue|[✘]', body, re.M), name
    selected[name] = sorted(matches)
    summaries[name] = {'functions': swift + xc, 'actual_cases': swift + xc + extra, 'failures': 0, 'skips': 0}
unique = sorted(set(item for values in selected.values() for item in values))
assert len(unique) == sum(v['functions'] for v in summaries.values())
assert summaries['CBv2AllocatorFootprintTests'] == {'functions': 10, 'actual_cases': 11, 'failures': 0, 'skips': 0}
(out / 'selected-identifiers.json').write_text(json.dumps({'by_filter': selected, 'unique_identifiers': unique}, indent=2) + '\n')
scratch = Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift')
graph = (scratch / 'debug.yaml').read_text()
assert str(repos['swift'] / 'Source/MLX/AllocationFootprint.swift') in graph
assert str(repos['native'] / 'Tests/MLXLMTests/CBv2AllocatorFootprintTests.swift') in graph or str((repos['native'] / 'Tests/MLXLMTests/CBv2AllocatorFootprintTests.swift').resolve()) in graph
assert '/checkouts/mlx-swift/Source/' not in graph
(out / 'native-actual-build-graph-final.yaml.gz').write_bytes(gzip.compress(graph.encode(), mtime=0))
shutil.copy2(scratch / 'workspace-state.json', out / 'native-actual-package-state-final.json')
exe = scratch / 'arm64-apple-macosx/debug/mlx-swift-lmPackageTests.xctest/Contents/MacOS/mlx-swift-lmPackageTests'
(out / 'test-binary.json').write_text(json.dumps({'path': str(exe), 'sha256': sha(exe), 'bytes': exe.stat().st_size}, indent=2) + '\n')
owned = json.loads((out / 'owned-manifest.json').read_text())['files']
patches = {}
baseline = {'swift': root / 'libs/mlx-swift', 'mlx': root / 'libs/mlx-swift/Source/Cmlx/mlx', 'mlx-c': root / 'libs/mlx-swift/Source/Cmlx/mlx-c', 'native': root / 'libs/mlx-swift-lm'}
with tarfile.open(out / 'owned-source.tar.gz', 'w:gz') as archive:
    for key in sorted(owned):
        alias, path = key.split('/', 1)
        current = repos[alias] / path
        prior = baseline[alias] / path
        assert sha(current) == owned[key]
        archive.add(current, arcname=key)
        before = prior.read_text() if prior.exists() else ''
        patches.setdefault(alias, '')
        patches[alias] += ''.join(difflib.unified_diff(before.splitlines(True), current.read_text().splitlines(True), fromfile='a/' + path if prior.exists() else '/dev/null', tofile='b/' + path))
patch_records = {}
for alias, patch in patches.items():
    path = out / (alias + '-against-banked.patch')
    path.write_text(patch)
    subprocess.run(['git', 'apply', '--check', str(path)], cwd=baseline[alias], check=True)
    numstat = subprocess.check_output(['git', 'apply', '--numstat', str(path)], cwd=baseline[alias], text=True)
    paths = sorted(line.split('\t')[-1] for line in numstat.splitlines())
    expected = sorted(key.split('/', 1)[1] for key in owned if key.startswith(alias + '/'))
    assert paths == expected, (alias, paths, expected)
    patch_records[alias] = {'sha256': sha(path), 'paths': paths, 'apply_check_passed': True}
(out / 'bankable-patches.json').write_text(json.dumps(patch_records, indent=2) + '\n')
lineage = {}
for name in range(1, 6):
    path = Path(f'/tmp/darkbloom-allocator-footprint-foundation{name}/partial-manifest.json')
    lineage[str(path)] = {'sha256': sha(path), 'role': 'Preserved original attempt; source corrections and final evidence must be read separately.'}
for path, role in [(Path('/tmp/darkbloom-footprint-ownership-diagnostic1/manifest.json'), 'Diagnostic external count getter/static Metal library: distinguishes completion Data references from shared-view references; tiny synchronization timings are not model measurements.')]:
    lineage[str(path)] = {'sha256': sha(path), 'role': role}
(out / 'evidence-lineage.json').write_text(json.dumps(lineage, indent=2) + '\n')
verdict = {
    'status': 'pass', 'baseline_parent': '69a75de82813beaf753fbbb4891c3b3261b63600',
    'baseline_native': '990475e3ae6f93615bebe0fc36e352aa601ea4a5',
    'native_build_seconds_reported': float(re.findall(r'Build complete! \(([0-9.]+)s\)', (out / 'native-build.log').read_text())[-1]),
    'native_filters': 29, 'native_unique_functions': len(unique),
    'native_unique_cases': sum(v['actual_cases'] for v in summaries.values()), 'native_by_filter': summaries,
    'swift_functions': 4, 'swift_cases': 4, 'swift_evidence': '/tmp/darkbloom-allocator-footprint-foundation3',
    'cpp_cases_per_backend': 3, 'cpp_backends': ['CPU', 'Metal'], 'cpp_evidence': '/tmp/darkbloom-allocator-footprint-foundation1',
    'source_verified': verify(), 'owned_files': 35,
    'compiler_source_paths': {'native': str(repos['native']), 'mlx_swift': str(repos['swift']), 'mlx': str(repos['mlx']), 'mlx_c': str(repos['mlx-c'])},
    'correction_lineage': ['Mechanical Foundation import and throwing-getter pre-evaluation.', 'Fresh-buffer exact ownership requires captured-stream completion after successful or throwing evaluation. Only fresh segment construction fences; metadata getter never evaluates or waits.', 'Shared-view test uses contiguous full-size reshape, not integer-index gather copy; unexpected rows are released before failed assertion.', 'Grant fixtures use per-buffer allocator bounds and observed actual physical bytes while retaining exact logical pages/refusal/epoch/reuse assertions. Only known decode-parity geometry receives summed independent-buffer bound.'],
    'limits': ['CUDA source is unexecuted.', 'Native process owner fake verifies C/M ownership transitions; actual provider coherent U plus sum(C-M) integration is a separate pending gate.', 'No requested fleet-size model, factory rollout, SSD codec union, production default or real-model latency change validated in this foundation gate.', 'Standalone diagnostic tiny stream-sync timings do not establish end-to-end model overhead.', 'Policy12 footprint parameter API has not yet been applied or validated.'],
}
(out / 'verdict.json').write_text(json.dumps(verdict, indent=2) + '\n')
(out / 'environment.txt').write_text(subprocess.check_output(['swift', '--version'], text=True, stderr=subprocess.STDOUT) + subprocess.check_output(['sw_vers'], text=True) + subprocess.check_output(['uname', '-a'], text=True))
files = {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size} for p in sorted(out.iterdir()) if p.is_file() and p.name != 'manifest.json'}
(out / 'manifest.json').write_text(json.dumps({'scope': 'Final allocator footprint native foundation with explicit carried-forward unchanged C++ and Swift dependency evidence and preserved failure lineage. Selected source identities and owned exact source archive included.', 'files': files}, indent=2) + '\n')
print(json.dumps({'functions': len(unique), 'cases': verdict['native_unique_cases'], 'payloads': len(files), 'manifest_sha256': sha(out / 'manifest.json')}, indent=2))
