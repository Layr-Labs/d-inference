"""One-shot source-only freeze preparation; never runs a model or edits the repository."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')

def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write(path, value):
    (ROOT / path).parent.mkdir(parents=True, exist_ok=True)
    (ROOT / path).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

sources = []
def copy(source, destination):
    source, destination = Path(source), ROOT / destination
    destination.parent.mkdir(parents=True, exist_ok=True)
    before = digest(source)
    shutil.copyfile(source, destination)
    assert before == digest(destination) == digest(source)
    sources.append({'source': str(source), 'path': str(destination.relative_to(ROOT)), 'sha256': before})

matrix_path = Path('/tmp/darkbloom-0.9-validation/matrix.json')
copy(matrix_path, 'provenance/fleet-matrix.json')
matrix = json.loads((ROOT / 'provenance/fleet-matrix.json').read_text())
for name in ('run_radix_engine.py', 'run_radix_http.py', 'compare_radix_engine.py', 'radix_engine_evidence.py'):
    copy(REPO / 'scripts/benchmarks' / name, 'runner/' + name)
for name in ('RadixBenchmark.swift', 'BenchmarkGeneration.swift', 'BenchmarkBatches.swift', 'BenchmarkIdleObservation.swift'):
    copy(REPO / 'scripts/benchmarks/radix-engine/Sources/radix-engine' / name, 'provenance/harness/' + name)
for relative in ('Inference/EngineV2SlotFactory.swift', 'Inference/EngineV2SlotFactory+CompletePrefixCache.swift',
                 'Inference/PrefixCachePolicy.swift', 'KVCacheSSD/SSDPrefixCachePolicy.swift'):
    copy(REPO / 'provider-swift/Sources/ProviderCore' / relative, 'provenance/policy/' + Path(relative).name)
copy(REPO / 'deploy/environments/prod.env', 'provenance/prod.env')
copy('/tmp/darkbloom-fleet-smoke-continuation/gemma-two-file-fixture-proof.json', 'provenance/gemma-two-file-fixture-proof.json')
copy('/tmp/darkbloom-historical-window/gemma-assistant-inventory.json', 'provenance/gemma-assistant-inventory.json')
paths = {
    'qwen36': '/Users/gaj/autoresearch/radix-prefix-cache/qwen35b/models/qwen3.6-35b-a3b-vl-mtp-mxfp8/73a03825c2226177f3e679210965dba3508cdee8',
    'qwen35': '/Users/gaj/autoresearch/radix-prefix-cache/qwen35b/models/qwen3.5-35b-a3b/8964653177a21be79662d51e69fe6a2263ffabb3',
    'qwen38': '/Users/gaj/.cache/huggingface/hub/models--EigenLabs--Qwen3.8-27B-4bit-mtp/snapshots/06d517d395dfc5588090f7f534112bee331f7b4a',
    'gpt-oss-20b': '/Users/gaj/.cache/huggingface/hub/models--gpt-oss-20b/snapshots/local',
    'gemma-4-26b': '/Users/gaj/.cache/huggingface/hub/models--gemma-4-26b/snapshots/local',
}
models = []
for old in matrix['models']:
    label = old['label']
    assert digest(old['manifest']) == old['manifest_sha256']
    copy(old['manifest'], 'provenance/' + label + '-manifest.json')
    source = Path('/tmp/darkbloom-final-fleet-smoke2/inputs') / (label + '.json')
    copy(source, 'provenance/inputs32/' + source.name)
    data = json.loads(source.read_text())
    for row in data['rows']:
        assert row['request']['model'] == old['model_id']
        assert row['case']['max_tokens'] == row['request']['max_tokens'] == 32
        row['case']['max_tokens'] = row['request']['max_tokens'] = 128
        row['request']['_darkbloom_prompt_date'] = '2026-09-05'
    write('inputs/' + source.name, data)
    models.append({k: old[k] for k in ('label', 'model_id', 'aggregate_sha256', 'normal_mtp')})
    models[-1].update(group='original', input='inputs/' + source.name,
                      input_sha256=digest(ROOT / 'inputs' / source.name),
                      manifest='provenance/' + label + '-manifest.json', manifest_sha256=old['manifest_sha256'],
                      historical_attention=label in ('gpt-oss-20b', 'gemma-4-26b'),
                      model_directory_hint=paths[label], assistant=old.get('assistant'), artifact_status='previously_audited_exact_artifact')
cat = Path('/tmp/qwen35b-ssd-model-inventory/catalog.json')
qat = next(m for m in json.loads(cat.read_text())['models'] if m['id'] == 'gemma-4-26b-qat-4bit')
write('provenance/gemma-qat-catalog-entry.json', {'source': str(cat), 'source_sha256': digest(cat), 'entry': qat})
assert qat['aggregate_sha256'] == '2468a0cb3049a871f42052f4d9f9380bf12a0792f64c7a29f768559fc7d28785'
data = json.loads((ROOT / 'inputs/gemma-4-26b.json').read_text())
for row in data['rows']:
    row['request']['model'] = qat['id']
write('inputs/gemma-4-26b-qat-4bit.json', data)
models.append(dict(label=qat['id'], model_id=qat['id'], aggregate_sha256=qat['aggregate_sha256'],
                   normal_mtp=True, group='supplement', historical_attention=True,
                   input='inputs/gemma-4-26b-qat-4bit.json', input_sha256=digest(ROOT / 'inputs/gemma-4-26b-qat-4bit.json'),
                   manifest=None, manifest_sha256=None, manifest_prefix=qat['r2_prefix'], total_size_bytes=qat['total_size_bytes'],
                   model_directory_hint=None, assistant=models[-1]['assistant'], artifact_status='pending_exact_manifest_download_and_identity_audit'))
cells, pairs = [], []
for model in models:
    for b in (1, 2, 4):
        for rep in (1, 2, 3):
            quartet = f"{model['label']}-b{b}-r{rep}"
            names = {}
            for backend, cache in [('contiguous','off'), ('contiguous','on'), ('paged','off'), ('paged','on')]:
                name = f'{quartet}-{backend}-cache-{cache}'
                blocked = []
                if model['group'] == 'supplement':
                    blocked.append('qat_exact_artifact_audit_pending')
                if model['historical_attention'] and backend == 'contiguous' and cache == 'on':
                    blocked.append('historical_contiguous_ssd_unsupported_in_reviewed_source')
                cells.append(dict(id=name, order=len(cells)+1, quartet=quartet, group=model['group'], model=model['label'],
                                  concurrency=b, repetition=rep, backend=backend, cache=cache, blockers=blocked))
                names[backend, cache] = name
            for backend in ('contiguous', 'paged'):
                pairs.append(dict(id=quartet+'-'+backend+'-cache', group=model['group'], quartet=quartet, axis='cache',
                                  baseline=names[backend,'off'], candidate=names[backend,'on'], expect_cache_hits=True))
            for cache in ('off', 'on'):
                pairs.append(dict(id=quartet+'-cache-'+cache+'-backend', group=model['group'], quartet=quartet, axis='backend',
                                  baseline=names['contiguous',cache], candidate=names['paged',cache], expect_cache_hits=cache=='on'))
write('plan.json', dict(schema=1, state='source_only_not_runtime_bound', source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=REPO,text=True).strip(),
                       prompt_date='2026-09-05', prompt_target_approximate=5500, output_token_cap=128,
                       original_cells=180, pending_supplement_cells=36, models=models, cells=cells, pairs=pairs,
                       ordering='model order, B1/B2/B4, repetition1/2/3, contiguous off/on then paged off/on; preserve every attempt'))
write('bindings.template.json', dict(schema=1, state='unreviewed', review_id=None, runtime_source_manifest=None,
    binary=None, resources=None, python_executable=None, results_root=None, storage_retention_review=None,
    models={m['label']: dict(directory=None, identity_audit=None, assistant_directory=None) for m in models},
    notes='Fill a separate copy after root runtime/source/resource and storage review. No probe including build6 is selected by this plan. Exact target SHA is enforced by unchanged serving probe; verify assistant exact two-file fixture.'))
write('source-provenance.json', {'files': sources, 'source_only': True})
assert len(cells) == 216 and sum(c['group']=='original' for c in cells) == 180
print('Prepared 180 original cells and 36 pending supplement cells; no runtime selected.')
