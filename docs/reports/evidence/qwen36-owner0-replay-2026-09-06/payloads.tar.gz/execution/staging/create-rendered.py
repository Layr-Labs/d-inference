import json
C=json.loads('{"remote_root": "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1", "binding_sha256": "a04631ec25459596b98561910463c88e334ed0e059714def34f54cfca57ee4c8"}')
from pathlib import Path
import json
root=Path(C['remote_root']);assert not root.exists() and not root.is_symlink()
root.mkdir(mode=0o700,exist_ok=False)
print(json.dumps({'fresh_root':str(root),'mode':oct(root.stat().st_mode&0o777)}))
