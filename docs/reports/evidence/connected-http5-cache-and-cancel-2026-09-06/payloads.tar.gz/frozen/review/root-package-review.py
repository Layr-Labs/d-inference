from pathlib import Path
import datetime, hashlib, json, os, stat, tarfile
base=Path('/tmp/darkbloom-connected-m5-bundle5'); old=Path('/tmp/darkbloom-connected-m5-bundle4'); repo=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
sha=lambda b:hashlib.sha256(b).hexdigest()
raw=(base/'package-manifest.json').read_bytes(); assert sha(raw)=='7c04de0ebc0064d31ce6aa642044d1075704bcf29779334c6d0a9d32aaa4efda'; manifest=json.loads(raw)
for name,e in manifest['files'].items():
 p=base/name; mode=p.lstat().st_mode;data=p.read_bytes();assert stat.S_ISREG(mode) and stat.S_IMODE(mode)==e['mode'],name;assert len(data)==e['bytes'] and sha(data)==e['sha256'],name
archive=Path('/tmp/darkbloom-connected-m5-bundle5.tar.gz');assert sha(archive.read_bytes())=='06eef81c7d1e03c93d59b0e0d330ecb4bd06c921702bf23b7b778fa546406101'
with tarfile.open(archive) as tf:
 members=tf.getmembers(); assert len(members)==1383
 names={m.name for m in members};assert names==set(manifest['files'])|{'package-manifest.json'}
 for m in members:
  assert m.isfile(),m.name; local=base/m.name;assert tf.extractfile(m).read()==local.read_bytes(),m.name;assert m.mode==stat.S_IMODE(local.stat().st_mode),m.name
 go=tf.getmember('connected-e2e.test');assert go.mode==0o755
assert os.access(base/'connected-e2e.test',os.X_OK)
source_names=[n for n in manifest['files'] if n.startswith('go-source/')];assert len(source_names)==988
for name in source_names: assert (base/name).read_bytes()==(repo/name.removeprefix('go-source/')).read_bytes(),name
review=json.loads(Path('/tmp/darkbloom-connected-bundle5-helper-review1/review.json').read_text())
for name,e in review['changed_files'].items():assert sha((base/name).read_bytes())==e['after_sha256']
for name in ['temporary_model_alias.py','verify_prompt_counts.py','compare_connected_cache_http.py','test_connected_bundle.py','test_local_assistant.py','test_temporary_model_alias.py']:
 assert (base/name).read_bytes()==(old/name).read_bytes(),name
assert (base/'make_inputs.py').read_text()==(old/'make_inputs.py').read_text().replace('090-connected-http4','090-connected-http5')
plan=json.loads((base/'bundle-plan.json').read_text());assert plan['expected_request_date_utc']==datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-09-06';assert len(plan['cells'])==12
inputs=[]
for cell in plan['cells']:
 name=cell['input']; data=json.loads((base/name).read_text()); previous=json.loads((old/name).read_text());expected=json.loads((old/name).read_text().replace('090-connected-http4','090-connected-http5'));assert data==expected,name
 assert data['provider_sha256']=='7345c5b29369a8ff168b1230254c0a164a6ccc97a0fb0baca380475acda43363';assert '/090-final-serving-build8/artifact/darkbloom' in data['provider_binary']
 inputs.append(data)
for a,b in zip(inputs[::2],inputs[1::2]):assert {k:v for k,v in a.items() if k!='cache_mode'}=={k:v for k,v in b.items() if k!='cache_mode'}
tok=json.loads((base/'tokenizer-plan.json').read_text());assert tok['status']=='passed' and tok['expected_request_date_utc']=='2026-09-06' and len(tok['rows'])==6
for row,data,cell in zip(tok['rows'],inputs[::2],plan['cells'][::2]):
 body={'model':data['artifact']['model_id'],'messages':[{'role':'user','content':data['prompt']}],'temperature':0,'seed':0,'max_tokens':64,'stream':True,'stream_options':{'include_usage':True},'_darkbloom_prompt_date':'2026-09-06'}
 assert row['input_sha256']==sha((base/cell['input']).read_bytes());assert row['normalized_body_sha256']==sha(json.dumps(body,sort_keys=True,separators=(',',':')).encode());assert row['prompt_tokens']>4096
assert (base/'reviews/bundle5-helper-root-review.json').read_bytes()==Path('/tmp/darkbloom-connected-bundle5-helper-root-review.json').read_bytes()
assert (base/'reviews/build8-root-review.json').read_bytes()==Path('/tmp/darkbloom-build8-root-review.json').read_bytes()
result={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'package_manifest_sha256':sha(raw),'archive_sha256':sha(archive.read_bytes()),'verified_local_files_and_modes':len(manifest['files']),'verified_archive_members_and_modes':len(members),'go_executable_mode':'0755','exact_current_go_sources':len(source_names),'exact_reviewed_changed_helpers':len(review['changed_files']),'unchanged_helpers':6,'input_comparison':'All twelve equal HTTP4 except declared http5 vision asset relocation; all six off/SSD pairs differ only cache_mode; build8 CLI binding unchanged','date':'September6 currentUTC, six normalized body hashes independently reconstructed; actual tokenizer runs retained','status':'PASS for owned M5 staging and sequential strict HTTP5 execution; no inference acceptance or release promotion claim'}
Path('/tmp/darkbloom-connected-bundle5-root-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
