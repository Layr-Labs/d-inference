from pathlib import Path
import hashlib,json,re,shutil
base=Path('/tmp/darkbloom-q36-attention-kernel-validation1');out=Path('/tmp/darkbloom-q36-attention-kernel-validation2');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();original=json.loads((base/'manifest.json').read_text())
assert sha(base/'manifest.json')=='3ecd3d2c5c3523f5f360c9fe08e7b6827c199b7916be03f09951a3b7af0c8aa5'
for p,row in original['files'].items():
 assert sha(base/p)==row['sha256'],p;target=out/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/p,target)
for p in ['manifest.json','verdict.json','test-identifier-coverage.json']:shutil.copy2(base/p,out/('initial-'+p))
coverage=json.loads((out/'test-identifier-coverage.json').read_text());ids=(out/'identifiers.log').read_text().splitlines();extra=[s for s in ids if 'CBv2NativeKVTypeProbeTests/' in s];assert len(extra)==2
coverage['by_filter']['CBv2PagedNativeDTypeTests']+=extra;coverage['unique_test_functions']=len(set(s for group in coverage['by_filter'].values() for s in group));coverage['executed_functions_with_targeted_overlap']=sum(map(len,coverage['by_filter'].values()));coverage['source_filename_filter_note']='Swift Testing filter also matches the source filename. CBv2PagedNativeDTypeTests.swift contains CBv2NativeKVTypeProbeTests, whose two tests ran and passed in the same filter, as raw suite names and5-test summary prove.'
(out/'test-identifier-coverage.json').write_text(json.dumps(coverage,indent=2)+'\n');verdict=json.loads((out/'verdict.json').read_text());verdict['unique_test_functions']=coverage['unique_test_functions'];verdict['function_executions_including_targeted_overlap']=coverage['executed_functions_with_targeted_overlap'];expanded={}
for name,rows in coverage['by_filter'].items():
 body=(out/(name+'.log')).read_text();counts=[int(n) for n in re.findall(r'with (\d+) test cases? passed',body)];expanded[name]=len(rows)+sum(n-1 for n in counts)
assert verdict['unique_test_functions']==26 and verdict['function_executions_including_targeted_overlap']==29
assert expanded=={'qwen36-new-cases':13,'CBv2PagedKernelTests':49,'CBv2PagedSegmentTests':19,'CBv2PagedNativeDTypeTests':5}
verdict['expanded_cases_by_filter']=expanded;verdict['unique_expanded_cases']=sum(expanded[k] for k in expanded if k!='qwen36-new-cases');verdict['expanded_executions_with_targeted_overlap']=sum(expanded.values());verdict['summary_correction']='Included two additional NativeKVTypeProbe functions selected through their source filename; no sources, test logs, assertions or executions changed.'
(out/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n')
(out/'summary-correction.json').write_text(json.dumps({'original_validation_manifest':str(base/'manifest.json'),'original_manifest_sha256':sha(base/'manifest.json'),'initial_unique_function_count':24,'correct_unique_function_count':26,'cause':'Initial identifier substring accounting omitted two functions that Swift Testing selected by their source file. Raw pass summaries already reported all5 native dtype functions.','source_changed':False,'tests_rerun':False,'native_workspace':str(base/'native')},indent=2)+'\n')
files={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
(out/'manifest.json').write_text(json.dumps({'schema':1,'status':'PASS; corrected complete function/case accounting','files':files},indent=2)+'\n')
print(json.dumps({'manifest_sha256':sha(out/'manifest.json'),'payloads':len(files),'verdict':verdict},indent=2))
