from pathlib import Path
import copy
import hashlib
import json
import shutil
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'package'
sys.path.insert(0, str(PACKAGE))
from common import digest, read_json, verify_package
from analyze_traces import trace_control_checks
import results as result_validation
import test_inspect_logit_pair as fixture_tests


def refresh_manifest(package):
    manifest = read_json(package / 'manifest.json')
    path = package / 'binding.json'
    manifest['files']['binding.json'] = {'bytes': path.stat().st_size, 'mode': path.stat().st_mode & 0o777,
                                        'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    (package / 'manifest.json').write_text(json.dumps(manifest))


class TracePreparationTests(unittest.TestCase):
    def test_only_two_flags_extend_the_frozen_same_mode_native_commands(self):
        binding = read_json(PACKAGE / 'binding.json')
        for cell in binding['cells']:
            original = read_json(PACKAGE / cell['control_relative'] / 'native-argv.json')
            planned = cell['native_argv']
            strip_trace = planned[:-4]
            normalized = strip_trace.copy()
            # New run-local input/report destinations are the only non-flag path changes.
            normalized[2] = original[2]
            normalized[3] = original[3]
            self.assertEqual(normalized, original)
            self.assertEqual(planned[-4:], ['--logit-diagnostic-position', '30', '--logit-diagnostic-candidates', '795,735'])

    def test_pending_review_refuses_before_ssh_or_result_creation(self):
        binding = read_json(PACKAGE / 'binding.json')
        completed = subprocess.run([sys.executable, '-B', str(ROOT / 'controller.py'), '--manifest-sha256',
                                    digest(PACKAGE / 'manifest.json'), '--cell', binding['cells'][0]['id']],
                                   capture_output=True, text=True, timeout=20)
        self.assertNotEqual(completed.returncode, 0)
        self.assertIn('root review and hardware handoff required', completed.stderr)
        self.assertFalse((ROOT / 'results').exists())

    def test_wrong_trace_selection_or_backend_is_rejected(self):
        for option, value in [('--logit-diagnostic-position', '29'), ('--logit-diagnostic-candidates', '735,795'),
                              ('--kv-backend', 'paged')]:
            with self.subTest(option=option), tempfile.TemporaryDirectory() as temporary:
                package = Path(temporary) / 'package'
                shutil.copytree(PACKAGE, package, ignore=shutil.ignore_patterns('__pycache__'))
                binding = read_json(package / 'binding.json')
                args = binding['cells'][0]['wrapper_arguments']
                args[args.index(option) + 1] = value
                (package / 'binding.json').write_text(json.dumps(binding))
                refresh_manifest(package)
                with self.assertRaisesRegex(ValueError, 'bound serving scope'):
                    verify_package(digest(package / 'manifest.json'), package, local=True)

    def test_trace_report_uses_original_execution_validators(self):
        binding = read_json(PACKAGE / 'binding.json')
        manifest_sha = digest(PACKAGE / 'manifest.json')
        for cell in binding['cells']:
            report, _, _ = fixture_tests.Checks().sample(cell['mode'])
            with self.subTest(mode=cell['mode']), tempfile.TemporaryDirectory() as temporary:
                output = Path(temporary) / 'result'
                shutil.copytree(PACKAGE / cell['control_relative'], output)
                (output / 'report.json').write_text(json.dumps(report))
                environment = read_json(output / 'environment.json')
                environment['DARKBLOOM_PREFIX_CACHE_TEST_ROOT'] = binding['root'] + '/runs/' + cell['id'] + '/prefix-cache'
                (output / 'environment.json').write_text(json.dumps(environment))
                (output / 'native-argv.json').write_text(json.dumps(cell['native_argv']))
                metadata = read_json(output / 'metadata.json')
                metadata.update(cell=cell['id'], manifest_sha256=manifest_sha, native_argv=cell['native_argv'], effective_environment=environment)
                (output / 'metadata.json').write_text(json.dumps(metadata))
                self.assertEqual(result_validation.result_errors(output, cell, binding, manifest_sha), [])
                report['logit_diagnostic']['status'] = 'inconclusive'
                (output / 'report.json').write_text(json.dumps(report))
                self.assertTrue(result_validation.result_errors(output, cell, binding, manifest_sha))

    def test_prefill_geometry_and_unknown_state_are_explicit(self):
        for mode in ['off', 'automatic']:
            report, control, _ = fixture_tests.Checks().sample(mode)
            value = trace_control_checks(report, control, mode)
            self.assertTrue(value['trace_output_parity_all_seven'])
            self.assertTrue(value['verifier_counter_parity'])
            self.assertTrue(value['prefill_geometry_parity'])
            self.assertEqual(value['full_KV_state_identity'], 'UNOBSERVED')
            self.assertIsNone(value['full_target_input_ids'])
            report['rows'][0]['prefill_chunk_tokens_max'] = 512
            with self.assertRaisesRegex(ValueError, 'prefill geometry'):
                trace_control_checks(report, control, mode)


if __name__ == '__main__':
    unittest.main()
