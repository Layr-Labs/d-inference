import json
C=json.loads('{"remote": "/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http6-q38", "review_sha": "91a25b23cb7be34e6bc3f35a63a2bc680bfaad96490cde7e4f1c3c5a385b6e35", "archive_sha": "e89ae41a2b21594465b5c31dd036ff9d62d5f5626a1e16afc23c65a95b067a31", "manifest_sha": "82e81db534ea14e80b3f3f2502949b25bc77768e887fdb2755fdab674dddbd0e", "members": 1183, "binding_sha": "401c59e24a3acf88186e03eef9b48c86bbce372fefa6e1c7c9238ef693044b82"}')
from pathlib import Path
import hashlib,json,os,shutil,stat
root=Path(C['remote']);binding_path=root/'runtime-binding.json'
assert hashlib.sha256(binding_path.read_bytes()).hexdigest()==C['binding_sha']
binding=json.loads(binding_path.read_text());target=root/'runtime';source=Path(binding['resources_copy_source'])
def verify(p,item):
 info=p.lstat();assert stat.S_ISREG(info.st_mode) and not p.is_symlink()
 assert info.st_size==item['bytes'] and stat.S_IMODE(info.st_mode)==int(item['mode'],8),str(p)
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],str(p)
assert {p.name for p in target.iterdir()}=={'darkbloom'}
verify(target/'darkbloom',binding['files']['darkbloom'])
for name,item in binding['files'].items():
 if name!='darkbloom':verify(source/name,item)
for name,item in binding['files'].items():
 if name!='darkbloom':
  destination=target/name;destination.parent.mkdir(parents=True,exist_ok=True)
  assert not destination.exists();shutil.copy2(source/name,destination)
for name,item in binding['files'].items():verify(target/name,item)
assert {str(p.relative_to(target)) for p in target.rglob('*') if p.is_file()}==set(binding['files'])
assert os.access(target/'darkbloom',os.X_OK)
result={'status':'RUNTIME_VERIFIED','binding_sha256':C['binding_sha'],'files':binding['files'],'runtime_root':str(target),'inference_launched':False}
(root/'runtime-transfer-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
