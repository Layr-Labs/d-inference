"""Compare captured native bytes without implying common-input native replay."""
import numpy as np
from attention_packet.packet import load_packet


def compare_packet_bytes(left_path, right_path):
    left,right = load_packet(left_path),load_packet(right_path)
    rows = {}
    for name in left.tensors:
        a,b = left.tensors[name],right.tensors[name]
        compatible = all(a.descriptor[k] == b.descriptor[k] for k in ['dtype','shape','packedStrides'])
        row = {'layout_and_dtype_equal':compatible,'native_bytes_equal':a.raw == b.raw,
               'left_sha256':a.descriptor['sha256'],'right_sha256':b.descriptor['sha256']}
        if compatible:
            dtype = '<u4' if a.descriptor['dtype'] == 'float32' else '<u2'
            x,y = np.frombuffer(a.raw,dtype=dtype),np.frombuffer(b.raw,dtype=dtype)
            mask = x != y
            row['mismatched_native_elements'] = int(np.count_nonzero(mask))
            first = np.flatnonzero(mask)[:16]
            row['first_mismatch_BHTD'] = [list(map(int,np.unravel_index(i,a.descriptor['shape']))) for i in first]
        rows[name] = row
    scale_equal = left.record['scaleBits'] == right.record['scaleBits']
    return {'scope':'Two independently executed model trajectories; not an actual same-input native/paged replay.',
            'left_packet_sha256':left.packet_sha256,'right_packet_sha256':right.packet_sha256,
            'scale_bits_equal':scale_equal,'tensors':rows,
            'captured_original_Q_stored_KV_bytes_equal':scale_equal and all(rows[n]['layout_and_dtype_equal'] and rows[n]['native_bytes_equal'] for n in ['queries','storedKeys','storedValues']),
            'numerical_release_gate_evaluated':False}
