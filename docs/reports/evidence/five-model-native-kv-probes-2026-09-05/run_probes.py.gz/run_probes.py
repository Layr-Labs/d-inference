#!/usr/bin/env python3
"""Five ordered, isolated target-only native KV observations; no serving claim."""
import hashlib,json,os,pathlib,signal,subprocess,sys,time
base=pathlib.Path('/Users/gaj/autoresearch/radix-prefix-cache')
artifact=pathlib.Path(sys.argv[1]); output=pathlib.Path(sys.argv[2]); inputs=pathlib.Path(sys.argv[3])
output.mkdir(parents=True,exist_ok=False)
models=[
 ('qwen36',base/'qwen35b/models/qwen3.6-35b-a3b-vl-mtp-mxfp8/73a03825c2226177f3e679210965dba3508cdee8','d932e96b00404b0575fff47e2dac8ed113056b3f22d0040c3c8d3f9ef25b09ed'),
 ('qwen35',base/'qwen35b/models/qwen3.5-35b-a3b/8964653177a21be79662d51e69fe6a2263ffabb3','95811153b3bb2ed78bf44b3248b07b52fce637706107de8b0fddf21796ade01c'),
 ('qwen38',pathlib.Path.home()/'.cache/huggingface/hub/models--EigenLabs--Qwen3.8-27B-4bit-mtp/snapshots/06d517d395dfc5588090f7f534112bee331f7b4a','bbd0e0adcfe74e095073fefd0b9e116e4311d606ad9989cf81f8175e8ac18463'),
 ('gpt-oss-20b',pathlib.Path.home()/'.cache/huggingface/hub/models--gpt-oss-20b/snapshots/local','61bfc04e4016a7fa487eb10e29f79360047e302487229f298da3681984aec512'),
 ('gemma-4-26b',pathlib.Path.home()/'.cache/huggingface/hub/models--gemma-4-26b/snapshots/local','a4722b6020adb1894c700b45ddcd58bc0e0f033abe7139f86cbbbfe60cba4eb6')]
def busy():
 return subprocess.run(['pgrep','-f',r'Runner\.Worker|benchctl measure-job|measure-job\.sh'],stdout=subprocess.DEVNULL).returncode==0
def stop(p):
 if p is not None and p.poll() is None:
  os.killpg(p.pid,signal.SIGTERM)
  try:p.wait(timeout=5)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait(timeout=5)
manifest=json.loads((artifact/'artifact-manifest.json').read_text())
for name,entry in manifest['files'].items():
 p=artifact/name
 assert p.stat().st_size==entry['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==entry['sha256'],name
summary={'scope':'Target KV type probe only, cache-off/MTP-off, two prefill tokens plus one decode; separate fresh process per artifact; no serving backend or SSD store.','artifact_manifest_sha256':hashlib.sha256((artifact/'artifact-manifest.json').read_bytes()).hexdigest(),'rows':[]}
for name,model,expected in models:
 if busy() or any(subprocess.run(['pgrep','-x',n],stdout=subprocess.DEVNULL).returncode==0 for n in ['darkbloom','radix-engine']):raise SystemExit('Dedicated host busy')
 row=output/name;row.mkdir()
 cmd=[str(artifact/'radix-engine'),str(model),str(inputs/(name+'.json')),str(row/'report.json'),'cache-off','mtp-off','contiguous','--native-kv-probe-only']
 meta={'command':cmd,'expected_model_hash':expected,'started_unix':time.time(),'load_average_before':os.getloadavg(),'input_sha256':hashlib.sha256((inputs/(name+'.json')).read_bytes()).hexdigest()}
 p=None; monitor=None
 with (row/'engine.log').open('w') as log,(row/'telemetry.jsonl').open('w') as telemetry:
  try:
   monitor=subprocess.Popen([str(pathlib.Path.home()/'bench-runner/bin/macmon'),'pipe','-i','200'],stdout=telemetry,stderr=subprocess.DEVNULL,start_new_session=True)
   p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   deadline=time.monotonic()+600
   while p.poll() is None:
    if busy():raise RuntimeError('ranked job appeared')
    if time.monotonic()>deadline:raise RuntimeError('probe timeout600s')
    time.sleep(1)
   meta['exit_code']=p.returncode
  except Exception as e:meta['runner_error']=str(e)
  finally:stop(p);stop(monitor)
 meta['finished_unix']=time.time()
 if (row/'report.json').exists():
  report=json.loads((row/'report.json').read_text());meta['reported_status']=report.get('status')
  meta['model_hash_matches']=report.get('model_hash_before_load')==expected and report.get('model_hash_after_load')==expected
  meta['layer_dtypes']=report.get('layer_dtypes');meta['error']=report.get('error')
 (row/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
 summary['rows'].append({'model':name,**meta})
 (output/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
 print(name,meta.get('reported_status'),meta.get('error'),flush=True)
 if 'runner_error' in meta:raise SystemExit(meta['runner_error'])
