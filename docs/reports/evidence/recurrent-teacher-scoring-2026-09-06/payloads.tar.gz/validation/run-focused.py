from pathlib import Path
import gzip
import hashlib
import json
import re
import shutil
import subprocess
import sys
import time

out = Path(__file__).resolve().parent
native = out / 'native'
build = out / 'build'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
attempt = sys.argv[1] if len(sys.argv) > 1 else ''
tag = '-' + attempt if attempt else ''

def write(name, value):
    destination = name if name == 'status.json' else name.replace('.json', tag + '.json')
    (out / destination).write_text(json.dumps(value, indent=2) + '\n')

manifest = json.loads((out / ('sources-before' + attempt + '.json')).read_text())
for name, digest in manifest['compiled_files'].items():
    if name != 'Package.resolved':
        assert sha(native / name) == digest, name
for key, value in manifest['dependencies'].items():
    actual = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=value['path'], text=True).strip()
    assert actual == value['commit'], key
    assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=value['path'], text=True), key

for name in ['debug.yaml', 'workspace-state.json']:
    p = build / name
    (out / (name + tag + ('.gz' if name.endswith('.yaml') else ''))).write_bytes(
        gzip.compress(p.read_bytes(), mtime=0) if name.endswith('.yaml') else p.read_bytes())
graph = (build / 'debug.yaml').read_text()
assert '/checkouts/mlx-swift/Source/' not in graph
changed = [
    'Libraries/MLXLMCommon/ContinuousBatchingV2/AdmissionV2.swift',
    'Libraries/MLXLMCommon/ContinuousBatchingV2/EngineLoopV2.swift',
    'Tests/MLXLMTests/CBv2TeacherForcedCapacityTests.swift',
    'Tests/MLXLMTests/CBv2TeacherForcedRecurrentTests.swift',
    'Tests/MLXLMTests/CBv2PagedRuntimeDTypeTests.swift',
]
proof = {}
for name in changed:
    p = native / name
    assert str(p) in graph or str(p.resolve()) in graph, name
    proof[name] = {'path': str(p), 'sha256': sha(p)}
swift = Path(manifest['dependencies']['swift']['path'])
generated = swift / 'Source/Cmlx/mlx-generated/quantized.cpp'
assert str(generated) in graph
assert generated.read_text().count('sum += U(x[i])') == 10
write('compiler-source-proof.json', {'native_sources': proof, 'dependencies': manifest['dependencies'],
    'corrected_generated_qmv': {'path': str(generated), 'sha256': sha(generated)},
    'remote_mlx_excluded': True})

binary = build / 'arm64-apple-macosx/debug/mlx-swift-lmPackageTests.xctest/Contents/MacOS/mlx-swift-lmPackageTests'
assert binary.is_file()
metal = Path(manifest['metallib']['path'])
assert sha(metal) == manifest['metallib']['sha256']
shutil.copy2(metal, binary.parent / 'mlx.metallib')
write('test-binary.json', {'path': str(binary), 'sha256': sha(binary), 'bytes': binary.stat().st_size,
    'metallib_path': str(binary.parent / 'mlx.metallib'), 'metallib_sha256': sha(binary.parent / 'mlx.metallib')})

filters = ['CBv2TeacherForcedCapacityTests', 'CBv2TeacherForcedRecurrentTests',
    'CBv2PagedRuntimeDTypeEngineTests', 'CBv2TeacherForcedScoringTests',
    'CBv2TeacherForcedScoreDiagnosticTests', 'CBv2PagedAdmissionTests', 'CBv2RecurrentStateTests']
write('filters.json', filters)
results = []
for filter_name in filters:
    argv = ['swift', 'test', '--skip-build', '--scratch-path', str(build), '--filter', filter_name]
    log = out / (filter_name + tag + '.log')
    start = time.time()
    with log.open('x') as stream:
        process = subprocess.Popen(argv, cwd=native, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
        write('status.json', {'state': 'TESTING', 'filter': filter_name, 'pid': process.pid, 'pgid': process.pid, 'argv': argv})
        code = process.wait(timeout=600)
    text = log.read_text()
    nonempty = bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test', text))
    skipped = bool(re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test', text, re.M))
    row = {'filter': filter_name, 'exit_code': code, 'nonempty': nonempty, 'skipped': skipped,
        'seconds': time.time() - start, 'log': str(log), 'log_sha256': sha(log), 'argv': argv}
    results.append(row)
    write('tests.json', results)
    print(json.dumps(row), flush=True)
    if code or not nonempty or skipped:
        write('status.json', {'state': 'TEST_FAILED', 'result': row})
        raise SystemExit(1)

for name, digest in manifest['compiled_files'].items():
    if name != 'Package.resolved':
        assert sha(native / name) == digest, name
write('sources-after.json', {'native_source_unchanged': True, 'dependencies': manifest['dependencies']})
write('status.json', {'state': 'FOCUSED_TESTS_PASS', 'filters': len(results),
    'all_nonempty': all(row['nonempty'] for row in results), 'zero_skips': all(not row['skipped'] for row in results)})
