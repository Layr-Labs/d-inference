package e2e

import (
	"context"
	"fmt"
	"time"

	"github.com/eigeninference/d-inference/e2e/testbed"
)

// Readiness is measured before each next request. Post-work cleanup is checked
// separately by Stop and cannot relabel a completed hot request as incorrect.
func waitConnectedHostEntry(ctx context.Context, suite *testbed.Suite, model string) ([]testbed.HostObservation, error) {
	wait, cancel := context.WithTimeout(ctx, 5*time.Minute)
	defer cancel()
	var latest []testbed.HostObservation
	for {
		latest = nil
		ready := true
		for _, p := range suite.Providers {
			observation, err := p.ObserveHost(wait)
			if err != nil {
				return latest, err
			}
			latest = append(latest, observation)
			if observation.EntryReady() != nil {
				ready = false
			}
		}
		slots := connectedSlots(suite, model)
		if len(slots) != len(suite.Providers) {
			ready = false
		}
		for _, slot := range slots {
			found := false
			if slot.Capacity != nil {
				for _, capacity := range slot.Capacity.Slots {
					if capacity.Model == model {
						found = true
						if capacity.NumRunning != 0 || capacity.NumWaiting != 0 || capacity.ActiveTokens != 0 {
							ready = false
						}
					}
				}
			}
			if !found {
				ready = false
			}
		}
		if ready {
			return latest, nil
		}
		select {
		case <-wait.Done():
			return latest, fmt.Errorf("next measured entry not ready: %w", wait.Err())
		case <-time.After(time.Second):
		}
	}
}

// Targets may move paths between hosts, but cannot change the selected runtime,
// target weights, assistant weights or immutable catalog input.
func validateConnectedTargetBindings(in connectedCacheInput) error {
	if in.Providers == nil {
		return nil
	}
	if err := testbed.ValidateProviderTargets(in.Providers, 2); err != nil {
		return err
	}
	for _, target := range in.Providers {
		if target.RuntimeFiles["darkbloom"].SHA256 != in.ProviderSHA256 || target.RuntimeFiles["mlx.metallib"].SHA256 != in.MetallibSHA256 {
			return fmt.Errorf("host runtime differs from selected connected runtime")
		}
		if (target.AssistantPath == "") != (in.AssistantPath == "") {
			return fmt.Errorf("host assistant selection differs")
		}
		if len(target.Models) != len(in.Catalog) {
			return fmt.Errorf("host model inputs differ from exact catalog")
		}
		for _, model := range target.Models {
			found := false
			for _, catalog := range in.Catalog {
				if model.ID != catalog.Entry.ID {
					continue
				}
				found = true
				if catalog.Manifest.ModelID != model.ID || len(model.Files) != len(catalog.Manifest.Files) {
					return fmt.Errorf("host model manifest differs from catalog")
				}
				for _, file := range catalog.Manifest.Files {
					actual, ok := model.Files[file.Path]
					if !ok || actual.SHA256 != file.SHA256 || actual.Bytes != file.SizeBytes {
						return fmt.Errorf("host model file differs from selected catalog")
					}
				}
				if model.Snapshot == target.AssistantPath && model.ID == in.Artifact.ModelID {
					return fmt.Errorf("assistant cannot substitute target model")
				}
			}
			if !found {
				return fmt.Errorf("host model not in selected catalog")
			}
		}
	}
	return nil
}
