from pathlib import Path
import gzip,hashlib,json,re,shutil
out=Path(__file__).resolve().parent; native=out/'native'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
assert not (out/'manifest.json').exists()
results=json.loads((out/'execution.json').read_text()); filters=json.loads((out/'filters.json').read_text())
assert len(results)==len(filters)+2 and all(r['exit_code']==0 and r['nonzero_no_skips'] for r in results)
status=json.loads((out/'run-status.json').read_text());assert status=={'failed':[],'all_filters_run':True}
identifiers=[line.strip() for line in (out/'identifiers.log').read_text().splitlines() if line.startswith('MLXLMTests.')]
selected={}
for name in filters:
 source=native/'Tests/MLXLMTests'/(name+'.swift')
 owners=re.findall(r'^(?:(?:final|private|public) )*(?:struct|class) (\w+)',source.read_text(),re.M)
 ids=[i for i in identifiers if any(i.startswith('MLXLMTests.'+owner+'/') for owner in owners)]
 body=(out/(name+'.log')).read_text();swift=[int(x) for x in re.findall(r'Test run with (\d+) tests?',body)];xct=[int(x) for x in re.findall(r'Executed (\d+) tests?, with 0 failures',body)]
 count=max(swift+xct+[0]);assert count==len(ids)>0,(name,count,len(ids),owners)
 assert not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',body,re.M)
 parameterized=[int(x) for x in re.findall(r'✔ Test .* with (\d+) test cases passed',body)]
 selected[name]={'identifiers':ids,'source_file_declared_test_owners':owners,'test_functions':count,'expanded_test_cases':count+sum(x-1 for x in parameterized),'log_sha256':sha(out/(name+'.log')),'framework':'XCTest' if max(xct+[0]) else 'Swift Testing'}
unique={i for suite in selected.values() for i in suite['identifiers']};functions=sum(s['test_functions'] for s in selected.values());expanded=sum(s['expanded_test_cases'] for s in selected.values())
assert len(unique)==functions==77
write('selected-identifiers.json',selected)
known={};nm=json.loads((out/'native-source-manifest.json').read_text())
for name,digest in nm['files'].items():
 p=native/name;assert sha(p)==digest,name;known[str(p.resolve())]={'group':'native','sha256':digest}
deps=json.loads((out/'dependency-source-manifest.json').read_text())
for key,digest in deps['files'].items():
 alias,name=key.split('/',1);p=Path(deps['repositories'][alias])/name;assert sha(p)==digest,key;known[str(p.resolve())]={'group':'dependency','sha256':digest}
scratch=Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift');jinja=json.loads((out/'jinja-source-manifest.json').read_text())
for name,digest in jinja['files'].items():
 p=scratch/'checkouts/swift-jinja'/name;assert sha(p)==digest,name;known[str(p.resolve())]={'group':'jinja','sha256':digest}
body=gzip.decompress((out/'actual-build-debug.yaml.gz').read_bytes()).decode();matched={};unknown=[]
for name in re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',body):
 p=Path(name);resolved=str(p.resolve());row=known.get(resolved)
 if row:
  assert sha(p)==row['sha256'],name;matched[name]={'resolved_source':resolved,**row}
 elif resolved.startswith(str(native.resolve())+'/'):unknown.append(name)
assert not unknown,unknown
assert '/checkouts/mlx-swift/Source/' not in body
write('all-owned-graph-source-proof.json',{'counts':{g:sum(r['group']==g for r in matched.values()) for g in ['native','dependency','jinja']},'files':matched,'unmapped_native_source_paths':unknown,'scope':'Declared build graph source references matched against frozen inputs; this is not a claim that every graph entry links into the selected test product. Test executions are independently recorded.','dependency_identity':'SwiftPM created an unused remote mlx-swift checkout during resolution. The actual declared source graph uses the verified local pinned MLX tree; checkout existence is not compile identity evidence.','remote_mlx_source_excluded':True})
for name,row in nm['candidate_changes'].items():
 assert sha(native/name)==row['after_sha256'];p=out/'owned'/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(native/name,p)
source=Path('/tmp/darkbloom-attention-packet-capture-source1');assert sha(source/'manifest.json')=='45e11082b4422bac8d7b008e4cf6b046cde972d28ef5b3218348217cfda58982'
shutil.copy2(source/'manifest.json',out/'approved-source1-manifest.json')
write('verdict.json',{'status':'PASS_NATIVE_ATTENTION_PACKET_AND_REGRESSION_TESTS','test_functions':functions,'expanded_test_cases':expanded,'new_packet_functions':12,'new_packet_expanded_cases':29,'failed':0,'skipped':0,'native_inputs':len(nm['files']),'dependency_inputs':len(deps['files']),'jinja_inputs':len(jinja['files']),'changed_native_files':len(nm['candidate_changes']),'source_corrections_during_validation':False,'build_seconds':results[0]['seconds'],'real_models_run':False,'benchmark_tests_run':False,'default_settings_changed':False,'limitations':'Synthetic packet byte correctness and ordinary engine lifecycle controls do not establish target-model numerical parity, same-input native replay, or independent full-history storage accuracy.','next':'Benchmark options/export tests; root review before integration, optimized packet build or real-model run.'})
files={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.relative_to(out).parts[0]!='native' and p.name!='manifest.json'}
write('manifest.json',{'schema':1,'status':'PASS_NATIVE_ATTENTION_PACKET_AND_REGRESSION_TESTS','files':files,'test_binary':json.loads((out/'test-binary.json').read_text())})
for name,row in files.items():assert sha(out/name)==row['sha256']
print(json.dumps({'manifest':str(out/'manifest.json'),'sha256':sha(out/'manifest.json'),'payloads':len(files),'verdict':json.loads((out/'verdict.json').read_text())},indent=2))
