from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0,'/tmp/darkbloom-q36-owner0-replay-plan1/runner')
from attention_packet.files import PacketError,hashed_file,sha256


class CanonicalRootTests(unittest.TestCase):
    def test_owned_root_alias_resolves_before_strict_payload_validation(self):
        with tempfile.TemporaryDirectory()as temporary:
            parent=Path(temporary).resolve();root=parent/'actual';root.mkdir()
            (root/'output.bin').write_bytes(b'\0\0');alias=parent/'alias';alias.symlink_to(root,target_is_directory=True)
            descriptor={'file':'output.bin','byteCount':2,'sha256':sha256(b'\0\0')}
            with self.assertRaisesRegex(PacketError,'symlink escapes'):hashed_file(alias,descriptor,set(),32)
            self.assertEqual(hashed_file(alias.resolve(strict=True),descriptor,set(),32),b'\0\0')

    def test_canonical_root_still_refuses_a_payload_symlink_escape(self):
        with tempfile.TemporaryDirectory()as temporary:
            parent=Path(temporary).resolve();root=parent/'actual';root.mkdir()
            outside=parent/'outside.bin';outside.write_bytes(b'\0\0');(root/'output.bin').symlink_to(outside)
            descriptor={'file':'output.bin','byteCount':2,'sha256':sha256(b'\0\0')}
            with self.assertRaisesRegex(PacketError,'symlink escapes'):hashed_file(root.resolve(strict=True),descriptor,set(),32)


if __name__=='__main__':unittest.main()
