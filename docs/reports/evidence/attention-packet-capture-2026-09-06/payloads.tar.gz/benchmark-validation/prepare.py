from pathlib import Path
import difflib, hashlib, io, json, shutil, subprocess, tarfile

out = Path(__file__).resolve().parent
primary = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
candidate = Path('/Users/gaj/Documents/DarkbloomDev/wt/q36-attention-packet-090')
native = Path('/tmp/darkbloom-attention-packet-native-validation1')
source = Path('/tmp/darkbloom-attention-packet-capture-source1')
prior = Path('/tmp/darkbloom-q36-attention-owner-identity-release-probe1')
review = Path('/tmp/darkbloom-attention-packet-capture-root-source-review1.json')
local_mlx = Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift')
scratch = Path('/tmp/darkbloom-process-memory-telemetry-swift-validation1/build')
workspace = out/'workspace'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value):
    (out/name).write_text(json.dumps(value, indent=2)+'\n')

assert sha(source/'manifest.json') == '45e11082b4422bac8d7b008e4cf6b046cde972d28ef5b3218348217cfda58982'
for name, row in json.loads((source/'manifest.json').read_text())['files'].items():
    assert sha(source/name) == row['sha256'], name
assert json.loads(review.read_text())['status'] == 'SOURCE_REVIEWED_FOR_ISOLATED_VALIDATION'
proof = json.loads((source/'source-proof.json').read_text())['parent']
base = proof['base_commit']
assert base == '384c321aa7565864182c02210fc4d212efc6501b'
workspace.mkdir()
archive = subprocess.check_output(['git', 'archive', base, 'provider-swift'], cwd=primary)
with tarfile.open(fileobj=io.BytesIO(archive)) as packed:
    packed.extractall(workspace, filter='data')
provider = workspace/'provider-swift'
canonical_provider = {str(p.relative_to(workspace)): sha(p) for p in sorted(provider.rglob('*')) if p.is_file()}
assert canonical_provider == json.loads((prior/'provider-source-manifest.json').read_text())['canonical_files']
before = (provider/'Package.swift').read_text()
old = '.package(path: "../libs/mlx-swift")'
assert before.count(old) == 1
after = before.replace(old, '.package(path: "'+str(local_mlx)+'")')
(provider/'Package.swift').write_text(after)
(out/'provider-package-compile-only-overlay.patch').write_text(''.join(difflib.unified_diff(
    before.splitlines(keepends=True), after.splitlines(keepends=True),
    fromfile='canonical/provider-swift/Package.swift', tofile='compiled/provider-swift/Package.swift')))
archive = subprocess.check_output(['git', 'archive', '--prefix=radix-engine/', base+':scripts/benchmarks/radix-engine'], cwd=primary)
with tarfile.open(fileobj=io.BytesIO(archive)) as packed:
    packed.extractall(out, filter='data')
before_after = {}
for name, row in proof['files'].items():
    original = subprocess.run(['git', 'show', base+':'+name], cwd=primary,
                              stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    before = hashlib.sha256(original.stdout).hexdigest() if original.returncode == 0 else None
    assert before == row['before_sha256'], name
    frozen = source/'sources/parent'/name
    assert sha(frozen) == sha(candidate/name) == row['after_sha256'], name
    assert frozen.stat().st_size == row['bytes'], name
    before_after[name] = {'archived_base_before_sha256': before, 'live_candidate_after_sha256': sha(candidate/name), 'matched': True}
    if name.startswith('scripts/benchmarks/radix-engine/'):
        destination = out/name.removeprefix('scripts/benchmarks/')
    else:
        destination = out/'owned-wrappers'/Path(name).name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(frozen, destination)
write('before-after-check.json', before_after)
canonical_harness = {str(p.relative_to(out)): sha(p) for p in sorted((out/'radix-engine').rglob('*')) if p.is_file()}
resolved = prior/'workspace/provider-swift/Package.resolved'
assert sha(resolved) == 'b2b12d24d48bbedc4583d8831e0b81fe68b96d641804e0ebc56715cd2d88a7ea'
shutil.copy2(resolved, provider/'Package.resolved')
shutil.copy2(resolved, out/'radix-engine/Package.resolved')
(workspace/'libs').mkdir()
(workspace/'libs/mlx-swift').symlink_to(local_mlx, target_is_directory=True)
(workspace/'libs/mlx-swift-lm').symlink_to(native/'native', target_is_directory=True)
for name in ['native-source-manifest.json', 'dependency-source-manifest.json', 'jinja-source-manifest.json', 'pinned-availability-api.json']:
    shutil.copy2(native/name, out/name)
for name, digest in json.loads((out/'native-source-manifest.json').read_text())['files'].items():
    assert sha(workspace/'libs/mlx-swift-lm'/name) == digest, name
deps = json.loads((out/'dependency-source-manifest.json').read_text())
for key, digest in deps['files'].items():
    alias, name = key.split('/', 1)
    assert sha(Path(deps['repositories'][alias])/name) == digest, key
for name, digest in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():
    assert sha(scratch/'checkouts/swift-jinja'/name) == digest, name
provider_files = {str(p.relative_to(workspace)): sha(p) for p in sorted(provider.rglob('*')) if p.is_file()}
harness_files = {str(p.relative_to(out)): sha(p) for p in sorted((out/'radix-engine').rglob('*')) if p.is_file()}
write('provider-source-manifest.json', {'base_commit': base, 'canonical_files': canonical_provider, 'files': provider_files})
write('harness-source-manifest.json', {'base_commit': base, 'canonical_files': canonical_harness,
                                     'files': harness_files, 'parent_candidate_changes': proof['files']})
write('filters.json', ['BenchmarkAttentionPacketOptionsTests', 'BenchmarkAttentionPacketExportTests',
                      'BenchmarkAttentionMetadataOptionsTests', 'BenchmarkLogitDiagnosticOptionsTests', 'BenchmarkIdleObservationTests'])
shutil.copy2(review, out/'root-source-review.json')
shutil.copy2(source/'manifest.json', out/'approved-source-manifest.json')
write('integration.json', {
    'status': 'PREPARED_ONLY_NO_SWIFT_PROCESS_STARTED', 'parent_base': base,
    'native_validation': str(native), 'workspace': str(workspace), 'scratch': str(scratch),
    'environment': {'RADIX_SOURCE_ROOT': str(workspace), 'RADIX_CANDIDATE_BUILD': '1'},
    'source_manifest': str(source/'manifest.json'), 'source_manifest_sha256': sha(source/'manifest.json'),
    'root_source_review': str(review), 'root_source_review_sha256': sha(review),
    'provider_inputs': len(provider_files), 'harness_inputs': len(harness_files),
    'policy': 'Await explicit Swift lane handoff; native packet validation must pass before benchmark run. No optimized compile/model/key operations.',
    'other_unintegrated_candidates_included': False,
})
print(json.dumps({'provider_inputs': len(provider_files), 'harness_inputs': len(harness_files),
                  'canonical_harness_inputs': len(canonical_harness), 'source_changes': len(proof['files']), 'swift_started': False}, indent=2))
