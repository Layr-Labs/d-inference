"""Pure checks; confirmed MTP context must match actual emitted history."""
import hashlib
import json
import math
import struct


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def logit_errors(report):
    errors = []
    def require(ok, message):
        if not ok:
            errors.append(message)
    try:
        diagnostic = report['logit_diagnostic']
        snapshot = diagnostic['snapshot']
        config = snapshot['configuration']
        require(diagnostic['status'] == 'captured' and config['requestID'] == 2
                and config['outputIndex'] == 7 and config['candidateIDs'] == [42392, 62203],
                'selected diagnostic configuration/status mismatch')
        records = snapshot['records']
        require(1 <= len(records) <= 8 and snapshot['reservedRecords'] == len(records)
                and snapshot['invalidVocabularyRecords'] == snapshot['omittedRecords'] == 0,
                'capture incomplete, omitted, or outside bounded record limit')
        confirmed = [r for r in records if r['outcome'] == 'confirmed']
        require(len(confirmed) == 1, 'exactly one confirmed selected decision required')
        if len(confirmed) != 1:
            return errors
        r = confirmed[0]
        main = report['rows'][0]
        tokens, prompt = main['token_ids'], main['prompt_token_ids']
        base, column = r['outputBase'], r['column']
        require(isinstance(base, int) and isinstance(column, int)
                and 0 <= base <= 7 and 0 <= column <= 7 and base + column == 7,
                'selected output base/column does not name index7')
        if not (isinstance(base, int) and isinstance(column, int) and 0 <= base <= 7 and 0 <= column <= 7):
            return errors
        require(r['requestID'] == 2 and r['outputIndex'] == 7
                and r['candidateIDs'] == [42392, 62203]
                and r['batchIndex'] == 0 and r['batchSize'] == 1,
                'selected request/position/candidates/batch mismatch')
        require(r['seedToken'] == (tokens[base - 1] if base else prompt[-1])
                and r['draftPrefix'] == tokens[base:7],
                'confirmed MTP seed/draft prefix differs from emitted history')
        require(r['cacheOffset'] == len(prompt) + base - 1,
                'native cache offset does not align with selected seed context')
        require(0 <= column <= r['acceptedDrafts'] <= r['draftDepth']
                and column < r['confirmedWidth'] <= r['verificationWidth']
                and isinstance(r['phase'], str) and bool(r['phase']),
                'selected decision is outside confirmed verification geometry')
        require(r['targetToken'] == r['argMaxID'] == tokens[7],
                'confirmed argmax/target differs from actual emitted token')
        require(r['nanCount'] == r['infiniteCount'] == 0
                and isinstance(r['logitDType'], str) and bool(r['logitDType'])
                and len(r['valueBits']) == 5
                and all(math.isfinite(struct.unpack('<f', struct.pack('<I', x))[0]) for x in r['valueBits']),
                'selected logits missing or nonfinite')
        require(all(0 <= x < r['vocabularySize'] for x in r['candidateIDs'] + r['topTwoIDs'] + [r['argMaxID']]),
                'selected token outside vocabulary')
        # Unconfirmed captures may occur before the eventual selected output.
        # They are retained for context and are never used as accepted decisions.
        require(all(r['requestID'] == 2 and r['outputIndex'] == 7
                    and r['candidateIDs'] == [42392, 62203]
                    and r['outcome'] in ['confirmed', 'speculative_suffix', 'truncated', 'discarded']
                    for r in records), 'unexpected additional diagnostic record')
    except (KeyError, TypeError, ValueError, IndexError, struct.error, OverflowError):
        errors.append('malformed or incomplete selected logit evidence')
    return errors


def result_errors(local, cell, plan, binding, report, output_root):
    errors = []
    def require(ok, message):
        if not ok:
            errors.append(message)
    try:
        meta = json.loads((local / 'metadata.json').read_text())
        expected = next(c for c in binding['commands'] if c['cell'] == cell['id'])
        require(meta['command'] == expected['expected_observed_native_argv'],
                'native argv differs after explicit owned input-copy substitution')
        require(meta['source_input_sha256'] == meta['input_sha256'] == plan['input_sha256']
                and digest(local / 'input.json') == plan['input_sha256'], 'input bytes changed')
        require(meta['binary_sha256'] == binding['artifacts']['radix-engine']['sha256']
                and meta['exit_code'] == 0 and meta['status'] == 'completed',
                'bound native runtime did not complete successfully')
        require(report['runtime_identity']['binary_sha256'] == binding['artifacts']['radix-engine']['sha256']
                and report['runtime_identity']['metallib_sha256'] == binding['artifacts']['mlx.metallib']['sha256'],
                'native report runtime differs from bound artifacts')
        require(report['requested_backend'] == report['resolved_backend'] == cell['backend']
                and report['backend_fallback'] is None, 'backend/fallback mismatch')
        require(report['cache_requested'] is False and report['max_concurrent_requests'] == 1
                and report['cache_mode_requested'] == 'ssd' and report['key_mode_requested'] == 'ephemeral'
                and report['kv_grant_mode'] == 'production_single_slot'
                and report['mtp'] == 'off', 'serving mode mismatch')
        require(report['expected_model_sha256'] == report['verified_model_hash'] == plan['expected_model_sha256']
                and report['input_sha256'] == plan['input_sha256'], 'model/input identity mismatch')
        rows = report['rows']
        require(len(rows) == 2 and all(r['prompt_tokens'] == 5418 and r['cache_outcome'] == 'disabled'
                and r['prompt_render_date'] == '2026-09-06' for r in rows), 'main prompt/cache/date mismatch')
        require(cell['trace'] is False, 'MTP-off control must not request diagnostics')
        require(report['cancelled']['token_ids'] == report['recovered']['token_ids'][:len(report['cancelled']['token_ids'])],
                'canceled output is not its own recovery prefix')
        require(report.get('attention_metadata') is None, 'unrequested attention metadata')
        if cell['backend'] == 'paged':
            other = next(c for c in plan['cells'] if c['backend'] == 'contiguous' and not c['trace'])
            other_report = json.loads((output_root / other['id'] / 'report.json').read_text())
            require(rows[0]['prompt_token_ids'] == other_report['rows'][0]['prompt_token_ids'],
                    'backend selected prompt/prior context differs')
        if not cell['trace']:
            require(report.get('logit_diagnostic') is None, 'control emitted logit diagnostic')
            return errors
        control_cell = next(c for c in plan['cells'] if c['backend'] == cell['backend'] and not c['trace'])
        control = json.loads((output_root / control_cell['id'] / 'report.json').read_text())
        fields = ['prompt_token_ids', 'token_ids', 'prompt_tokens', 'completion_tokens', 'finish', 'outcome']
        count = 0
        for group in ['rows', 'tenant_checks', 'cancel_donor', 'recovered']:
            left = control[group] if isinstance(control[group], list) else [control[group]]
            right = report[group] if isinstance(report[group], list) else [report[group]]
            require(len(left) == len(right), group + ' membership changed')
            for index, (a, b) in enumerate(zip(left, right)):
                count += 1
                require(all(a[k] == b[k] for k in fields), group + ':' + str(index) + ' same-build trajectory changed')
        require(count == 7, 'seven complete same-build trajectories required')
        errors.extend(logit_errors(report))
    except (OSError, ValueError, KeyError, TypeError, IndexError, AttributeError):
        errors.append('malformed or incomplete strict evidence')
    return errors
