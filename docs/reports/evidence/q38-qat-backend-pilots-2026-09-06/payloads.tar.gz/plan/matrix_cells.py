#!/usr/bin/env python3
"""Read-only commands/status/collection for one frozen benchmark plan; never executes a model."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import shlex
import shutil
import statistics
import sys

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'runner'))
from compare_radix_engine import compare, mismatch
from radix_engine_evidence import report_errors

RESOURCE_NAMES = {
    'mlx.metallib', 'mlx-swift-lm_MLXLMCommon.bundle/pagedattention.metal',
    'swift-crypto_Crypto.bundle/PrivacyInfo.xcprivacy', 'swift-nio_NIOPosix.bundle/PrivacyInfo.xcprivacy',
    'swift-transformers_Hub.bundle/gpt2_tokenizer_config.json', 'swift-transformers_Hub.bundle/t5_tokenizer_config.json',
}

def read(path):
    return json.loads(Path(path).read_text())

def sha256(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def require(condition, message):
    if not condition:
        raise ValueError(message)

def verify_file(record):
    require(isinstance(record, dict) and record.get('path') and record.get('sha256'), 'unbound file identity')
    path = Path(record['path'])
    require(path.is_absolute() and path.is_file(), 'missing absolute file: ' + str(path))
    require(sha256(path) == record['sha256'], 'file hash mismatch: ' + str(path))
    return path

def load_plan():
    plan = read(ROOT / 'plan.json')
    for model in plan['models']:
        require(sha256(ROOT / model['input']) == model['input_sha256'], 'input hash mismatch: ' + model['label'])
        require(sha256(ROOT / model['manifest']) == model['manifest_sha256'], 'model manifest mismatch: ' + model['label'])
        prepared = (json.dumps(read(ROOT / model['input']), indent=2, sort_keys=True) + '\n').encode()
        require(hashlib.sha256(prepared).hexdigest() == model['prepared_input_sha256'], 'prepared input hash mismatch')
    require(len(plan['models']) == 6 and len(plan['cells']) == 216, 'incomplete six-artifact topology')
    require(sum(c['support'] == 'supported' for c in plan['cells']) == 189, 'supported cell count changed')
    require(sum(p['required_comparison'] for p in plan['pairs']) == 162, 'supported comparison count changed')
    require(len(plan['pairs']) == 216 and len({p['id'] for p in plan['pairs']}) == 216,
            'missing or duplicated conceptual comparisons')
    require(len({c['id'] for c in plan['cells']}) == 216, 'duplicated conceptual cells')
    require(sorted(c['order'] for c in plan['cells']) == list(range(1, 217)), 'invalid cell order')
    require(len(plan['rollback_controls']) == 27
            and {c['unsupported_cell'] for c in plan['rollback_controls']}
            == {c['id'] for c in plan['cells'] if c['support'] == 'unsupported'},
            'missing or duplicated unsupported rollback controls')
    return plan

def verify_package(manifest_path):
    """Verify the reviewed payload inventory before using its helpers or plan."""
    manifest_path = Path(manifest_path)
    inventory = read(manifest_path)['files']
    require(isinstance(inventory, dict) and inventory, 'empty plan package inventory')
    for relative, identity in inventory.items():
        path = Path(relative)
        require(not path.is_absolute() and '..' not in path.parts, 'unsafe package inventory path')
        payload = manifest_path.parent / path
        require(payload.is_file() and payload.stat().st_size == identity['bytes']
                and sha256(payload) == identity['sha256'], 'plan package mismatch: ' + relative)

def require_current_prompt_date(plan, utc_day=None):
    utc_day = utc_day or datetime.now(timezone.utc).date().isoformat()
    require(plan['prompt_date'] == utc_day,
            'prompt date expired; prepare a separately reviewed successor input/CPU plan')

def require_executable(path):
    require(Path(path).is_file() and os.access(path, os.X_OK),
            'runtime executable permission missing: ' + str(path))

def verified_bindings(path):
    binding = read(path)
    require(binding.get('state') == 'reviewed' and binding.get('review_id'), 'runtime binding is unreviewed')
    require(binding.get('storage_retention_review'), 'storage/retention review is pending')
    require(verify_file(binding.get('plan_manifest')).resolve() == (ROOT / 'manifest.json').resolve(), 'binding targets a different plan')
    verify_package(ROOT / 'manifest.json')
    verify_file(binding.get('runtime_source_manifest'))
    binary = verify_file(binding.get('binary'))
    require_executable(binary)
    resources = binding.get('resources')
    require(isinstance(resources, dict) and RESOURCE_NAMES <= set(resources), 'runtime resource identities are unbound')
    for name, record in resources.items():
        resource = verify_file(record)
        require(resource.resolve() == (binary.parent / name).resolve(), 'resource must accompany probe: ' + name)
    require(Path(binding.get('python_executable') or '').is_file(), 'absolute Python executable is unbound')
    require(Path(binding['python_executable']).is_absolute(), 'Python path must be absolute')
    require_executable(binding['python_executable'])
    require(isinstance(binding.get('min_free_bytes'), int) and binding['min_free_bytes'] > 0, 'minimum free storage is unbound')
    require(binding.get('results_root') and Path(binding['results_root']).is_absolute(), 'absolute results root is unbound')
    return binding

def output_directory(binding, cell):
    return Path(binding['results_root']) / cell['id']

def cell_status(binding, cell):
    out = output_directory(binding, cell)
    if cell.get('support') == 'unsupported':
        return 'unsupported_attempt_retained' if out.exists() else 'unsupported_unrun'
    if out.exists():
        try:
            metadata = read(out / 'metadata.json')
            report = read(out / 'report.json')
            if metadata.get('status') == report.get('status') == 'completed' and metadata.get('exit_code') == 0:
                return 'completed_unvalidated'
            return 'retained_failed_or_partial'
        except (OSError, ValueError):
            return 'retained_failed_or_partial'
    return 'blocked' if cell['blockers'] else 'untouched'

def command(plan, binding, cell):
    require(cell.get('support', 'supported') == 'supported', 'unsupported performance cell; use its separate readiness-refusal control')
    require(not cell['blockers'], 'cell blocked: ' + ', '.join(cell['blockers']))
    require(cell_status(binding, cell) == 'untouched', 'attempt directory already exists; preserve it and use a separately reviewed attempt root')
    require_current_prompt_date(plan)
    model = next(m for m in plan['models'] if m['label'] == cell['model'])
    target = binding.get('models', {}).get(model['label'], {})
    require(target.get('directory') and Path(target['directory']).is_absolute() and Path(target['directory']).is_dir(), 'exact target directory is unbound')
    verify_file(target.get('identity_audit'))
    out = output_directory(binding, cell)
    ancestor = out.parent
    while not ancestor.exists():
        ancestor = ancestor.parent
    space = shutil.disk_usage(ancestor)
    floor = max(20 * (1 << 30), int(space.total * 0.05), binding['min_free_bytes'])
    require(space.free > floor, 'free space below reviewed entry threshold')
    args = [binding['python_executable'], '-B', str(ROOT / 'runner/run_radix_engine.py'),
            '--binary', binding['binary']['path'], '--model-directory', target['directory'],
            '--input', str(ROOT / model['input']), '--output', str(out),
            '--cache', cell['cache'], '--mtp', 'on' if model['normal_mtp'] else 'off',
            '--kv-backend', cell['backend'], '--cache-mode', 'ssd', '--key-mode', 'ephemeral',
            '--production-kv-grant', '--concurrency', str(cell['concurrency']),
            '--expected-model-sha256', model['aggregate_sha256'], '--prompt-date', plan['prompt_date'],
            '--trial', str(cell['repetition']), '--startup-timeout', '240']
    if model['assistant']:
        fixture = Path(target.get('assistant_directory') or '')
        expected = read(ROOT / 'provenance/gemma-two-file-fixture-proof.json')['copied']
        require(fixture.is_absolute() and fixture.is_dir() and {p.name for p in fixture.iterdir()} == set(expected), 'Gemma requires the exact two-file local override')
        for name, identity in expected.items():
            verify_file(dict(path=str(fixture / name), sha256=identity['sha256']))
        args += ['--assistant-directory', str(fixture)]
    # No inherited SERIAL/fixed-depth/grant/cache debug switches. This applies
    # to the printed command itself, even if the invoking shell later changes.
    return ['/usr/bin/env', '-i', 'HOME=' + str(Path.home()),
            'PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin', 'PYTHONDONTWRITEBYTECODE=1'] + args

def refusal_command(plan, binding, control):
    """Print the existing wrapper invocation in a separate control root; never run it."""
    unsupported = next(c for c in plan['cells'] if c['id'] == control['unsupported_cell'])
    require(unsupported['support'] == 'unsupported', 'refusal control requires an unsupported cell')
    cold = next(c for c in plan['cells'] if c['id'] == control['cold_rollback_cell'])
    require(cell_status(binding, cold) == 'completed_unvalidated', 'run and retain the cold rollback cell first')
    cold_dir = output_directory(binding, cold)
    require(not cell_evidence_errors(plan, binding, cold, read(cold_dir / 'report.json'), read(cold_dir / 'metadata.json')),
            'cold rollback integrity failed')
    probe = dict(unsupported, id='refusal-controls/' + control['id'], support='supported', blockers=[])
    return command(plan, binding, probe)

def native_hit(row):
    before = row.get('metrics_before', {}).get('ssd_cache', {}).get('stage_read_bytes')
    after = row.get('metrics_after', {}).get('ssd_cache', {}).get('stage_read_bytes')
    return (row.get('cache_outcome') == 'hit' and row.get('ssd_stage_disposition') == 'staged'
            and all(type(row.get(k)) is int and row[k] > 0 for k in ('matched_tokens', 'saved_tokens'))
            and type(before) is int and type(after) is int and after > before >= 0)

def cell_evidence_errors(plan, binding, cell, report, metadata):
    errors = list(report_errors(report))
    model = next(m for m in plan['models'] if m['label'] == cell['model'])
    expected = {'schema': 2, 'status': 'completed', 'model': model['model_id'],
                'verified_model_hash': model['aggregate_sha256'], 'input_sha256': model['prepared_input_sha256'],
                'requested_backend': cell['backend'], 'resolved_backend': cell['backend'],
                'cache_requested': cell['cache'] == 'on', 'cache_mode_requested': 'ssd',
                'key_mode_requested': 'ephemeral', 'kv_grant_mode': 'production_single_slot',
                'max_concurrent_requests': cell['concurrency'], 'cancellation_probe_version': 2}
    for key, value in expected.items():
        if report.get(key) != value:
            errors.append({'plan_report_difference': key})
    expected_args = {'cache': cell['cache'], 'mtp': 'on' if model['normal_mtp'] else 'off',
                     'kv_backend': cell['backend'], 'concurrency': cell['concurrency'], 'trial': cell['repetition'],
                     'production_kv_grant': True, 'prompt_date': plan['prompt_date'], 'cache_mode': 'ssd', 'key_mode': 'ephemeral'}
    for key, value in expected_args.items():
        if metadata.get('arguments', {}).get(key) != value:
            errors.append({'plan_metadata_difference': key})
    if not report.get('mtp', '').startswith('on' if model['normal_mtp'] else 'off'):
        errors.append({'normal_mtp_configuration_mismatch': True})
    if (metadata.get('status') != 'completed' or metadata.get('exit_code') != 0
            or metadata.get('binary_sha256') != binding['binary']['sha256']
            or metadata.get('input_sha256') != model['prepared_input_sha256']
            or metadata.get('source_input_sha256') != model['input_sha256']
            or report.get('runtime_identity', {}).get('binary_sha256') != binding['binary']['sha256']
            or report.get('runtime_identity', {}).get('metallib_sha256') != binding['resources']['mlx.metallib']['sha256']):
        errors.append({'metadata_or_runtime_identity_mismatch': True})
    if report.get('logit_diagnostic') is not None or metadata.get('arguments', {}).get('logit_diagnostic_position') is not None:
        errors.append({'diagnostic_capture_not_allowed_in_performance_cell': True})
    rows = report.get('rows', [])
    b = cell['concurrency']
    ids = [kind + ('-b' + str(i) if b > 1 else '') for kind in ('long-first', 'long-repeat') for i in range(b)]
    if [r.get('id') for r in rows] != ids:
        errors.append({'missing_or_reordered_planned_rows': True})
    if len(rows) == 2 * b and any(mismatch(rows[i], rows[b+i]) for i in range(b)):
        errors.append({'completed_donor_repeat_output_mismatch': True})
    for row in rows:
        if row.get('prompt_render_date') != plan['prompt_date'] or not 4096 < row.get('prompt_tokens', 0) < 6500:
            errors.append({'id': row.get('id'), 'prompt_contract_mismatch': True})
        if not 0 < row.get('completion_tokens', 0) <= plan['output_token_cap']:
            errors.append({'id': row.get('id'), 'output_cap_mismatch': True})
        if any(type(row.get(k)) not in (int, float) or not math.isfinite(row[k]) or row[k] < 0
               for k in ('ttft_s', 'elapsed_s', 'decode_tps')):
            errors.append({'id': row.get('id'), 'missing_or_invalid_decode_or_latency_measurement': True})
    if b > 1:
        batches = report.get('batches', [])
        if len(batches) != 2 or any(batch.get('concurrency_requested') != b or batch.get('completed') != b
                or batch.get('failed') != 0 or batch.get('peak_active_requests', 0) < 2 for batch in batches):
            errors.append({'required_overlapping_completed_cohorts_not_observed': True})
    if cell['cache'] == 'on':
        warmed = [r for r in rows if r.get('kind') == 'repeat']
        tenants = report.get('tenant_checks', [])
        warmed += tenants[1:2] + [report.get('cancelled', {}), report.get('recovered', {})]
        for row in warmed:
            if not native_hit(row):
                errors.append({'id': row.get('id'), 'missing_native_authenticated_restore': True})
    controls = report.get('tenant_checks', []) + [report.get(k, {}) for k in ('warmup', 'cancel_donor', 'cancelled', 'recovered')]
    observations = [r.get('metrics_after', {}) for r in rows + controls if not r.get('batch_id')]
    observations += [batch.get('metrics_after_batch', {}) for batch in report.get('batches', [])]
    observations += [report.get('metrics_after_shutdown', {})]
    if any(m.get('idle_observation', {}).get('status') != 'ready' for m in observations):
        errors.append({'coherent_idle_observation_missing_or_failed': True})
    return errors

def admission_summary(report):
    return [dict(id=b.get('id'), requested=b.get('concurrency_requested'),
                 observed_peak_active=b.get('peak_active_requests'), peak_waiting=b.get('peak_waiting_requests'),
                 completed=b.get('completed'), failed=b.get('failed'),
                 observed_overlap=b.get('peak_active_requests', 0) >= 2,
                 observed_full_requested_width=b.get('peak_active_requests', 0) >= b.get('concurrency_requested', 1))
            for b in report.get('batches', [])]

def required_width_observed(report, requested):
    if requested == 1:
        return True
    batches = report.get('batches', [])
    return (len(batches) == 2 and all(b.get('concurrency_requested') == requested
            and b.get('peak_active_requests', 0) >= requested
            and b.get('completed') == requested and b.get('failed') == 0 for b in batches))

def timing(report):
    # Keep first cohort and warm repeat separate. Do not invent a kind=decode
    # row: the frozen comparator's optional decode aggregate is inapplicable.
    return {kind: [{k: r.get(k) for k in ('id', 'ttft_s', 'elapsed_s', 'completion_cleanup_s',
             'decode_tps', 'first_delta_token_count', 'decode_tokens_after_first_delta', 'completion_tokens',
             'saved_tokens', 'matched_tokens', 'cache_outcome', 'chunks', 'metrics_before', 'metrics_after')}
             for r in report.get('rows', []) if r.get('kind') == kind] for kind in ('first', 'repeat')}

def rollback_evidence(plan, binding, control, accepted):
    """A reviewed refusal is a negative capability check, never a cache/performance pass."""
    item = dict(control, cold_rollback_integrity_passed=control['cold_rollback_cell'] in accepted,
                refusal_state='unrun', passed=False)
    directory = Path(binding['results_root']) / 'refusal-controls' / control['id']
    if not directory.exists():
        return item
    item['refusal_state'] = 'retained_partial_or_unexpected_refusal'
    try:
        metadata, report = read(directory / 'metadata.json'), read(directory / 'report.json')
        model = next(m for m in plan['models'] if m['label'] == control['model'])
        report_hash, metadata_hash = sha256(directory / 'report.json'), sha256(directory / 'metadata.json')
        item.update(report_sha256=report_hash, metadata_sha256=metadata_hash)
        message = report.get('error', '')
        expected_arguments = {'cache': 'on', 'mtp': 'on' if model['normal_mtp'] else 'off',
                              'kv_backend': 'contiguous', 'cache_mode': 'ssd', 'key_mode': 'ephemeral',
                              'concurrency': control['concurrency'], 'trial': control['repetition'],
                              'production_kv_grant': True, 'prompt_date': plan['prompt_date']}
        expected = (metadata.get('status') == report.get('status') == 'failed'
                    and type(metadata.get('exit_code')) is int and metadata['exit_code'] != 0
                    and metadata.get('binary_sha256') == binding['binary']['sha256']
                    and metadata.get('source_input_sha256') == model['input_sha256']
                    and metadata.get('input_sha256') == report.get('input_sha256') == model['prepared_input_sha256']
                    and report.get('model') == model['model_id'] and report.get('expected_model_sha256') == model['aggregate_sha256']
                    and report.get('requested_backend') == 'contiguous' and report.get('cache_requested') is True
                    and report.get('cache_mode_requested') == 'ssd' and report.get('key_mode_requested') == 'ephemeral'
                    and report.get('kv_grant_mode') == 'production_single_slot'
                    and report.get('max_concurrent_requests') == control['concurrency']
                    and report.get('mtp', '').startswith('on' if model['normal_mtp'] else 'off')
                    and all(metadata.get('arguments', {}).get(k) == v for k, v in expected_arguments.items())
                    and metadata.get('arguments', {}).get('logit_diagnostic_position') is None
                    and all(s in message for s in ('ssdUnavailable', 'disabled', 'unsupportedLayout', 'hasEvidenceSource: false'))
                    and report.get('warmup', {}).get('outcome') == 'not_run'
                    and len(report.get('rows', [])) == 2 * control['concurrency']
                    and all(r.get('outcome') == 'not_run' and not r.get('chunks') and not r.get('token_ids') for r in report['rows'])
                    and not report.get('batches') and 'metrics_loaded' not in report and 'resolved_backend' not in report)
        if not expected:
            return item
        cold_metadata = read(Path(binding['results_root']) / control['cold_rollback_cell'] / 'metadata.json')
        require(cold_metadata['ended_unix'] <= metadata['started_unix'], 'refusal probe preceded or overlapped cold rollback')
        item['refusal_state'] = 'expected_refusal_observed_review_pending'
        review_binding = binding.get('refusal_review_records', {}).get(control['id'])
        if review_binding is None:
            return item
        review = read(verify_file(review_binding))
        require(review.get('state') == 'reviewed_expected_refusal' and review.get('review_id'), 'refusal review is pending')
        for key, value in {'control_id': control['id'], 'unsupported_cell': control['unsupported_cell'],
                           'report_sha256': report_hash, 'metadata_sha256': metadata_hash,
                           'binary_sha256': binding['binary']['sha256']}.items():
            require(review.get(key) == value, 'refusal review identity mismatch: ' + key)
        item['refusal_state'] = 'reviewed_expected_refusal'
        item['passed'] = item['cold_rollback_integrity_passed']
    except (OSError, ValueError, TypeError, KeyError) as error:
        item['error'] = type(error).__name__ + ': ' + str(error)
    return item

def collect(plan, binding, cells):
    output = {'scope': 'strict named-cell evidence; timings descriptive until all required gates pass',
              'cells': [], 'comparisons': [], 'all_supported_matrix_cells_accepted': False,
              'all_rollback_controls_accepted': False, 'all_matrix_requirements_accepted': False,
              'release_gates_satisfied': False}
    reports, metadatas, acceptable, full_width = {}, {}, set(), set()
    for cell in cells:
        item = {'id': cell['id'], 'status': cell_status(binding, cell), 'blockers': cell['blockers']}
        if item['status'] == 'completed_unvalidated':
            directory = output_directory(binding, cell)
            report, metadata = read(directory / 'report.json'), read(directory / 'metadata.json')
            try:
                errors = cell_evidence_errors(plan, binding, cell, report, metadata)
                reports[cell['id']], metadatas[cell['id']] = report, metadata
                item.update(errors=errors, report_sha256=sha256(directory / 'report.json'), metadata_sha256=sha256(directory / 'metadata.json'),
                            timings=timing(report), batches=report.get('batches', []), admission=admission_summary(report), production_grant=report.get('production_grant'),
                            metrics_after_shutdown=report.get('metrics_after_shutdown'))
                if not errors:
                    acceptable.add(cell['id'])
                    item['status'] = 'cell_integrity_pass_pair_pending'
                    item['required_width_observed'] = required_width_observed(report, cell['concurrency'])
                    if item['required_width_observed']:
                        full_width.add(cell['id'])
                else:
                    item['status'] = 'failed_integrity'
            except (KeyError, TypeError, ValueError, IndexError) as error:
                item.update(status='malformed_evidence', error=type(error).__name__ + ': ' + str(error))
        output['cells'].append(item)
    ids = {c['id'] for c in cells}
    for pair in plan['pairs']:
        if pair['baseline'] not in ids:
            continue
        item = dict(pair, passed=False, state='missing_or_failed_cell')
        if not pair['required_comparison']:
            item['state'] = 'unsupported_comparison'
            output['comparisons'].append(item)
            continue
        if {pair['baseline'], pair['candidate']} <= acceptable:
            try:
                verdict = compare(reports[pair['baseline']], reports[pair['candidate']], pair['expect_cache_hits'], pair['axis'])
                item.update(verdict, state='evaluated')
                before, after = metadatas[pair['baseline']], metadatas[pair['candidate']]
                if not before['ended_unix'] <= after['started_unix']:
                    item['passed'] = False
                    item['errors'].append({'ordered_process_pair_not_observed': True})
            except (KeyError, TypeError, ValueError, IndexError) as error:
                item.update(state='malformed_comparison', error=type(error).__name__ + ': ' + str(error))
        output['comparisons'].append(item)
    selected_supported = {c['id'] for c in cells if c['support'] == 'supported'}
    selected_pairs = [p for p in output['comparisons'] if p['required_comparison']]
    complete_scope = ids == {c['id'] for c in plan['cells']}
    output['all_selected_supported_integrity_passed'] = acceptable == selected_supported
    output['all_selected_required_widths_observed'] = full_width == selected_supported
    output['all_selected_supported_cells_accepted'] = (acceptable == selected_supported
            and full_width == selected_supported and all(p['passed'] for p in selected_pairs))
    output['all_supported_matrix_cells_accepted'] = complete_scope and output['all_selected_supported_cells_accepted']
    output['coverage'] = {'selected_conceptual_cells': len(cells), 'supported_required': len(selected_supported),
                          'unsupported': len(cells) - len(selected_supported), 'supported_comparisons': len(selected_pairs),
                          'unsupported_comparisons': len(output['comparisons']) - len(selected_pairs), 'complete_six_model_scope': complete_scope}
    output['missing_required_width_cells'] = sorted(acceptable - full_width)
    ordered_cells = [c for c in sorted(cells, key=lambda c: c['order']) if c['id'] in acceptable]
    output['process_order_errors'] = []
    for previous, following in zip(ordered_cells, ordered_cells[1:]):
        try:
            ordered = metadatas[previous['id']]['ended_unix'] <= metadatas[following['id']]['started_unix']
        except (KeyError, TypeError):
            ordered = False
        if not ordered:
            output['process_order_errors'].append({'previous': previous['id'], 'following': following['id']})
    if output['process_order_errors']:
        output['all_supported_matrix_cells_accepted'] = output['all_selected_supported_cells_accepted'] = False
    # Only aggregate paired repetitions if all three corresponding pairs passed.
    groups = {}
    by_id = {c['id']: c for c in cells}
    for pair in output['comparisons']:
        if not pair['required_comparison']:
            continue
        cell = by_id[pair['baseline']]
        group = (cell['model'], cell['concurrency'], pair['axis'], cell['backend'] if pair['axis']=='cache' else cell['cache'])
        groups.setdefault(group, []).append(pair)
    output['repeated_pair_summaries'] = []
    for key, group in groups.items():
        if output['process_order_errors']:
            continue
        if len(group) != 3 or not all(p['passed'] for p in group):
            continue
        if any(p[arm] not in full_width for p in group for arm in ('baseline', 'candidate')):
            continue
        ordered = sorted(group, key=lambda p: by_id[p['baseline']]['repetition'])
        if any(metadatas[a['candidate']]['ended_unix'] > metadatas[b['baseline']]['started_unix'] for a,b in zip(ordered, ordered[1:])):
            output['all_supported_matrix_cells_accepted'] = False
            output['all_selected_supported_cells_accepted'] = False
            continue
        for kind in ('first', 'repeat'):
            for metric in ('ttft_s', 'decode_tps', 'elapsed_s'):
                changes = []
                for pair in ordered:
                    old = statistics.median(r[metric] for r in reports[pair['baseline']]['rows'] if r['kind']==kind)
                    new = statistics.median(r[metric] for r in reports[pair['candidate']]['rows'] if r['kind']==kind)
                    changes.append({'repetition': by_id[pair['baseline']]['repetition'], 'baseline': old, 'candidate': new, 'candidate_minus_baseline': new-old})
                deltas = [v['candidate_minus_baseline'] for v in changes]
                output['repeated_pair_summaries'].append(dict(group=key, kind=kind, metric=metric, trials=changes,
                    delta_min=min(deltas), delta_median=statistics.median(deltas), delta_max=max(deltas)))
    output['rollback_controls'] = [rollback_evidence(plan, binding, c, acceptable)
                                   for c in plan['rollback_controls'] if c['unsupported_cell'] in ids]
    output['all_rollback_controls_accepted'] = complete_scope and all(c['passed'] for c in output['rollback_controls'])
    output['all_matrix_requirements_accepted'] = (output['all_supported_matrix_cells_accepted']
            and output['all_rollback_controls_accepted']
            and all(c['status'] == 'unsupported_unrun' for c in output['cells'] if c['id'] not in selected_supported))
    return output

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['status', 'command', 'refusal-command', 'collect'])
    parser.add_argument('--bindings', required=True)
    parser.add_argument('--group', choices=['original', 'supplement', 'all'], default='all')
    parser.add_argument('--cell')
    parser.add_argument('--format', choices=['json', 'shell'], default='json')
    args = parser.parse_args()
    plan = load_plan()
    binding = read(args.bindings) if args.action == 'status' else verified_bindings(args.bindings)
    require(binding.get('results_root'), 'set an absolute results_root in a separate binding copy')
    cells = [c for c in plan['cells'] if args.group == 'all' or c['group'] == args.group]
    if args.action == 'status':
        result = [{'id': c['id'], 'state': cell_status(binding, c), 'blockers': c['blockers']} for c in cells]
    elif args.action in ('command', 'refusal-command'):
        choices = cells if args.action == 'command' else [c for c in plan['rollback_controls'] if c['unsupported_cell'] in {row['id'] for row in cells}]
        matches = [c for c in choices if c['id'] == args.cell]
        require(len(matches) == 1, 'select one exact cell ID')
        argv = command(plan, binding, matches[0]) if args.action == 'command' else refusal_command(plan, binding, matches[0])
        if args.format == 'shell':
            print(shlex.join(argv))
            return
        result = {'cell': args.cell, 'bindings_sha256': sha256(args.bindings), 'argv': argv, 'shell': shlex.join(argv)}
    else:
        result = collect(plan, binding, cells)
    print(json.dumps(result, indent=2, sort_keys=True))

if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError) as error:
        raise SystemExit(str(error))
