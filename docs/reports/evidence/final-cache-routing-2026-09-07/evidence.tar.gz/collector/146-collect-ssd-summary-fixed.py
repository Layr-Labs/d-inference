from pathlib import Path
import hashlib,json,shlex,subprocess,tarfile
here=Path('/private/tmp/darkbloom-release090-routing-logging-execution1');root='/Users/gaj/autoresearch/radix-prefix-cache/146-release090-routing-logging1';cell='qwen38-paged-ssd-b1';run=root+'/owned-runs/'+cell
ssh=json.loads(Path('/private/tmp/darkbloom-release090-qwen-execution1/relay/command.json').read_text())['argv'][:-1]
archive=here/'qwen38-ssd-evidence.tar.gz'
with archive.open('xb') as out:result=subprocess.run(ssh+['exec '+shlex.join(['/bin/cat',run+'/evidence.tar.gz'])],stdout=out,stderr=subprocess.PIPE,timeout=60)
assert result.returncode==0,result.stderr.decode()
script=r'''
from pathlib import Path
import json,sys,time
root=Path('/Users/gaj/autoresearch/radix-prefix-cache/146-release090-routing-logging1');cell='qwen38-paged-ssd-b1';run=root/'owned-runs'/cell
sys.path.insert(0,str(root/'owner'));import pilot_core as core,owner_helper
binding=core.read(root/'bindings'/(cell+'.json'));mac=binding['macmon'];obs=owner_helper.observe({'macmon_path':mac['path'],'macmon':mac});owner_helper.require_entry(obs)
receipt={'cell':cell,'collection':core.read(run/'collection-receipt.json'),'terminal':core.read(run/'terminal.json'),'supervisor':core.read(run/'supervisor-terminal.json'),'cleanup':core.read(run/'foreground-retirement.json'),'worker':core.read(run/'worker-verdict.json'),'observation':obs,'observed_unix':time.time(),'no_model_or_provider_process_remaining':not obs['unexpected_processes'] and not obs['owned_processes']}
core.write_new(root/'qwen38-ssd-clean-postflight.json',receipt);print(json.dumps(receipt))
'''
res=subprocess.run(ssh+['exec '+shlex.join(['/usr/bin/python3','-B','-c',script])],capture_output=True,text=True,timeout=60);assert res.returncode==0,res.stderr
receipt=json.loads(res.stdout)
(here/'qwen38-ssd-clean-postflight.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert hashlib.sha256(archive.read_bytes()).hexdigest()==receipt['collection']['archive_sha256']
dest=here/'qwen38-ssd-evidence';dest.mkdir()
with tarfile.open(archive,'r:gz') as tar:
 for m in tar:
  assert m.isfile() and not Path(m.name).is_absolute() and '..' not in Path(m.name).parts
 tar.extractall(dest)
manifest=json.loads((dest/'evidence-manifest.json').read_text())
for rel,row in manifest['files'].items():assert hashlib.sha256((dest/rel).read_bytes()).hexdigest()==row['sha256'],rel
assert receipt['terminal']['accepted'] and receipt['supervisor']['accepted'] and receipt['cleanup']['complete'] and receipt['worker']['accepted'] and receipt['no_model_or_provider_process_remaining']
(here/'qwen38-ssd-clean-postflight.json').write_text(json.dumps(receipt,indent=2)+'\n')
report=json.loads((dest/'steps/1/http-evidence/evidence/report.json').read_text())
summary={'model':report['input']['artifact']['model_id'],'state':report['state'],'scope':report.get('scope', 'same_host_connected_functional_routing'),'cases':[{'name':c['name'],'status':c['status'],'http':{k:c['http'].get(k) for k in ('finish_reason','usage','first_content_ms','total_ms')},'slots':c['slots_after']} for c in report['cases']],'clean':True,'observation':receipt['observation']}
(here/'qwen38-ssd-summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps({'model':summary['model'],'state':summary['state'],'cases':[{'name':c['name'],'status':c['status'],'http':c['http'],'cache_status':c['slots'][0]['cache_status'],'mtp_rounds':c['slots'][0]['capacity']['slots'][0]['telemetry']['mtp_rounds_total']} for c in summary['cases']],'clean':summary['clean'],'observation':summary['observation']},indent=2))
