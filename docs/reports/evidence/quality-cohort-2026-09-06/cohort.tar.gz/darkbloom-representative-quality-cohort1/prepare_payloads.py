"""Emit existing serving/teacher JSON formats using cached canonical CPU tools."""
from pathlib import Path
import copy
import json
import shutil
import subprocess

from canonical_cpu import ARTIFACTS, EXPORTER_SHA, SIDECAR_SHA, export, sidecar
from cohort_common import digest, identity, read_json, require, token_digest, write_json
from corpus_cases import build

ROOT = Path(__file__).resolve().parent
MATRIX = Path('/tmp/darkbloom-six-artifact-batching-plan2')
SOURCE = Path('/Users/gaj/Documents/DarkbloomDev/wt/representative-quality-cohort1')
SOURCE_SHA = '252ccfb94c7fa8c47a9eb35214e7e5e187d945b2'
DATE = '2026-09-06'
REQUIRED_CONTROL_IDS = {'tools', 'nulls', 'harmony', 'gemma', 'reasoning_effort', 'unicode',
    'endpoint_chat_completions', 'endpoint_completions', 'endpoint_responses', 'endpoint_messages',
    'exact_block_multiple', 'long_prompt'}
GEMMA_GENERATION_SUFFIX = [100, 45518, 107, 101]


def continuation_start(prompt, full, model):
    if full[:len(prompt)] == prompt:
        return len(prompt), 'exact canonical prompt prefix'
    common = 0
    for left, right in zip(prompt, full):
        if left != right:
            break
        common += 1
    require(model['model_id'].startswith('gemma-4-26b') and prompt[common:] == GEMMA_GENERATION_SUFFIX,
            'unexpected canonical reference-message alignment')
    return common, 'Gemma generation-only empty-thought suffix remains in teacher prompt; completed-message content supplies reference tokens'


def main():
    require(subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == SOURCE_SHA,
            'coherent benchmark source differs')
    require(not (ROOT/'payload-index.json').exists(), 'payload index is already frozen')
    cases = build(ROOT)['cases']
    matrix = read_json(MATRIX/'plan.json')
    control_source = Path('/tmp/darkbloom-release-090/corpus-date.json')
    controls = [copy.deepcopy(case) for case in read_json(control_source)['cases'] if case['id'] in REQUIRED_CONTROL_IDS]
    require({case['id'] for case in controls} == REQUIRED_CONTROL_IDS, 'fixture exporter controls incomplete')
    for case in controls:
        messages = case['body'].get('messages', [])
        if messages and messages[0]['role'] in ['assistant', 'tool']:
            messages.insert(0, {'role': 'user', 'content': 'Use these tool results to answer the request.'})
        if case['id'] == 'reasoning_effort':
            case['body']['reasoning_effort'] = 'medium'
    write_json(ROOT/'codec-controls.json', {'schema_version': 1, 'cases': controls})
    fixture_cases = copy.deepcopy(controls)
    for case in cases:
        body = {'model': '{{MODEL_ID}}', '_darkbloom_prompt_date': DATE,
                'chat_template_kwargs': {'enable_thinking': False},
                'messages': [{'role': 'user', 'content': case['prompt_text']}],
                'max_tokens': case['output_token_cap']}
        full = copy.deepcopy(body)
        full['messages'].append({'role': 'assistant', 'content': case['reference_text']})
        for suffix, value in [('', body), ('--reference', full)]:
            fixture_cases.append({'id': case['id'] + suffix, 'endpoint': 'chat_completions',
                                  'scope_id': 'quality-v1:' + case['id'], 'body': value})
    write_json(ROOT/'fixture-cases.json', {'schema_version': 1, 'cases': fixture_cases})
    fleet, index, observations = [], [], []
    for model in matrix['models']:
        label = model['label']
        contract_path = ARTIFACTS/model['prompt_contract_id']/'prompt-contract.json'
        contract = read_json(contract_path)
        require(contract['model_id'] == model['model_id'] and contract['model_aggregate_sha256'] == model['aggregate_sha256'],
                'cached contract does not bind exact fleet artifact')
        artifact_files = []
        for item in contract['artifacts']:
            path = ARTIFACTS/model['prompt_contract_id']/item['path']
            require(path.stat().st_size == item['size_bytes'] and digest(path) == item['sha256'], 'cached tokenizer artifact differs')
            artifact_files.append(dict(item))
        config = read_json(ARTIFACTS/model['prompt_contract_id']/'config.json')
        text = config.get('text_config', config)
        vocabulary, context_limit = text['vocab_size'], text['max_position_embeddings']
        require(type(vocabulary) is int and type(context_limit) is int, 'model declaration lacks token/context bounds')
        manifest = ROOT/'fleet'/(label+'-manifest.json')
        manifest.parent.mkdir(exist_ok=True)
        shutil.copy2(MATRIX/model['manifest'], manifest)
        contract_copy = ROOT/'fleet'/(label+'-prompt-contract.json')
        config_copy = ROOT/'fleet'/(label+'-config.json')
        shutil.copy2(contract_path, contract_copy)
        shutil.copy2(ARTIFACTS/model['prompt_contract_id']/'config.json', config_copy)
        model_row = {key: model[key] for key in ['label', 'model_id', 'aggregate_sha256', 'prompt_contract_id', 'normal_mtp', 'assistant', 'model_directory_hint']}
        model_row.update(vocabulary_size=vocabulary, declared_context_limit=context_limit,
                         manifest={'path': str(manifest.relative_to(ROOT)), **identity(manifest)},
                         contract_file={'path': str(contract_copy.relative_to(ROOT)), **identity(contract_copy)},
                         config_file={'path': str(config_copy.relative_to(ROOT)), **identity(config_copy)},
                         prompt_artifacts=artifact_files, cached_contract_sha256=digest(contract_path))
        fleet.append(model_row)
        (ROOT/'canonical').mkdir(exist_ok=True); (ROOT/'logs').mkdir(exist_ok=True)
        vectors_path = ROOT/'canonical'/(label+'-vectors.json')
        proof = {'model': label, 'plans': []}
        proof['exporter'] = export(manifest, ROOT/'fixture-cases.json', vectors_path, ROOT/'logs'/(label+'-export.log'))
        generated = read_json(vectors_path)['models']
        require(len(generated) == 1 and generated[0]['model_id'] == model['model_id']
                and generated[0]['prompt_contract_id'] == model['prompt_contract_id'], 'fixture model/contract differs')
        vectors = {case['id']: case for case in generated[0]['cases']}
        proof['sidecar'] = {}
        with sidecar(ROOT/'logs'/(label+'-sidecar.log'), proof['sidecar']) as post:
            post('/v1/preload', {'prompt_contract_ids': [model['prompt_contract_id']]})
            for case in cases:
                key = case['id']; prompt_case, full_case = vectors[key], vectors[key+'--reference']
                for vector in [prompt_case, full_case]:
                    observed = post('/v1/plan', {'prompt_contract_id': model['prompt_contract_id'],
                        'scope_id': vector['scope_id'], 'endpoint': vector['endpoint'], 'body': vector['request_body']})
                    require(observed == vector['plan'], 'cached exporter/sidecar canonical plans differ')
                    proof['plans'].append({'id': vector['id'], 'plan': observed, 'exact_plan_match': True})
                prompt, full = prompt_case['token_ids'], full_case['token_ids']
                start, alignment = continuation_start(prompt, full, model)
                continuation = full[start:start+case['teacher_continuation_cap']]
                require(len(continuation) == 64, 'reference is shorter than the frozen 64-token scoring span')
                require(all(type(token) is int and 0 <= token < vocabulary for token in prompt + continuation), 'token outside model vocabulary')
                low, high = (128, 2_048) if case['length'] == 'short' else (3_072, 12_288)
                require(low <= len(prompt) <= high, 'short/long canonical token bound not met: ' + label + '/' + key + ':' + str(len(prompt)))
                require(len(prompt) <= 32_768 and len(prompt) + max(64, case['output_token_cap']) <= context_limit, 'context plus cap exceeds declaration')
                body = prompt_case['request_body']
                serving = {'purpose': 'Frozen public quality coverage; strict serving trajectory checks remain required.',
                    'quality_case_id': key,
                    'rows': [{'case': {'id': 'long-'+kind, 'kind': kind, 'max_tokens': case['output_token_cap'], 'target_length': None},
                              'request': copy.deepcopy(body)} for kind in ['first', 'repeat']]}
                teacher = {'modelID': model['model_id'], 'expectedModelAggregateSHA256': model['aggregate_sha256'],
                           'promptTokens': prompt, 'continuation': continuation}
                canonical = {'model': label, 'case_id': key, 'prompt_contract_id': model['prompt_contract_id'],
                    'prompt_token_ids': prompt, 'continuation_token_ids': continuation,
                    'reference_full_token_ids': full, 'reference_token_start': start,
                    'reference_alignment': alignment, 'plan': prompt_case['plan'],
                    'scope_id': prompt_case['scope_id'], 'full_reference_plan': full_case['plan']}
                record = {'model': label, 'case_id': key, 'domain': case['domain'], 'length': case['length'],
                    'prompt_tokens': len(prompt), 'continuation_tokens': len(continuation),
                    'output_token_cap': case['output_token_cap'], 'prompt_token_sha256': token_digest(prompt),
                    'continuation_token_sha256': token_digest(continuation), 'reference_alignment': alignment,
                    'source_sha256': case['source_sha256']}
                for kind, value in [('serving', serving), ('teacher', teacher), ('canonical', canonical)]:
                    path = ROOT/'inputs'/kind/label/(key+'.json')
                    write_json(path, value)
                    record[kind] = {'path': str(path.relative_to(ROOT)), **identity(path)}
                index.append(record)
        observations.append(proof)
        print(label, '12 payload pairs, prompt range', min(row['prompt_tokens'] for row in index if row['model']==label),
              max(row['prompt_tokens'] for row in index if row['model']==label), flush=True)
    write_json(ROOT/'fleet.json', {'schema': 1, 'models': fleet,
        'source_plan_manifest_sha256': digest(MATRIX/'manifest.json'), 'model_weights_read_or_downloaded': False})
    write_json(ROOT/'payload-index.json', {'schema': 1, 'records': index, 'source_commit': SOURCE_SHA,
        'prompt_date': DATE, 'teacher_scope': 'scheduler-free eager reference likelihood, not a serving oracle',
        'model_or_gpu_execution': False})
    write_json(ROOT/'cpu-proof.json', {'schema': 1, 'models': observations,
        'fixture_exporter_sha256': EXPORTER_SHA, 'canonical_sidecar_sha256': SIDECAR_SHA,
        'codec_controls_source_sha256': digest(control_source),
        'codec_control_adjustments': ['Only the 12 mandatory legacy exporter controls are included, outside quality coverage.',
            'Assistant-first control gets an initial user request; reasoning-effort control uses medium, supported by Qwen3.8.',
            'No existing regression fixture or gate was modified.'],
        'verification_scope': 'Exact plan/count/complete-block hashes; full token IDs pinned to the cached exporter and must match serving reports exactly.',
        'model_or_gpu_execution': False})


if __name__ == '__main__':
    main()
