from common import *
import remote_scripts as code

def main():
 review=Path(sys.argv[1]);review_sha=sys.argv[2];assert sha(review)==review_sha
 summary,binding=frozen_inputs();archive=Path(summary['archive']['path']);assert item(archive)=={k:v for k,v in summary['archive'].items() if k!='path'}
 out=Path('/tmp/darkbloom-connected-http6-transfer1');out.mkdir(exist_ok=False)
 constants={'remote':REMOTE,'review_sha':review_sha,'archive_sha':sha(archive),'manifest_sha':summary['manifest']['sha256'],'members':summary['payloads']+1,'binding_sha':summary['binding']['sha256']}
 try:
  ownership(out,'ownership-before')
  run(out,SSH+['python3 -B -'],'create',render(code.CREATE,constants))
  run(out,SCP+[str(archive),'gaj@100.124.35.99:'+REMOTE+'/transfer.tar.gz'],'archive-transfer')
  run(out,SCP+[str(review),'gaj@100.124.35.99:'+REMOTE+'/approved-root-review.json'],'review-transfer')
  run(out,SSH+['python3 -B -'],'extract',render(code.EXTRACT,constants))
  binary=Path(binding['local_artifact_root'])/'darkbloom';expected=binding['files']['darkbloom']
  assert item(binary)==dict(expected,mode=int(expected['mode'],8))
  run(out,SCP+['-p',str(binary),'gaj@100.124.35.99:'+REMOTE+'/runtime/darkbloom'],'provider-transfer')
  receipt=run(out,SSH+['python3 -B -'],'runtime',render(code.RUNTIME,constants));(out/'runtime-transfer-receipt.json').write_text(receipt)
  command=ENV+[PYTHON,'-B','-m','unittest','-v','test_connected_bundle','test_executable_modes','test_flat_runtime','test_local_assistant','test_temporary_model_alias']
  run(out,SSH+['cd '+shlex.quote(REMOTE)+' && '+shlex.join(command)],'remote-helper-tests')
  ownership(out,'ownership-after');save(out/'approved-root-review.json',json.loads(review.read_text()))
  save(out/'status.json',{'status':'STAGED_RUNTIME_VERIFIED_HELPER_TESTS_PASS_NO_MODEL_RUN','constants':constants})
 finally:freeze(out,'HTTP6 approved fresh package and runtime transfer, 20 CPU helper tests; no model execution.')
 print(out/'manifest.json')
if __name__=='__main__':main()
