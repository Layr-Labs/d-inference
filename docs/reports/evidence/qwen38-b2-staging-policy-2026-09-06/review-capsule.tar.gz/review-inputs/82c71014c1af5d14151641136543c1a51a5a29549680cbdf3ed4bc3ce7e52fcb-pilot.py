"""Activate reviewed Q38-only bindings, then run one foreground, leased pilot."""
import argparse
import fcntl
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import sys
import time

import pilot_core as core
from control_input import ControlInput, ControlLost

ROOT = Path(__file__).resolve().parent
SIGNALS = (signal.SIGTERM, signal.SIGHUP, signal.SIGINT)
LEASE = 30
CELL_DEADLINE = 1900
TOTAL_DEADLINE = 10800


def emit(value):
    print(json.dumps(value, allow_nan=False), flush=True)


def publish_caller(run_root, caller, alive, reason=None):
    temporary = run_root / "caller-lease.tmp"
    with temporary.open("w") as stream:
        json.dump(caller.receipt(alive, reason), stream, allow_nan=False)
        stream.flush(); os.fsync(stream.fileno())
    temporary.replace(run_root / "caller-lease.json")


def require_caller_live(run_root):
    value = core.read(run_root / "caller-lease.json")
    core.require(value.get("requires_external_pings") is True and value.get("alive") is True
                 and type(value.get("last_ping_unix")) in (int, float)
                 and 0 < value.get("lease_seconds", 0) <= LEASE
                 and 0 <= time.time() - value["last_ping_unix"] < value["lease_seconds"],
                 "external caller lease lost; no successor cell may start")


def birth(pid):
    result = subprocess.run(["/bin/ps", "-p", str(pid), "-o", "lstart="],
                            capture_output=True, text=True, timeout=10)
    return result.stdout.strip() if result.returncode == 0 else None


def group_present(pgid):
    try:
        os.killpg(pgid, 0)
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True


def retire_known(record):
    pid = record["pid"]
    core.require(type(pid) is int and pid > 1 and record["pgid"] == pid and record.get("birth"),
                 "invalid owned process identity")
    proof = dict(record, signals=[], signal_errors=[], group_absent=False)
    for sig, seconds in ((signal.SIGTERM, 5), (signal.SIGKILL, 3)):
        if not group_present(pid):
            break
        current_birth = birth(pid)
        if current_birth is not None:
            core.require(current_birth == record["birth"], "owned PID/PGID reused; refusing foreign signal")
            try:
                core.require(os.getpgid(pid) == pid, "owned PGID changed; refusing foreign signal")
            except (ProcessLookupError, PermissionError):
                pass
        try:
            os.killpg(pid, sig); proof["signals"].append(int(sig))
        except ProcessLookupError:
            pass
        except PermissionError as error:
            proof["signal_errors"].append(str(error))
        deadline = time.monotonic() + seconds
        while group_present(pid) and time.monotonic() < deadline:
            time.sleep(.05)
    proof["group_absent"] = not group_present(pid)
    core.require(proof["group_absent"], "owned detached group did not retire")
    return proof


def retire_detached(run_root):
    proofs, errors = [], []
    for registry in sorted((Path(run_root) / "steps").glob("*/children.jsonl")):
        try:
            wrapper = core.read(registry.parent / "wrapper.json")
            lines = registry.read_text().splitlines()
        except Exception as error:
            errors.append(str(error)); continue
        for line in lines:
            try:
                row = json.loads(line)
                if row.get("event") != "spawn":
                    continue
                core.require(row["parent_pid"] == wrapper["pid"] and row["argv"][0] in wrapper["allowed_executables"],
                             "detached child has no reviewed wrapper owner")
                proofs.append(retire_known(row))
            except Exception as error:
                errors.append(str(error))
    return {"groups": proofs, "errors": errors, "complete": not errors}


def supervise(command, environment, run_root, control, lease=LEASE, deadline=TOTAL_DEADLINE):
    import owner_helper
    run_root = Path(run_root)
    owner_root = run_root / "owner"; owner_root.mkdir(mode=0o700)
    record = None
    def event(value):
        if value.get("event") == "started":
            core.write_new(run_root / "owned-worker.json", dict(value, birth=birth(value["pid"])))
        emit(value)
    try:
        record = owner_helper.run_owner(command, environment, owner_root, control, event,
                                       lease_seconds=lease, deadline_seconds=deadline)
    finally:
        handlers = {sig: signal.signal(sig, signal.SIG_IGN) for sig in SIGNALS}
        try:
            cleanup = retire_detached(run_root)
            core.write_new(run_root / "detached-retirement.json", cleanup)
            accepted = bool(record and record["provider_started"] and record["exit_code"] == 0
                            and not record["failure"] and not record["stop_requested"]
                            and record["group_cleanup_complete"] and cleanup["complete"])
            core.write_new(run_root / "supervisor-terminal.json", {"accepted": accepted,
                           "owner": record, "detached_cleanup_complete": cleanup["complete"]})
        finally:
            for sig, handler in handlers.items():
                signal.signal(sig, handler)
    return accepted


def execute_cell(argv, step, allowed_executables):
    mask = signal.pthread_sigmask(signal.SIG_BLOCK, SIGNALS)
    process = None
    try:
        with (step / "runner.log").open("xb") as log:
            process = subprocess.Popen(argv, env=core.ENV, stdout=log, stderr=log,
                                       preexec_fn=lambda: signal.pthread_sigmask(signal.SIG_SETMASK, mask))
            core.write_new(step / "wrapper.json", {"pid": process.pid, "pgid": os.getpgid(process.pid),
                           "birth": birth(process.pid), "allowed_executables": allowed_executables, "argv": argv})
            signal.pthread_sigmask(signal.SIG_SETMASK, mask)
            try:
                return process.wait(timeout=CELL_DEADLINE)
            finally:
                if process.poll() is None:
                    process.terminate()
                    try:
                        process.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        process.kill(); process.wait(timeout=10)
    finally:
        signal.pthread_sigmask(signal.SIG_SETMASK, mask)


def worker(activation_path, activation_sha):
    activation, context = core.verify_activation(activation_path, activation_sha)
    scoped, plan, matrix, binding, _ = context
    run_root = Path(activation["run_root"])
    supervisor = core.read(run_root / "supervisor.json")
    core.require(os.getppid() == supervisor["pid"] and birth(os.getppid()) == supervisor["birth"],
                 "worker requires its live leased supervisor; no direct execution")
    cells = scoped.select(plan, core.PILOT)
    final = None
    completed = []
    try:
        for index, cell in enumerate(cells, 1):
            require_caller_live(run_root)
            step = run_root / "steps" / str(index); step.mkdir(mode=0o700)
            activation, context = core.verify_activation(activation_path, activation_sha)
            scoped, plan, matrix, binding, _ = context
            core.verify_completed(run_root)
            core.entry(binding, step / "entry-wait.json")
            before = core.audit_all(activation, plan, binding)
            core.write_new(step / "audit-before.json", before)
            core.verify_activation(activation_path, activation_sha)
            core.entry(binding, step / "entry.json", timeout=0)
            core.require_stable_stats(before)
            raw = scoped.command(plan, matrix, binding, cell["id"], activation["ack"])
            script = str(Path(activation["plan_root"]) / "runner/run_radix_engine.py")
            position = raw.index(script)
            argv = raw[:position] + [str(ROOT / "tracked_runner.py"), str(step / "children.jsonl")] + raw[position:]
            core.write_new(step / "command.json", {"cell": cell["id"], "reviewed_runner_argv": raw,
                           "tracked_argv": argv, "activation_sha256": activation_sha})
            failure = None
            try:
                require_caller_live(run_root)
                status = execute_cell(argv, step, [binding["binary"]["path"], binding["macmon"]["path"]])
                core.require(status == 0, "runner exited nonzero: " + str(status))
            except Exception as error:
                failure = error
            finally:
                cleanup = retire_detached(run_root)
                core.write_new(step / "retirement.json", cleanup)
                after = core.audit_all(activation, plan, binding)
                core.write_new(step / "audit-after.json", after)
                core.require(cleanup["complete"] and before == after, "model/source/runtime changed or cleanup incomplete")
                core.verify_activation(activation_path, activation_sha)
            if failure:
                raise failure
            core.verify_completed(run_root)
            core.write_new(step / "cell-results.json", {"cell": cell["id"],
                           "files": core.audit_tree(Path(binding["results_root"]) / cell["id"])})
            completed.append(cell)
            final = scoped.collect(plan, matrix, binding, completed)
            core.write_new(step / "verdict.json", final)
            core.require(final["completed_prefix_gates_passed"] and len(final["comparisons"]) == index - 1,
                         "strict completed-cell gate failed; dependent arms stopped")
            emit({"event": "cell_accepted", "cell": cell["id"], "comparisons": len(final["comparisons"])})
        core.require(final["all_selected_supported_cells_accepted"] and len(final["comparisons"]) == 2,
                     "full Q38 triad not accepted")
        core.verify_completed(run_root)
        core.write_new(run_root / "worker-verdict.json", {"accepted": True, "pilot": final,
                       "matrix_expanded": False, "gpu_ready": False,
                       "production_default_validated": False, "auto_http_validated": False})
        return 0
    except Exception as error:
        core.write_new(run_root / "worker-verdict.json", {"accepted": False, "error": str(error),
                       "completed_cells": [cell["id"] for cell in completed], "matrix_expanded": False})
        try:
            core.write_new(run_root / "partial-verdict.json", scoped.collect(plan, matrix, binding, cells))
        except Exception as collection_error:
            core.write_new(run_root / "partial-collection-error.json", {"error": str(collection_error)})
        return 1


def owned(activation_path, activation_sha, lock_fd):
    activation, _ = core.verify_activation(activation_path, activation_sha)
    core.require(os.fstat(lock_fd).st_ino == (ROOT / ".m5-pilot.lock").stat().st_ino,
                 "supervisor requires inherited foreground ownership lock")
    run_root = Path(activation["run_root"])
    core.write_new(run_root / "supervisor.json", {"pid": os.getpid(), "birth": birth(os.getpid())})
    argv = [sys.executable, "-B", str(ROOT / "pilot.py"), "_worker", "--activation", str(activation_path),
            "--activation-sha256", activation_sha]
    accepted = supervise(argv, core.ENV, run_root, sys.stdin.buffer)
    if finish_orphan(run_root):
        return 1
    return 0 if accepted else 1


def finish_orphan(run_root):
    controller = core.read(run_root / "controller.json")
    if birth(controller["pid"]) == controller["birth"]:
        return False
    core.write_new(run_root / "terminal.json", {"accepted": False, "failure": "foreground controller lost",
                   "post_audit_may_be_incomplete": True, "matrix_expanded": False, "gpu_ready": False,
                   "production_default_validated": False, "auto_http_validated": False})
    core.seal(run_root)
    return True


def run(activation_path, control=None):
    caller = ControlInput(control if control is not None else sys.stdin.buffer, lease=LEASE)
    try:
        caller.wait_for_ping()
        return run_leased(activation_path, caller)
    finally:
        caller.close()


def run_leased(activation_path, caller):
    activation_sha = core.sha(activation_path)
    activation, _ = core.verify_activation(activation_path, activation_sha)
    caller.poll()
    import owner_helper
    run_root = owner_helper.canonical_owned_root(activation["run_root"], Path.home())
    lock = os.open(ROOT / ".m5-pilot.lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    try:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        os.close(lock); raise ValueError("another foreground pilot owns this driver")
    run_root.mkdir(mode=0o700); (run_root / "steps").mkdir(mode=0o700)
    core.write_new(run_root / "activation.json", activation)
    core.snapshot_reviews(activation, run_root / "review-inputs")
    core.write_new(run_root / "controller.json", {"pid": os.getpid(), "birth": birth(os.getpid()),
                   "activation_sha256": activation_sha, "only_cells": core.CELLS})
    process, failure = None, None
    selector = selectors.DefaultSelector()
    def interrupted(signum, frame):
        raise ControlLost("foreground controller signal " + str(signum))
    handlers = {sig: signal.signal(sig, interrupted) for sig in SIGNALS}
    try:
        first_ping = caller.wait_for_ping()
        publish_caller(run_root, caller, True)
        argv = [sys.executable, "-B", str(ROOT / "pilot.py"), "_owned", "--activation", str(activation_path),
                "--activation-sha256", activation_sha, "--lock-fd", str(lock)]
        with (run_root / "supervisor.stderr").open("xb") as error_log, (run_root / "controller-events.jsonl").open("xb") as events:
            process = subprocess.Popen(argv, env=core.ENV, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                       stderr=error_log, start_new_session=True, pass_fds=(lock,))
            selector.register(process.stdout, selectors.EVENT_READ)
            first_ping += caller.poll()
            process.stdin.write(first_ping); process.stdin.flush()
            start = time.monotonic()
            while process.poll() is None:
                core.require(time.monotonic() - start < TOTAL_DEADLINE + 60, "foreground deadline expired")
                received = caller.poll()
                if received:
                    publish_caller(run_root, caller, True)
                    process.stdin.write(received); process.stdin.flush()
                if selector.select(.1):
                    data = os.read(process.stdout.fileno(), 65536)
                    if not data:
                        break
                    events.write(data); events.flush()
                    sys.stdout.buffer.write(data); sys.stdout.buffer.flush()
            process.wait(timeout=45)
            caller.poll()
            remaining = process.stdout.read()
            events.write(remaining)
    except Exception as error:
        failure = type(error).__name__ + ": " + str(error)
    finally:
        for sig in SIGNALS:
            signal.signal(sig, signal.SIG_IGN)
        try:
            publish_caller(run_root, caller, False, failure or "supervision finished")
            if process is not None:
                try:
                    if process.poll() is None:
                        process.stdin.write(b'{"command":"stop"}\n'); process.stdin.flush()
                    process.stdin.close()
                except (BrokenPipeError, OSError):
                    pass
                try:
                    process.wait(timeout=45)
                except subprocess.TimeoutExpired:
                    process.terminate()
                    try:
                        process.wait(timeout=20)
                    except subprocess.TimeoutExpired:
                        process.kill(); process.wait(timeout=10)
                remaining = process.stdout.read()
                if remaining:
                    with (run_root / "controller-events.jsonl").open("ab") as events:
                        events.write(remaining)
                process.stdout.close()
                if (run_root / "owned-worker.json").exists():
                    try:
                        retire_known(core.read(run_root / "owned-worker.json"))
                    except Exception as error:
                        failure = (failure or "") + " worker cleanup: " + str(error)
            cleanup = retire_detached(run_root)
            core.write_new(run_root / "foreground-retirement.json", cleanup)
            try:
                core.verify_activation(activation_path, activation_sha)
                core.verify_completed(run_root)
            except Exception as error:
                failure = (failure or "") + " final immutable-input/result check: " + str(error)
            supervisor = core.read(run_root / "supervisor-terminal.json") if (run_root / "supervisor-terminal.json").exists() else {}
            verdict = core.read(run_root / "worker-verdict.json") if (run_root / "worker-verdict.json").exists() else {}
            accepted = bool(not failure and process and process.returncode == 0 and supervisor.get("accepted")
                            and verdict.get("accepted") and cleanup["complete"])
            missing_post_audits = [step.name for step in (run_root / "steps").iterdir()
                                  if (step / "command.json").exists() and not (step / "audit-after.json").exists()]
            core.write_new(run_root / "terminal.json", {"accepted": accepted, "failure": failure,
                           "supervisor_exit_code": process.returncode if process else None,
                           "missing_post_audits": missing_post_audits, "gpu_ready": False,
                           "matrix_expanded": False, "no_automatic_rerun": True,
                           "external_caller_control": caller.receipt(False, failure or "supervision finished"),
                           "production_default_validated": False, "auto_http_validated": False})
            core.seal(run_root)
        finally:
            selector.close(); os.close(lock)
            for sig, handler in handlers.items():
                signal.signal(sig, handler)
    emit({"accepted": accepted, "results": str(run_root), "archive": str(run_root / "evidence.tar.gz")})
    return 0 if accepted else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["activate", "run", "_owned", "_worker"])
    parser.add_argument("--plan", type=Path)
    parser.add_argument("--binding", type=Path)
    parser.add_argument("--ack", type=Path)
    parser.add_argument("--run-root", type=Path)
    parser.add_argument("--out", type=Path)
    parser.add_argument("--activation", type=Path)
    parser.add_argument("--activation-sha256")
    parser.add_argument("--lock-fd", type=int)
    args = parser.parse_args()
    core.verify_driver()
    if args.action == "activate":
        core.require(all((args.plan, args.binding, args.ack, args.run_root, args.out)), "activation requires all five paths")
        core.activate(args.plan, args.binding, args.ack, args.run_root, args.out)
        emit({"activated": True, "gpu_ready": False, "launched": False, "activation": str(args.out)})
        return 0
    core.require(args.activation is not None, "--activation is required")
    if args.action == "run":
        return run(args.activation.resolve())
    core.require(args.activation_sha256, "internal owned command requires activation identity")
    if args.action == "_owned":
        core.require(args.lock_fd is not None, "inherited lock required")
        return owned(args.activation, args.activation_sha256, args.lock_fd)
    return worker(args.activation, args.activation_sha256)


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, KeyError, TypeError, RuntimeError) as error:
        raise SystemExit("REFUSED: " + str(error))
