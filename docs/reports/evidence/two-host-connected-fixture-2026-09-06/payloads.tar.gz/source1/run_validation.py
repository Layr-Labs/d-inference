from pathlib import Path
import hashlib,json,subprocess,time
root=Path(__file__).resolve().parent
source=json.loads((root/'source-before-tests.json').read_text())
wt=Path(source['worktree'])
def unchanged():
 for row in source['files']:
  assert hashlib.sha256((wt/row['path']).read_bytes()).hexdigest()==row['sha256'],row['path']
unchanged()
commands=[('go-race',['go','test','-race','./e2e/testbed','./e2e','-short','-run','TestProvider|TestBuildProvider|TestResolve|TestDescribe|TestConnected','-count=1','-json']),('python',['python3','-m','unittest','discover','-s','e2e/testbed','-p','test_provider_host.py','-v'])]
results=[]
for name,argv in commands:
 start=time.time()
 with (root/(name+'.log')).open('xb') as out:
  p=subprocess.run(argv,cwd=wt,stdout=out,stderr=subprocess.STDOUT,timeout=300)
 row={'name':name,'argv':argv,'exit_code':p.returncode,'seconds':time.time()-start}
 results.append(row);(root/'validation.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(row),flush=True)
 assert p.returncode==0,name
unchanged()
print('all selected CPU validation passed; source unchanged',flush=True)
