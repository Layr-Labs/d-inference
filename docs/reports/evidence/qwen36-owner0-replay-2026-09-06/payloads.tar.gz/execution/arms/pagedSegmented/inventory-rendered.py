import json
C=json.loads('{"remote_root": "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1", "binding_sha256": "a04631ec25459596b98561910463c88e334ed0e059714def34f54cfca57ee4c8", "arm": "pagedSegmented", "argv": ["/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1/runtime/attention-replay", "--input", "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1/transfer/input.json", "--input-sha256", "17114f5243a9657bfcc3d4c7d1f3d9362bffeb744b1ceb5f815c321f0479d487", "--output", "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1/runs/pagedSegmented", "--arm", "pagedSegmented"]}')
from pathlib import Path
import hashlib,json,stat
root=Path(C['remote_root'])/'runs';arm=C['arm'];files={};total=0
paths=[root/(arm+'-execution.json'),root/(arm+'.log')]
if (root/arm).exists():
 assert not (root/arm).is_symlink()
 paths+=list((root/arm).iterdir())
for path in paths:
 if not path.exists():continue
 info=path.lstat();assert stat.S_ISREG(info.st_mode) and not path.is_symlink()
 name=str(path.relative_to(root));assert not Path(name).is_absolute() and '..'not in Path(name).parts
 assert name in {arm+'-execution.json',arm+'.log',arm+'/result.json',arm+'/output.bin',arm+'/storedKeys.bin',arm+'/storedValues.bin'}
 assert info.st_size<=32*(1<<20);total+=info.st_size;assert total<=64*(1<<20)
 digest=hashlib.sha256()
 with path.open('rb')as stream:
  for chunk in iter(lambda:stream.read(1<<20),b''):digest.update(chunk)
 files[name]={'bytes':info.st_size,'sha256':digest.hexdigest(),'mode':oct(stat.S_IMODE(info.st_mode))}
print(json.dumps({'files':files,'total_bytes':total},indent=2))
