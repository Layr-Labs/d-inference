from pathlib import Path
import gzip, hashlib, io, json, shutil, tarfile

out = Path(__file__).resolve().parent
worktree = Path('/Users/gaj/Documents/DarkbloomDev/wt/logit-diagnostic-generic-reducer')
destination = worktree/'docs/reports/evidence/generic-logit-reducer-2026-09-06'
sha = lambda data: hashlib.sha256(data).hexdigest()
payloads = {'bank.py': Path(__file__).read_bytes()}
roots = {
    'source1': ('/tmp/darkbloom-generic-logit-reducer-source1', 'b96c5cc13cd4e0545a7ed55c39d03e749a4445b33cffa10e5f21838084bfcdaa'),
    'source2': ('/tmp/darkbloom-generic-logit-reducer-source2', '8560ec30d9228d2efa9cb6ff045932f10df3d38b20dfcaa1a69b96f885a6f6db'),
    'failed-validation1': ('/tmp/darkbloom-generic-logit-reducer-native-failure1', 'c40e706c3311481e1e00a0998db8aa187821b8de676d174e90ee26ee844284ec'),
    'passed-validation2': ('/tmp/darkbloom-generic-logit-reducer-native-validation2', '8a5ebd074173b5e1fd64f0477cc82edda734e086db6b500c2d41d7073ce72499'),
}
source_freezes = {}
for alias, (name, digest) in roots.items():
    root = Path(name)
    body = (root/'manifest.json').read_bytes()
    assert sha(body) == digest
    rows = json.loads(body)['files']
    payloads[alias+'/manifest.json'] = body
    for relative, row in rows.items():
        data = (root/relative).read_bytes()
        assert sha(data) == row['sha256'] and len(data) == row['bytes'], relative
        payloads[alias+'/'+relative] = data
    source_freezes[alias] = {'manifest_sha256': digest, 'verified_payloads': len(rows)}

review = Path('/tmp/darkbloom-generic-logit-reducer-root-source-review1.json').read_bytes()
assert sha(review) == '03449a04fbbdf44ddc2ea4a4a6bb7975bfea9bed4082799577e68c4a9b7df704'
payloads['root-source-review1.json'] = review
review = Path('/tmp/darkbloom-generic-logit-reducer-root-validation-review2.json').read_bytes()
assert sha(review) == 'cdfe3bea66b97a12859c8064d16bde0413144fe0e46575549860cb08c1f41c36'
payloads['root-validation-review2.json'] = review
native_commit = json.loads((out/'native-commit.json').read_text())
payloads['native-commit.json'] = (out/'native-commit.json').read_bytes()
qat = Path('/tmp/darkbloom-qat-actual-logits-attempt1-freeze')
body = (qat/'manifest.json').read_bytes()
assert sha(body) == '70087dd4c2bf0d51de6cf1668fa19861556d0acaffa9f090b92c3c9ef827e8b5'
manifest = json.loads(body)
archive = (qat/'payloads.tar.gz').read_bytes()
assert sha(archive) == manifest['archive']['sha256']
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as packed:
    assert sorted(packed.getnames()) == sorted(row['path'] for row in manifest['files'])
    for row in manifest['files']:
        member = packed.getmember(row['path'])
        assert member.isfile() and not member.issym()
        data = packed.extractfile(member).read()
        assert sha(data) == row['sha256'] and len(data) == row['bytes']
    analysis = packed.extractfile('analysis.json').read()
payloads['qat-failed-attempt/manifest.json'] = body
payloads['qat-failed-attempt/payloads.tar.gz'] = archive
payloads['qat-failed-attempt/analysis.json'] = analysis

files = {name: {'sha256': sha(data), 'bytes': len(data)} for name, data in sorted(payloads.items())}
stream = io.BytesIO()
with tarfile.open(fileobj=stream, mode='w') as packed:
    for name, data in sorted(payloads.items()):
        entry = tarfile.TarInfo(name)
        entry.size = len(data)
        entry.mode = 0o644
        entry.mtime = 0
        packed.addfile(entry, io.BytesIO(data))
archive = gzip.compress(stream.getvalue(), mtime=0)
destination.mkdir(parents=True, exist_ok=True)
(destination/'payloads.tar.gz').write_bytes(archive)
record = {
    'scope': 'Model-independent optional logit diagnostics: unchanged reducer extraction, source-only stride fixture correction, and native validation. No full-model rerun or numerical/performance acceptance.',
    'parent_base_commit': '1be058a6b14945ee50ef3b376a57bdf34946aad0',
    'native_base_commit': 'dcf39f6b43effaa2b483211c97d7d3a3e7c0269b',
    'native_commit': native_commit['commit'],
    'source_freezes': source_freezes,
    'files': files,
    'archive': {'path': 'payloads.tar.gz', 'sha256': sha(archive), 'bytes': len(archive)},
    'payload_count': len(files),
    'payload_bytes': sum(row['bytes'] for row in files.values()),
    'nested_QAT_failed_attempt_payloads_verified': len(manifest['files']),
    'test_functions': 96,
    'expanded_test_cases': 105,
    'real_model_rerun_pending': True,
}
(destination/'manifest.json').write_text(json.dumps(record, indent=2)+'\n')
shutil.copy2(destination/'manifest.json', out/'evidence-manifest.json')
# Portable direct link to the actual failure analysis; bytes also exist in the archive.
(destination/'qat-failure-analysis.json').write_bytes(analysis)
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as packed:
    assert sorted(packed.getnames()) == sorted(files)
    for name, row in files.items():
        data = packed.extractfile(name).read()
        assert sha(data) == row['sha256'] and len(data) == row['bytes']
print(json.dumps({'manifest_sha256': sha((destination/'manifest.json').read_bytes()),
                  'archive': record['archive'], 'payload_count': len(files),
                  'payload_bytes': record['payload_bytes']}, indent=2))
