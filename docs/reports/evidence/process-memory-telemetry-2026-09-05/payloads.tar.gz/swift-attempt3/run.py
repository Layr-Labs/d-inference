from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated');out=Path('/tmp/darkbloom-process-memory-telemetry-swift-validation3');workspace=out/'workspace';package=workspace/'provider-swift';scratch=Path('/tmp/darkbloom-process-memory-telemetry-swift-validation1/build');native=Path('/tmp/darkbloom-paged-runtime-validation6/package');dep=root/'libs/mlx-swift'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def verify():
 source=json.loads((out/'provider-source-manifest.json').read_text())
 for p,h in source['files'].items():assert sha(workspace/p)==h,p
 primary=json.loads((out/'primary-provider-baseline.json').read_text())
 for p,h in primary['files'].items():assert sha(root/p)==h,p
 ns=json.loads((out/'native-source-manifest.json').read_text())
 for p,h in ns['files'].items():assert sha(native/p)==h,p
 deps=json.loads((out/'dependency-source-manifest.json').read_text())
 for key,h in deps['files'].items():alias,p=key.split('/',1);assert sha(Path(deps['repositories'][alias])/p)==h,key
 for alias,pin in json.loads((out/'dependency-pins.json').read_text()).items():assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=deps['repositories'][alias],text=True).strip()==pin,alias
 for name in ['Package.swift','Package.resolved']:assert sha(root/'provider-swift'/name)==sha(out/('provider-'+name)),name
 assert sha(package/'Package.swift')==sha(out/'validation-provider-Package.swift') and sha(package/'Package.resolved')==sha(out/'provider-Package.resolved')
 assert sha(native/'Package.swift')==sha(out/'native-Package.swift')
 for p,h in json.loads((out/'owned-manifest.json').read_text())['files'].items():assert sha(workspace/p)==h,p
 for p,h in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():assert sha(scratch/'checkouts/swift-jinja'/p)==h,p
 for p,h in json.loads((out/'fixture-input-manifest.json').read_text())['files'].items():assert sha(workspace/p)==h,p
 return {'candidate_provider_selected':len(source['files']),'primary_provider_selected':len(primary['files']),'native_runtime_selected':len(ns['files']),'dependency_selected':len(deps['files']),'owned_swift_and_fixture':9,'no_drift':True}
(out/'source-verified-before.json').write_text(json.dumps(verify(),indent=2)+'\n');results=[];groups=json.loads((out/'filters.json').read_text())
def run(name,cmd):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=package,stdout=log,stderr=subprocess.STDOUT)
 log=(out/(name+'.log')).read_text();valid=True
 if name in groups:valid=bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test',log)) and not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',log,re.M)
 e={'name':name,'command':cmd,'exit_code':r.returncode,'seconds':time.monotonic()-start,'nonzero_and_no_skips':valid};results.append(e);(out/'execution.json').write_text(json.dumps({'cwd':str(package),'results':results},indent=2)+'\n');print(json.dumps({k:v for k,v in e.items() if k!='command'}),flush=True)
 if r.returncode or not valid:raise SystemExit(r.returncode or 1)
run('build',['swift','build','--scratch-path',str(scratch),'--build-tests','--jobs','4','--disable-automatic-resolution'])
graph=(scratch/'debug.yaml').read_text();assert str(dep/'Source/MLX/Memory.swift') in graph;assert str(dep/'Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp') in graph;assert '/checkouts/mlx-swift/Source/' not in graph
native_suffix='Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVWriteValidation.swift'
native_compile_candidates=[native.resolve()/native_suffix,workspace.resolve()/'libs/mlx-swift-lm'/native_suffix]
native_compile=next(p for p in native_compile_candidates if str(p) in graph)
assert native_compile.resolve()==(native/native_suffix).resolve()
for p in [package/'Sources/ProviderCore/Inference/ProcessMemoryTelemetrySampler.swift',package/'Tests/ProviderCoreTests/ProcessMemoryTelemetryTests.swift']:assert str(p.resolve()) in graph,p
assert str(root/'provider-swift/Sources/ProviderCore/Inference/GlobalKVCacheBudget.swift') not in graph
(out/'actual-build-graph.yaml.gz').write_bytes(gzip.compress(graph.encode(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'actual-package-state.json')
(out/'actual-compiler-source-proof.json').write_text(json.dumps({'native_source':str(native),'provider_source':str(package),'mlx_source':str(dep),'remote_mlx_source_path_absent':True,'primary_provider_compile_source_absent':True,'heads':json.loads((out/'dependency-pins.json').read_text()),'graph_lines':[x for x in graph.splitlines() if str(dep/'Source/MLX/Memory.swift') in x or str(dep/'Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp') in x or 'ProcessMemoryTelemetrySampler.swift' in x]},indent=2)+'\n')
lib=root/'provider-swift/.build/arm64-apple-macosx/debug/mlx.metallib';debug=scratch/'arm64-apple-macosx/debug';targets=[debug/'mlx.metallib']+[p/'mlx.metallib' for p in debug.glob('*.xctest/Contents/MacOS')];assert len(targets)==2
for p in targets:shutil.copy2(lib,p)
(out/'metallib-placement.json').write_text(json.dumps({'source':str(lib),'sha256':sha(lib),'destinations':[str(p) for p in targets]},indent=2)+'\n')
run('identifiers',['swift','test','list','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution'])
for name,filters in groups.items():run(name,['swift','test','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution','--filter','|'.join(filters)])
(out/'source-verified-after.json').write_text(json.dumps(verify(),indent=2)+'\n');(out/'actual-build-graph-after.yaml.gz').write_bytes(gzip.compress((scratch/'debug.yaml').read_bytes(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'actual-package-state-after.json')
print('ALL COMMANDS PASSED AND SOURCE BYTES VERIFIED',flush=True)
