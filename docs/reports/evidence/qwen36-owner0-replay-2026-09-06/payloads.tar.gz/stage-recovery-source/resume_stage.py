"""Complete the verified populated stage without changing the retained failed attempt."""
from pathlib import Path
import json
import sys

SOURCE = Path('/tmp/darkbloom-q36-owner0-replay-execution1')
sys.path.insert(0, str(SOURCE))
import common
import remote_sources

EXPECTED_BINDING = 'a04631ec25459596b98561910463c88e334ed0e059714def34f54cfca57ee4c8'
EXPECTED_STAGING_MANIFEST = 'f1d2d2020f1573640e1dab2d3236a075e96a50e5099744630000466b5a9b9721'
RESUME = common.RESULTS/'staging-resume1'
COMPLETION = remote_sources.VERIFY + '\nprint(json.dumps({"status":"PASS","verified":True,"artifacts":len(binding["artifacts"]),"input_sha256":binding["input_sha256"],"operator_invoked":False}))\n'


def validate_failure(root):
    assert common.sha(root/'manifest.json') == EXPECTED_STAGING_MANIFEST
    for name,row in json.loads((root/'manifest.json').read_text())['files'].items():common.verify_file(root/name,row)
    summary=json.loads((root/'summary.json').read_text())
    assert summary == {'status':'FAIL','error':'JSONDecodeError: Expecting value: line 1 column 1 (char 0)'}
    assert (root/'populate.stdout').read_bytes()==b'' and (root/'populate.stderr').read_bytes()==b''
    expected=common.render(remote_sources.POPULATE,{'remote_root':'/Users/gaj/autoresearch/radix-prefix-cache/090-q36-owner0-operator-replay1','binding_sha256':EXPECTED_BINDING,'resources_source':'/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact'})
    assert (root/'populate-rendered.py').read_text()==expected
    return {'original_staging_manifest_sha256':common.sha(root/'manifest.json'),
            'original_failure':summary,'populate_stdout_sha256':common.sha(root/'populate.stdout'),
            'populate_stderr_sha256':common.sha(root/'populate.stderr'),
            'populate_exit_code':0,'exit_evidence':'Inferred from the frozen common.remote control flow: its returncode==0 assertion passed before json.loads produced this retained failure; separate raw exit receipt was not recorded.'}


def main():
    binding,plan=common.load_binding(EXPECTED_BINDING)
    original=validate_failure(common.RESULTS/'staging')
    RESUME.mkdir(exist_ok=False)
    common.write(RESUME/'original-failure-binding.json',original)
    result=common.remote(RESUME,'complete-verification',COMPLETION,{'remote_root':plan['remote_root'],'binding_sha256':EXPECTED_BINDING})
    assert result=={'status':'PASS','verified':True,'artifacts':7,'input_sha256':plan['input_sha256'],'operator_invoked':False}
    common.remote(RESUME,'entry-readiness',remote_sources.READINESS,{'entry':True})
    common.write(RESUME/'summary.json',{'status':'PASS','binding_sha256':EXPECTED_BINDING,
        'scope':'Completed verification receipt after original populated-stage JSON output omission. No stage overwrite or operator invocation.',
        'original_staging_manifest_sha256':original['original_staging_manifest_sha256']})
    common.seal(RESUME)
    print((RESUME/'summary.json').read_text())


if __name__=='__main__':main()
