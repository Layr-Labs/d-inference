from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,time
out=Path('/tmp/darkbloom-final-serving-build7');old=Path('/tmp/darkbloom-final-serving-build6');ws=out/'workspace';scratch=Path('/tmp/darkbloom-final-serving-build1/build')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();info=json.loads((out/'integration.json').read_text());env=os.environ.copy()
def write(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
def verify():
 for file,base in [('provider-source-manifest.json',ws),('native-source-manifest.json',ws/'libs/mlx-swift-lm')]:
  manifest=json.loads((out/file).read_text())
  for name,digest in manifest['files'].items():assert sha(base/name)==digest,name
  for name in manifest.get('deleted_files',[]):assert not (base/name).exists(),name
 deps=json.loads((out/'dependency-source-manifest.json').read_text())
 for key,digest in deps['files'].items():
  alias,name=key.split('/',1);assert sha(Path(deps['repositories'][alias])/name)==digest,key
 for name,digest in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():assert sha(scratch/'checkouts/swift-jinja'/name)==digest,name
 for name,identity in json.loads((out/'package-resolution-inputs.json').read_text())['files'].items():assert sha(Path(name))==identity['sha256'],name
 assert sha(old/'manifest.json')==info['baseline_manifest_sha256']
 return {'provider_inputs':677,'native_inputs':481,'dependency_inputs':1356,'jinja_inputs':27,'package_resolved_inputs':2,'no_drift':True,'source':'Exact frozen build6 source equals primary9e490/nativea932 apart from documented package overlays.'}
write('source-verified-before.json',verify())
write('compile-environment.json',{k:env[k] for k in ['DEVELOPER_DIR','SDKROOT','SWIFT_EXEC','SWIFT_FLAGS','MACOSX_DEPLOYMENT_TARGET','RADIX_SOURCE_ROOT','RADIX_CANDIDATE_BUILD'] if k in env})
(out/'toolchain.txt').write_text(subprocess.check_output(['swift','--version'],text=True))
(out/'hardware.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize'],text=True)+subprocess.check_output(['sw_vers'],text=True))
command=['swift','build','-c','release','--scratch-path',str(scratch),'--jobs','4','--disable-automatic-resolution','--product','darkbloom'];started=time.monotonic()
with (out/'cli-release.log').open('w') as log:p=subprocess.run(command,cwd=ws/'provider-swift',env=env,stdout=log,stderr=subprocess.STDOUT)
result={'command':command,'cwd':str(ws/'provider-swift'),'seconds':time.monotonic()-started,'exit_code':p.returncode};write('execution.json',result);print(json.dumps(result),flush=True)
write('source-verified-after.json',verify());graph=scratch/'release.yaml';text=graph.read_text();(out/'actual-build-graph.yaml.gz').write_bytes(gzip.compress(graph.read_bytes(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'actual-package-state.json');assert p.returncode==0
expected=[ws/'provider-swift/Sources/ProviderCore/Inference/EngineV2Factory+BenchmarkSession.swift',ws/'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/MTP/EngineLoopV2+MTPPlanning.swift',ws/'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVSegments.swift',ws/'libs/mlx-swift/Source/MLX/AllocationFootprint.swift',ws/'libs/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp'];rows=[]
for path in expected:
 aliases=[str(path),str(path.resolve()),str(path).replace('/tmp/','/private/tmp/',1),str(path.resolve()).replace('/private/tmp/','/tmp/',1)];actual=next((Path(x) for x in aliases if x in text),None);assert actual is not None,str(path);assert actual.resolve()==path.resolve();rows.append({'actual_compile_path':str(actual),'resolved_frozen_source':str(path.resolve()),'sha256':sha(path)})
assert '/checkouts/mlx-swift/Source/' not in text
assert '/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated/provider-swift/Sources/' not in text
write('actual-compiler-source-proof.json',{'paths':rows,'remote_mlx_compile_source_absent':True,'primary_source_excluded':True})
artifact=out/'artifact';artifact.mkdir();shutil.copy2(scratch/'arm64-apple-macosx/release/darkbloom',artifact/'darkbloom')
previous=json.loads((old/'artifact-manifest.json').read_text())
for name,row in previous['files'].items():
 assert sha(old/'artifact'/name)==row['sha256'],name
 target=artifact/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old/'artifact'/name,target)
files={str(p.relative_to(artifact)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(artifact.rglob('*')) if p.is_file()}
write('artifact-manifest.json',{'scope':'New release CLI plus byte-identical validated build6 probe and six resources. No live model or HTTP result asserted.','files':files,'probe_rebuilt':False,'baseline_cli':{'sha256':'a81fd9f9ff01fb84f3c236ceaba5fed4fca730b261be1f332b87c38e69cd3cfd'},'cli_rebuilt':True})
for name in ('darkbloom','radix-engine'):(out/(name+'-dylibs.txt')).write_text(subprocess.check_output(['otool','-L',str(artifact/name)],text=True))
write('source-verified-final.json',verify());print('RELEASE CLI PASS '+files['darkbloom']['sha256'],flush=True)
