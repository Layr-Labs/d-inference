Qwen 3.6 actual-logit plan

Four ordered cells use the identical historical input and MTP-off/cache-off controls: contiguous trace off, contiguous trace on, paged trace off, paged trace on. The trace targets zero-based output index62 (human token63), candidates1928 and6829. Trace timings are not performance evidence.

Source and arguments are frozen here. Final build8 runtime hashes are now bound in plan.json. Root runtime/package/launch review is pending. Do not stage or run this package until root runtime/package/launch approval and the reviewed diagnostic comparator are present. Keep the source package unchanged when adding those bindings. No baseline or failed output root may be reused.

The older build6 controls remain separately frozen and cannot substitute for either new uninstrumented build8 arm. Same-build trace-off/on trajectory equality is required before interpreting captured logits. Historical request fields, including the thinking override, remain byte-for-byte unchanged. No ordinary serving/default claim follows from these diagnostics.
