# Remaining Gemma automatic-verification discrepancy

The corrected B1 package separates two outcomes. Paged/contiguous parity now passes for ordinary, automatic and serial-target generation across all seven complete trajectories. Automatic/ordinary equality still fails on both backends at zero-based token index 30: corrected ordinary and serial target emit 795, while corrected automatic emits 735. All main completions have 61 tokens and finish with `stop`. The exact-token requirement remains failed; this packet does not establish whole-model verifier correctness.

The correction is active in the official M5 runtime. All six full Q/K/V output tensors from the `[529,62203]` layer-0 projection equal the independently reviewed corrected M3 replay byte-for-byte. The ten parameter identities, model hash, quantization and both embedding/normalized input tensors match the frozen old M5 packet. M2 Q/K/V tensors remain byte-identical to the old packet, while the corrected M1 tensors reproduce the promoted-bias replay. Source/artifact provenance plus this arithmetic reproduction supports the promoted-bias path. Runtime kernel names were not instrumented.

| Projection | Old M1/M2 first-column differences | Corrected differences | Corrected maximum absolute difference |
|---|---:|---:|---:|
| Q | 2509 / 4096 | 1 / 4096 | 0.00000762939453125 |
| K | 1251 / 2048 | 0 / 2048 | 0 |
| V | 1449 / 2048 | 0 / 2048 | 0 |

The remaining Q coordinate is 1914: M1 = `-0.00186920166015625`, M2 = `-0.0018768310546875`, ideal affine F64 = `-0.0018734186887741089`. The two outputs differ by one BF16 step. Against the existing ideal affine F64 references rounded directly to BF16, corrected M1 matches 4094/4096 Q, 2047/2048 K and 2048/2048 V coordinates; corrected M2 matches 4095/4096 Q, 2047/2048 K and 2048/2048 V. Every residual error relative to this rounded ideal is at most one BF16 step. This is a bounded operator result, not an acceptance tolerance for generation.

The old/new contiguous outputs change in opposite directions at index 30: ordinary and serial target change 735→795; automatic changes 795→735. The arithmetic revision therefore affects both full-model modes. The old paged automatic first difference from ordinary was index 7 and its mains had 38 tokens; corrected paged automatic now equals contiguous automatic and has 61 tokens. These are descriptive comparisons across arithmetic revisions, where equality was never required.

## What the captures support

- The measured large layer-0 affine bias-sum discrepancy is corrected in the official runtime on the retained packet. A stale host/JIT binary explanation for this particular operator behavior is inconsistent with the exact output match to the reviewed corrected replay and the runtime hash receipts.
- Residual shape-dependent operator rounding exists: the same normalized input and weights produce one differing Q coordinate at widths one and two. The independent source review identifies different M1/M2 reduction paths by dispatch inference. This is a concrete numerical difference, but its connection to the index-30 generation choice has not been measured.
- The remaining generation discrepancy follows the rectangular automatic mode on both backends. Serial-target equality establishes that the tested serial verification route follows ordinary output. It narrows the investigation toward behavior shared by rectangular verification, but does not exclude a common state, position, mask, or acceptance fault in that route.
- The earlier paged-versus-contiguous discrepancy is resolved within this exact B1/cache-off/current-serving-profile/128-token-cap scope. That result must remain separate from automatic-versus-ordinary equality.

## What remains unproven

The retained projection evaluates only actual embedding, input normalization and layer-0 Q/K/V, using the frozen `[529,62203]` packet. It does not evaluate attention, later layers, an index-30 KV state, acceptance transitions or the output logits. Its residual Q coordinate cannot by itself establish the cause of the index-30 flip. The seven current reports contain complete token trajectories and round counters, but no same-state logits or top-two score gaps at that decision. In particular, a near tie between token 735 and token 795 has not been observed here.

Residual floating-point reduction ordering is a plausible candidate; another operator precision issue or a rectangular verification/state error remains possible. Exact greedy equality is the required oracle and has not been relaxed. Neither the small operator residual nor matching output lengths establishes harmlessness, and no throughput ratio is reported for unequal trajectories.

## Evidence required for a reviewed follow-up

Before another model run, bind a diagnostic to the corrected runtime, exact prompt, accepted prefix through token index 29, proposal record, positions/masks and identical starting KV state. Compare serial and rectangular target evaluation on that same state. Capture candidate/accepted IDs, the scores of 735 and 795, the top-two score gap and the first differing layer/state representation. This distinguishes a genuine same-input logit shift from different input/state or acceptance handling. Then compare the first differing operator with a higher-precision reference while retaining the production dtype and exact-token gate. Broad batch-invariance changes or another affine patch would require evidence beyond the present packet.

No follow-up model, M5, GPU or build command was executed for this diagnosis. ROOT owns M5 after the seventh cell's successful terminal, postflight and local collection. The analysis reads only retained capture bytes and saved CPU references. The initial analysis invocation lacked NumPy; rerunning with the existing temporary analysis interpreter exposed an inactive-MTP counter-key omission in this new local summarizer. The summarizer now treats absent inactive counters as zero and completed successfully. Neither analysis issue affected or reran a model cell.

Evidence: `corrected-complete-comparison.json`, `actual-model-results.json`, `projection-native-byte-validation.json`, and the seven raw result directories. CPU reference manifest: `510fe6e1e194430d63344ea95a88bda8585211ea7544ae98c6334fb7a856a235`. Independent corrected replay review manifest: `d0eb579af0d03780881db5ac2d78112481f11dc7ecef2abc2a144715db36a9df`. Frozen old result manifest: `cfbe2b0cb4bc583b604e015f9aae248ac9a396e8ca8e636360f3895f6d7998e0`.
