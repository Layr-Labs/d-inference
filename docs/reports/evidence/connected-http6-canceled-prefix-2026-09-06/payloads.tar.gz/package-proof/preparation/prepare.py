from pathlib import Path
import hashlib,json,shutil,stat,subprocess,sys,tarfile
PLAN=Path('/tmp/darkbloom-connected-http6-q38-plan1')
OLD=Path('/tmp/darkbloom-connected-m5-bundle5')
REL=Path('/tmp/darkbloom-attention-packet-release-build1')
ROOT_REVIEW=Path('/tmp/darkbloom-attention-packet-root-release-review1.json')
SCOPE=Path('/tmp/darkbloom-connected-http6-bundle-test-scope1')
BASE=Path('/tmp/darkbloom-connected-m5-bundle6-q38')
OUT=Path('/tmp/darkbloom-connected-http6-finalize1')
PRIMARY=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
REMOTE='/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http6-q38'

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def save(path,value):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')
def cp(a,b):
 b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(a,b)
def item(p): return {'sha256':sha(p),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.lstat().st_mode)}
def verify(root,name,expected):
 mpath=root/name; assert sha(mpath)==expected,(mpath,sha(mpath)); m=json.loads(mpath.read_text())
 for rel,record in m['files'].items():
  p=root/rel;actual=item(p)
  assert p.is_file() and not p.is_symlink() and actual['sha256']==record['sha256'] and actual['bytes']==record['bytes'],p
  if 'mode' in record: assert actual['mode']==(int(record['mode'],8) if isinstance(record['mode'],str) else record['mode']),p
 return m
OUT.mkdir(exist_ok=False);BASE.mkdir(exist_ok=False)
cp(Path(__file__),OUT/'prepare.py')
pm=verify(PLAN,'manifest.json','5108701e61721f4f01d3390d17ed4a1dad9204d59f397f5a99a9e79af91f1f64')
om=verify(OLD,'package-manifest.json','7c04de0ebc0064d31ce6aa642044d1075704bcf29779334c6d0a9d32aaa4efda')
rm=verify(REL,'manifest.json','15173f887b22b281c4902367bee5b6e4a79a6738f35b0cc6f27c5bfb16a25a53')
sm=verify(SCOPE,'manifest.json','ce932abbe52d9c21878e294fc452c028f1fb01173ff3a723b834b6e3b3a112d8')
assert sha(ROOT_REVIEW)=='a7496912570228710c5a119317c671db54a5675fbf9e9acc001394943ead45ea'
review=json.loads(ROOT_REVIEW.read_text());artifacts=json.loads((REL/'artifact-manifest.json').read_text())
assert review['artifacts']==artifacts['files'] and review['manifest_sha256']==sha(REL/'manifest.json')
for name,record in artifacts['files'].items():
 assert item(REL/'artifact'/name)==dict(record,mode=int(record['mode'],8)),name
runtime={k:v for k,v in artifacts['files'].items() if k!='radix-engine'};assert len(runtime)==7
for name in list(pm['files'])+['manifest.json']: cp(PLAN/name,BASE/'provenance/source-plan'/name)
for name in list(rm['files'])+['manifest.json']: cp(REL/name,BASE/'provenance/release-build'/name)
for name in list(sm['files'])+['manifest.json']: cp(SCOPE/name,BASE/'provenance/test-scope'/name)
cp(ROOT_REVIEW,BASE/'reviews/provider-release-root-review.json')
helpers=[p.name for p in PLAN.glob('*.py') if p.name!='prepare.py']
helper_map={}
for name in helpers:
 source=SCOPE/name if name=='test_connected_bundle.py' else PLAN/name
 cp(source,BASE/name);helper_map[name]={'http5':sha(OLD/name),'http6':sha(BASE/name),'unchanged':sha(OLD/name)==sha(BASE/name)}
assert sum(not x['unchanged'] for x in helper_map.values())==1 and len(helper_map)==10
for dirname in ['manifests','assets','oracle-source']:
 shutil.copytree(PLAN/dirname,BASE/dirname)
cp(PLAN/'go-source-manifest.json',BASE/'go-source-manifest.json')
gom=json.loads((PLAN/'go-source-manifest.json').read_text())
for name,digest in gom['files'].items():
 assert sha(OLD/'go-source'/name)==digest and sha(PRIMARY/name)==digest,name
 cp(OLD/'go-source'/name,BASE/'go-source'/name)
shutil.copytree(OLD/'go-build-evidence',BASE/'go-build-evidence')
cp(OLD/'connected-e2e.test',BASE/'connected-e2e.test')
assert sha(BASE/'connected-e2e.test')=='6e30a1e53cc26ac1bb7953216b6d0af835b8b08a29f1920b2df07999c0e2bc8f'
binding={'schema':1,'state':'REVIEWED_RUNTIME_BOUND_PACKAGE_EXECUTION_PENDING_ROOT_REVIEW','remote_root':REMOTE,
 'runtime_root':REMOTE+'/runtime','local_artifact_root':str(REL/'artifact'),
 'provider_parent_commit':artifacts['parent_commit'],'native_commit':artifacts['native_commit'],
 'source_artifact_manifest_sha256':sha(REL/'artifact-manifest.json'),'release_manifest_sha256':sha(REL/'manifest.json'),
 'root_release_review_sha256':sha(ROOT_REVIEW),'files':runtime,
 'resources_copy_source':'/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact',
 'sidecar':{'path':'/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-smoke1/payload/bin/promptsidecar','sha256':'6a0c4498c6a3d23f85001fe1d1e0b8a502e2397858a586808e792b66e85576ea'},
 'scope':'New exact cancellation + packet CLI, six unchanged build8 resources. Separate strict HTTP execution required.'}
save(BASE/'runtime-binding.json',binding)
save(BASE/'source-inputs/payload--transfer-manifest.json',{'scope':'Seven CLI runtime resources under bin/ provenance names, projected from reviewed artifact identity; no probe required.',
 'source_artifact_manifest_sha256':sha(REL/'artifact-manifest.json'),'files':{'bin/'+k:{'sha256':v['sha256'],'bytes':v['bytes']} for k,v in runtime.items()}})
plan=json.loads((PLAN/'bundle-plan.template.json').read_text());plan['state']='BOUND_TWO_CELLS_UNRUN_PENDING_ROOT_PACKAGE_REVIEW'
plan['source_inputs_sha256']={'runtime-binding.json':sha(BASE/'runtime-binding.json'),'source-inputs/payload--transfer-manifest.json':sha(BASE/'source-inputs/payload--transfer-manifest.json')}
rows=[]
for cell in plan['cells']:
 name=cell['cell'];source=PLAN/'inputs'/(name+'.template.json');data=json.loads(source.read_text())
 assert data['provider_sha256'] is None;data['provider_sha256']=runtime['darkbloom']['sha256']
 target=BASE/cell['input'];save(target,data)
 before=json.loads((PLAN/'provenance'/(name+'.json')).read_text())
 changes={key:{'before':before.get(key),'after':data.get(key)} for key in set(before)|set(data) if before.get(key)!=data.get(key)}
 assert set(changes)=={'provider_binary','provider_sha256','vision_png'},changes
 rows.append({'cell':name,'input':cell['input'],'input_sha256':sha(target),'template_sha256':sha(source),'http5_input_sha256':sha(PLAN/'provenance'/(name+'.json')),'allowed_changes':changes})
a,b=[json.loads((BASE/c['input']).read_text()) for c in plan['cells']]
assert a.pop('cache_mode')=='off' and b.pop('cache_mode')=='ssd' and a==b
save(BASE/'bundle-plan.json',plan)
execution=json.loads((PLAN/'execution-plan.json').read_text());execution.update(state='BOUND_PENDING_FINAL_ROOT_PACKAGE_CONTROLLER_REVIEW',provider_runtime_binding={'path':'runtime-binding.json','sha256':sha(BASE/'runtime-binding.json')})
save(BASE/'execution-plan.json',execution)
for command,label in [([sys.executable,'-B',str(BASE/'verify_prompt_counts.py')],'tokenizer'),([sys.executable,'-B','-m','unittest','-v','test_connected_bundle','test_executable_modes','test_flat_runtime','test_local_assistant','test_temporary_model_alias'],'helper-tests')]:
 result=subprocess.run(command,cwd=BASE,text=True,capture_output=True)
 (OUT/(label+'.stdout')).write_text(result.stdout);(OUT/(label+'.stderr')).write_text(result.stderr)
 save(OUT/(label+'.command.json'),{'argv':command,'cwd':str(BASE),'exit_code':result.returncode})
 assert result.returncode==0,(label,result.stderr)
tokenizer=json.loads((BASE/'tokenizer-plan.json').read_text());assert tokenizer['status']=='passed' and len(tokenizer['rows'])==1
tr=tokenizer['rows'][0];assert tr['input_sha256']==rows[0]['input_sha256']
old_tokenizer=json.loads((PLAN/'tokenizer-plan.json').read_text());previous=next(r for r in old_tokenizer['rows'] if r['model_id']==tr['model_id'])
assert {k:v for k,v in previous.items() if k!='input_sha256'}=={k:v for k,v in tr.items() if k!='input_sha256'}
save(BASE/'paired-input-validation.json',{'status':'PASS','expected_request_date_utc':plan['expected_request_date_utc'],'rows':rows,
 'paired_differences':['cache_mode'],'cache_modes':['off','ssd'],'provider_sha256':runtime['darkbloom']['sha256'],
 'cpu_tokenizer_proof':{'path':'tokenizer-plan.json','sha256':sha(BASE/'tokenizer-plan.json'),'representative_input_sha256':tr['input_sha256'],'all_other_pair_fields_identical':True,'exact_historical_request_and_tokenizer_plan_except_input_hash':True},
 'scope':'Two current bound input identities. One representative CPU tokenizer request covers the exact cache-only pair. No model or HTTP result.'})
save(BASE/'final-source-correspondence.json',{'http5_files_rehashed':len(om['files']),'source_plan_files_rehashed':len(pm['files']),'release_files_rehashed':len(rm['files']),
 'all_go_source_resource_files_unchanged':len(gom['files']),'Go_source_commit':plan['source_commit'],'provider_parent_commit':artifacts['parent_commit'],'native_commit':artifacts['native_commit'],
 'helpers':helper_map,'test_scope_patch':'provenance/test-scope/test-scope.patch','input_validation':'paired-input-validation.json',
 'historical_six_pair_proofs':'provenance/source-plan/paired-input-validation.json and tokenizer-plan.json; historical only',
 'scope':'Go binary and source unchanged; nine helpers byte-identical; one test-only exact two-cell membership change. Production launcher and ten-case Go oracle unchanged.'})
for p in OUT.iterdir(): cp(p,BASE/'preparation'/p.name)
files={str(p.relative_to(BASE)):item(p) for p in sorted(BASE.rglob('*')) if p.is_file()}
save(BASE/'package-manifest.json',{'schema':6,'state':'FROZEN_TWO_BOUND_CELLS_UNRUN_PENDING_ROOT_REVIEW','source_commit':plan['source_commit'],'provider_source_commit':artifacts['parent_commit'],'native_source_commit':artifacts['native_commit'],
 'date_utc':plan['expected_request_date_utc'],'remote_bundle_root':REMOTE,'go_test_binary_sha256':plan['go_test_binary_sha256'],'provider_cli_sha256':runtime['darkbloom']['sha256'],
 'checks':{'python_tests_executed':20,'exact_off_ssd_pairs':1,'current_input_hashes':2,'representative_cpu_prompt_plans':1,'go_source_resource_files_unchanged':len(gom['files'])},'files':files})
result=subprocess.run([sys.executable,'-B',str(BASE/'verify_package.py')],text=True,capture_output=True);assert result.returncode==0,result.stderr
(OUT/'package-verification.stdout').write_text(result.stdout)
archive=BASE.with_suffix('.tar.gz')
with tarfile.open(archive,'w:gz') as tf:
 for name in sorted(list(files)+['package-manifest.json']): tf.add(BASE/name,arcname=name,recursive=False)
save(OUT/'summary.json',{'status':'FROZEN_PENDING_ROOT_PACKAGE_CONTROLLER_REVIEW','package':str(BASE),'manifest':item(BASE/'package-manifest.json'),'payloads':len(files),'archive':dict(item(archive),path=str(archive)),'binding':item(BASE/'runtime-binding.json'),'inputs':rows,'helper_tests':20,'runtime_artifacts':7})
save(OUT/'manifest.json',{'files':{p.name:item(p) for p in sorted(OUT.iterdir()) if p.is_file()}})
print((OUT/'summary.json').read_text())
