from pathlib import Path
import gzip,hashlib,json,re
out=Path('/tmp/darkbloom-q36-diagnostic-harness-validation1');parent=Path('/tmp/darkbloom-receipt-diagnostic-provider-validation1');info=json.loads((out/'integration.json').read_text());ws=Path(info['provider_candidate_workspace']);scratch=Path(info['scratch']);sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
assert json.loads((out/'verdict.json').read_text())['status']=='PASS';known={}
def add(p,d,g):
 key=str(p.resolve());assert key not in known or known[key]['sha256']==d;known[key]={'sha256':d,'group':g}
for filename,root,g in [('candidate/provider-source-manifest.json',ws,'provider'),('native-source-manifest.json',ws/'libs/mlx-swift-lm','native'),('ancillary-package-manifest.json',ws/'libs/mlx-swift-lm','ancillary')]:
 for p,d in json.loads((parent/filename).read_text())['files'].items():add(root/p,d,g)
deps=json.loads((parent/'dependency-source-manifest.json').read_text())
for key,d in deps['files'].items():
 alias,p=key.split('/',1);add(Path(deps['repositories'][alias])/p,d,'dependency')
for p,d in json.loads((parent/'jinja-source-manifest.json').read_text())['files'].items():add(scratch/'checkouts/swift-jinja'/p,d,'jinja')
for p,row in json.loads((out/'compile-source-manifest.json').read_text())['files'].items():add(out/p,row['sha256'],'harness')
graph=gzip.decompress((out/'actual-debug.yaml.gz').read_bytes()).decode();matches={};unmapped=[];roots=[ws.resolve(),(ws/'libs/mlx-swift-lm').resolve(),(out/'radix-engine').resolve()]
for literal in sorted(set(re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',graph))):
 p=Path(literal);key=str(p.resolve())
 if key in known:assert sha(p)==known[key]['sha256'];matches[literal]={'resolved_frozen_source':key,**known[key]}
 elif any(key.startswith(str(root)+'/') for root in roots):unmapped.append(literal)
assert not unmapped,unmapped
write('all-owned-graph-source-proof.json',{'files':matches,'counts':{g:sum(r['group']==g for r in matches.values()) for g in ['provider','native','ancillary','dependency','jinja','harness']},'unmapped_owned_sources':unmapped})
write('upstream-validation.json',{'receipt_manifest':str(parent/'manifest.json'),'receipt_manifest_sha256':sha(parent/'manifest.json'),'wrapper_source_freeze':'/tmp/darkbloom-logit-wrapper-forwarding1/manifest.json','wrapper_independent_review':'/tmp/darkbloom-logit-wrapper-independent-review1/review.json'})
files={}
for p in sorted(out.rglob('*')):
 if not p.is_file() or 'radix-engine'==p.relative_to(out).parts[0] or '__pycache__' in p.relative_to(out).parts or p.name=='manifest.json':continue
 files[str(p.relative_to(out))]={'sha256':sha(p),'bytes':p.stat().st_size}
write('manifest.json',{'schema':1,'status':'PASS: 3 diagnostic option tests and 8 immutable idle-observation tests; no models','files':files})
print(json.dumps({'manifest_sha256':sha(out/'manifest.json'),'payloads':len(files),'counts':json.loads((out/'all-owned-graph-source-proof.json').read_text())['counts']},indent=2))
