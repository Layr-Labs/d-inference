from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time
out=Path('/tmp/darkbloom-final-serving-build8');ws=out/'workspace';base=Path('/tmp/darkbloom-final-serving-build7');scratch=Path('/tmp/darkbloom-final-serving-build1/build');info=json.loads((out/'integration.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
for directory in [Path(info['provider_validation'])/'candidate',Path(info['harness_validation'])]:assert json.loads((directory/'verdict.json').read_text())['status']=='PASS',str(directory)
known={}
def add(p,digest,group):
 key=str(p.resolve());assert key not in known or known[key]['sha256']==digest;known[key]={'sha256':digest,'group':group}
for name,root,group in [('provider-source-manifest.json',ws,'provider'),('native-source-manifest.json',ws/'libs/mlx-swift-lm','native'),('ancillary-package-manifest.json',ws/'libs/mlx-swift-lm','ancillary')]:
 for p,d in json.loads((out/name).read_text())['files'].items():add(root/p,d,group)
deps=json.loads((out/'dependency-source-manifest.json').read_text())
for key,d in deps['files'].items():
 alias,p=key.split('/',1);add(Path(deps['repositories'][alias])/p,d,'dependency')
for p,d in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():add(scratch/'checkouts/swift-jinja'/p,d,'jinja')
for p,row in json.loads((out/'compile-source-manifest.json').read_text())['files'].items():add(out/p,row['sha256'],'harness')
def verify():
 for p,row in known.items():assert sha(Path(p))==row['sha256'],p
 for p in json.loads((out/'provider-source-manifest.json').read_text()).get('deleted_files',[]):assert not (ws/p).exists(),p
 for p,row in json.loads((out/'package-resolution-inputs.json').read_text())['files'].items():assert sha(Path(p))==row['sha256'],p
 for p,d in info['source_freezes'].items():assert sha(Path(p))==d,p
 assert sha(Path(info['baseline_artifact_manifest']))==info['baseline_artifact_manifest_sha256']
 return {'no_drift':True,'counts':{g:sum(r['group']==g for r in known.values()) for g in ['provider','native','ancillary','dependency','jinja','harness']}}
def proof(product):
 graph=scratch/'release.yaml';text=graph.read_text();(out/(product+'-actual-build-graph.yaml.gz')).write_bytes(gzip.compress(graph.read_bytes(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/(product+'-actual-package-state.json'))
 rows={};unmapped=[]
 roots=[str(ws.resolve()),str((ws/'libs/mlx-swift-lm').resolve()),str((ws/'libs/mlx-swift').resolve()),str((out/'radix-engine').resolve())]
 for literal in sorted(set(re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',text))):
  p=Path(literal);key=str(p.resolve())
  if key in known:assert sha(p)==known[key]['sha256'];rows[literal]={'resolved_frozen_source':key,**known[key]}
  elif any(key.startswith(root+'/') for root in roots):unmapped.append(literal)
 assert not unmapped,unmapped
 assert '/checkouts/mlx-swift/Source/' not in text
 assert '/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated/provider-swift/Sources/' not in text
 for name in ['CBv2LogitDiagnostic.swift','EngineV2Bridge+Submission.swift']+(['BenchmarkLogitDiagnostic.swift'] if product=='radix-engine' else []):assert any(p.endswith('/'+name) for p in rows),name
 write(product+'-all-owned-graph-source-proof.json',{'scope':'Actual SwiftPM graph membership with matching frozen source bytes; executed product command/log separate.','files':rows,'counts':{g:sum(r['group']==g for r in rows.values()) for g in ['provider','native','ancillary','dependency','jinja','harness']},'unmapped_owned_sources':unmapped,'remote_mlx_source_excluded':True,'primary_source_excluded':True})
write('source-verified-before.json',verify());env=os.environ.copy();env.update(info['environment']);write('compile-environment.json',{k:v for k,v in env.items() if k in ['DEVELOPER_DIR','SDKROOT','SWIFT_EXEC','SWIFT_FLAGS','MACOSX_DEPLOYMENT_TARGET','RADIX_SOURCE_ROOT','RADIX_CANDIDATE_BUILD'] or k.startswith(('DARKBLOOM_MTP_','MLX_'))})
(out/'toolchain.txt').write_text(subprocess.check_output(['swift','--version'],text=True));(out/'hardware.txt').write_text(subprocess.check_output(['sysctl','hw.model','hw.memsize'],text=True)+subprocess.check_output(['sw_vers'],text=True))
artifact=out/'artifact';artifact.mkdir();executions=[];baseline=json.loads((base/'artifact-manifest.json').read_text())['files'];resources={p:r for p,r in baseline.items() if p not in ['darkbloom','radix-engine']}
for product,pkg in [('radix-engine',out/'radix-engine'),('darkbloom',ws/'provider-swift')]:
 write(product+'-source-verified-before.json',verify());command=['swift','build','-c','release','--scratch-path',str(scratch),'--jobs','4','--disable-automatic-resolution','--product',product];start=time.monotonic()
 with (out/(product+'-release.log')).open('w') as log:r=subprocess.run(command,cwd=pkg,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'product':product,'command':command,'cwd':str(pkg),'seconds':time.monotonic()-start,'exit_code':r.returncode};executions.append(row);write('execution.json',executions);print(json.dumps(row),flush=True)
 write(product+'-source-verified-after.json',verify());proof(product);assert r.returncode==0,product
 release=scratch/'arm64-apple-macosx/release';shutil.copy2(release/product,artifact/product)
 observed={}
 for name,identity in resources.items():
  origin=release/name if name!='mlx.metallib' else base/'artifact'/name
  assert sha(origin)==identity['sha256'],(product,name)
  target=artifact/name;target.parent.mkdir(parents=True,exist_ok=True)
  if target.exists():assert sha(target)==identity['sha256']
  else:shutil.copy2(origin,target)
  observed[name]={'sha256':sha(target),'source':str(origin),'bytes':target.stat().st_size}
 write(product+'-runtime-resource-proof.json',observed)
 (out/(product+'-dylibs.txt')).write_text(subprocess.check_output(['otool','-L',str(artifact/product)],text=True))
 write(product+'-binary.json',{'sha256':sha(artifact/product),'bytes':(artifact/product).stat().st_size})
files={str(p.relative_to(artifact)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(artifact.rglob('*')) if p.is_file()};write('artifact-manifest.json',{'scope':'New diagnostic-capable probe + provider receipt ownership fix in both new release products; diagnostics nil by default. Six runtime resources byte-identical to build7. No model/HTTP/performance result asserted.','files':files,'probe_rebuilt':True,'cli_rebuilt':True,'baseline_build7_artifacts':baseline})
write('source-verified-final.json',verify());print('BUILD8 BOTH RELEASE PRODUCTS PASS',flush=True)
