from pathlib import Path
import hashlib,json,shutil,subprocess,time
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/mlx-coherent-memory-snapshot')
out=Path('/tmp/darkbloom-mlx-memory-snapshot-validation1')
project=out/'project/CMakeLists.txt'
original=project.read_text()
(out/'CMakeLists.candidate.txt').write_text(original)
source=root/'Source/Cmlx/mlx/mlx/backend/no_gpu/allocator.cpp'
text=source.read_text()
before='''MemorySnapshot get_memory_snapshot() {
  return allocator::common_allocator().get_memory_snapshot();
}'''
after='''MemorySnapshot get_memory_snapshot() {
  return {get_active_memory(), get_cache_memory(), get_peak_memory()};
}'''
assert text.count(before)==1
negative=out/'negative-control-allocator.cpp';negative.write_text(text.replace(before,after))
project.write_text(original+'''
if(NEGATIVE_CONTROL_ALLOCATOR)
 get_target_property(snapshot_mlx_sources mlx SOURCES)
 list(FILTER snapshot_mlx_sources EXCLUDE REGEX "/backend/no_gpu/allocator[.]cpp$")
 set_property(TARGET mlx PROPERTY SOURCES "${snapshot_mlx_sources}")
 target_sources(mlx PRIVATE "${NEGATIVE_CONTROL_ALLOCATOR}")
endif()
''')
artifacts=out/'artifacts';artifacts.mkdir(exist_ok=True)
build=out/'build-cpu'
shutil.copy2(build/'snapshot_tests',artifacts/'cpu-candidate-tests')
shutil.copy2(out/'build-metal/snapshot_tests',artifacts/'metal-candidate-tests')
configure=['cmake','-S',str(out/'project'),'-B',str(build),'-DNEGATIVE_CONTROL_ALLOCATOR='+str(negative)]
commands=[('negative-configure',configure,False),('negative-build',['cmake','--build',str(build),'--target','snapshot_tests','--parallel','4'],False),('negative-coherence',[str(build/'snapshot_tests'),'--test-case=test coherent memory snapshot during cache transfers'],True)]
results=[]
try:
 for name,command,expected_failure in commands:
  start=time.monotonic()
  with (out/(name+'.log')).open('w') as log:result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
  body=(out/(name+'.log')).read_text()
  passed=(result.returncode != 0 and 'inconsistent' in body and '0 failed' not in body) if expected_failure else result.returncode==0
  entry={'name':name,'command':command,'exit_code':result.returncode,'seconds':time.monotonic()-start,'expected_failure':expected_failure,'verdict_pass':passed}
  results.append(entry);(out/'negative-execution.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({k:v for k,v in entry.items() if k!='command'}),flush=True)
  if not passed:raise RuntimeError(name+' did not produce expected result')
 shutil.copy2(build/'snapshot_tests',artifacts/'cpu-negative-control-tests')
finally:
 project.write_text(original)
 command=['cmake','-S',str(out/'project'),'-B',str(build),'-DNEGATIVE_CONTROL_ALLOCATOR=']
 with (out/'restore-configure.log').open('w') as log:subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 with (out/'restore-build.log').open('w') as log:subprocess.run(['cmake','--build',str(build),'--target','snapshot_tests','--parallel','4'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
for name,test in [('restore-coherence','test coherent memory snapshot during cache transfers'),('restore-no-stream-wait','test memory snapshot does not wait for stream work')]:
 command=[str(build/'snapshot_tests'),'--test-case='+test]
 with (out/(name+'.log')).open('w') as log:subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 assert '1 | 1 passed | 0 failed' in (out/(name+'.log')).read_text()
assert source.read_text()==text
(out/'negative-control-source.json').write_text(json.dumps({'original':str(source),'original_sha256':hashlib.sha256(text.encode()).hexdigest(),'negative_copy':str(negative),'negative_sha256':hashlib.sha256(negative.read_bytes()).hexdigest(),'candidate_source_unchanged':True,'candidate_build_restored':True},indent=2)+'\n')
print('Candidate source and CPU build restored; both tests pass.',flush=True)
