from pathlib import Path
import json,os,subprocess,time
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
out=Path('/tmp/darkbloom-090-paged-telemetry-provider4')
env=os.environ.copy();env['MLX_METALLIB_PATH']=str(root/'provider-swift/.build/arm64-apple-macosx/debug/mlx.metallib')
filters='|'.join(json.loads((out/'filters.json').read_text()))
commands=[('build',['swift','build','--package-path','provider-swift','--build-tests','--jobs','4','--disable-automatic-resolution']),('focused',['scripts/run-nested-suite.sh',filters,'--package-path','provider-swift','--disable-automatic-resolution'])]
results=[]
for name,command in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 results.append({'name':name,'command':command,'cwd':str(root),'exit_code':result.returncode,'seconds':time.monotonic()-start})
 (out/'execution.json').write_text(json.dumps({'environment':{'MLX_METALLIB_PATH':env['MLX_METALLIB_PATH']},'results':results},indent=2)+'\n')
 print(json.dumps({'name':name,'exit_code':result.returncode,'seconds':results[-1]['seconds']}),flush=True)
 if result.returncode: raise SystemExit(result.returncode)
