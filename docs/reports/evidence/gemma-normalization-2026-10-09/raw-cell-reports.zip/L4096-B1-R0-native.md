# BenchCBv2RealModel report

| | |
|---|---|
| Model | /Users/gaj/.cache/huggingface/hub/models--gemma-4-26b-qat-4bit/snapshots/local |
| Label | L4096-B1-R0-native |
| Profile | stock |
| Prefill construction | chunk=512, soloStripe=off |
| Chip | Apple M4 Max |
| RAM | 128 GB |
| OS | Version 27.0.1 (Build 26A434) |
| Host at start | load avg (1m) 6.6 / 16 cores; no darkbloom process |
| Invocation | `/tmp/kv-gemma-c2-native/BenchCBv2 --model /Users/gaj/.cache/huggingface/hub/models--gemma-4-26b-qat-4bit/snapshots/local --mode perf --engines v2 --batches 1 --steps 64 --prompt-lengths 4096 --prefill-chunk 512 --label L4096-B1-R0-native --out docs/reports/evidence/gemma-normalization-2026-10-09/L4096-B1-R0-native.md` |
| Prompt lengths | 4096 |
| Paged nominalMaxSeqLen | 4160 |
| mlx-swift-lm (build) | 45fedc1 |
| Date | 2026-10-09T12:34:24Z |

model class: Gemma4TextModel; layers: 30
- optimization model: layer18(requested=true, effective=true, interval=18); weightedUnsort(requested=false, effective=false); safeR1GeometryEligible=true; safeR1(requested=false, effective=false, aot=true, nax=false)
- optimization-run-json: {"model":{"layer18Effective":true,"layer18Interval":18,"layer18Requested":true,"safeR1GeometryEligible":true,"weightedUnsortEffective":false,"weightedUnsortRequested":false},"safeR1AOTAvailable":true,"safeR1Effective":false,"safeR1NAXAvailable":false,"safeR1Requested":false}
vocabSize=262144

## Performance (maxTokens 64)

| engine | B | prompts (tok) | decode TPS/req | agg TPS | TTFT p50 (ms) | ITL p50 (ms) |
|---|---|---|---|---|---|---|
| v2 | 1 | 4096 | 95.9 | 18.0 | 2898 | 10.3 |

- optimization provenance [perf/v2/B1]: layer18(requested=true, effective=true, interval=18); weightedUnsort(requested=false, effective=false); safeR1GeometryEligible=true; layer18ExpectedMinimumSubmissions=1, layer18Submissions=8, layer18Engaged=true; weightedCalls=0, weightedEngaged=false; safeR1(requested=false, effective=false, armed=true, aot=true, nax=false, exactGeometryExpected=true, attempts=0, hits=0, fallbacks=0, fallbackNAX=0, fallbackOuterRoute=0, fallbackQuantization=0, fallbackTopology=0, fallbackAssignmentCount=0, fallbackGeometry=0, fallbackMetallibUnavailable=0)
- optimization-cell-json [perf/v2/B1]: {"aggregateTPS":17.99296885559691,"batch":1,"decodeTPSPerRequest":95.9292513964209,"engine":"v2","itlP50Ms":10.322093963623047,"optimizationProvenance":{"layer18Engaged":true,"layer18ExpectedMinimumSubmissions":1,"layer18IntermediateSubmissions":8,"model":{"layer18Effective":true,"layer18Interval":18,"layer18Requested":true,"safeR1GeometryEligible":true,"weightedUnsortEffective":false,"weightedUnsortRequested":false},"safeR1":{"aotAvailable":true,"armed":true,"attempts":0,"effective":false,"exactGeometryExpected":true,"fallbackAssignmentCount":0,"fallbackGeometry":0,"fallbackMetallibUnavailable":0,"fallbackNAX":0,"fallbackOuterRoute":0,"fallbackQuantization":0,"fallbackTopology":0,"fallbacks":0,"hits":0,"naxAvailable":false,"requested":false},"weightedUnsortEffectiveCalls":0,"weightedUnsortEngaged":false},"perRequest":["    req 0: prompt=4096 tokens=64 ttft=2898ms decodeTPS=95.9 finish=length"],"promptMix":[4096],"tokenReceipts":[{"completionTokens":64,"finishReason":"length","promptTokens":4096,"tokenIDs":[10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,10595,100,236751,100,236771,236761,236771,236761,236771,236761,236771,236761,236771,236761]}],"ttftP50Ms":2898.1759548187256}

Per-request detail:
    [mem after v2 B=1] gpuActive=13.48 GiB gpuPeak=14.53 GiB
  v2 B=1:
    req 0: prompt=4096 tokens=64 ttft=2898ms decodeTPS=95.9 finish=length
