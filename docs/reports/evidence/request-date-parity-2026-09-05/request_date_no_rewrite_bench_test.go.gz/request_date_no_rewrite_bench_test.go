package api

import (
	"encoding/json"
	"testing"
)

// Same helper pipeline, with no alias, catalog defaults or missing output bound.
// This isolates requests which did not require provider-body serialization before
// request-date ownership was added. Generated image bytes are opaque test data.
func BenchmarkRequestDatePreviouslyUnchangedBodies(b *testing.B) {
	bodies := benchRequestBodies()
	srv, _, _ := newBenchServer(b)
	registerBuildsProvider(srv, "date-bench-provider", benchDesiredBuild, benchPreviousBuild)
	for _, name := range []string{"small_2KB", "image_3MB"} {
		var fields map[string]any
		if err := json.Unmarshal(bodies[name], &fields); err != nil {
			b.Fatal(err)
		}
		fields["model"] = benchPreviousBuild
		fields["max_tokens"] = 64
		body, err := json.Marshal(fields)
		if err != nil {
			b.Fatal(err)
		}
		b.Run(name, func(b *testing.B) {
			b.ReportAllocs()
			b.SetBytes(int64(len(body)))
			for i := 0; i < b.N; i++ {
				benchPreprocess(b, srv, body)
			}
		})
	}
}
