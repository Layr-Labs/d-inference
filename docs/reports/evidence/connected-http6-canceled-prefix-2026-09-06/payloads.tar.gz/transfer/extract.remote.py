import json
C=json.loads('{"remote": "/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http6-q38", "review_sha": "91a25b23cb7be34e6bc3f35a63a2bc680bfaad96490cde7e4f1c3c5a385b6e35", "archive_sha": "e89ae41a2b21594465b5c31dd036ff9d62d5f5626a1e16afc23c65a95b067a31", "manifest_sha": "82e81db534ea14e80b3f3f2502949b25bc77768e887fdb2755fdab674dddbd0e", "members": 1183, "binding_sha": "401c59e24a3acf88186e03eef9b48c86bbce372fefa6e1c7c9238ef693044b82"}')
from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,tarfile
root=Path(C['remote'])
assert hashlib.sha256((root/'approved-root-review.json').read_bytes()).hexdigest()==C['review_sha']
archive=root/'transfer.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==C['archive_sha']
with tarfile.open(archive) as tar:
 members=tar.getmembers()
 assert len(members)==C['members'] and len({m.name for m in members})==C['members']
 for member in members:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  assert not (root/member.name).exists()
 tar.extractall(root)
assert hashlib.sha256((root/'package-manifest.json').read_bytes()).hexdigest()==C['manifest_sha']
sys.path.insert(0,str(root))
from verify_package import verify_package
verified=verify_package(root)
(root/'runtime').mkdir(exist_ok=False)
print(json.dumps({'package':verified,'remote_root':str(root),'manifest_sha256':C['manifest_sha'],'inference_launched':False},indent=2))
