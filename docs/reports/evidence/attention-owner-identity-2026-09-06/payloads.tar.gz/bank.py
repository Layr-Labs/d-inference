from pathlib import Path
import gzip, hashlib, io, json, tarfile

out = Path(__file__).resolve().parent
worktree = Path('/Users/gaj/Documents/DarkbloomDev/wt/q36-attention-owner-identity')
destination = worktree/'docs/reports/evidence/attention-owner-identity-2026-09-06'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
payloads = {}
inputs = {}

def add(name, path):
    assert name not in payloads, name
    assert path.is_file() and not path.is_symlink(), path
    payloads[name] = path.read_bytes()

def frozen(label, root, expected):
    manifest = root/'manifest.json'
    assert sha(manifest) == expected, str(manifest)
    rows = json.loads(manifest.read_text())['files']
    for name, row in rows.items():
        path = root/name
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], name
        add(label+'/'+name, path)
    add(label+'/manifest.json', manifest)
    inputs[label] = {'manifest_sha256': expected, 'verified_payloads': len(rows)}

frozen('source', Path('/tmp/darkbloom-q36-attention-owner-identity-source1'),
       'd7d8d892e076df4bc90d6ffbc346d22108ba7a04463bb5a4036938b642506743')
frozen('native-validation', Path('/tmp/darkbloom-q36-attention-owner-identity-native-validation1'),
       'b072176bfa8d23fcd7e9a6223b51de67341a5eb2a5b64f6ad8e24141bc5f5abc')
frozen('provider-validation', Path('/tmp/darkbloom-q36-attention-owner-identity-provider-validation1'),
       '68d4366a22c422a10a619a4cd8612fe3f652686e0fe83efe3cb4f8e6c92ca51b')
execution = Path('/tmp/darkbloom-q36-attention-metadata-execution1')
for cell in json.loads((execution/'four-cell-review.json').read_text())['cells']:
    frozen('pre-fix-runtime/'+cell['cell'], execution/cell['cell'], cell['manifest_sha256'])
for name in ['four-cell-review.json', 'contiguous-trace-comparison.json',
             'paged-control-comparison.json', 'paged-trace-comparison.json', 'run_cell.py']:
    add('pre-fix-runtime/'+name, execution/name)
for label, path in {
    'reviews/owner-source.json': '/tmp/darkbloom-q36-attention-owner-identity-root-source-review.json',
    'reviews/pre-fix-contiguous-trace.json': '/tmp/darkbloom-q36-attention-metadata-root-trace-review1.json',
    'reviews/pre-fix-paged-trace.json': '/tmp/darkbloom-q36-attention-metadata-root-paged-trace-review1.json',
    'pre-fix-runtime/runtime-binding.json': '/tmp/darkbloom-q36-attention-metadata-runtime-binding1.json',
    'pre-fix-runtime/postflight.json': '/tmp/darkbloom-q36-attention-metadata-four-cell1-postflight.json',
    'pre-fix-probe/manifest.json': '/tmp/darkbloom-q36-attention-metadata-release-probe1/manifest.json',
    'pre-fix-probe/probe-binary.json': '/tmp/darkbloom-q36-attention-metadata-release-probe1/probe-binary.json',
}.items():
    add(label, Path(path))
add('bank.py', Path(__file__).resolve())
destination.mkdir(parents=True)
files = {name: {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
         for name, data in sorted(payloads.items())}
archive = destination/'payloads.tar.gz'
with archive.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as packed:
            for name, data in sorted(payloads.items()):
                entry = tarfile.TarInfo(name)
                entry.size = len(data)
                entry.mode = 0o644
                entry.mtime = 0
                entry.uid = entry.gid = 0
                packed.addfile(entry, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as packed:
    assert set(packed.getnames()) == set(files)
    for member in packed.getmembers():
        data = packed.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest() == files[member.name]['sha256']
        assert len(data) == files[member.name]['bytes']
manifest = {
    'scope': 'Owner-identity metadata fix and local native/provider validation, with the unchanged pre-fix four-cell real-model attempt and its strict contiguous capture failure preserved.',
    'parent_base_commit': 'c9bd3ab7886675ce9fc79a483e5c93ed60a8ae12',
    'native_commit': 'e972340a7ba6e22fda5d8be1a7af918f9bf67b03',
    'source_freezes': inputs, 'files': files,
    'archive': {'file': archive.name, 'sha256': sha(archive), 'bytes': archive.stat().st_size},
    'payload_count': len(files), 'payload_bytes': sum(row['bytes'] for row in files.values()),
    'corrected_fix_real_model_rerun_completed': False,
    'numerical_or_performance_acceptance': False,
}
(destination/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
result = {'manifest': str(destination/'manifest.json'), 'manifest_sha256': sha(destination/'manifest.json'),
          'archive_sha256': sha(archive), 'archive_bytes': archive.stat().st_size,
          'payload_count': len(files), 'payload_bytes': manifest['payload_bytes']}
(out/'bank-result.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result, indent=2))
