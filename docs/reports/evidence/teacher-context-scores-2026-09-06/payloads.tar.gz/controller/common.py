from pathlib import Path
import hashlib
import json
import math
import stat

ROOT = Path(__file__).resolve().parent
HOST = ROOT / 'provider_host.py'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as source:
        for chunk in iter(lambda: source.read(1 << 20), b''):
            value.update(chunk)
    return value.hexdigest()


def identity(path):
    path = Path(path)
    return {'sha256': digest(path), 'bytes': path.stat().st_size, 'mode': stat.S_IMODE(path.stat().st_mode)}


def checked_file(path, expected):
    path = Path(path)
    facts = path.lstat()
    require(stat.S_ISREG(facts.st_mode) and not path.is_symlink(), 'regular non-symlink file required: ' + str(path))
    require(type(expected.get('bytes')) is int and expected['bytes'] >= 0, 'invalid bound file size')
    require(type(expected.get('mode')) is int and expected['mode'] in (0o600, 0o644, 0o700, 0o755), 'invalid bound file mode')
    require(facts.st_size == expected['bytes'] and stat.S_IMODE(facts.st_mode) == expected['mode'], 'file size/mode differs: ' + str(path))
    require(digest(path) == expected['sha256'], 'file hash differs: ' + str(path))


def read_json(path, maximum=8 << 20):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= maximum, 'bounded regular JSON required: ' + str(path))
    def nonfinite(value):
        raise ValueError('nonfinite JSON: ' + value)
    return json.loads(path.read_text(), parse_constant=nonfinite)


def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    with temporary.open('x') as destination:
        destination.write(json.dumps(value, indent=2, allow_nan=False) + '\n')
    temporary.replace(path)


def finite_number(value, minimum=0, maximum=None):
    return type(value) in (int, float) and math.isfinite(value) and value >= minimum and (maximum is None or value <= maximum)


def local_path(root, relative):
    value = Path(relative)
    require(not value.is_absolute() and '..' not in value.parts and str(value) == relative, 'nonlocal manifest path')
    return root / value


def controller_environment():
    return {'PATH': '/usr/bin:/bin:/usr/sbin:/sbin', 'LANG': 'en_US.UTF-8'}
