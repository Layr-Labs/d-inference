from pathlib import Path
import argparse
import ipaddress
import json
import shutil
import signal
import sys
import time

from common import ROOT, checked_file, controller_environment, digest, finite_number, identity, local_path, read_json, require, write_json
from owned_process import run_owned
from runtime_identity import runtime_files, stage_snapshot, validate_snapshot
from validation import REQUIRED_FILES, check_previous, process_checks, process_file_checks, readiness_checks, report_checks

SOURCE_FILES = {'controller.py', 'common.py', 'owned_process.py', 'provider_host.py', 'runtime_identity.py',
                'validation.py', 'readiness.py', 'foundation_home.py', 'effective-gemma-environment.json'}
GEMMA_KEYS = {'DARKBLOOM_GEMMA4_PREFILL_CHUNK_EVAL', 'MLX_GEMMA4_FUSED_WEIGHTED_UNSORT', 'MLX_GATHER_QMM_EXPERT_SLICES',
              'MLX_COMPILED_DECODE', 'DARKBLOOM_GEMMA4_PREFILL_TAIL_ROWS', 'DARKBLOOM_GEMMA4_PREFILL_TAIL_MIN_CHUNK',
              'DARKBLOOM_GEMMA4_PREFILL_LAST_QUERY'}


def plan_inputs():
    plan = read_json(ROOT / 'plan.json')
    require(plan['schema'] == 2, 'successor plan schema required')
    required = SOURCE_FILES | {model[key] for model in plan['models'].values() for key in ('input', 'config')}
    require(set(plan['files']) == required, 'complete executable/input/config plan inventory required')
    for relative, expected in plan['files'].items():
        checked_file(local_path(ROOT, relative), expected)
    require(plan['gemma_optimizations'] == {'prefill_layer18': True, 'weighted_r1': True}, 'original teacher serving profile required')
    require(set(plan['effective_gemma_environment']) == GEMMA_KEYS and plan['effective_gemma_environment'] == read_json(ROOT / 'effective-gemma-environment.json'), 'complete exact Gemma environment required')
    for model in plan['models'].values():
        value = read_json(ROOT / model['input'], maximum=1 << 20)
        require(value['modelID'] == model['model_id'] and value['expectedModelAggregateSHA256'] == model['model_sha256'], 'input model identity differs')
        require(digest(ROOT / model['input']) == model['input_sha256'], 'input SHA binding differs')
        require(len(value['promptTokens']) == model['prompt_tokens'] and 1 <= model['prompt_tokens'] <= 32768, 'prompt count differs')
        require(len(value['continuation']) == model['continuation_tokens'] and 1 <= model['continuation_tokens'] <= 256, 'continuation count differs')
        require(all(type(token) is int and 0 <= token < 1048576 for token in value['promptTokens'] + value['continuation']), 'invalid token IDs')
    expected = [(model, backend) for model in ('qwen36', 'gemma-qat4') for backend in ('contiguous', 'paged')]
    require([(cell['model'], cell['backend']) for cell in plan['cells']] == expected and [cell['id'] for cell in plan['cells']] == [model + '-' + backend for model, backend in expected], 'original exact four-cell teacher order required')
    return plan


def environment(plan, output):
    home = output / 'fixture-home'
    result = dict(controller_environment(), CFFIXED_USER_HOME=str(home), HF_HOME=str(home / '.cache/huggingface'),
                  HUGGINGFACE_HUB_CACHE=str(home / '.cache/huggingface/hub'), HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1',
                  DARKBLOOM_PREFIX_CACHE='0', DARKBLOOM_PREFIX_CACHE_MEMORY='0', TMPDIR=str(output / 'tmp'))
    result.update(plan['effective_gemma_environment'])
    return result


def command(artifact, model, cell, output):
    return [str(artifact / 'darkbloom'), 'benchmark', '--config', str(output / 'provider.toml'), '--model', model['model_id'],
            '--kv-backend', cell['backend'], '--teacher-forced-input', str(ROOT / model['input'])]


def probe(argv, env, output, timeout):
    output.mkdir(mode=0o700)
    record = run_owned(argv, env, output, timeout=timeout, graceful_seconds=1)
    process_checks(record, argv)
    process_file_checks(output, argv)
    return read_json(output / 'go.stdout', maximum=1 << 20)


def run_cell(plan, cell, binding, binding_path, binding_sha, artifact):
    for prior in plan['cells'][:plan['cells'].index(cell)]:
        output = ROOT / 'results' / prior['id']
        check_previous(ROOT, plan, prior, binding, binding_sha, command(artifact, plan['models'][prior['model']], prior, output), environment(plan, output))
    model = plan['models'][cell['model']]
    output = ROOT / 'results' / cell['id']
    output.mkdir(parents=True, exist_ok=False, mode=0o700)
    started = time.monotonic()
    summary = {'schema': 2, 'status': 'refused', 'cell': cell['id'], 'binding_sha256': binding_sha,
               'plan_sha256': binding['plan_sha256'], 'process': None}
    signals = (signal.SIGINT, signal.SIGTERM, signal.SIGHUP)
    previous = {signum: signal.getsignal(signum) for signum in signals}
    def interrupted(signum, _frame):
        raise InterruptedError('controller signal ' + str(signum))
    for signum in signals:
        signal.signal(signum, interrupted)
    try:
        write_json(output / 'binding.json', binding)
        ready = probe([sys.executable, '-B', str(ROOT / 'readiness.py'), '--binding', str(binding_path)], controller_environment(), output / 'readiness-probe', 45)
        write_json(output / 'readiness.json', ready)
        readiness_checks(ready, binding)
        home = output / 'fixture-home'
        snapshot = home / '.cache/huggingface/hub' / ('models--' + model['model_id'].replace('/', '--')) / 'snapshots/local'
        target = stage_snapshot(model, snapshot)
        with (output / 'provider.toml').open('xb') as destination:
            destination.write((ROOT / model['config']).read_bytes())
        (output / 'tmp').mkdir(mode=0o700)
        env = environment(plan, output)
        observed_home = probe([sys.executable, '-B', str(ROOT / 'foundation_home.py')], env, output / 'foundation-probe', 15)
        write_json(output / 'foundation-home.json', observed_home)
        require(Path(observed_home['foundation_home']).resolve() == home.resolve(), 'Foundation home isolation failed')
        argv = command(artifact, model, cell, output)
        write_json(output / 'command.json', {'argv': argv, 'environment': env, 'snapshot_target': str(target)})
        record = run_owned(argv, env, output, timeout=binding['timeout_seconds'], graceful_seconds=10)
        summary['process'] = record
        for source, retained in [('go.stdout', 'report.json'), ('go.stderr', 'stderr.log')]:
            if (output / source).is_file():
                shutil.copy2(output / source, output / retained)
        process_checks(record, argv)
        process_file_checks(output, argv)
        runtime_files(binding)
        checked_file(output / 'provider.toml', plan['files'][model['config']])
        plan_inputs()
        validate_snapshot(model, snapshot)
        report = read_json(output / 'report.json')
        report_checks(report, model, cell, binding, read_json(ROOT / model['input']), snapshot, plan)
        summary['status'] = 'observed'
        summary['meanForcedTokenNLL'] = report['meanForcedTokenNLL']
    except BaseException as error:
        summary['error'] = type(error).__name__ + ': ' + str(error)
        raise
    finally:
        for signum in signals:
            signal.signal(signum, signal.SIG_IGN)
        try:
            summary['elapsed_seconds'] = time.monotonic() - started
            summary['files'] = {relative: identity(output / relative) for relative in sorted(REQUIRED_FILES) if (output / relative).is_file() and not (output / relative).is_symlink()}
            if summary['status'] == 'observed' and set(summary['files']) != REQUIRED_FILES:
                summary.update(status='refused', error='complete receipt inventory missing')
            write_json(output / 'summary.json', summary)
        finally:
            for signum, handler in previous.items():
                signal.signal(signum, handler)
    require(summary['status'] == 'observed', 'teacher cell refused; evidence retained')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('cell', nargs='?')
    parser.add_argument('--check-plan', action='store_true')
    parser.add_argument('--binding', type=Path)
    parser.add_argument('--binding-sha256')
    arguments = parser.parse_args()
    plan = plan_inputs()
    if arguments.check_plan:
        print(json.dumps({'status': 'prepared_only', 'cells': plan['cells'], 'runtime_launched': False}, indent=2))
        return
    require(arguments.binding and arguments.binding_sha256 and arguments.cell, 'explicit cell/binding/hash required')
    require(digest(arguments.binding) == arguments.binding_sha256, 'binding hash differs')
    binding = read_json(arguments.binding)
    require(binding.get('state') == 'peer_reviewed', 'fixed successor peer review is required before execution')
    require(binding['plan_sha256'] == digest(ROOT / 'plan.json'), 'bound plan differs')
    require(str(ROOT) == str(Path(binding['execution_root']).resolve(strict=True)), 'wrong execution root')
    require(finite_number(binding['timeout_seconds'], 1, 1800), 'bounded CLI timeout required')
    require(len(binding['target_host'].split('@')) == 2, 'typed target host required')
    ipaddress.ip_address(binding['target_host'].split('@')[1])
    require(binding.get('host_identity', {}).get('hardware_model') and type(binding['host_identity'].get('memory_bytes')) is int, 'bound hardware identity required')
    artifact = runtime_files(binding)
    selected = [cell for cell in plan['cells'] if cell['id'] == arguments.cell]
    require(len(selected) == 1, 'unknown cell')
    run_cell(plan, selected[0], binding, arguments.binding, arguments.binding_sha256, artifact)


if __name__ == '__main__':
    main()
