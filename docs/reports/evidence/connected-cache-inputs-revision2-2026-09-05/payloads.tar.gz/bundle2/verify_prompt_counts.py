#!/usr/bin/env python3
"""Local CPU-only exact sidecar plan proof; no provider/model/GPU execution."""
from pathlib import Path
import hashlib
import http.client
import json
import os
import socket
import subprocess
import tempfile
import time

BASE = Path(__file__).resolve().parent
SIDECAR = Path('/tmp/darkbloom-final-promptsidecar-build1/promptsidecar')
ARTIFACTS = Path('/tmp/darkbloom-release-090/prompt-artifacts').resolve()
EXPECTED = '6a0c4498c6a3d23f85001fe1d1e0b8a502e2397858a586808e792b66e85576ea'
assert hashlib.sha256(SIDECAR.read_bytes()).hexdigest() == EXPECTED
plan = json.loads((BASE/'bundle-plan.json').read_text())
results = {'scope':'Local M3 CPU-only exact pinned Rust rendering/tokenization; no provider/inference or GPU test',
           'binary_sha256':EXPECTED,'expected_request_date_utc':plan['expected_request_date_utc'],
           'status':'running','rows':[]}
with tempfile.TemporaryDirectory(prefix='db-connect-plan-', dir='/private/tmp') as tmp:
    endpoint = str(Path(tmp)/'s.sock')
    with (BASE/'tokenizer-plan.log').open('w') as log:
        child = subprocess.Popen([str(SIDECAR),'--socket',endpoint,'--artifact-root',str(ARTIFACTS),
                                  '--max-loaded-contracts','2','--max-tokens','65536',
                                  '--memory-limit-mib','1024','--parent-pid',str(os.getpid())],
                                 stdout=log,stderr=subprocess.STDOUT)
        try:
            for _ in range(100):
                if Path(endpoint).exists(): break
                if child.poll() is not None: raise RuntimeError('sidecar exited during startup')
                time.sleep(.05)
            class UnixHTTP(http.client.HTTPConnection):
                def connect(self):
                    self.sock=socket.socket(socket.AF_UNIX,socket.SOCK_STREAM)
                    self.sock.settimeout(30);self.sock.connect(endpoint)
            def post(path, body):
                c=UnixHTTP('localhost',timeout=30)
                c.request('POST',path,json.dumps(body),{'Content-Type':'application/json'})
                response=c.getresponse(); raw=response.read(); c.close()
                if response.status!=200: raise ValueError(str(response.status)+': '+raw.decode())
                return json.loads(raw)
            for cell in plan['cells'][::2]:
                data=json.loads((BASE/cell['input']).read_text());contract=data['artifact']['prompt_contract_id']
                post('/v1/preload',{'prompt_contract_ids':[contract]})
                # Matches connectedTextBody plus coordinator-owned request date.
                body={'model':data['artifact']['model_id'],'messages':[{'role':'user','content':data['prompt']}],
                      'temperature':0,'seed':0,'max_tokens':64,'stream':True,
                      'stream_options':{'include_usage':True},'_darkbloom_prompt_date':plan['expected_request_date_utc']}
                answer=post('/v1/plan',{'prompt_contract_id':contract,'scope_id':'connected-fixture-token-count-only',
                                      'endpoint':'chat_completions','body':body})
                row={'model_id':data['artifact']['model_id'],'input_sha256':hashlib.sha256((BASE/cell['input']).read_bytes()).hexdigest(),
                     'prompt_sha256':hashlib.sha256(data['prompt'].encode()).hexdigest(),'characters':len(data['prompt']),
                     'normalized_body_sha256':hashlib.sha256(json.dumps(body,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
                     'prompt_contract_id':contract,'prompt_tokens':answer['prompt_token_count'],
                     'last_boundary':answer['block_boundaries'][-1]['token_count'],
                     'contract_metadata_sha256':hashlib.sha256((ARTIFACTS/contract/'prompt-contract.json').read_bytes()).hexdigest()}
                results['rows'].append(row)
                assert row['prompt_tokens'] > 4096,row
            results['status']='passed'
        finally:
            child.terminate()
            try: child.wait(timeout=10)
            except subprocess.TimeoutExpired: child.kill();child.wait()
            (BASE/'tokenizer-plan.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
