from pathlib import Path
import json,hashlib,shlex,subprocess,sys,time
backend=sys.argv[1];assert backend in ('contiguous','paged');base=Path('/tmp/darkbloom-q36-backend-mtp-off-diagnostic1');proof=json.loads((base/'commands.json').read_text());command=proof['commands'][backend]['argv'];local=base/backend;local.mkdir(exist_ok=False);remote=command[command.index('--output')+1];ssh=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99']
check='''import sys,json
from pathlib import Path
sys.dont_write_bytecode=True
sys.path.insert(0,'/Users/gaj/autoresearch/radix-prefix-cache/090-repeated-matrix1/plan')
import matrix_cells as c
binding=c.verified_bindings('/Users/gaj/autoresearch/radix-prefix-cache/090-repeated-matrix1/bindings.reviewed1.json')
assert not Path(OUTPUT).exists()
print(json.dumps({'binary':binding['binary'],'scope':'Reviewed runtime identities; diagnostic arguments separately authorized'},indent=2))
'''.replace('OUTPUT',repr(remote));r=subprocess.run(ssh+['python3 -B -'],input=check,text=True,capture_output=True);(local/'runtime-precheck.stdout').write_text(r.stdout);(local/'runtime-precheck.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr
(local/'command.json').write_text(json.dumps({'scope':proof['scope'],'argv':command},indent=2)+'\n');start=time.monotonic()
with (local/'ssh-run.log').open('x') as log:r=subprocess.run(ssh+[shlex.join(command)],stdout=log,stderr=subprocess.STDOUT)
exit_code=r.returncode;(local/'execution.json').write_text(json.dumps({'exit_code':exit_code,'seconds':time.monotonic()-start},indent=2)+'\n')
code='''from pathlib import Path
import json,hashlib
root=Path(ROOT);files={}
if root.exists():
 for p in sorted(root.iterdir()):
  if p.is_file() and not p.is_symlink():files[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'exists':root.exists(),'files':files},indent=2))
'''.replace('ROOT',repr(remote));r=subprocess.run(ssh+['python3 -B -'],input=code,text=True,capture_output=True);assert r.returncode==0,r.stderr;(local/'remote-inventory.json').write_text(r.stdout);inventory=json.loads(r.stdout)
for name,item in inventory['files'].items():
 assert all(x.isalnum() or x in '.-_' for x in name);p=local/name;r=subprocess.run(['scp','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','gaj@100.124.35.99:'+remote+'/'+name,str(p)],text=True,capture_output=True);assert r.returncode==0,r.stderr;assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
summary={'scope':'MTP-off diagnostic only, never normal acceptance','backend':backend,'exit_code':exit_code}
if (local/'report.json').exists():
 sys.path.insert(0,'/tmp/darkbloom-repeated-matrix-plan1/runner');from radix_engine_evidence import report_errors
 report=json.loads((local/'report.json').read_text());errors=report_errors(report);summary.update(passed_report_integrity=not errors,errors=errors,mtp=report.get('mtp'),rows=[{k:r.get(k) for k in ('id','prompt_tokens','completion_tokens','finish','cache_outcome')} for r in report.get('rows',[])])
(local/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');files={str(p.relative_to(local)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(local.rglob('*')) if p.is_file()};(local/'manifest.json').write_text(json.dumps({'scope':proof['scope'],'files':files},indent=2)+'\n');print(json.dumps(summary,indent=2));print('manifest_sha256',hashlib.sha256((local/'manifest.json').read_bytes()).hexdigest());sys.exit(exit_code or (1 if summary.get('errors') else 0))
