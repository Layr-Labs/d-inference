ObjC.import("Foundation");
function run(args) { return JSON.stringify(args.map(function(path) { var url = $.NSURL.fileURLWithPath(path); return {input:path,resolved:url.URLByResolvingSymlinksInPath.path.js}; })); }
