"""CPU-only transport/ownership failures; no SSH or real operator invocation."""
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
import hashlib
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import Mock, patch

import common
import remote_sources as snippets
import run_arm


class TransportTests(unittest.TestCase):
    def test_every_remote_snippet_compiles_with_ambiguous_old_marker_as_data(self):
        values = {'remote_root': '/owned/SOURCE_ONLY_PENDING_ROOT_REVIEW', 'entry': True,
                  'argv': ['/owned/probe', 'literal $(private) `private`'], 'arm': 'nativeSDPA'}
        for name in ('READINESS', 'CREATE', 'EXTRACT', 'VERIFY', 'POPULATE', 'EXECUTE', 'INVENTORY'):
            code = common.render(getattr(snippets, name), values)
            compile(code, '<' + name + '>', 'exec')
            self.assertIn('SOURCE_ONLY_PENDING_ROOT_REVIEW', code)

    def test_wrong_binding_refuses_before_any_remote_or_artifact_work(self):
        with patch.object(common, 'sha', return_value='a'*64), patch.object(common.subprocess, 'run') as runner:
            with self.assertRaises(AssertionError): common.load_binding('b'*64)
            runner.assert_not_called()

    def test_failed_predecessor_blocks_without_network(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); common.write(root/'summary.json', {'status': 'FAIL'})
            with patch.object(common.subprocess, 'run') as runner:
                with self.assertRaisesRegex(AssertionError, 'Prior failed'): run_arm.verify_previous(root)
                runner.assert_not_called()

    def test_created_root_cannot_replace_previous_evidence(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)/'owned'
            code = common.render(snippets.CREATE, {'remote_root': str(root)})
            with redirect_stdout(StringIO()): exec(code, {})
            self.assertEqual(root.stat().st_mode&0o777, 0o700)
            with self.assertRaises(AssertionError): exec(code, {})

    def test_inventory_refuses_symlink_and_unexpected_payloads(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); arm = root/'runs/nativeSDPA'; arm.mkdir(parents=True)
            external = root/'outside'; external.write_bytes(b'bounded')
            target = arm/'output.bin'; target.symlink_to(external)
            code = common.render(snippets.INVENTORY, {'remote_root': str(root), 'arm': 'nativeSDPA'})
            with self.assertRaises(AssertionError): exec(code, {})
            target.unlink(); (arm/'unexpected.bin').write_bytes(b'bounded')
            with self.assertRaises(AssertionError): exec(code, {})

    def test_file_verification_checks_mode_and_symlink(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary); file = root/'input'; file.write_bytes(b'exact')
            row = common.file_record(file); file.chmod(0o600)
            if row['mode'] == '0o600': file.chmod(0o644)
            with self.assertRaises(AssertionError): common.verify_file(file, row)
            link = root/'link'; link.symlink_to(file)
            with self.assertRaises(AssertionError): common.file_record(link)

    def execution_fixture(self, root):
        for name in ('plan', 'runtime', 'transfer', 'runs'): (root/name).mkdir()
        native = root/'runtime/attention-replay'; native.write_bytes(b'never executed'); native.chmod(0o755)
        source = root/'transfer/queries.bin'; source.write_bytes(b'\0\0')
        (root/'transfer/input.json').write_bytes(b'{}')
        mapping = {'queries': {'destination_file': 'queries.bin', **common.file_record(source)}}
        common.write(root/'plan/native-buffer-map.json', mapping)
        common.write(root/'plan/manifest.json', {'files': {'native-buffer-map.json': common.file_record(root/'plan/native-buffer-map.json')}})
        command = {'arm': 'nativeSDPA', 'timeout_seconds': 180,
                   'argv': [str(native), '--input', str(root/'transfer/input.json'), '--input-sha256',
                            common.sha(root/'transfer/input.json'), '--output', str(root/'runs/nativeSDPA'), '--arm', 'nativeSDPA']}
        binding = {'remote_root': str(root), 'artifacts': {'attention-replay': common.file_record(native)},
                   'plan_manifest_sha256': common.sha(root/'plan/manifest.json'),
                   'input_sha256': common.sha(root/'transfer/input.json'), 'commands': [command]}
        common.write(root/'runtime-binding.json', binding)
        return {'remote_root': str(root), 'binding_sha256': common.sha(root/'runtime-binding.json'),
                'arm': 'nativeSDPA', 'argv': command['argv']}

    def test_timeout_kills_only_owned_process_group_and_reaps(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve(); values = self.execution_fixture(root)
            child = Mock(pid=987654); child.wait.side_effect = [subprocess.TimeoutExpired(values['argv'],180), -9]
            child.poll.return_value = None
            with patch('subprocess.Popen', return_value=child) as popen, patch('os.getpgid', return_value=987654), \
                 patch('os.killpg') as kill, redirect_stdout(StringIO()):
                exec(common.render(snippets.EXECUTE, values), {})
            self.assertEqual(popen.call_args.args[0], values['argv'])
            self.assertTrue(popen.call_args.kwargs['start_new_session'])
            self.assertEqual(set(popen.call_args.kwargs['env']), {'HOME', 'PATH'})
            kill.assert_called_once(); self.assertEqual(kill.call_args.args[0],987654)
            self.assertEqual(child.wait.call_count,2)
            receipt = json.loads((root/'runs/nativeSDPA-execution.json').read_text())
            self.assertIn('TimeoutExpired',receipt['failure']); self.assertEqual(receipt['exit_code'],-9)

    def test_spawn_failure_retains_receipt_without_kill(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve(); values = self.execution_fixture(root)
            with patch('subprocess.Popen', side_effect=OSError('synthetic spawn refusal')), \
                 patch('os.killpg') as kill, redirect_stdout(StringIO()):
                exec(common.render(snippets.EXECUTE, values), {})
            kill.assert_not_called()
            receipt = json.loads((root/'runs/nativeSDPA-execution.json').read_text())
            self.assertIn('OSError',receipt['failure']); self.assertIsNone(receipt['exit_code'])

    def test_hup_and_term_reap_a_real_harmless_owned_child_and_keep_receipt(self):
        for signum in (signal.SIGHUP,signal.SIGTERM):
            with self.subTest(signal=signum), tempfile.TemporaryDirectory() as temporary:
                root=Path(temporary).resolve(); values=self.execution_fixture(root)
                native=root/'runtime/attention-replay'
                native.write_text('#!'+sys.executable+'\nimport time\ntime.sleep(60)\n')
                binding=json.loads((root/'runtime-binding.json').read_text())
                binding['artifacts']['attention-replay']=common.file_record(native)
                common.write(root/'runtime-binding.json',binding)
                values['binding_sha256']=common.sha(root/'runtime-binding.json')
                owner=subprocess.Popen([sys.executable,'-B','-c',common.render(snippets.EXECUTE,values)],
                                       stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
                child_pid=None
                try:
                    deadline=time.monotonic()+5
                    while time.monotonic()<deadline:
                        receipt=root/'runs/nativeSDPA-execution.json'
                        if receipt.exists():
                            child_pid=json.loads(receipt.read_text())['pid'];break
                        time.sleep(0.01)
                    self.assertIsNotNone(child_pid,'owned child PID was not retained')
                    owner.send_signal(signum)
                    stdout,stderr=owner.communicate(timeout=5)
                    self.assertEqual(owner.returncode,0,stderr)
                    record=json.loads(receipt.read_text())
                    self.assertIn('OwnerInterrupted',record['failure'])
                    self.assertEqual(record['exit_code'],-signal.SIGKILL)
                    self.assertEqual(record['pid'],child_pid)
                    with self.assertRaises(ProcessLookupError):os.kill(child_pid,0)
                finally:
                    if owner.poll()is None:owner.kill();owner.wait(timeout=5)
                    if child_pid is not None:
                        try:os.killpg(child_pid,signal.SIGKILL)
                        except ProcessLookupError:pass


if __name__ == '__main__': unittest.main()
