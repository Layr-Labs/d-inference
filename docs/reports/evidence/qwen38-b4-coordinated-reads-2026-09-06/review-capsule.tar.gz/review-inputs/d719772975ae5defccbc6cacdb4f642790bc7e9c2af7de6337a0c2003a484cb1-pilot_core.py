"""Pinned review, stable audits and lossless evidence for the Q38-only pilot."""
import hashlib
import importlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parent
PLAN_SHA = "e5c76a918f4599d41d675fdd6a65f03b69a9cf06154bd805b0ab07a5eb388f4f"
PILOT = "qwen38-retained-b4-r1"
CELLS = [PILOT + suffix for suffix in ("-contiguous-cache-off", "-paged-cache-off", "-paged-cache-on")]
SOURCE = {"parent": "35fea6d0e3b05ff65d60d9675ab480159913ac62",
          "native": "f2d79145e040bbc28c6e0e355a19bc8923a70434"}
ENV = {"HOME": str(Path.home()), "PATH": "/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin",
       "TMPDIR": "/private/tmp", "PYTHONDONTWRITEBYTECODE": "1", "GIT_OPTIONAL_LOCKS": "0"}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(filename):
    return json.loads(Path(filename).read_text())


def write_new(filename, value):
    filename = Path(filename)
    with filename.open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n"); stream.flush(); os.fsync(stream.fileno())


def file_state(info):
    return {"device": info.st_dev, "inode": info.st_ino, "bytes": info.st_size,
            "mtime_ns": info.st_mtime_ns, "ctime_ns": info.st_ctime_ns, "mode": stat.S_IMODE(info.st_mode)}


def stable_file(filename, expected=None, checkpoint=lambda: None, allow_link=False):
    filename = Path(filename)
    link_before = file_state(filename.lstat())
    require(allow_link or not filename.is_symlink(), "symlink refused: " + str(filename))
    resolved = filename.resolve(strict=True)
    descriptor = os.open(resolved, os.O_RDONLY | os.O_NOFOLLOW)
    digest = hashlib.sha256()
    with os.fdopen(descriptor, "rb") as stream:
        before = os.fstat(stream.fileno())
        require(stat.S_ISREG(before.st_mode), "not a regular file: " + str(filename))
        while True:
            checkpoint()
            block = stream.read(1 << 20)
            if not block:
                break
            digest.update(block)
        require(file_state(before) == file_state(os.fstat(stream.fileno())), "file changed during audit")
    require(filename.resolve(strict=True) == resolved and file_state(filename.lstat()) == link_before
            and file_state(resolved.stat()) == file_state(before), "file replaced during audit")
    result = dict(file_state(before), sha256=digest.hexdigest(), path=str(filename.absolute()),
                  resolved_path=str(resolved), link=link_before)
    for key in ("sha256", "bytes", "mode"):
        if expected is not None and key in expected:
            require(result[key] == expected[key], "file identity drift: " + str(filename))
    return result


def sha(filename):
    return stable_file(filename)["sha256"]


def verify_driver():
    inventory = read(ROOT / "manifest.json")["files"]
    require(bool(inventory), "driver inventory empty")
    for relative, expected in inventory.items():
        require(not Path(relative).is_absolute() and ".." not in Path(relative).parts, "unsafe driver inventory")
        stable_file(ROOT / relative, expected)


def plan_module(plan_root):
    plan_root = Path(plan_root).resolve(strict=True)
    require(sha(plan_root / "manifest.json") == PLAN_SHA, "frozen plan manifest drift")
    for relative, expected in read(plan_root / "manifest.json")["files"].items():
        require(not Path(relative).is_absolute() and ".." not in Path(relative).parts, "unsafe plan inventory")
        stable_file(plan_root / relative, expected)
    sys.path.insert(0, str(plan_root))
    module = importlib.import_module("qwen_plan")
    require(module.ROOT == plan_root, "different cached Qwen plan module")
    return module


def file_records(value):
    if isinstance(value, dict):
        if value.get("path") and value.get("sha256") and Path(value["path"]).is_absolute():
            yield value
        else:
            for child in value.values():
                yield from file_records(child)
    elif isinstance(value, list):
        for child in value:
            yield from file_records(child)


def context(plan_root, binding_path, ack_path):
    verify_driver()
    scoped = plan_module(plan_root)
    plan, matrix = scoped.load_plan()
    binding = scoped.verified_binding(plan, matrix, binding_path)
    require(binding["reviewed_cell_ids"] == CELLS, "only the exact three Q38 pilot cells may execute")
    require([cell["id"] for cell in scoped.select(plan, PILOT)] == CELLS, "pilot selection changed")
    matrix.require_current_prompt_date(plan)
    ack = read(ack_path)
    require(ack.get("status") == "QWEN_EXECUTION_AUTHORIZED" and ack.get("review_id")
            and ack.get("binding_sha256") == sha(binding_path) and ack.get("only_cells") == CELLS
            and ack.get("host_id") == "m5", "exact ROOT/main ACK missing or changed")
    controller = read(matrix.verify_file(ack.get("owned_controller_review")))
    require(controller.get("status") == "QWEN_PILOT_CONTROLLER_REVIEWED"
            and controller.get("driver_manifest_sha256") == sha(ROOT / "manifest.json")
            and controller.get("only_cells") == CELLS and controller.get("exclusive_host_id") == "m5",
            "ROOT/main controller scope/ownership review differs")
    source = read(matrix.verify_file(binding.get("runtime_source_manifest")))
    pins = read(ROOT / "source-pins.json")
    require(all(pins.get(key) == value for key, value in SOURCE.items()) and source.get("source") == pins,
            "signed primary/native source selection differs")
    repositories = source.get("repositories", [])
    require({row["name"]: row["commit"] for row in repositories} == pins
            and set(source["files"]) == set(pins), "incomplete source manifest")
    workspace = Path(binding.get("source_workspace") or "")
    require(workspace.is_absolute() and workspace.is_dir(), "source workspace unbound")
    artifact = read(matrix.verify_file(binding.get("artifact_manifest")))
    require(artifact.get("source") == pins and artifact.get("canonical_swiftpm_build") is True
            and artifact.get("manual_object_link") is False and artifact.get("M5_built") is True,
            "artifact is not the pinned canonical M5 build")
    runtime_review = read(binding["runtime_review"]["path"])
    require(runtime_review.get("artifact_manifest_sha256") == binding["artifact_manifest"]["sha256"],
            "artifact manifest not covered by ROOT runtime review")
    records = dict(binding["resources"], **{"radix-engine": binding["binary"]})
    require(set(artifact["files"]) == set(records), "artifact runtime inventory differs")
    for name, record in records.items():
        require(record["sha256"] == artifact["files"][name]["sha256"], "artifact hash differs from binding")
        stable_file(record["path"], artifact["files"][name])
    return scoped, plan, matrix, binding, ack


def activate(plan_root, binding_path, ack_path, run_root, output):
    scoped, plan, matrix, binding, ack = context(plan_root, binding_path, ack_path)
    import owner_helper
    run_root = owner_helper.canonical_owned_root(str(run_root), Path.home())
    require(Path(binding["results_root"]) == run_root / "results", "results_root must be fresh run_root/results")
    output = Path(output).absolute()
    require(not output.is_relative_to(run_root), "activation must be outside fresh run root")
    records = list(file_records(binding)) + list(file_records(ack))
    for field in ("source_review", "runtime_review"):
        records.extend(file_records(read(binding[field]["path"])))
    for directory in (ROOT, Path(plan_root)):
        records.append({"path": str(directory / "manifest.json"), "sha256": sha(directory / "manifest.json")})
        records.extend(dict(expected, path=str(directory / relative))
                       for relative, expected in read(directory / "manifest.json")["files"].items())
    records.extend({"path": str(Path(filename).resolve()), "sha256": sha(filename)} for filename in (binding_path, ack_path))
    dependencies = {record["path"]: stable_file(record["path"], record) for record in records}
    value = {"schema": 1, "plan_root": str(Path(plan_root).resolve()), "binding": str(Path(binding_path).resolve()),
             "ack": str(Path(ack_path).resolve()), "run_root": str(run_root), "dependencies": dependencies,
             "source": read(ROOT / "source-pins.json"), "only_cells": CELLS, "gpu_ready": False}
    write_new(output, value)
    return value


def verify_activation(filename, expected_sha=None):
    stable_file(filename, {"sha256": expected_sha} if expected_sha else None)
    value = read(filename)
    require(value["schema"] == 1 and value["only_cells"] == CELLS and value["gpu_ready"] is False,
            "activation scope drift")
    for path, expected in value["dependencies"].items():
        require(stable_file(path, expected) == expected, "source/config dependency changed: " + path)
    result = context(value["plan_root"], value["binding"], value["ack"])
    require(Path(result[3]["results_root"]) == Path(value["run_root"]) / "results", "activation result root drift")
    require(value["source"] == read(ROOT / "source-pins.json"), "activation source drift")
    return value, result


def audit_model(plan_root, plan, binding):
    import owner_helper
    model = next(row for row in plan["models"] if row["label"] == "qwen38")
    manifest = read(Path(plan_root) / model["manifest"])
    snapshot = Path(binding["models"]["qwen38"]["directory"]).resolve(strict=True)
    files = {}
    for row in manifest["files"]:
        resolved = owner_helper.model_file(snapshot, row["path"])
        expected = {"bytes": row["size_bytes"], "sha256": row["sha256"]}
        files[row["path"]] = stable_file(snapshot / row["path"], expected, allow_link=True)
        require(files[row["path"]]["resolved_path"] == str(resolved), "model link drift")
    allowed_sidecars = {"manifest.json", ".darkbloom-model.json", "model.manifest.json"}
    extra = {}
    for filename in snapshot.rglob("*"):
        if filename.is_file() and str(filename.relative_to(snapshot)) not in files:
            relative = str(filename.relative_to(snapshot))
            require(filename.suffix not in {".json", ".safetensors", ".bin", ".model", ".jinja", ".txt"}
                    or relative in allowed_sidecars, "unmanifested model/config payload: " + relative)
            owner_helper.model_file(snapshot, relative)
            extra[relative] = stable_file(filename, allow_link=True)
    return {"model_id": model["model_id"], "aggregate_sha256": model["aggregate_sha256"],
            "directory": str(snapshot), "files": files, "extra_files": extra}


def audit_sources(binding):
    manifest = read(binding["runtime_source_manifest"]["path"])
    workspace = Path(binding["source_workspace"]).resolve(strict=True)
    files = {}
    for row in manifest["repositories"]:
        relative = Path(row["relative_path"])
        require(not relative.is_absolute() and ".." not in relative.parts, "source repo path escape")
        repository = workspace / relative
        require(repository.resolve().is_relative_to(workspace), "source repository escapes workspace")
        head = subprocess.check_output(["git", "-C", str(repository), "rev-parse", "HEAD"], env=ENV, text=True, timeout=30).strip()
        dirty = subprocess.check_output(["git", "-C", str(repository), "status", "--porcelain", "--untracked-files=all"],
                                        env=ENV, text=True, timeout=30)
        require(head == row["commit"] and not dirty, "source/config drift in " + row["name"])
        entries = manifest["files"][row["name"]]
        require(bool(entries), "source inventory empty")
        for name, expected in entries.items():
            filename = repository / name
            require(not Path(name).is_absolute() and ".." not in Path(name).parts
                    and filename.resolve().is_relative_to(workspace), "source payload path escape")
            files[row["name"] + "/" + name] = stable_file(filename, expected, allow_link=True)
    return {"source": manifest["source"], "files": files}


def audit_runtime(binding):
    artifact = read(binding["artifact_manifest"]["path"])
    records = dict(binding["resources"], **{"radix-engine": binding["binary"]})
    return {name: stable_file(record["path"], artifact["files"][name]) for name, record in records.items()}


def audit_all(activation, plan, binding):
    return {"model": audit_model(activation["plan_root"], plan, binding),
            "source": audit_sources(binding), "runtime": audit_runtime(binding)}


def require_stable_stats(value):
    if isinstance(value, dict):
        if "resolved_path" in value and "link" in value:
            filename = Path(value["path"])
            require(str(filename.resolve(strict=True)) == value["resolved_path"]
                    and file_state(filename.lstat()) == value["link"]
                    and all(file_state(filename.stat())[key] == value[key] for key in file_state(filename.stat())),
                    "source/model/runtime changed after audit: " + str(filename))
        else:
            for child in value.values():
                require_stable_stats(child)


def audit_tree(directory):
    directory = Path(directory)
    require(directory.is_dir() and not directory.is_symlink(), "missing result directory")
    records = {}
    for filename in sorted(directory.rglob("*")):
        require(not filename.is_symlink(), "symlink in result evidence")
        if filename.is_file():
            records[str(filename.relative_to(directory))] = stable_file(filename)
    require(bool(records), "empty result evidence")
    return records


def verify_completed(run_root):
    for receipt in sorted((Path(run_root) / "steps").glob("*/cell-results.json")):
        value = read(receipt)
        require(value["cell"] in CELLS, "out-of-scope result receipt")
        require(audit_tree(Path(run_root) / "results" / value["cell"]) == value["files"],
                "completed cell evidence changed; no baseline replacement")


def entry(binding, output, timeout=600):
    import owner_helper
    target = {"macmon_path": binding["macmon"]["path"], "macmon": stable_file(binding["macmon"]["path"], binding["macmon"])}
    deadline = time.monotonic() + timeout
    samples = []
    while True:
        observation = owner_helper.observe(target)
        samples.append(dict(owner_helper.report_observation(observation), observed_unix=time.time()))
        reason, transient = owner_helper.entry_refusal(observation)
        if observation["hardware_model"] != "Mac17,6" or observation["memory_bytes"] != 137438953472:
            reason, transient = "not the exact M5 hardware/memory", False
        disk = shutil.disk_usage(Path(binding["results_root"]).parent)
        if disk.free <= max(binding["min_free_bytes"], 20 * (1 << 30), int(disk.total * .05)):
            reason, transient = "reviewed storage floor not met", False
        if reason is None or not transient or time.monotonic() >= deadline:
            write_new(output, {"accepted": reason is None, "reason": reason, "samples": samples})
            require(reason is None, "measured entry refused: " + str(reason))
            return
        time.sleep(2)


def snapshot_reviews(activation, destination):
    destination.mkdir(mode=0o700)
    inventory = {}
    for filename, identity in activation["dependencies"].items():
        if Path(filename).suffix not in {".json", ".py", ".md"}:
            continue
        name = identity["sha256"] + "-" + Path(filename).name
        target = destination / name
        if not target.exists():
            with target.open("xb") as stream:
                stream.write(Path(filename).read_bytes())
        require(sha(target) == identity["sha256"], "review snapshot drift")
        inventory[filename] = name
    write_new(destination / "index.json", inventory)


def seal(run_root):
    run_root = Path(run_root)
    files = {}
    for filename in sorted(run_root.rglob("*")):
        require(not filename.is_symlink(), "symlink in retained evidence")
        if filename.is_file():
            files[str(filename.relative_to(run_root))] = stable_file(filename)
    write_new(run_root / "evidence-manifest.json", {"files": files, "lossless": True})
    names = sorted(files) + ["evidence-manifest.json"]
    archive_path = run_root / "evidence.tar.gz"
    with archive_path.open("xb") as stream, tarfile.open(fileobj=stream, mode="w:gz") as archive:
        for relative in names:
            archive.add(run_root / relative, arcname=relative, recursive=False)
    with tarfile.open(archive_path, "r:gz") as archive:
        require(archive.getnames() == names, "evidence archive inventory differs")
        for member in archive:
            require(member.isfile(), "non-file archive member")
            digest = hashlib.sha256()
            with archive.extractfile(member) as stream:
                for block in iter(lambda: stream.read(1 << 20), b""):
                    digest.update(block)
            require(digest.hexdigest() == sha(run_root / member.name), "evidence archive hash differs")
    for relative, expected in files.items():
        require(stable_file(run_root / relative) == expected, "evidence mutated during collection")
    write_new(run_root / "collection-receipt.json", {"archive_sha256": sha(archive_path),
              "manifest_sha256": sha(run_root / "evidence-manifest.json"), "files": len(files), "verified": True})
    for filename in run_root.rglob("*"):
        if filename.is_file():
            filename.chmod(0o400)
    return len(files)
