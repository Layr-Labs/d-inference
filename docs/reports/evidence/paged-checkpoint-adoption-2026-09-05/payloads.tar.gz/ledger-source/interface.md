# Pure process memory ledger — aggregate ownership interface

Status: source frozen in freeze1; 18 focused test functions authored but not compiled or executed. Native/process integration and real capacity proof remain pending. This replaces the earlier process-ticket draft, which has been deleted rather than retained as an alternative implementation.

Worktree: /Users/gaj/Documents/DarkbloomDev/wt/process-memory-ledger, parent c8ec9469fc58442feeca262517df4c5e53e637a2.
Frozen source, tests, patch and hashes: /tmp/darkbloom-process-memory-ledger/freeze1/manifest.json.

## Ownership and authority

One opaque process owner per native engine accounts the COMPLETE Admission aggregate C: target max(P, N), fixed/auxiliary A and disjoint X, including private preparations and native checkpoint stages before allocation. Native Admission is the only geometry/pricing authority. The process core does not implement private-allocation tickets, second baseline pins, stage transfer prices, or per-page geometry. Separate pending-load and host-only owners remain separate sums; host-only coverage M stays zero.

For each live owner, 0 <= M <= C. M is exact native-proven, exclusively owned allocated backing already included in coherent MLX active+cache usage. It is never a global before/after delta or heartbeat estimate. Native allocation/physical lease identities must prevent double materialization credit; process owner/revision tokens prevent cross-generation or stale aggregate updates.

Every native private candidate must enter native P/X BEFORE allocation. Under its own Admission lock, native code computes complete next C, calls replaceCharge, and commits already validated local metadata if accepted. The local commit must be non-failing; no actor hop, allocation, eval, file I/O or callback sits between shared acceptance and local metadata publication. A native refusal leaves both the global C and local candidate registry unchanged.

Allocation/evaluation occurs off-lock. After exact arrays exist, native code reports its complete proven M under Admission serialization using recordMaterialization. On failure/cancellation, withdraw credit before aliases may disappear, destroy actual aliases, recompute CURRENT native C including every surviving child, then replaceCharge. Never restore an obsolete pre-allocation C. Typed native ownership handles retain charge across SSD streaming; no process preparation ticket spans I/O.

## Methods

- createOwner: new generation, C=M=0, open; caller owns explicit retirement.
- state(for:): current revision, C, M and closing flag, or nil for retired/unknown generation.
- replaceCharge(owner, expectedRevision, expectedPolicyEpoch, chargedBytes): exact complete aggregate C, preserving M. Requires current revision. Growth requires open owner, current policy epoch and fresh capacity sampled under the same process lock. Same charge and decreases do not depend on a policy epoch or headroom. C cannot fall below current M. Native alias retirement precedes the C reduction. When a closing owner's C becomes zero, M is necessarily zero and it is removed immediately.
- recordMaterialization(owner, expectedRevision, materializedBytes): absolute complete proven M after evaluated backing exists; never changes C. Requires current revision and oldM <= nextM <= C. This converts an already accepted promise and is permitted under policy debt or closing. It is not an allocation permit. Coverage withdrawal is a separate explicit method.
- withdrawCoverage(owner, bytes): exact ownership-proven removal, before actual backing destruction. No revision/policy/headroom/closing refusal. Unknown generation or withdrawing more than current M is an ownership error. Changes revision. Temporary debt is conservative and expected.
- retire(owner): closes generation to new C growth but preserves all current C/M. Already reserved allocations may still complete and receive exact credit; withdrawals and C reductions remain permitted. Returns draining(C,M) until children finish. At zero state it returns retired; duplicate close after deletion is alreadyRetired and cannot affect a successor. There is no retry queue, timer, finalizer or age refund.
- updatePolicy: caller-supplied monotonic UInt64 epoch; same/older updates ignored. Core consumes already resolved cap/reserve bytes; the adapter retains existing unified-cap/operator/OS-floor arithmetic.
- snapshot: one locked policy/usage/owner accounting view with explicit total C, M, unmaterialized C-M, remaining headroom, commitment debt and closing owner count. Commitment debt does not claim to measure physical cap excess when C-M is zero.

Every live mutation uses one NSLock. Lock order is native Admission -> process ledger -> bounded allocator counters. Allocator singleton initialization happens outside the ledger. The injected reader must return one coherent active/cache snapshot; the old independent Memory getters are not sufficient. It may read OS availability but must not await, perform I/O, evaluate GPU work or call an engine/actor. External OS activity after sampling is not atomically controlled.

Headroom before commitments = max(min(max(cap - active - cache, 0), systemAvailable) - reserve, 0). Capacity checks compare sum(C-M) against this freshly sampled headroom. Checked aggregate additions refuse overflow atomically; overflowing active+cache yields zero allocatable headroom. No old-U/new-M pair can cross the ledger lock.

## Worked native trace

Exact bytes, cap180, no other usage or reserve. P includes each disjoint private physical plan before it allocates. X is disjoint native stage backing.

| Step | N | P | X | C=max(P,N)+X | M | U | Outstanding C-M |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| Initial request promise | 100 | 0 | 0 | 100 | 0 | 0 | 100 |
| Prepare A physical60 | 100 | 60 | 0 | 100 | 0 | 0 | 100 |
| Prepare B physical60 | 100 | 120 | 0 | 120 | 0 | 0 | 120 |
| Prepare stage X60 | 100 | 120 | 60 | 180 | 0 | 0 | 180 |
| Cancel unallocated A | 100 | 60 | 60 | 160 | 0 | 0 | 160 |
| B evaluated and retained | 100 | 60 | 60 | 160 | 60 | 60 | 100 |
| Stage evaluated and retained | 100 | 60 | 60 | 160 | 120 | 120 | 40 |

The three preparations may race; Native Admission serializes their complete projections and reaches C180 in any order. A new physical byte would make C181 and must refuse before local candidate metadata is inserted or allocation begins. After A cancellation, B and stage materialization leave projected usage160 and remaining20. If A had already materialized, its M withdrawal precedes alias destruction; its P remains in C until destruction, after which native recomputes current P60/X60/C160. Request completion dropping N while other children survive uses the same aggregate update, preserving their physical/stage charge.

## Validation handoff

The API agent owns all Swift/Metal/build execution. No Swift command was run in this worktree. The exact new test functions all have prefix processLedger; intended focused command is swift test --filter processLedger in the provider package using API's existing prepared dependency/build lane. A temporary Foundation-only harness is also possible if API records exact source identities, but full ProviderCore compilation must still establish module integration.

The 18 authored tests cover two-owner exact fit/+1; independent floor/nominal sums; same-backing stage adoption vs copied-source overlap; materialization at cap and policy shrink; withdrawal/alias/refund ordering; closing completion and multiple-child drain; failed publication recomputing current C rather than an obsolete baseline; policy monotonicity/reductions; invalid/stale coverage; generation-safe duplicate retirement; repeated rejection without live refund; host/OS reserve clamps; overflow; simultaneous P60/P60/X60 projections; pending model load vs native growth; and a barrier-controlled stale-U/new-M interleave.

The NativeProjection test helper is a pure accounting model, not an actual native engine or allocator. It proves the process interface's transaction ordering with caller-owned projection serialization, but does not prove native Admission integration, physical retirement, usable model capacity, or latency. Those remain mandatory subsequent gates.
