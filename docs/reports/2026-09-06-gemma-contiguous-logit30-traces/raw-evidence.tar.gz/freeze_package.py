from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parent
PACKAGE=ROOT/'package'
files={}
for path in sorted(PACKAGE.rglob('*')):
    if path.is_file() and path.name!='manifest.json' and '__pycache__' not in path.parts:
        files[str(path.relative_to(PACKAGE))]={'bytes':path.stat().st_size,'mode':path.stat().st_mode&0o777,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
# Include nested frozen-control manifests too; only the package's own manifest is self-excluded.
for path in sorted((PACKAGE/'controls').glob('*/manifest.json')):
    files[str(path.relative_to(PACKAGE))]={'bytes':path.stat().st_size,'mode':path.stat().st_mode&0o777,'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}
(PACKAGE/'manifest.json').write_text(json.dumps({'schema':3,'state':'PREPARED_PENDING_ROOT_REVIEW_AND_HARDWARE_RELEASE','runtime_payload_embedded':False,'files':files},indent=2,sort_keys=True)+'\n')
