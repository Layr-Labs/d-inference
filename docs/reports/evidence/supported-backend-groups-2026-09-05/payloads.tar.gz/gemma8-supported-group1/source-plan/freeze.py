"""Freeze the source-only plan after pure tests; never execute inference."""
import hashlib
import json
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parent
REPO=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
def digest(data): return hashlib.sha256(data).hexdigest()
plan=json.loads((ROOT/'plan.json').read_text())
proof=[]
for name in ('run_radix_engine.py','run_radix_http.py','compare_radix_engine.py','radix_engine_evidence.py'):
    relative='scripts/benchmarks/'+name
    banked=subprocess.check_output(['git','show',plan['source_commit']+':'+relative],cwd=REPO)
    frozen=(ROOT/'runner'/name).read_bytes()
    assert banked==frozen, relative
    proof.append(dict(path=relative,sha256=digest(frozen),exact_banked_source=True))
(ROOT/'banked-runner-proof.json').write_text(json.dumps(proof,indent=2,sort_keys=True)+'\n')
files={str(p.relative_to(ROOT)): {'sha256':digest(p.read_bytes()),'bytes':p.stat().st_size}
       for p in sorted(ROOT.rglob('*')) if p.is_file() and p!=ROOT/'manifest.json'}
manifest={'schema':1,'scope':'Source-only repeated matrix plan; no runtime selected and no models executed',
          'source_commit':plan['source_commit'],'original_cells':180,'pending_qat_supplement_cells':36,
          'original_unsupported_historical_contiguous_ssd_cells':18,'pending_qat_analogous_cells':9,
          'pure_test_functions_passed':8,'files':files}
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
for path, identity in files.items():
    assert digest((ROOT/path).read_bytes())==identity['sha256']
print(json.dumps({'directory':str(ROOT),'manifest_sha256':digest((ROOT/'manifest.json').read_bytes()),'payload_files':len(files)},indent=2))
