#!/usr/bin/env python3
"""Run the direct token/cache probe with dedicated-host ownership and telemetry."""

import argparse
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

from run_radix_http import ranked_job, terminate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", required=True)
    parser.add_argument("--model-directory", required=True)
    parser.add_argument("--input", required=True, help="Retained HTTP report.json")
    parser.add_argument("--output", required=True)
    parser.add_argument("--cache", choices=["on", "off"], default="on")
    parser.add_argument("--mtp", choices=["on", "off"], default="off")
    parser.add_argument("--kv-backend", choices=["auto", "paged", "contiguous"], default="auto")
    parser.add_argument("--cache-mode", choices=["ssd", "resident"], help="New harness default is SSD; resident is explicit historical reproduction")
    parser.add_argument("--key-mode", choices=["persistent", "ephemeral"], help="SSD default requires persistent KEK; ephemeral is an explicit non-restart test control")
    parser.add_argument("--startup-timeout", type=float, default=180, help="Bound model/hash/key setup before first request (seconds)")
    args = parser.parse_args()
    if args.key_mode and args.cache_mode != "ssd":
        parser.error("--key-mode requires --cache-mode ssd")
    if args.startup_timeout <= 0:
        parser.error("--startup-timeout must be positive")
    if ranked_job() or subprocess.run(["pgrep", "-x", "darkbloom"], stdout=subprocess.DEVNULL).returncode == 0:
        raise SystemExit("Dedicated host is busy")
    if os.getloadavg()[0] > 4:
        raise SystemExit("Dedicated host load exceeds 4")
    root = Path(args.output).resolve()
    root.mkdir(parents=True, exist_ok=False)
    macmon = Path.home() / "bench-runner/bin/macmon"
    raw = subprocess.check_output([str(macmon), "pipe", "-s", "1", "-i", "200"], text=True, timeout=10)
    temperature = json.loads(raw.splitlines()[0])["temp"]["gpu_temp_avg"]
    if temperature > 42:
        raise SystemExit(f"GPU entry temperature {temperature} exceeds 42 C")
    metadata = {"started_unix": time.time(), "arguments": vars(args), "entry_gpu_temp_c": temperature}
    probe = telemetry = None
    try:
        with (root / "engine.log").open("w") as log, (root / "telemetry.jsonl").open("w") as telemetry_log:
            telemetry = subprocess.Popen([str(macmon), "pipe", "-i", "100"], stdout=telemetry_log,
                                         stderr=subprocess.DEVNULL, start_new_session=True)
            command = [args.binary, args.model_directory, args.input,
                       str(root / "report.json"), "cache-" + args.cache,
                       "mtp-" + args.mtp, args.kv_backend]
            if args.cache_mode:
                command.append(args.cache_mode)
            if args.key_mode:
                command.append(args.key_mode + "-key")
            probe = subprocess.Popen(command,
                                     stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            deadline = time.monotonic() + 1800
            setup_deadline = time.monotonic() + args.startup_timeout
            setup_ready = args.cache_mode != "ssd"
            while probe.poll() is None:
                if not setup_ready:
                    setup_ready = "radix-model-ready" in (root / "engine.log").read_text(errors="replace")
                    if not setup_ready and time.monotonic() > setup_deadline:
                        raise RuntimeError("Bounded model/hash/persistent-key setup time exceeded")
                if ranked_job():
                    raise RuntimeError("Ranked job appeared; abandoning owned probe")
                if time.monotonic() > deadline:
                    raise RuntimeError("Bounded benchmark time exceeded")
                time.sleep(1)
            metadata["exit_code"] = probe.returncode
            if probe.returncode:
                raise RuntimeError("Probe failed; inspect engine.log")
    finally:
        for process in (probe, telemetry):
            terminate(process)
        metadata["ended_unix"] = time.time()
        metadata["ranked_job_at_end"] = ranked_job()
        (root / "metadata.json").write_text(json.dumps(metadata, indent=2))


if __name__ == "__main__":
    for sig in (signal.SIGTERM, signal.SIGHUP):
        signal.signal(sig, lambda signum, frame: sys.exit(128 + signum))
    main()
