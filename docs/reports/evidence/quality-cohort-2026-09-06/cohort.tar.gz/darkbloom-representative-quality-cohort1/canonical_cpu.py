"""Reuse the pinned CPU fixture exporter and sidecar; never invoke model code."""
from contextlib import contextmanager
from pathlib import Path
import http.client
import json
import os
import socket
import subprocess
import tempfile
import time

from cohort_common import digest, require

EXPORTER = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated/coordinator/promptsidecar/target/release/prompt-fixtures')
EXPORTER_SHA = '88b7439067c5a2ea8c22ce6b7435d3f512793abfa7830e6f6de496bcafb2f582'
SIDECAR = Path('/tmp/darkbloom-final-promptsidecar-build1/promptsidecar')
SIDECAR_SHA = '6a0c4498c6a3d23f85001fe1d1e0b8a502e2397858a586808e792b66e85576ea'
ARTIFACTS = Path('/tmp/darkbloom-release-090/prompt-artifacts').resolve()


def export(manifest, cases, output, log):
    require(digest(EXPORTER) == EXPORTER_SHA, 'cached fixture exporter identity differs')
    command = [str(EXPORTER), '--manifest', str(Path(manifest).resolve()), '--artifact-root', str(ARTIFACTS),
               '--cases', str(Path(cases).resolve()), '--output', str(Path(output).resolve())]
    with Path(log).open('w') as stream:
        result = subprocess.run(command, stdout=stream, stderr=subprocess.STDOUT, timeout=60)
    require(result.returncode == 0, 'CPU fixture export failed; see ' + str(log))
    require(digest(EXPORTER) == EXPORTER_SHA, 'cached exporter changed during invocation')
    return {'argv': command, 'returncode': result.returncode, 'binary_sha256': EXPORTER_SHA}


@contextmanager
def sidecar(log, receipt):
    require(digest(SIDECAR) == SIDECAR_SHA, 'canonical sidecar identity differs')
    with tempfile.TemporaryDirectory(prefix='dq-', dir='/private/tmp') as directory:
        endpoint = str(Path(directory) / 's.sock')
        command = [str(SIDECAR), '--socket', endpoint, '--artifact-root', str(ARTIFACTS),
                   '--max-loaded-contracts', '1', '--max-tokens', '32768',
                   '--memory-limit-mib', '1024', '--parent-pid', str(os.getpid())]
        receipt.update(argv=command, binary_sha256=SIDECAR_SHA)
        with Path(log).open('w') as output:
            child = subprocess.Popen(command, stdout=output, stderr=subprocess.STDOUT)
            receipt['pid'] = child.pid
            try:
                deadline = time.monotonic() + 10
                while not Path(endpoint).exists():
                    require(child.poll() is None and time.monotonic() < deadline, 'CPU sidecar did not become ready')
                    time.sleep(0.05)
                class Connection(http.client.HTTPConnection):
                    def connect(self):
                        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
                        self.sock.settimeout(30)
                        self.sock.connect(endpoint)
                def post(path, body):
                    connection = Connection('localhost', timeout=30)
                    try:
                        connection.request('POST', path, json.dumps(body, allow_nan=False), {'Content-Type': 'application/json'})
                        response = connection.getresponse()
                        data = response.read(2 << 20)
                        require(response.status == 200, 'canonical sidecar refused: ' + str(response.status))
                        return json.loads(data)
                    finally:
                        connection.close()
                yield post
            finally:
                child.terminate()
                try:
                    child.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    child.kill(); child.wait(timeout=5)
                receipt.update(exit_code=child.returncode, reaped=child.poll() is not None)
    require(digest(SIDECAR) == SIDECAR_SHA, 'canonical sidecar changed during observation')
