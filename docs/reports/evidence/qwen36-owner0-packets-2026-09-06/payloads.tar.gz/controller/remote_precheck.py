# Executed only after a JSON CONFIG preamble; this source is locally compiled first.
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import stat

root = Path(CONFIG['root']); output = Path(CONFIG['output'])
assert not output.exists(), 'Fresh output root required'
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat() == CONFIG['date'], 'Date rollover requires reviewed successor'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(root/'manifest.json') == CONFIG['plan_manifest_sha256']
assert sha(root/'runtime-binding.json') == CONFIG['binding_sha256']
binding = json.loads((root/'runtime-binding.json').read_text())
for name, row in json.loads((root/'manifest.json').read_text())['files'].items():
    p = root/name
    assert stat.S_ISREG(p.lstat().st_mode) and p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], name
artifacts = {}
for name, row in binding['artifacts'].items():
    p = root/'runtime'/name
    assert stat.S_ISREG(p.lstat().st_mode) and p.stat().st_size == row['bytes'], name
    assert oct(stat.S_IMODE(p.stat().st_mode)) == row['mode'] and sha(p) == row['sha256'], name
    if name == 'radix-engine': assert row['mode'] == '0o755' and os.access(p, os.X_OK)
    artifacts[name] = row
assert len(artifacts) == 7 and 'radix-engine' in artifacts
plan = json.loads((root/'plan.json').read_text())
cell = next(c for c in plan['cells'] if c['id'] == CONFIG['cell'])
assert cell['argv'] == CONFIG['argv']
free = shutil.disk_usage(root).free
assert free >= plan['guards']['minimum_free_bytes']
print(json.dumps({'fresh_output_root':True,'date':CONFIG['date'],'free_bytes':free,'artifacts':artifacts,'cell':cell['id']}))
