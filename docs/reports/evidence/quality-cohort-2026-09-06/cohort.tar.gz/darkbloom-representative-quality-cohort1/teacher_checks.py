"""Verbatim existing teacher validators/comparator; no numerical tolerance added."""
import math
from pathlib import Path
import struct
from cohort_common import require


def finite_number(value, minimum=0, maximum=None):
    return type(value) in (int, float) and math.isfinite(value) and value >= minimum and (maximum is None or value <= maximum)


def report_checks(report, model, cell, binding, input_value, snapshot, plan):
    runtime = binding['runtime']['files']
    require(report['schema'] == 1 and report['scope'] == 'ordinary_teacher_forced_scores', 'teacher report schema/scope differs')
    require(report['status'] == 'observed' and report['inconclusiveReasons'] == [], 'teacher controls did not pass')
    require(report['input'] == input_value and report['inputSHA256'] == model['input_sha256'], 'teacher input differs')
    require(report['verifiedModelAggregateSHA256'] == model['model_sha256'], 'verified model aggregate differs')
    require(report['executableSHA256'] == runtime['darkbloom']['sha256'] and report['metallibSHA256'] == runtime['mlx.metallib']['sha256'], 'reported runtime differs')
    require(Path(report['modelDirectory']).resolve(strict=True) == snapshot.resolve(strict=True), 'reported model directory differs')
    require(report['resolvedBackend'] == cell['backend'] and report['cacheMode'] == 'off' and report['mtpEnabled'] is False and report['concurrency'] == 1, 'ordinary target scoring posture differs')
    require(report['gemmaOptimizations'] == plan['gemma_optimizations'], 'Gemma serving profile differs')
    grant = report['productionGrant']
    require(grant['slotCount'] == 1 and grant['assistantWeightBytes'] == 0 and grant['ramPrefixAllowanceBytes'] == 0, 'production grant posture differs')
    require(type(grant['grantBytes']) is int and grant['grantBytes'] == report['kvCapacityBytes'] > 0, 'production capacity differs')
    diagnostic = report['diagnostic']
    require(diagnostic == report['repeatedDiagnostic'] and report['plainTop1'] == diagnostic['top1'], 'plain/diagnostic/repeat output differs')
    count = model['continuation_tokens']
    require(len(report['plainTop1']) == len(diagnostic['records']) == count, 'incomplete scoring sequence')
    activity = report['activity']
    require(len(activity) == 3 and activity[0] == activity[1] == activity[2], 'three identical control activities required')
    require(type(activity[0]['prefillChunks']) is int and activity[0]['prefillChunks'] > 0 and activity[0]['decodeForwards'] == count - 1, 'extra/missing model forwards')
    for index, record in enumerate(diagnostic['records']):
        require(record['index'] == index and record['contextLength'] == model['prompt_tokens'] + index and record['forcedToken'] == input_value['continuation'][index], 'score record context differs')
        require(record['argMaxID'] == report['plainTop1'][index] and record['nanCount'] == record['infiniteCount'] == 0, 'invalid score IDs or nonfinite counts')
        bits = [record[key] for key in ('argMaxValueBits', 'forcedTokenValueBits', 'logSumExpBits', 'forcedLogProbabilityBits', 'nllBits', 'topTwoMarginBits')] + record['topTwoValueBits']
        require(all(type(value) is int and 0 <= value <= 0xffffffff and math.isfinite(struct.unpack('!f', struct.pack('!I', value))[0]) for value in bits), 'nonfinite score bits')
    require(finite_number(report['meanForcedTokenNLL'], -1e30, 1e30), 'finite mean NLL required')


def float32(bits):
    return struct.unpack('!f', struct.pack('!I', bits))[0]


def compare_reports(model, input_value, contiguous, paged):
    reports = {'contiguous': contiguous, 'paged': paged}
    for backend, report in reports.items():
        require(report['input'] == input_value and report['inputSHA256'] == model['input_sha256'], 'backend forced input differs')
        require(report['resolvedBackend'] == backend, 'backend identity differs')
        require(len(report['diagnostic']['records']) == model['continuation_tokens'], 'backend record count differs')
    rows = []
    for index, forced in enumerate(input_value['continuation']):
        left, right = (reports[backend]['diagnostic']['records'][index] for backend in ('contiguous', 'paged'))
        expected = (index, model['prompt_tokens'] + index, forced)
        for record in (left, right):
            require(tuple(record[key] for key in ('index', 'contextLength', 'forcedToken')) == expected, 'backend forced context differs')
        rows.append({'index': index, 'contextLength': expected[1], 'forcedToken': forced,
                     'contiguous_argmax': left['argMaxID'], 'paged_argmax': right['argMaxID'],
                     'argmax_equal': left['argMaxID'] == right['argMaxID'], 'complete_record_equal': left == right,
                     'contiguous_nll_bits': left['nllBits'], 'paged_nll_bits': right['nllBits'],
                     'paged_minus_contiguous_nll': float32(right['nllBits']) - float32(left['nllBits']),
                     'contiguous_forced_log_probability_bits': left['forcedLogProbabilityBits'],
                     'paged_forced_log_probability_bits': right['forcedLogProbabilityBits'],
                     'paged_minus_contiguous_forced_log_probability': float32(right['forcedLogProbabilityBits']) - float32(left['forcedLogProbabilityBits'])})
    return {'model_id': model['model_id'], 'input_sha256': model['input_sha256'],
            'prompt_tokens': model['prompt_tokens'], 'continuation_tokens': model['continuation_tokens'],
            'same_forced_contexts': True, 'argmax_mismatch_indices': [row['index'] for row in rows if not row['argmax_equal']],
            'complete_record_equal_count': sum(row['complete_record_equal'] for row in rows),
            'mean_forced_token_nll': {backend: report['meanForcedTokenNLL'] for backend, report in reports.items()},
            'control_activity': {backend: report['activity'] for backend, report in reports.items()},
            'records': rows}
