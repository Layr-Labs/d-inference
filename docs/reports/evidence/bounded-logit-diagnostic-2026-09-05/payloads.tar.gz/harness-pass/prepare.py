from pathlib import Path
import hashlib,json,shutil

out=Path('/tmp/darkbloom-q36-diagnostic-harness-validation1')
base=Path('/tmp/darkbloom-final-serving-build6')
source=Path('/tmp/darkbloom-q36-logit-diagnostic-source/freeze2')
provider=Path('/tmp/darkbloom-receipt-diagnostic-provider-validation1/candidate')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for root,digest in [(base,'802f51029f30a4e7d7fcdc3dc898aac83bb0edb55939dd88468ab81a6baf8817'),(source,'2c6a6abd0c32c5544c8ea10f74f085ad10865b5238209901cbee6d612f49cab2')]:
 assert sha(root/'manifest.json')==digest
 for name,row in json.loads((root/'manifest.json').read_text())['files'].items():assert sha(root/name)==row['sha256'],name
shutil.copytree(base/'radix-engine',out/'radix-engine')
manifest=json.loads((base/'compile-source-manifest.json').read_text())
changes=json.loads((source/'source-proof.json').read_text())['harness']['files']
for name,row in changes.items():
 local=name.removeprefix('scripts/benchmarks/');p=out/local
 if row['before_sha256'] is not None:assert sha(p)==row['before_sha256'],name
 else:assert not p.exists(),name
 shutil.copy2(source/'files/harness'/name,p)
 manifest['files'][local]={'sha256':sha(p),'bytes':p.stat().st_size}
for name,row in manifest['files'].items():assert sha(out/name)==row['sha256'],name
(out/'compile-source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(out/'integration.json').write_text(json.dumps({'source_manifest':str(source/'manifest.json'),'source_sha256':sha(source/'manifest.json'),'provider_candidate_workspace':str(provider/'workspace'),'provider_candidate_manifest':str(provider/'provider-source-manifest.json'),'provider_candidate_sha256':sha(provider/'provider-source-manifest.json'),'harness_inputs':len(manifest['files']),'scratch':'/tmp/darkbloom-process-memory-telemetry-swift-validation1/build','environment':{'RADIX_SOURCE_ROOT':str(provider/'workspace'),'RADIX_CANDIDATE_BUILD':'1'},'status':'prepared only; run after reviewed provider baseline/candidate tests','wrapper_manifest':'/tmp/darkbloom-logit-wrapper-forwarding1/manifest.json','wrapper_independent_review':'/tmp/darkbloom-logit-wrapper-independent-review1/review.json'},indent=2)+'\n')
print('Prepared exact14-input harness package; no build started.')
