from pathlib import Path
import argparse
import gzip
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

OUT = Path('/tmp/darkbloom-provider-cancel-settlement-validation2')
SCRATCH = Path('/tmp/darkbloom-process-memory-telemetry-swift-validation1/build')
NATIVE = OUT / 'native'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def verify(variant):
    workspace = OUT / variant / 'workspace'
    provider = json.loads((OUT / variant / 'provider-source-manifest.json').read_text())
    actual = {'provider-swift/' + str(p.relative_to(workspace / 'provider-swift'))
              for p in (workspace / 'provider-swift').rglob('*')
              if p.is_file() and '.swiftpm' not in p.parts and '.build' not in p.parts}
    assert actual == set(provider['files']), ('provider source membership', variant)
    for name, digest in provider['files'].items():
        assert sha(workspace / name) == digest, (variant, name)
    native = json.loads((OUT / 'native-source-manifest.json').read_text())
    for name, digest in native['files'].items():
        assert sha(NATIVE / name) == digest, name
    deps = json.loads((OUT / 'dependency-source-manifest.json').read_text())
    for name, digest in deps['files'].items():
        alias, relative = name.split('/', 1)
        assert sha(Path(deps['repositories'][alias]) / relative) == digest, name
    jinja = json.loads((OUT / 'jinja-source-manifest.json').read_text())
    for name, digest in jinja['files'].items():
        assert sha(SCRATCH / 'checkouts/swift-jinja' / name) == digest, name
    return {'provider': len(provider['files']), 'native': len(native['files']),
            'dependencies': len(deps['files']), 'jinja': len(jinja['files']),
            'no_source_or_pin_drift': True}


def graph(phase, label):
    for name in ['debug.yaml', 'workspace-state.json']:
        path = SCRATCH / name
        if path.exists():
            data = path.read_bytes()
            suffix = '.gz' if name.endswith('yaml') else ''
            (phase / (label + '-' + name + suffix)).write_bytes(
                gzip.compress(data, mtime=0) if suffix else data)


def run(phase, name, argv, records, is_test=False):
    path = phase / (name + '.log')
    assert not path.exists(), ('preserve every prior run', path)
    started = time.monotonic()
    with path.open('w') as log:
        process = subprocess.run(argv, cwd=phase / 'workspace/provider-swift',
                                 stdout=log, stderr=subprocess.STDOUT)
    body = path.read_text()
    nonzero = bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test', body))
    skipped = bool(re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test', body, re.M))
    result = {'name': name, 'argv': argv, 'cwd': str(phase / 'workspace/provider-swift'),
              'exit_code': process.returncode, 'seconds': time.monotonic() - started,
              'nonzero_no_skips': not is_test or nonzero and not skipped,
              'log_sha256': sha(path)}
    records.append(result)
    write(phase / 'executions.json', records)
    print(json.dumps(result), flush=True)
    return result, body


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--phase', choices=['baseline', 'candidate'], required=True)
    parser.add_argument('--execute-after-lane-handoff', action='store_true', required=True)
    args = parser.parse_args()
    phase = OUT / args.phase
    assert not (phase / 'executions.json').exists(), 'Never overwrite a previous run'
    records = []
    write(phase / 'source-verified-before.json', verify(args.phase))
    write(phase / 'execution-environment.json', {k: os.environ[k] for k in [
        'DARKBLOOM_CBV2_MTP', 'DARKBLOOM_CBV2_COMPILED_DECODE', 'MLX_METALLIB_PATH'
    ] if k in os.environ})
    result, _ = run(phase, 'build', ['swift', 'build', '--scratch-path', str(SCRATCH),
        '--build-tests', '--jobs', '4', '--disable-automatic-resolution'], records)
    graph(phase, 'actual-build')
    write(phase / 'source-verified-postcompile.json', verify(args.phase))
    if result['exit_code']:
        write(phase / 'verdict.json', {'status': 'BUILD_FAILED', 'exit_code': result['exit_code']})
        raise SystemExit(result['exit_code'])
    debug = (SCRATCH / 'debug.yaml').read_text()
    expected = json.loads((OUT / 'source-correspondence.json').read_text())['changed_files']
    paths = [phase / 'workspace' / row['path'] for row in expected if row['variant'] == args.phase]
    paths += [NATIVE / 'Libraries/MLXLMCommon/ContinuousBatchingV2/EngineV2.swift',
              NATIVE / 'Libraries/MLXLMCommon/ContinuousBatchingV2/CBv2LogitDiagnostic.swift']
    proof = []
    for path in paths:
        aliases = [str(path), str(path.resolve()), str(path).replace('/tmp/', '/private/tmp/', 1)]
        actual = next((value for value in aliases if value in debug), None)
        assert actual, ('compiler source missing', path)
        proof.append({'path': actual, 'sha256': sha(path)})
    assert '/checkouts/mlx-swift/Source/' not in debug
    assert '/q36-attention-metadata-diagnostic/' not in debug
    write(phase / 'actual-compiler-source-proof.json', {'paths': proof,
        'native_base': '5cb848dfdaae04118ecfa901f53fc21a4aa86a06',
        'remote_mlx_and_new_metadata_native_excluded': True})
    built = SCRATCH / 'arm64-apple-macosx/debug'
    bundle = built / 'DarkbloomProviderPackageTests.xctest/Contents/MacOS'
    binary = bundle / 'DarkbloomProviderPackageTests'
    lib = Path('/tmp/darkbloom-final-serving-build8/artifact/mlx.metallib')
    assert sha(lib) == '4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0'
    for target in [built / 'mlx.metallib', bundle / 'mlx.metallib']:
        shutil.copy2(lib, target)
        assert sha(target) == sha(lib)
    write(phase / 'test-binary.json', {'path': str(binary), 'bytes': binary.stat().st_size,
        'sha256': sha(binary), 'metallib_sha256': sha(lib)})
    run(phase, 'identifiers', ['swift', 'test', 'list', '--skip-build', '--scratch-path',
        str(SCRATCH), '--disable-automatic-resolution'], records)
    filters = ['ProviderCancelledPrefixCacheTests']
    if args.phase == 'candidate':
        filters += ['CancelledSettlementLifecycleTests', 'EngineProfileCancelTests',
            'cancelledUsage', 'EngineV2CancellationTests', 'EngineV2ShutdownTests',
            'EngineV2EventFramingTests', 'EngineV2ErrorMappingTests',
            'EngineV2BridgePumpReceiptTests', 'EngineV2LookupReceiptCoverageTests',
            'OuterPrefixCacheReceiptTests', 'EngineV2SharedBudgetTests',
            'RetirementGateTests', 'EngineV2LivenessVerdictTests',
            'EngineV2LivenessRecoveryTests']
    write(phase / 'filters.json', filters)
    bodies = []
    for name in filters:
        result, body = run(phase, name, ['swift', 'test', '--skip-build', '--scratch-path',
            str(SCRATCH), '--disable-automatic-resolution', '--filter', name], records, is_test=True)
        bodies.append(body)
        if args.phase == 'candidate' and (result['exit_code'] or not result['nonzero_no_skips']):
            break
    write(phase / 'source-verified-after.json', verify(args.phase))
    graph(phase, 'actual-after')
    failed = [row['name'] for row in records if row['exit_code'] or not row['nonzero_no_skips']]
    if args.phase == 'baseline':
        body = bodies[0]
        reproduced = failed == ['ProviderCancelledPrefixCacheTests'] and 'provider_terminal' in body and 'settlement_wait' in body and 'Expectation failed' in body
        verdict = {'status': 'ORDERING_FAILURE_REPRODUCED_REVIEW_RAW_BEFORE_CANDIDATE' if reproduced else 'UNEXPECTED_BASELINE_RESULT',
                   'failed': failed, 'raw_review_required': 'Both hit and cold argument cases must fail only expected ordering/cache fields; native adoption assertions must pass.'}
        success = reproduced
    else:
        success = not failed and len(bodies) == len(filters)
        verdict = {'status': 'PASS' if success else 'FAIL', 'failed': failed,
                   'filters_completed': len(bodies), 'filters_planned': len(filters)}
    write(phase / 'verdict.json', verdict)
    print(json.dumps(verdict), flush=True)
    raise SystemExit(0 if success else 1)


if __name__ == '__main__':
    main()
