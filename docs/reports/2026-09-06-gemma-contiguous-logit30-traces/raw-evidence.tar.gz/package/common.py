from pathlib import Path
import hashlib
import json
import re
import stat
import sys
import time

ROOT = Path(__file__).resolve().parent
MANDATORY = {'input.json', 'report.json', 'native-argv.json', 'environment.json', 'preflight.json',
             'postflight.json', 'terminal.json', 'metadata.json', 'summary.json', 'engine.log', 'telemetry.jsonl'}

def require(condition, message):
    if not condition:
        raise ValueError(message)

def read_json(path, limit=32 << 20):
    with Path(path).open('rb') as stream:
        raw = stream.read(limit + 1)
    require(len(raw) <= limit, 'JSON exceeds byte limit')
    return json.loads(raw, parse_constant=lambda value: (_ for _ in ()).throw(ValueError('nonfinite JSON: ' + value)))

def write_json(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
    temporary.replace(path)

def digest(path, deadline=None):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            require(deadline is None or time.monotonic() < deadline, 'hash deadline expired')
            result.update(chunk)
    return result.hexdigest()

def safe_file(root, name):
    path = Path(name)
    require(not path.is_absolute() and path.parts and '..' not in path.parts and str(path) == name,
            'invalid relative file path')
    candidate = Path(root) / path
    require(candidate.resolve().is_relative_to(Path(root).resolve()), 'file escapes root')
    return candidate

def file_record(path, deadline=None):
    path = Path(path)
    before = path.lstat()
    require(stat.S_ISREG(before.st_mode) and not path.is_symlink(), 'regular file required: ' + str(path))
    value = {'bytes': before.st_size, 'mode': stat.S_IMODE(before.st_mode), 'sha256': digest(path, deadline)}
    after = path.lstat()
    require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns, before.st_mode)
            == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns, after.st_mode), 'file changed while hashing')
    return value

def check_file(path, expected, deadline=None):
    require(type(expected.get('bytes')) is int and expected['bytes'] >= 0
            and type(expected.get('mode')) is int and bool(re.fullmatch('[0-9a-f]{64}', expected.get('sha256', ''))),
            'invalid file identity')
    observed = file_record(path, deadline)
    require(all(observed[key] == expected[key] for key in observed), 'file identity differs: ' + str(path))
    return observed

def validate_prompt_dates(binding, root=ROOT):
    requests = read_json(root / 'inputs/input.json')['rows']
    references = read_json(root / 'inputs/reference-prompt-ids.json')['rows']
    require(len(requests) == len(references) == 2
            and all(row['request'].get('_darkbloom_prompt_date') == binding['prompt_date'] for row in requests)
            and all(row.get('prompt_render_date') == binding['prompt_date'] for row in references),
            'prepared input or reference prompt date differs from binding')

def runtime_directory(binding, local=False):
    path = Path(binding['local_runtime_source'] if local else binding['runtime_root'])
    require(path.is_absolute() and '..' not in path.parts and path.is_dir() and not path.is_symlink(),
            'bound canonical runtime directory required')
    require(all(not child.is_symlink() for child in path.rglob('*')), 'runtime symlink refused')
    return path

def verify_package(expected_sha, root=ROOT, local=False):
    require(bool(re.fullmatch('[0-9a-f]{64}', expected_sha)), 'manifest digest required')
    require(digest(root / 'manifest.json') == expected_sha, 'controller manifest differs')
    manifest = read_json(root / 'manifest.json')
    require(type(manifest.get('files')) is dict and len(manifest['files']) >= 15, 'incomplete package manifest')
    deadline = time.monotonic() + 60
    for name, row in manifest['files'].items():
        check_file(safe_file(root, name), row, deadline)
    binding = read_json(root / 'binding.json')
    limits = binding['limits']
    for name, maximum in [('native_seconds', 1800), ('startup_seconds', 240), ('lease_seconds', 30),
                          ('hash_seconds', 150), ('control_seconds', 2400)]:
        require(type(limits[name]) is int and 0 < limits[name] <= maximum, 'invalid finite deadline: ' + name)
    require(len(binding['cells']) == 2 and len({cell['id'] for cell in binding['cells']}) == 2, 'wrong cell inventory')
    require([(cell['backend'], cell['mode']) for cell in binding['cells']] == [('contiguous', 'off'), ('contiguous', 'automatic')], 'wrong two-trace order')
    require(binding['state'] in ['awaiting_root_review_and_hardware_release', 'peer_reviewed'], 'unknown review state')
    plan = read_json(root / 'trace-plan.json')
    require(digest(root / 'trace-plan.json') == binding['trace_plan_sha256']
            and binding['runtime_root'] == plan['artifact_reused_from']
            and binding['root'] == plan['proposed_remote_root']
            and binding['runtime'] == plan['runtime']
            and binding['profile'] == plan['profile'], 'original trace plan binding differs')
    require(all(re.fullmatch('[a-z0-9-]+', cell['id']) for cell in binding['cells']), 'invalid cell identity')
    profile = read_json(root / 'profile.json')
    require(profile == binding['profile'] and len(profile) == 7
            and profile['MLX_GATHER_QMM_EXPERT_SLICES'] == 'trust', 'wrong serving profile')
    review = read_json(root / 'runtime-root-review.json')
    required_runtime = {'darkbloom', 'radix-engine', 'mlx.metallib',
        'mlx-swift-lm_MLXLMCommon.bundle/pagedattention.metal',
        'swift-crypto_Crypto.bundle/PrivacyInfo.xcprivacy', 'swift-nio_NIOPosix.bundle/PrivacyInfo.xcprivacy',
        'swift-transformers_Hub.bundle/gpt2_tokenizer_config.json', 'swift-transformers_Hub.bundle/t5_tokenizer_config.json'}
    runtime = read_json(root / 'runtime-manifest.json')
    require(digest(root / 'runtime-root-review.json') == binding['runtime_review_sha256']
            and binding['runtime_review_sha256'] == '3e5d473d1a37e4a8b4e9f8070fb707521843d4d505617f978f937f114afbf449'
            and review['status'] == 'accepted_for_corrected_normal_generation_model_validation'
            and review['artifact_manifest_sha256'] == digest(root / 'runtime-manifest.json')
            and review['source'] == runtime['source'] and review['runtime_files_verified'] == 8
            and set(runtime['files']) == required_runtime
            and runtime == binding['runtime'], 'unreviewed runtime binding')
    handoff = read_json(root / 'runtime-handoff.json')
    require(digest(root / 'runtime-handoff.json') == binding['runtime_handoff_sha256']
            and handoff['source'] == runtime['source']
            and handoff['artifact_manifest_sha256'] == review['artifact_manifest_sha256'], 'runtime handoff differs')
    runtime_root = runtime_directory(binding, local=local)
    actual = {str(path.relative_to(runtime_root)) for path in runtime_root.rglob('*') if path.is_file() or path.is_symlink()}
    require(actual == set(runtime['files']), 'incomplete or extra runtime file')
    for name, row in runtime['files'].items():
        check_file(safe_file(runtime_root, name), row, deadline)
    require(digest(root / 'inputs/input.json') == binding['input_sha256'], 'input bytes differ')
    validate_prompt_dates(binding, root)
    sys.path.insert(0, str(root / 'runner'))
    from run_radix_engine import arguments, probe_command
    for cell in binding['cells']:
        require(cell['backend'] in ['contiguous', 'paged'] and cell['mode'] in ['off', 'automatic', 'serial_target'], 'invalid mode')
        options = arguments(cell['wrapper_arguments'])
        require(options.binary == binding['runtime_root'] + '/radix-engine'
                and options.model_directory == binding['model']['directory']
                and options.assistant_directory == binding['assistant']['directory']
                and options.input == binding['root'] + '/inputs/input.json'
                and options.output == binding['root'] + '/runs/' + cell['id']
                and options.mtp == ('off' if cell['mode'] == 'off' else 'on')
                and options.cache == 'off' and options.cache_mode == 'ssd' and options.key_mode == 'ephemeral'
                and options.concurrency == 1 and options.production_kv_grant and options.kv_budget_gib is None
                and options.expected_model_sha256 == binding['model']['aggregate_sha256']
                and options.kv_backend == cell['backend'] and options.prompt_date == binding['prompt_date']
                and options.gemma_mtp_verification == (None if cell['mode'] == 'off' else cell['mode'])
                and cell['projection'] is False and cell['trace'] is True
                and options.gemma_projection_tokens is None
                and options.logit_diagnostic_position == 30 and options.logit_diagnostic_candidates == '795,735'
                and options.attention_metadata_position is None
                and options.attention_packet_position is None and options.cache_directory is None,
                'cell leaves its bound serving scope')
        options.input = binding['root'] + '/runs/' + cell['id'] + '/input.json'
        require(probe_command(options, binding['root'] + '/runs/' + cell['id'] + '/report.json') == cell['native_argv'],
                'native argv differs from validated wrapper command')
    require(digest(root / 'frozen-control-results-manifest.json') == binding['baseline']['frozen_results_manifest_sha256'], 'frozen controls manifest differs')
    for cell in binding['cells']:
        control = root / cell['control_relative']
        require(digest(control / 'manifest.json') == binding['baseline']['controls'][cell['mode']]['original_manifest_sha256'], 'frozen control manifest differs')
        require(digest(control / 'report.json') == cell['control_report_sha256'], 'frozen control report differs')
        for name, row in read_json(control / 'manifest.json')['files'].items():
            check_file(safe_file(control, name), row, deadline)
        report = read_json(control / 'report.json')
        require(len(report['rows']) == 2 and all(row['prefill_chunks'] == 3 and row['prefill_chunk_tokens_max'] == 2048 for row in report['rows']), 'frozen three-chunk geometry differs')
    return binding

def result_inventory(root, limits):
    files = {}
    total = 0
    for path in sorted(Path(root).rglob('*')):
        name = str(path.relative_to(root))
        if name == 'manifest.json' or name.startswith('prefix-cache/'):
            continue
        if path.is_symlink():
            raise ValueError('symlink in result inventory')
        if path.is_file():
            require(bool(re.fullmatch('[A-Za-z0-9_./-]+', name)), 'unsafe result filename')
            require(path.stat().st_size <= limits['max_file_bytes'], 'result file exceeds limit')
            files[name] = file_record(path)
            total += files[name]['bytes']
            require(total <= limits['max_result_bytes'], 'result inventory exceeds limit')
    return files
