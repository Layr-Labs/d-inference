"""Run the banked strict evaluator without editing a frozen raw pair."""

from pathlib import Path
import hashlib
import json
import subprocess
import sys

commit = '437bea4fe89100d8b6773c1039e398f52a5569dc'
repo = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
baseline, candidate, output = map(Path, sys.argv[1:])
output.mkdir(parents=True, exist_ok=False)
for name in ('compare_radix_engine.py', 'radix_engine_evidence.py'):
    source = subprocess.check_output(['git', 'show', commit + ':scripts/benchmarks/' + name], cwd=repo)
    (output / name).write_bytes(source)
command = ['python3', str(output / 'compare_radix_engine.py'), str(baseline / 'report.json'),
           str(candidate / 'report.json'), '--expect-cache-hits']
result = subprocess.run(command, text=True, capture_output=True)
(output / 'verdict.json').write_text(result.stdout)
(output / 'stderr.txt').write_text(result.stderr)
(output / 'command.json').write_text(json.dumps({'command': command, 'exit_code': result.returncode,
    'evaluator_commit': commit, 'scope': 'One existing B1 pair; original raw reports and historical verdict unchanged.'}, indent=2) + '\n')
files = sorted(path for path in output.iterdir() if path.is_file())
files += [baseline / 'report.json', candidate / 'report.json', Path(__file__)]
manifest = {'files': {str(path): {'bytes': path.stat().st_size,
    'sha256': hashlib.sha256(path.read_bytes()).hexdigest()} for path in files}}
(output / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(result.stdout)
print('manifest_sha256', hashlib.sha256((output / 'manifest.json').read_bytes()).hexdigest())
