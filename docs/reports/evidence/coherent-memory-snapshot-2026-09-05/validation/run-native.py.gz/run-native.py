from pathlib import Path
import json,os,re,subprocess,time
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/mlx-coherent-memory-snapshot')
out=Path('/tmp/darkbloom-mlx-memory-snapshot-validation1')
commands=[]
for backend,metal in [('metal','ON'),('cpu','OFF')]:
 build=out/('build-'+backend)
 commands.append((backend+'-configure',['cmake','-S',str(out/'project'),'-B',str(build),'-G','Ninja','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_OSX_DEPLOYMENT_TARGET=14.0','-DMLX_BUILD_METAL='+metal,'-DMLX_BUILD_CPU=ON','-DMLX_BUILD_CUDA=OFF','-DFETCHCONTENT_SOURCE_DIR_METAL_CPP='+str(root/'Source/Cmlx/metal-cpp')]))
 commands.append((backend+'-build',['cmake','--build',str(build),'--target','snapshot_tests','--parallel','4']))
 for name,test in [('coherence','test coherent memory snapshot during cache transfers'),('no-stream-wait','test memory snapshot does not wait for stream work')]:
  commands.append((backend+'-'+name,[str(build/'snapshot_tests'),'--test-case='+test,'--no-skip=true']))
results=[]
for name,command in commands:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log: result=subprocess.run(command,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 text=(out/(name+'.log')).read_text()
 valid=True
 if name.endswith('coherence') or name.endswith('no-stream-wait'): valid=bool(re.search(r'test cases:\s+1\s+\|\s+1 passed\s+\|\s+0 failed',text))
 entry={'name':name,'command':command,'cwd':str(root),'exit_code':result.returncode,'seconds':time.monotonic()-start,'selected_count_verified':valid}
 results.append(entry);(out/'execution.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps({k:v for k,v in entry.items() if k not in ['command','cwd']}),flush=True)
 if result.returncode or not valid: raise SystemExit(result.returncode or 1)
