from pathlib import Path
import hashlib,json,os,statistics,subprocess,time
O=Path(__file__).resolve().parent;B=O/'artifact/BenchSegmentedDecode'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def dump(n,j):(O/n).write_text(json.dumps(j,indent=2)+'\n')
assert not (O/'smokes.json').exists()and not (O/'measurement.json').exists()
for name,row in json.loads((O/'artifact-manifest.json').read_text())['files'].items():
 p=O/'artifact'/name;assert sha(p)==row['sha256']and p.stat().st_size==row['bytes']and p.stat().st_mode&0o777==int(row['mode'],8)
smokes=[]
for index,(args,code)in enumerate([(['--help'],0),(['--owners','0'],1),(['--owners','11'],1),(['--offset','8193'],1),(['--offset','1'],1),(['--steps','129'],1),(['--repetitions','4'],1),(['--warmup','0'],1),(['--unknown','1'],1),(['--owners','2','--owners','3'],1),(['--steps'],1)]):
 r=subprocess.run([str(B)]+args,capture_output=True,text=True,timeout=30)
 (O/f'smoke{index}.stdout').write_text(r.stdout);(O/f'smoke{index}.stderr').write_text(r.stderr)
 smokes.append({'args':args,'exit_code':r.returncode,'expected':code});dump('smokes.json',smokes);assert r.returncode==code
# Production defaults, including PTOK, must be visible in this bounded run.
dump('measurement-environment.json',{'load_before':os.getloadavg(),'settings':{k:v for k,v in os.environ.items()if k.startswith(('DARKBLOOM_','MLX_'))},'time':time.time()})
assert 'DARKBLOOM_CBV2_PAGED_PTOK_TARGET'not in os.environ
start=time.monotonic()
with (O/'measurement.json').open('x')as out,(O/'measurement.stderr').open('x')as err:
 r=subprocess.run([str(B)],stdout=out,stderr=err,timeout=180)
dump('measurement-execution.json',{'exit_code':r.returncode,'seconds':time.monotonic()-start,'command':[str(B)],'binary_sha256':sha(B),'load_after':os.getloadavg()})
assert r.returncode==0
report=json.loads((O/'measurement.json').read_text());assert report['allOutputAndFullHistoryDigestsEqual']is True
arms=report['arms'];assert len(arms)==6
for arm in arms:
 assert len(arm['steps'])==64 and arm['residentOwners']==10
 assert len(arm['fullHistoryKeySHA256'])==len(arm['fullHistoryValueSHA256'])==10
 assert len(arm['outputSHA256'])==64 and all(len(row)==10 for row in arm['outputSHA256'])
 assert all(s['bypasses']==0 and s['hits']+s['rebuilds']==64 for s in arm['counts'])
for rep in range(3):
 pair=[a for a in arms if a['repetition']==rep];assert len(pair)==2
 for k in ['outputSHA256','fullHistoryKeySHA256','fullHistoryValueSHA256']:assert pair[0][k]==pair[1][k],k
summary=[]
for arm in arms:
 counts=arm['counts'];steps=arm['steps'];n=len(steps)
 summary.append({'repetition':arm['repetition'],'mode':arm['mode'],'resolved_segments':len(arm['segments']),'resident_owners':arm['residentOwners'],'hits':sum(s['hits']for s in counts),'rebuilds':sum(s['rebuilds']for s in counts),'key_ms_per_step':sum(s['keyNanoseconds']for s in counts)/1e6/n,'preparation_ms_per_step':sum(s['preparationNanoseconds']for s in counts)/1e6/n,**{k:{'mean':statistics.mean(s[k]for s in steps),'median':statistics.median(s[k]for s in steps),'min':min(s[k]for s in steps),'max':max(s[k]for s in steps)}for k in ['hostConstructionMs','fencedEvaluationMs','wholeStepMs']}})
dump('measurement-summary.json',{'scope':report['scope'],'timingDefinition':report['timingDefinition'],'allOutputAndFullHistoryDigestsEqual':True,'arms':summary})
print(json.dumps({'smokes':len(smokes),'measurements':'PASS','arms':summary},indent=2),flush=True)
