# Representative public quality coverage cohort

This package contains **12 logical cases for six exact fleet artifacts**: 72
serving inputs, 72 teacher inputs and 72 canonical token records. All were
generated and validated on CPU. No model, GPU, Swift build, weight download,
remote host, dev or production operation was performed. **No quality pass is
claimed.** Runtime bindings remain empty for ROOT review.

## Corpus and deterministic selection

| Domain | Source | Frozen revision and license |
| --- | --- | --- |
| Prose | Project Gutenberg ebook 11, *Alice's Adventures in Wonderland*; ebook 35, *The Time Machine* | Catalog status: public domain in the USA. Exact downloaded text hashes, HTTP metadata and original notices are retained. |
| Code | CPython `Lib/functools.py` and `Lib/fractions.py` | `v3.12.0`, commit `0fb18b02c8ad56299d6a2910be0bab8ad601ef24`; PSF license and historical notices retained. |
| Reasoning | GSM8K test split, target rows 528 and 1303 (zero-based) | Commit `3101c7d5072418e28b9008a6636bde82a006892c`; MIT license retained. |

`source-lock.json` binds every source byte and primary URL. The public downloads
total 1,225,726 bytes. `selection-before-download.json` records the seed and code
selection before retrieval. Sources/windows/examples are selected by SHA256
ranking with the fixed seed `darkbloom-representative-quality-v1-2026-09-06`;
no model output informs selection. `corpus_cases.py` rebuilds `cases.json`
deterministically from the locked sources.

Each of the six underlying targets has short and long context variants with the
same reference continuation. Prose/code use contiguous source windows; long
reasoning uses 48 disjoint worked examples and short reasoning uses two. Target
questions/answers are excluded from demonstrations. This custom two-target
reasoning protocol is **not an official GSM8K score**. The sample provides domain
and context coverage, not a population-level quality estimate.

`holdout.json` inventories the retained/sustained local tuning inputs and the two
old teacher inputs. New corpus text shares no normalized 128-character span with
the listed tuning prompt text, and the new Q36/GemmaQAT4 prompts and reference
spans differ from the retained teacher fixtures. This establishes separation from
**those listed local fixtures only**. Training-data overlap is unknown; no claim
is made that these public texts were excluded from any model's training data or
every prior experiment.

## Actual token and cap verification

| Artifact | Six short prompts | Six long prompts |
| --- | ---: | ---: |
| Q36 | 330–539 | 5,716–8,956 |
| Q35 | 330–539 | 5,716–8,956 |
| Q38 | 330–539 | 5,716–8,956 |
| GPT20B | 346–574 | 5,486–7,681 |
| Gemma8 | 324–543 | 5,619–8,856 |
| GemmaQAT4 | 324–543 | 5,619–8,856 |

`fleet.json` retains all six exact model IDs, aggregate hashes, prompt contracts,
vocabulary/context declarations and normal MTP/assistant settings. The loader
recomputes contract digests and verifies their artifacts against the fleet
manifests. `token-counts.csv` contains every case's counts and file fingerprints.

Teacher inputs use the existing four-field `TeacherForcedBenchmarkInput` schema
with exactly **64 reference tokens**, below its 256-token continuation bound.
Serving inputs use the existing two-row first/repeat benchmark format, with
**128 output tokens for prose/code and 256 for reasoning**. Every token lies in
the declared vocabulary, and each context plus cap fits its declared context
limit. These are static checks, not physical admission clearance. Gemma8 remains
prohibited on M3.

The cached fixture exporter (`88b74390…`) emits literal token IDs. The cached
canonical sidecar (`6a0c4498…`) independently confirms counts and complete-block
hash plans for all 144 prompt/reference encodings. All six owned sidecar children
exited and were reaped. The sidecar API does not return tail-token IDs; full
arrays are pinned to the exporter and must match serving report token arrays
exactly before comparison. No new tokenizer/model framework was built.

Gemma's generation-only empty-thought suffix is retained in the teacher prompt;
reference content is taken from the canonical completed-message encoding.
`alignment-proof.json` and each token record make this boundary explicit. GPT
references can include normal channel framing. All 72 scored spans avoid
declared EOS tokens (`reference-span-proof.json`). A 64-token span is a bounded
reference-likelihood observation, not a complete-answer accuracy score.

## Separate likelihood and serving scopes

The teacher path is scheduler-free ordinary/eager target scoring. Its exact
plain/diagnostic/repeat controls, finite FP32 bit checks and per-position forced
contexts are retained verbatim from the existing validator. Its backend
comparison remains descriptive; no tolerance or quality predicate was added.
NLL values across different tokenizers/framing are not interchangeable rankings.

Teacher likelihood is **never accepted as a serving oracle by this package**.
The known 11-versus-3 prefill-chunk mismatch is explicitly tested as a refusal;
even matching counts do not establish matching paths. A separate reviewed gate
must bind ordered prefill/decode geometry, dtype/kernel/attention/recurrent and
compiled/eager paths, and the same conditioned token history at every position.
The native teacher controls do not certify scheduler, sampler or MTP verification.

Serving comparison requires the exact frozen token arrays, input/model/runtime
identities, same reviewed host/profile binding and ordered process metadata. It
then calls the existing schema-3 integrity and exact-trajectory comparator
unchanged. Existing numerical and trajectory failures remain failures.

The original B2/B4, full-admission, 2,048-token/10-second sustained decode,
HTTP/shared, persistent restart, whole-verifier and default/release gates remain
separate and unchanged. Here, **long means prompt context**, not sustained decode
qualification. All top-level quality verdicts remain `null`.

## Staged execution with existing runners

`plan.json` contains independent serving and teacher tracks, each with 144 cells
(72 inputs × explicit contiguous/paged backends). Stages are:

1. Pilot: GPT20B / Alice short — two serving cells and two teacher cells.
2. Remaining short coverage: 35 model/case pairs per track.
3. Long coverage: 36 model/case pairs per track.

These are staged recipes, not authorization to launch all cells. The serving
track is B1/cache-off with normal MTP per artifact and the exact seven-key profile.
The teacher track is B1/cache/MTP-off with the existing production grant. Both
Gemmas retain the exact two-file external assistant for normal serving.

The serving wrapper is the unchanged reviewed matrix wrapper, including its
explicit macmon path. Comparison modules are unchanged copies from source
`252ccfb94…`. Teacher argv and validation/comparison function bodies are copied
verbatim from the existing controller. `inherited-gates.json` binds these sources.
No new model execution framework is introduced.

After the new runtime is built/reviewed, ROOT fills a separate copy of
`binding-template.json`: exact runtime manifest/hash/source, executable paths,
model/assistant directories, host/profile, reviewed cell IDs and fresh execution
root. Teacher fixture homes/snapshots use the existing controller's generic
`stage_snapshot`/`validate_snapshot` helpers and Foundation-home check. Its old
four-cell plan is unchanged; ROOT's existing execution driver consumes the new
command specs rather than passing this plan to that old controller entry point.
Root's existing host/readiness, source inventory, process ownership,
bounded retirement and full evidence receipts remain mandatory; these offline
comparison functions do not replace them.

```sh
python3 -B cohort.py validate
python3 -B -m unittest -v test_quality_cohort.py
```

Print one fully bound existing-runner command, without launching it:

```sh
python3 -B cohort.py commands --scope serving \
  --cell serving--gpt-oss-20b--prose-gutenberg-11-short--contiguous \
  --binding /absolute/reviewed-binding.json --binding-sha256 EXACT_BINDING_SHA256
```

The emitted record contains argv, environment, output path, input identity and
the existing execution prerequisites. Teacher records also identify the config
copy and stdout report path required by the existing controller. No `--execute`
option exists here. Preserve failed attempts and run each pair in listed order.

After real execution, the same CLI exposes `compare-serving` and
`compare-teacher` with explicit model/case, contiguous/paged report paths and a
reviewed binding. Serving metadata is read from each report's sibling
`metadata.json`. Teacher comparison must run where its retained fixture snapshot
exists, preserving the original validator's filesystem identity check.

The request-owned prompt date is frozen at **September 6, 2026**. Do not silently
rewrite it; a policy requiring a new date needs a separately hashed successor.
Likewise, a different corpus, tokenizer, input cap or model artifact changes the
cohort identity.

## Primary source references

- Project Gutenberg ebook 11 catalog/copyright status:
  `https://www.gutenberg.org/ebooks/11`
- Project Gutenberg ebook 35 catalog/copyright status:
  `https://www.gutenberg.org/ebooks/35`
- CPython source/license at the pinned commit:
  `https://github.com/python/cpython/tree/0fb18b02c8ad56299d6a2910be0bab8ad601ef24`
- GSM8K repository and dataset description:
  `https://github.com/openai/grade-school-math/tree/3101c7d5072418e28b9008a6636bde82a006892c`
- GSM8K MIT license:
  `https://raw.githubusercontent.com/openai/grade-school-math/3101c7d5072418e28b9008a6636bde82a006892c/LICENSE`

Original licenses/notices and raw public sources are retained under `sources/`.
The derived payloads normalize line endings, select contiguous windows and add
the documented instruction/fence framing; raw source files are unchanged.

## CPU validation

**68 unique checks pass in both normal and `python -O` mode**, with zero skips:
17 new cohort checks and 51 unchanged comparison/acceptance/evidence checks.
They cover actual payload coverage, source/token tampering, duplicate cases,
invalid token IDs/caps/dates, exact tokenization, reference leakage, unchanged
teacher controls/nonfinite refusal, existing trajectory failure propagation,
the 11-versus-3 oracle refusal, reviewed-binding refusal, and existing runner argv.
These are CPU/schema/control tests, not a native inference or quality result.

`validation-results.json` and retained logs distinguish successful checks from
earlier preparation/import/argument failures. `manifest.json` freezes the final
payload inventory; compare its SHA with the handoff receipt before use.
