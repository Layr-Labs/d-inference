"""Offline pilot orchestration checks; never invokes the model or a remote host."""
from contextlib import ExitStack
import copy
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import pilot_cells as pilot

m = pilot.matrix


class PilotTests(unittest.TestCase):
    def test_original_plan_and_selected_input_bytes_are_exact(self):
        plan = pilot.load_plan()
        self.assertEqual(len(plan['cells']), 7)
        self.assertEqual([c['order'] for c in plan['cells']], [73, 74, 75, 76, 181, 183, 184])
        self.assertEqual(len(plan['pairs']), 8)
        self.assertEqual(sum(p['required_comparison'] for p in plan['pairs']), 6)
        self.assertEqual(plan['prompt_date'], '2026-09-06')
        self.assertEqual(plan['output_token_cap'], 128)
        for model in plan['models']:
            self.assertTrue(model['normal_mtp'])
            self.assertEqual(model['input_sha256'], model['prepared_input_sha256'])
        qat = next(model for model in plan['models'] if model['label'].endswith('qat-4bit'))
        for row in m.read(pilot.ROOT / qat['input'])['rows']:
            self.assertNotIn('chat_template_kwargs', row['request'])

    def test_selection_refuses_missing_duplicate_reordered_or_unsupported_cell(self):
        origin = m.read(pilot.ROOT / 'origin-plan.json')
        ids = m.read(pilot.ROOT / 'pilot-selection.json')['cell_ids']
        for wrong in (ids[:-1], ids + [ids[-1]], ids[::-1],
                      ids[:5] + ['gemma-4-26b-qat-4bit-b1-r1-contiguous-cache-on'] + ids[5:]):
            with self.subTest(selection=wrong), self.assertRaisesRegex(ValueError, 'selection'):
                pilot.select(origin, wrong)

    def test_candidate_binding_is_not_execution_authorization(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / 'pending.json'
            path.write_text(json.dumps({'state': 'pending_root_review', 'review_id': None}))
            with self.assertRaisesRegex(ValueError, 'unreviewed'):
                m.verified_bindings(path)

    def test_canonical_results_root_cannot_be_reused(self):
        pilot.require_owned_results_root({'results_root': str(pilot.ROOT / 'runs')})
        with self.assertRaisesRegex(ValueError, 'separate package runs root'):
            pilot.require_owned_results_root({'results_root': '/Users/gaj/autoresearch/radix-prefix-cache/090-repeated-matrix3/runs'})

    def test_seven_commands_change_only_owned_paths(self):
        # Path/hash/date/storage spies permit source-level argv comparison only.
        # Real command generation retains every frozen matrix guard.
        plan = pilot.load_plan()
        binding = m.read(pilot.ROOT / 'provenance/origin-bindings-reviewed3.json')
        original_root = Path('/Users/gaj/autoresearch/radix-prefix-cache/090-repeated-matrix3/plan')
        new_root = Path('/Users/gaj/autoresearch/radix-prefix-cache/090-q38-qat-backend-pilots1')
        fixture = m.read(pilot.ROOT / 'provenance/gemma-two-file-fixture-proof.json')['copied']
        with ExitStack() as stack:
            stack.enter_context(patch.object(m, 'cell_status', return_value='untouched'))
            stack.enter_context(patch.object(m, 'require_current_prompt_date'))
            stack.enter_context(patch.object(m, 'verify_file'))
            stack.enter_context(patch.object(Path, 'is_dir', return_value=True))
            stack.enter_context(patch.object(Path, 'exists', return_value=True))
            stack.enter_context(patch.object(Path, 'iterdir', return_value=iter([])))
            stack.enter_context(patch.object(m.shutil, 'disk_usage', return_value=type('Space', (), {'total': 1 << 40, 'free': 1 << 39})()))
            stack.enter_context(patch.object(m, 'read', return_value={'copied': fixture}))
            for cell in plan['cells']:
                def argv(root, current):
                    with patch.object(m, 'ROOT', root), patch.object(Path, 'iterdir', return_value=iter(Path(name) for name in fixture)):
                        return m.command(plan, current, cell)
                original = argv(original_root, binding)
                candidate = copy.deepcopy(binding)
                candidate['results_root'] = str(new_root / 'runs')
                actual = argv(new_root, candidate)
                expected = [arg.replace(str(original_root), str(new_root)).replace(
                    '/090-repeated-matrix3/runs/', '/090-q38-qat-backend-pilots1/runs/') for arg in original]
                self.assertEqual(actual, expected)
                self.assertEqual(actual[actual.index('--cache-mode') + 1], 'ssd')
                self.assertEqual(actual[actual.index('--key-mode') + 1], 'ephemeral')
                self.assertEqual(actual[actual.index('--mtp') + 1], 'on')

    def test_date_rollover_and_existing_attempt_still_refuse(self):
        plan = pilot.load_plan()
        with self.assertRaisesRegex(ValueError, 'prompt date expired'):
            m.require_current_prompt_date(plan, '2026-09-07')
        with tempfile.TemporaryDirectory() as tmp:
            cell = plan['cells'][0]
            (Path(tmp) / cell['id']).mkdir()
            with self.assertRaisesRegex(ValueError, 'already exists'):
                m.command(plan, {'results_root': tmp}, cell)

    def fixtures(self, root, plan):
        for index, cell in enumerate(plan['cells']):
            directory = root / cell['id']; directory.mkdir()
            (directory / 'report.json').write_text(json.dumps({'status': 'completed', 'marker': cell['id']}))
            (directory / 'metadata.json').write_text(json.dumps({
                'status': 'completed', 'exit_code': 0, 'started_unix': index * 10, 'ended_unix': index * 10 + 1}))

    def collect(self, root, plan):
        # These fixtures isolate the new orchestration after the unchanged
        # matrix's own raw validators; separate original-plan tests cover them.
        with patch.object(m, 'cell_evidence_errors', side_effect=lambda *a: []), patch.object(
                m, 'compare', side_effect=lambda *a: {'passed': True, 'errors': []}):
            return pilot.collect(plan, {'results_root': str(root)})

    def test_seven_passing_fixtures_cannot_claim_matrix_or_release_completion(self):
        plan = pilot.load_plan()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); self.fixtures(root, plan)
            result = self.collect(root, plan)
            self.assertEqual(sum(pair['passed'] for pair in result['comparisons']), 6)
            self.assertEqual(sum(pair['state'] == 'unsupported_comparison' for pair in result['comparisons']), 2)
            self.assertFalse(result['matrix_completion_claim'])
            self.assertFalse(result['release_gates_satisfied'])
            self.assertNotIn('repeated_pair_summaries', result)

    def test_partial_missing_cells_do_not_invent_comparisons(self):
        plan = pilot.load_plan()
        with tempfile.TemporaryDirectory() as tmp:
            result = self.collect(Path(tmp), plan)
            self.assertEqual(sum(pair['passed'] for pair in result['comparisons']), 0)
            self.assertTrue(all(cell['state'] == 'untouched' for cell in result['cells']))

    def test_overlap_in_failed_attempt_invalidates_all_pair_interpretations(self):
        plan = pilot.load_plan()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); self.fixtures(root, plan)
            path = root / plan['cells'][0]['id'] / 'metadata.json'
            meta = m.read(path); meta.update(status='failed', exit_code=1, ended_unix=15)
            path.write_text(json.dumps(meta))
            result = self.collect(root, plan)
            self.assertTrue(result['process_order_errors'])
            self.assertFalse(any(pair['passed'] for pair in result['comparisons']))

    def test_malformed_or_nonfinite_process_windows_cannot_pass(self):
        plan = pilot.load_plan()
        for wrong in (None, True, '1', float('nan'), float('inf'), -1):
            with self.subTest(window=wrong), tempfile.TemporaryDirectory() as tmp:
                root = Path(tmp); self.fixtures(root, plan)
                path = root / plan['cells'][0]['id'] / 'metadata.json'
                meta = m.read(path); meta['ended_unix'] = wrong; path.write_text(json.dumps(meta))
                result = self.collect(root, plan)
                self.assertTrue(result['process_order_errors'])
                self.assertFalse(any(pair['passed'] for pair in result['comparisons']))

    def test_existing_partial_root_with_no_window_blocks_pair_interpretation(self):
        plan = pilot.load_plan()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); self.fixtures(root, plan)
            (root / plan['cells'][-1]['id'] / 'metadata.json').write_text('[]')
            result = self.collect(root, plan)
            self.assertTrue(result['process_order_errors'])
            self.assertFalse(any(pair['passed'] for pair in result['comparisons']))

    def test_strict_integrity_and_pair_failures_are_preserved(self):
        plan = pilot.load_plan()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp); self.fixtures(root, plan)
            with patch.object(m, 'cell_evidence_errors', side_effect=lambda *a: []), patch.object(
                    m, 'compare', side_effect=lambda *a: {'passed': False, 'errors': [{'token_mismatch': True}]}):
                result = pilot.collect(plan, {'results_root': str(root)})
            self.assertFalse(any(pair['passed'] for pair in result['comparisons']))
            self.assertEqual(sum(pair.get('errors') == [{'token_mismatch': True}] for pair in result['comparisons']), 6)
            with patch.object(m, 'cell_evidence_errors', side_effect=lambda *a: [{'missing_native_restore': True}]):
                result = pilot.collect(plan, {'results_root': str(root)})
            self.assertTrue(all(cell['state'] == 'failed_integrity' for cell in result['cells']))
            self.assertFalse(any(pair['passed'] for pair in result['comparisons']))


if __name__ == '__main__':
    unittest.main()
