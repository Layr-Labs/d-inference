"""Render every remote template with network and child execution mocked out."""
import importlib.util
import json
from pathlib import Path
import shutil
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch


def module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


class RenderedScriptTests(unittest.TestCase):
    def run_dry(self, path, kind, expected_count):
        rendered = []
        def fake_run(argv, **kwargs):
            code = kwargs.get('input')
            if code is not None:
                compile(code, '<cpu-rendered-' + kind + '>', 'exec')
                self.assertNotIn('__REMOTE_ROOT_PATH__', code)
                rendered.append(code)
            return SimpleNamespace(returncode=0, stdout='{"files": {}}', stderr='')
        value = module(path, 'dry_' + kind)
        with tempfile.TemporaryDirectory() as temp:
            value.OUT = Path(temp)
            argv = [str(path)]
            if kind == 'execution':
                source = Path('/tmp/darkbloom-qat-actual-logits-execution2')
                for p in source.iterdir():
                    if p.is_file():
                        shutil.copy2(p, value.OUT / p.name)
                argv += ['gemma-qat4-contiguous-cache-off-mtp-on-trace-off']
            elif kind == 'transfer':
                argv += ['--binding', '/tmp/darkbloom-qat-actual-logits-runtime-binding1.json',
                         '--binding-sha256', '1c714fa86469c935c911cb7b02a318da9ee0490319457d692cad0f8bae39875f']
            with patch.object(value.subprocess, 'run', side_effect=fake_run), patch.object(sys, 'argv', argv):
                if kind == 'execution':
                    with self.assertRaises(SystemExit) as exit:
                        value.main()
                    self.assertEqual(exit.exception.code, 1)  # No model report exists in this CPU mock.
                else:
                    value.main()
            self.assertEqual(len(rendered), expected_count)
            if kind != 'execution':
                self.assertTrue(any("['state']=='SOURCE_ONLY_PENDING_ROOT_REVIEW'" in s for s in rendered))
        return rendered

    def test_stage_renders_three_scripts_with_literal_root_in_state(self):
        self.run_dry(Path('/tmp/darkbloom-qat-actual-logits-staging1/stage.py'), 'stage', 3)

    def test_transfer_renders_two_scripts_with_literal_root_in_state(self):
        self.run_dry(Path('/tmp/darkbloom-qat-actual-logits-runtime-transfer1/transfer.py'), 'transfer', 2)

    def test_execution_renders_both_scripts_without_network_or_model(self):
        self.run_dry(Path('/tmp/darkbloom-qat-actual-logits-execution2/run_cell.py'), 'execution', 2)

    def test_original_global_substitution_is_a_negative_control(self):
        raw = "root=Path(ROOT)\nassert state=='SOURCE_ONLY_PENDING_ROOT_REVIEW'\n"
        broken = raw.replace('ROOT', repr('/Users/gaj/090-qat-actual-logits1'))
        with self.assertRaises(SyntaxError):
            compile(broken, '<old-template>', 'exec')
        fixed = raw.replace('Path(ROOT)', 'Path(__REMOTE_ROOT_PATH__)').replace(
            '__REMOTE_ROOT_PATH__', repr('/Users/gaj/090-qat-actual-logits1'))
        compile(fixed, '<fixed-template>', 'exec')
        self.assertIn('SOURCE_ONLY_PENDING_ROOT_REVIEW', fixed)


if __name__ == '__main__':
    unittest.main()
