from pathlib import Path
import hashlib
import json
import struct
import sys

ROOT = Path(__file__).resolve().parent
RUNS = Path('/tmp/darkbloom-qat-actual-logits-execution3')
PLAN = Path('/tmp/darkbloom-qat-actual-logits-plan2')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    plan = json.loads((PLAN/'plan.json').read_text())
    reports = {}
    records = {}
    cells = {}
    for cell in plan['cells']:
        root = RUNS/cell['id']
        for name, row in json.loads((root/'manifest.json').read_text())['files'].items():
            assert sha(root/name) == row['sha256'] and (root/name).stat().st_size == row['bytes']
        summary = json.loads((root/'summary.json').read_text())
        assert summary['report_integrity_passed'] and summary['exit_code'] == 0 and not summary['errors']
        report = json.loads((root/'report.json').read_text())
        reports[(cell['backend'], cell['trace'])] = report
        cells[cell['id']] = {'manifest_sha256': sha(root/'manifest.json'),
                            'execution': json.loads((root/'execution.json').read_text())}
        if cell['trace']:
            snapshot = report['logit_diagnostic']['snapshot']
            assert len(snapshot['records']) == snapshot['reservedRecords'] == 1
            record = snapshot['records'][0]
            values = [struct.unpack('<f', struct.pack('<I', n))[0] for n in record['valueBits']]
            records[cell['backend']] = {'record': record, 'all_values': values,
                                       'candidate_values': values[-2:]}
    comparisons = {}
    fields = ['prompt_token_ids', 'token_ids', 'prompt_tokens', 'completion_tokens', 'finish', 'outcome']
    for backend in ['contiguous', 'paged']:
        control, trace = reports[(backend, False)], reports[(backend, True)]
        equality = {}
        for group in ['rows', 'tenant_checks', 'cancel_donor', 'recovered']:
            left = control[group] if isinstance(control[group], list) else [control[group]]
            right = trace[group] if isinstance(trace[group], list) else [trace[group]]
            assert len(left) == len(right)
            for index, (a, b) in enumerate(zip(left, right)):
                assert all(a[k] == b[k] for k in fields)
                equality[group+':'+str(index)] = True
        assert len(equality) == 7
        for report in [control, trace]:
            assert report['cancelled']['token_ids'] == report['recovered']['token_ids'][:len(report['cancelled']['token_ids'])]
        comparisons[backend] = equality
    left, right = reports[('contiguous', False)]['rows'][0], reports[('paged', False)]['rows'][0]
    assert left['prompt_token_ids'] == right['prompt_token_ids'] and len(left['prompt_token_ids']) == 5418
    assert left['token_ids'][:7] == right['token_ids'][:7] and left['token_ids'][7] != right['token_ids'][7]
    sys.path.insert(0, str(PLAN/'runner'))
    from compare_radix_engine import compare
    strict = compare(reports[('contiguous', False)], reports[('paged', False)], axis='backend')
    (ROOT/'strict-backend.json').write_text(json.dumps(strict, indent=2)+'\n')
    result = {'scope': 'Four same-build Gemma QAT controls with normal MTP; actual diagnostic support verified, backend token mismatch retained.',
        'cells': cells, 'same_backend_complete_trajectory_equality': comparisons,
        'shared_prompt_count': 5418, 'shared_prior_token_ids': left['token_ids'][:7],
        'first_backend_difference_index': 7,
        'output_lengths': {'contiguous': len(left['token_ids']), 'paged': len(right['token_ids'])},
        'selected_actual_records': records,
        'limitations': ['No Q/K/V attention metadata was requested; Q dtype and common operator input are unmeasured.',
            'Confirmed rectangular MTP verification context is observed; accepted drafts differ after the selected decision.',
            'Generic logit diagnostic success is not backend model-quality or performance acceptance.',
            'Original unsupported c153 trace failure remains frozen separately.'],
        'postflight': json.loads(Path('/tmp/darkbloom-qat-actual-logits2-final-postflight1.json').read_text())}
    (ROOT/'analysis.json').write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps({'cells': len(cells), 'same_backend_trajectories_each': 7,
                      'candidate_logits': {b: r['candidate_values'] for b,r in records.items()},
                      'strict_backend': strict}, indent=2))


if __name__ == '__main__': main()
