"""Bounded CPU-only file and identity helpers for the frozen quality cohort."""
from pathlib import Path
import hashlib
import json
import struct


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(path):
    value = hashlib.sha256()
    with Path(path).open('rb') as source:
        for block in iter(lambda: source.read(1 << 20), b''):
            value.update(block)
    return value.hexdigest()


def token_digest(tokens):
    return hashlib.sha256(b"".join(struct.pack(">I", token) for token in tokens)).hexdigest()


def local_path(root, relative):
    path = Path(relative)
    require(isinstance(relative, str) and not path.is_absolute() and ".." not in path.parts
            and str(path) == relative and "\\" not in relative, "unsafe package path")
    return Path(root) / path


def read_json(path, maximum=16 << 20):
    path = Path(path)
    require(path.is_file() and not path.is_symlink() and path.stat().st_size <= maximum,
            "bounded regular JSON required: " + str(path))
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON key: " + key)
            result[key] = value
        return result
    def invalid(value):
        raise ValueError("nonfinite JSON: " + value)
    return json.loads(path.read_text(), object_pairs_hook=pairs, parse_constant=invalid)


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + "\n")


def identity(path):
    path = Path(path)
    return {"sha256": digest(path), "bytes": path.stat().st_size}


def checked(root, row):
    path = local_path(root, row["path"])
    require(type(row.get("bytes")) is int and 0 <= row["bytes"] <= 32 << 20,
            "package file exceeds size bound")
    require(path.resolve().is_relative_to(Path(root).resolve()), "package path escapes root")
    require(path.is_file() and not path.is_symlink(), "missing regular package file")
    require(path.stat().st_size == row["bytes"] and digest(path) == row["sha256"],
            "file identity differs: " + row["path"])
    return path
