from pathlib import Path
import hashlib
import json
import shutil
import tarfile

ROOT=Path(__file__).resolve().parent
PAYLOAD=ROOT/'payload';PAYLOAD.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def copy(source,name):
    assert source.is_file() and not source.is_symlink(),str(source)
    target=PAYLOAD/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)


def group(source,name,manifest_name='manifest.json'):
    manifest=json.loads((source/manifest_name).read_text())
    for relative,row in manifest['files'].items():
        path=source/relative
        assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes']
        if 'mode'in row:assert oct(path.stat().st_mode&0o777)==row['mode']
        copy(path,name+'/'+relative)
    copy(source/manifest_name,name+'/'+manifest_name)


plan=Path('/tmp/darkbloom-qat-actual-logits-plan2')
execution=Path('/tmp/darkbloom-qat-actual-logits-execution3')
group(plan,'plan')
group(execution,'controller','preparation-manifest.json')
for cell in json.loads((plan/'plan.json').read_text())['cells']:
    group(execution/cell['id'],'raw/'+cell['id'])
for source,name in [(Path('/tmp/darkbloom-qat-actual-logits-staging2'),'staging'),
                    (Path('/tmp/darkbloom-qat-actual-logits-runtime-transfer2'),'transfer')]:
    for path in sorted(source.iterdir()):
        if path.is_file() and path.name!='plan-package.tar.gz':copy(path,name+'/'+path.name)
for path in Path('/tmp/darkbloom-qat-actual-logits2-analysis1').iterdir():
    if path.is_file():copy(path,'analysis/'+path.name)
for name in ['darkbloom-qat-successor-peer-review1.json','darkbloom-qat-successor-peer-tests1.log',
             'darkbloom-qat-successor-remote-helper-tests1.log','darkbloom-qat-actual-logits2-final-postflight1.json',
             'darkbloom-generic-qat-release-probe-root-final-review1.json']:
    copy(Path('/tmp')/name,'reviews/'+name)
build=Path('/tmp/darkbloom-generic-qat-release-probe1')
for name in ['manifest.json','artifact-manifest.json','integration.json','source-union.json',
             'generic-source-proof.json','native-source-manifest.json','provider-source-manifest.json',
             'harness-source-manifest.json','runner-source-manifest.json','dependency-source-manifest.json',
             'jinja-source-manifest.json','radix-engine-actual-release.yaml.gz',
             'radix-engine-all-owned-graph-source-proof.json','radix-engine-runtime-resource-proof.json',
             'final-resource-mode-proof.json','verdict.json','smoke-verdict.json','delta-from-packet-release.json']:
    copy(build/name,'runtime-provenance/'+name)
copy(Path(__file__),'freeze.py')
files={str(p.relative_to(PAYLOAD)):{'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)}
       for p in sorted(PAYLOAD.rglob('*'))if p.is_file()}
assert not any('__pycache__'in n for n in files)
(ROOT/'manifest.json').write_text(json.dumps({'scope':'Four actual Gemma QAT generic-diagnostic cells; all integrity PASS, strict backend token FAIL. No executables/weights/keys.','files':files},indent=2)+'\n')
with tarfile.open(ROOT/'payloads.tar.gz','x:gz')as tar:
    for name in sorted(files):tar.add(PAYLOAD/name,arcname=name,recursive=False)
result={'payloads':len(files),'manifest_sha256':sha(ROOT/'manifest.json'),
        'archive_sha256':sha(ROOT/'payloads.tar.gz'),'archive_bytes':(ROOT/'payloads.tar.gz').stat().st_size}
(ROOT/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
