from pathlib import Path
import subprocess,json,hashlib,datetime,shutil
out=Path(__file__).parent
candidate=Path('/Users/gaj/Documents/DarkbloomDev/wt/prefix-receipt-pump-ownership')
primary=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
sha=lambda b:hashlib.sha256(b).hexdigest()
paths=['provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge+Submission.swift','provider-swift/Tests/ProviderCoreTests/EngineV2BridgeTests.swift']
proof=[]
for rel in paths:
 before=subprocess.check_output(['git','-C',str(candidate),'show','HEAD:'+rel]);after=(candidate/rel).read_bytes()
 for group,data in [('before',before),('after',after)]:
  dst=out/group/rel;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data)
 proof.append({'path':rel,'before_sha256':sha(before),'after_sha256':sha(after)})
(out/'candidate.patch').write_bytes(subprocess.check_output(['git','-C',str(candidate),'diff','--binary','--']+paths))
(out/'source-change.json').write_text(json.dumps({'base':subprocess.check_output(['git','-C',str(candidate),'rev-parse','HEAD'],text=True).strip(),'paths':proof,'tests_run':False},indent=2)+'\n')
files=[
('/tmp/darkbloom-connected-http3-q38-donation-failure1/manifest.json','raw/fleet-freeze-manifest.json'),
('/tmp/darkbloom-connected-http3-results/qwen38-paged-ssd-b1/evidence/report.json','raw/failed-report.json'),
('/tmp/darkbloom-connected-http3-results/qwen38-paged-ssd-b1/connected.log','raw/failed-connected.log'),
('/tmp/darkbloom-connected-http3-results/qwen38-paged-ssd-b1/manifest.json','raw/failed-cell-manifest.json'),
('/tmp/darkbloom-final-serving-build7/provider-source-manifest.json','raw/cli7-provider-source-manifest.json')]
for rel in ['provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge+Admission.swift','provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge+Events.swift','provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge.swift','provider-swift/Sources/ProviderCore/Inference/PrefixCacheEvidenceSequencer.swift','provider-swift/Sources/ProviderCore/KVCacheSSD/SSDHybridCheckpointStore+Maintenance.swift','provider-swift/Sources/ProviderCore/KVCacheSSD/SSDHybridCheckpointStore+Write.swift','e2e/connected_cache_http_test.go','e2e/exact_cache_routing_test.go','coordinator/registry/cache_receipts_v2.go']:
 files.append((str(primary/rel),'source/'+rel))
for src,rel in files:
 dst=out/rel;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
build7=json.loads((out/'raw/cli7-provider-source-manifest.json').read_text())['files']
assert proof[0]['before_sha256']==build7[paths[0]]
report=json.loads((out/'raw/failed-report.json').read_text());row=report['cases'][0]
obs={'report_sha256':sha((out/'raw/failed-report.json').read_bytes()),'before':row['before']['lifecycle'],'after':row['after']['lifecycle'],'wire_types':[x['type'] for x in report['wire']],'wire_dropped':report['wire_dropped'],'before_holders':row['before']['holders'],'after_holders':row['after']['holders'],'source_matches_actual_cli7':True,'fleets_frozen_manifest_sha256':sha((out/'raw/fleet-freeze-manifest.json').read_bytes()),'tests_run':False}
(out/'observations.json').write_text(json.dumps(obs,indent=2)+'\n')
print(json.dumps({'candidate_patch_sha256':sha((out/'candidate.patch').read_bytes()),'files':proof,'source_matches_cli7':True},indent=2))
