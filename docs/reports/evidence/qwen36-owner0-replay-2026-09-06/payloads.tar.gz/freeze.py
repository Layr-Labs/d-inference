"""Freeze raw operator output and compact provenance; never include runtime products."""
from pathlib import Path
import hashlib
import json
import shutil
import tarfile

ROOT=Path(__file__).resolve().parent
PAYLOAD=ROOT/'payload';PAYLOAD.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()


def copy(source,name):
    assert source.is_file() and not source.is_symlink(),str(source)
    target=PAYLOAD/name;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,target)


def group(source,name,manifest_name='manifest.json'):
    manifest=json.loads((source/manifest_name).read_text())
    for relative,row in manifest['files'].items():
        path=source/relative
        assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes']
        if 'mode'in row:assert oct(path.stat().st_mode&0o777)==row['mode']
        copy(path,name+'/'+relative)
    copy(source/manifest_name,name+'/'+manifest_name)


group(Path('/tmp/darkbloom-q36-owner0-replay-plan1'),'plan')
group(Path('/tmp/darkbloom-q36-owner0-replay-execution1'),'controller','preparation-manifest.json')
group(Path('/tmp/darkbloom-q36-owner0-replay-stage-resume1'),'stage-recovery-source')
group(Path('/tmp/darkbloom-q36-owner0-replay-collection2'),'collection-correction')
results=Path('/tmp/darkbloom-q36-owner0-replay-results1')
for name in ['staging','staging-resume1','analysis2']:
    group(results/name,'execution/'+name)
for arm in ['nativeSDPA','pagedFixed','pagedSegmented']:
    group(results/'arms'/arm,'execution/arms/'+arm)
    entries=json.loads((results/'arms'/arm/'raw-manifest.json').read_text())
    for name,row in entries.items():
        path=results/'raw'/name
        assert sha(path)==row['sha256'] and path.stat().st_size==row['bytes']
        assert oct(path.stat().st_mode&0o777)==row['mode']
        copy(path,'execution/raw/'+name)
for path in (results/'resume-invocations').iterdir():copy(path,'execution/resume-invocations/'+path.name)
copy(results/'analysis/unchanged-collector.json','execution/first-partial-analysis/unchanged-collector.json')
assert (results/'analysis/unchanged-collector.json').read_bytes()==(results/'analysis2/unchanged-collector.json').read_bytes()
group(Path('/tmp/darkbloom-q36-owner0-replay-staging-inspection1'),'staging-independent-inspection')
copy(Path('/tmp/darkbloom-q36-owner0-replay-runtime-binding1.json'),'runtime-binding.json')
for parent in ['darkbloom-q36-owner0-replay-peer-review1',
               'darkbloom-q36-owner0-replay-controller-peer-review1',
               'darkbloom-q36-owner0-replay-stage-resume-peer-review1',
               'darkbloom-q36-owner0-replay-results-peer-review1']:
    directory=Path('/tmp')/parent
    for path in sorted(directory.iterdir()):
        if path.is_file():copy(path,'reviews/'+parent+'/'+path.name)
copy(Path('/tmp/darkbloom-attention-operator-replay-root-release-final-review1.json'),'reviews/root-optimized-build.json')
build=Path('/tmp/darkbloom-attention-operator-replay-release-build1')
for name in ['manifest.json','artifact-manifest.json','integration.json','reviewed-source-correspondence.json',
             'native-source-manifest.json','harness-source-manifest.json','dependency-source-manifest.json',
             'jinja-source-manifest.json','actual-compiler-source-proof.json','actual-release.yaml.gz',
             'actual-workspace-state.json','compile-environment.json','runtime-resource-proof.json',
             'runtime-resource-inputs.json','package-resolution-inputs.json','native-package-location-overlay.patch',
             'source-verified-final.json','source-verified-freeze.json','execution.json','verdict.json',
             'smoke-verdict.json','smoke-results.json','build_proof.py','run.py','prepare.py','smoke.py',
             'toolchain.txt','hardware.txt','dylibs.txt']:
    copy(build/name,'runtime-provenance/'+name)
smoke_links={}
for path in sorted((build/'smokes').iterdir()):
    if path.is_symlink():smoke_links[path.name]=str(path.readlink())
    elif path.is_file():copy(path,'runtime-provenance/smokes/'+path.name)
(PAYLOAD/'runtime-provenance/smoke-symlinks.json').write_text(json.dumps(smoke_links,indent=2)+'\n')
native=build/'workspace/libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2'
for name in ['CBv2AttentionReplay.swift','CBv2AttentionReplay+Paged.swift']:copy(native/name,'source/native/'+name)
harness=build/'workspace/scripts/benchmarks/attention-replay'
for path in sorted(harness.rglob('*')):
    if path.is_file() and path.suffix in ['.swift','.md']:
        copy(path,'source/harness/'+str(path.relative_to(harness)))
captures=json.loads(Path('/tmp/darkbloom-q36-owner0-replay-plan1/captures.json').read_text())
for backend,row in captures.items():
    directory=Path(row['path']).parent
    for name in ['packet.json','attention-metadata.json','output.bin']:
        assert sha(directory/name)==row['files'][name]['sha256'];copy(directory/name,'original-selected-reference/'+backend+'/'+name)
copy(Path(__file__),'freeze.py')
files={str(p.relative_to(PAYLOAD)):{'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)}
       for p in sorted(PAYLOAD.rglob('*'))if p.is_file()}
assert not any('__pycache__'in name or name.endswith('.metallib') or name.endswith('.safetensors')for name in files)
manifest={'scope':'Three genuine Q36 owner0 operators; output and full KV readbacks, compact optimized build/source/graph proofs. Original complete common input is retained in prior banked packet archive, not duplicated here. Strict model-token FAIL remains. No executable/runtime-resource/weight/key payload.','files':files}
(ROOT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(ROOT/'payloads.tar.gz','x:gz')as tar:
    for name in sorted(files):tar.add(PAYLOAD/name,arcname=name,recursive=False)
result={'payloads':len(files),'manifest_sha256':sha(ROOT/'manifest.json'),
        'archive_sha256':sha(ROOT/'payloads.tar.gz'),'archive_bytes':(ROOT/'payloads.tar.gz').stat().st_size}
(ROOT/'summary.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
