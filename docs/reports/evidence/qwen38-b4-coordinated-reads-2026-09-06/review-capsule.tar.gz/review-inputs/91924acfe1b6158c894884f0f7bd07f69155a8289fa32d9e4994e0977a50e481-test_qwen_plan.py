import copy
import contextlib
import io
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest
from unittest.mock import patch

import qwen_plan as scoped
import test_compare_radix_engine as comparator_fixtures
import test_radix_forward_shapes as shape_fixtures


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
    return {"path": str(path), "sha256": scoped.digest(path)}


def shape_report(width=4):
    rows, batches = [], []
    for kind in ("first", "repeat"):
        name = "long-" + kind
        for index in range(width):
            rows.append({"id": name + "-b" + str(index), "batch_id": name, "kind": kind,
                         "completion_tokens": 2048, "finish": "length", "batch_start_offset_s": 0,
                         "chunks": [{"elapsed_s": .2, "tokens": [1]}, {"elapsed_s": 12.2, "tokens": [2]}],
                         "forward_shapes": shape_fixtures.packet(rows=width)})
        batches.append({"id": name, "concurrency_requested": width, "completed": width,
                        "failed": 0, "peak_active_requests": width, "capacity_samples_omitted": 0,
                        "capacity_samples": [{"elapsed_s": moment, "active_requests": width}
                                             for moment in (.5, 1, 5, 10)],
                        "forward_shapes": shape_fixtures.packet(rows=width)})
    return {"schema": 3, "status": "completed", "forward_shape_telemetry_schema": 1,
            "max_concurrent_requests": width, "rows": rows, "batches": batches}


class QwenPlanTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.plan, cls.matrix = scoped.load_plan()

    def binding_fixture(self, directory):
        binding = scoped.read(scoped.ROOT / "bindings/m5.candidate.json")
        binding.update(state="reviewed", review_id="cpu-only-fixture", results_root=str(directory / "results"),
                       storage_retention_review="cpu-only", python_executable=sys.executable,
                       reviewed_cell_ids=scoped.read(scoped.ROOT / "schedule.json")["pilot_cells"])
        binding["plan_manifest"] = {"path": str(scoped.ROOT / "manifest.json"),
                                    "sha256": scoped.digest(scoped.ROOT / "manifest.json")}
        binding["runtime_source_manifest"] = write_json(directory / "source.json", {"fixture": "new Qwen source"})
        binary = directory / "runtime/radix-engine"
        binary.parent.mkdir(); binary.write_text("CPU fixture, not executable benchmark code\n"); binary.chmod(0o700)
        binding["binary"] = {"path": str(binary), "sha256": scoped.digest(binary), "mode": 0o700}
        binding["resources"] = {name: write_json(binary.parent / name, {"fixture": name})
                                for name in self.matrix.RESOURCE_NAMES}
        binding["macmon"] = write_json(directory / "macmon", {"fixture": "never run"})
        source = {"status": "QWEN_ONLY_SOURCE_REVIEWED", "review_id": "cpu-source",
                  "enabled_artifacts": scoped.identities(self.plan),
                  "runtime_source_manifest_sha256": binding["runtime_source_manifest"]["sha256"]}
        binding["source_review"] = write_json(directory / "source-review.json", source)
        runtime = {"status": "QWEN_ONLY_RUNTIME_REVIEWED", "review_id": "cpu-runtime",
                   "source_review_sha256": binding["source_review"]["sha256"],
                   "binary_sha256": binding["binary"]["sha256"],
                   "resources": {name: record["sha256"] for name, record in binding["resources"].items()},
                   "tests_passed": True,
                   "test_evidence": {kind: write_json(directory / (kind + ".json"), {"fixture": kind})
                                     for kind in ("native", "compiler")}}
        binding["runtime_review"] = write_json(directory / "runtime-review.json", runtime)
        model = next(model for model in self.plan["models"] if model["label"] == "qwen38")
        audit = {"model_id": model["model_id"], "directory": model["model_directory_hint"],
                 "aggregate_sha256": model["aggregate_sha256"], "manifest_sha256": model["manifest_sha256"],
                 "all_manifest_file_hashes_verified": True, "unmanifested_payloads": [],
                 "files": {row["path"]: {"bytes": row["size_bytes"], "sha256": row["sha256"]}
                           for row in scoped.read(scoped.ROOT / model["manifest"])["files"]}}
        binding["models"]["qwen38"].update(live_identity_verified_for_this_run=True,
                                         identity_audit=write_json(directory / "audit.json", audit))
        path = directory / "binding.json"; write_json(path, binding)
        verified = scoped.verified_binding(self.plan, self.matrix, path)
        ack = {"status": "QWEN_EXECUTION_AUTHORIZED", "review_id": "cpu-root", "host_id": "m5",
               "only_cells": binding["reviewed_cell_ids"], "binding_sha256": scoped.digest(path),
               "owned_controller_review": write_json(directory / "owner-review.json", {"fixture": True})}
        ack_path = directory / "ack.json"; write_json(ack_path, ack)
        return path, verified, ack_path

    def test_exact_frozen_selection_and_identities(self):
        predecessor = Path(scoped.read(scoped.ROOT / "scope-change.json")["frozen_predecessor"])
        original = scoped.read(predecessor / "plan.json")
        for key in ("models", "cells"):
            label_key = "label" if key == "models" else "model"
            self.assertEqual(self.plan[key], [row for row in original[key] if row[label_key] in scoped.LABELS])
        ids = {cell["id"] for cell in self.plan["cells"]}
        self.assertEqual(self.plan["pairs"], [pair for pair in original["pairs"]
                                            if {pair["baseline"], pair["candidate"]} <= ids])
        for key in ("workloads", "serving_profile", "prompt_date", "rollback_controls"):
            self.assertEqual(self.plan[key], original[key])
        self.assertEqual(scoped.identities(self.plan), scoped.read(scoped.ROOT / "scope-change.json")["enabled_exact_artifacts"])

    def test_counts_widths_common_arms_and_order(self):
        cells = scoped.select(self.plan)
        self.assertEqual((len(self.plan["models"]), len(cells), len(self.plan["pairs"])), (3, 108, 72))
        self.assertEqual({cell["quartet"] for cell in cells[:3]}, {scoped.PILOT})
        self.assertEqual(sum(cell["workload"] == "retained" for cell in cells), 27)
        self.assertEqual(sum(cell["workload"] == "sustained" and cell["repetition"] == 1 for cell in cells), 27)
        for offset in range(0, 108, 3):
            triad = cells[offset:offset + 3]
            self.assertEqual([(cell["backend"], cell["cache"]) for cell in triad],
                             [("contiguous", "off"), ("paged", "off"), ("paged", "on")])
            edges = [edge for edge in self.plan["pairs"] if edge["quartet"] == triad[0]["quartet"]]
            self.assertEqual(len(edges), 2)
            self.assertEqual(next(edge for edge in edges if edge["axis"] == "backend")["candidate"], triad[1]["id"])
            self.assertEqual(next(edge for edge in edges if edge["axis"] == "cache")["baseline"], triad[1]["id"])
        for label in scoped.LABELS:
            self.assertEqual({cell["concurrency"] for cell in cells if cell["model"] == label}, {1, 2, 4})
            self.assertTrue(next(model for model in self.plan["models"] if model["label"] == label)["normal_mtp"])
            for width in (1, 2, 4):
                repeats = [cell["repetition"] for cell in cells if cell["model"] == label
                           and cell["concurrency"] == width and cell["workload"] == "sustained"]
                self.assertEqual(repeats, [1] * 3 + [2] * 3 + [3] * 3)

    def test_no_gpt_gemma_or_alias_selection(self):
        for cohort in ("gpt-oss-20b-retained-b2-r1", "gemma-4-26b-retained-b2-r1", "Qwen3.8-retained-b2-r1"):
            with self.subTest(cohort=cohort), self.assertRaises(ValueError):
                scoped.select(self.plan, cohort)
        with tempfile.TemporaryDirectory() as directory:
            _, binding, ack = self.binding_fixture(Path(directory))
            with patch.object(self.matrix, "command") as native:
                for name in ("gpt-oss-20b", "gemma-4-26b", "gemma-4-26b-qat-4bit"):
                    with self.assertRaisesRegex(ValueError, "out-of-scope"):
                        scoped.command(self.plan, self.matrix, binding, name + "-retained-b2-r1-paged-cache-off", ack)
                native.assert_not_called()

    def test_selection_mutations_refused(self):
        mutations = [("models", lambda value: value[0].update(aggregate_sha256="0" * 64)),
                     ("cells", lambda value: value[0].update(concurrency=8)),
                     ("pairs", lambda value: value[0].update(required_comparison=False)),
                     ("serving_profile", lambda value: value.update(MLX_COMPILED_DECODE="0")),
                     ("workloads", lambda value: value["sustained"].update(required_actual_completion_tokens=512))]
        for key, mutate in mutations:
            changed = copy.deepcopy(self.plan); mutate(changed[key])
            with self.subTest(key=key), self.assertRaisesRegex(ValueError, "selection changed"):
                scoped.validate_selection(changed)

    def test_mutable_payload_refused_before_helper_use(self):
        for relative in ("inputs/retained/qwen38.json", "inputs/sustained/qwen35.json", "plan.json",
                         "cpu-plans/qwen36-sustained.json", "provenance/qwen38-manifest.json",
                         "runner/compare_radix_engine.py", "schedule.json"):
            with tempfile.TemporaryDirectory() as directory:
                temporary = Path(directory) / "payload"; shutil.copytree(scoped.ROOT, temporary)
                with (temporary / relative).open("a") as stream:
                    stream.write(" ")
                with patch.object(scoped, "ROOT", temporary), patch.object(scoped, "engine") as imported:
                    with self.subTest(relative=relative), self.assertRaisesRegex(ValueError, "mutable package"):
                        scoped.load_plan()
                    imported.assert_not_called()

    def test_candidate_cannot_generate_commands(self):
        with patch.object(self.matrix, "command") as native:
            with self.assertRaisesRegex(ValueError, "source/runtime unbound"):
                scoped.verified_binding(self.plan, self.matrix, scoped.ROOT / "bindings/m5.candidate.json")
            native.assert_not_called()

    def test_missing_source_or_runtime_review_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            path, _, _ = self.binding_fixture(Path(directory)); original = scoped.read(path)
            for field in ("source_review", "runtime_review", "runtime_source_manifest", "binary"):
                changed = copy.deepcopy(original); changed[field] = None; write_json(path, changed)
                with self.subTest(field=field), self.assertRaises(ValueError):
                    scoped.verified_binding(self.plan, self.matrix, path)

    def test_different_source_scope_and_stale_review_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            path, _, _ = self.binding_fixture(Path(directory)); binding = scoped.read(path)
            review = scoped.read(binding["source_review"]["path"])
            review["enabled_artifacts"]["gpt-oss-20b"] = {}
            binding["source_review"] = write_json(Path(directory) / "wrong-source.json", review); write_json(path, binding)
            with self.assertRaisesRegex(ValueError, "artifact scope"):
                scoped.verified_binding(self.plan, self.matrix, path)

    def test_no_auto_gpu_or_scope_expansion(self):
        with tempfile.TemporaryDirectory() as directory:
            path, _, _ = self.binding_fixture(Path(directory)); original = scoped.read(path)
            for field, value in (("gpu_ready", True), ("host_id", "m3"),
                                 ("reviewed_cell_ids", original["reviewed_cell_ids"] + [scoped.select(self.plan)[3]["id"]])):
                changed = copy.deepcopy(original); changed[field] = value; write_json(path, changed)
                with self.subTest(field=field), self.assertRaises(ValueError):
                    scoped.verified_binding(self.plan, self.matrix, path)
            changed = copy.deepcopy(original); changed["models"]["gpt-oss-20b"] = {}
            write_json(path, changed)
            with self.assertRaisesRegex(ValueError, "non-Qwen"):
                scoped.verified_binding(self.plan, self.matrix, path)

    def test_changed_audit_inventory_or_model_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            path, _, _ = self.binding_fixture(Path(directory)); original = scoped.read(path)
            for field, value in (("directory", "/different/qwen38"), ("live_identity_verified_for_this_run", False),
                                 ("assistant_directory", "/different/assistant")):
                changed = copy.deepcopy(original); changed["models"]["qwen38"][field] = value; write_json(path, changed)
                with self.subTest(field=field), self.assertRaises(ValueError):
                    scoped.verified_binding(self.plan, self.matrix, path)
            audit = scoped.read(original["models"]["qwen38"]["identity_audit"]["path"])
            audit["files"].pop(next(iter(audit["files"])))
            original["models"]["qwen38"]["identity_audit"] = write_json(Path(directory) / "incomplete-audit.json", audit)
            write_json(path, original)
            with self.assertRaisesRegex(ValueError, "file inventory"):
                scoped.verified_binding(self.plan, self.matrix, path)

    def test_emitted_pilot_argv_preserves_profile_mtp_grant_and_no_launch(self):
        with tempfile.TemporaryDirectory() as directory:
            _, binding, ack = self.binding_fixture(Path(directory))
            with patch.object(Path, "is_dir", return_value=True), \
                 patch.object(self.matrix, "require_current_prompt_date"), \
                 patch.object(self.matrix.shutil, "disk_usage", return_value=shutil._ntuple_diskusage(10**12, 0, 10**12)):
                argv = scoped.command(self.plan, self.matrix, binding, scoped.select(self.plan)[0]["id"], ack)
            self.assertEqual(argv[:2], ["/usr/bin/env", "-i"])
            for flag, value in (("--mtp", "on"), ("--cache-mode", "ssd"), ("--concurrency", "4"),
                                ("--kv-backend", "contiguous"), ("--expected-model-sha256", scoped.identities(self.plan)["qwen38"]["aggregate_sha256"])):
                self.assertEqual(argv[argv.index(flag) + 1], value)
            self.assertIn("--production-kv-grant", argv)
            self.assertNotIn("--assistant-directory", argv)
            self.assertFalse((Path(directory) / "results").exists())
            for key, value in self.plan["serving_profile"].items():
                self.assertIn(key + "=" + value, argv)

    def test_ack_and_prior_failures_prevent_emission(self):
        with tempfile.TemporaryDirectory() as directory:
            _, binding, ack = self.binding_fixture(Path(directory)); cells = scoped.select(self.plan)
            with patch.object(self.matrix, "command") as native:
                with self.assertRaisesRegex(ValueError, "prior cell/comparison"):
                    scoped.command(self.plan, self.matrix, binding, cells[1]["id"], ack)
                record = scoped.read(ack); record["binding_sha256"] = "wrong"; write_json(ack, record)
                with self.assertRaisesRegex(ValueError, "acknowledgement"):
                    scoped.command(self.plan, self.matrix, binding, cells[0]["id"], ack)
                native.assert_not_called()

    def test_partial_endpoints_and_final_strict_acceptance(self):
        cells = scoped.select(self.plan, scoped.PILOT)
        with tempfile.TemporaryDirectory() as directory:
            binding = {"results_root": directory, "_binding_sha256": "fixture"}
            for index, cell in enumerate(cells):
                output = Path(directory) / cell["id"]
                write_json(output / "report.json", shape_report())
                write_json(output / "metadata.json", {"status": "completed", "exit_code": 0,
                           "matrix_host": {"id": "m5"}, "matrix_binding_sha256": "fixture",
                           "started_unix": index * 10, "ended_unix": index * 10 + 1})
            with patch.object(self.matrix, "cell_evidence_errors", return_value=[]), \
                 patch.object(self.matrix, "compare", return_value={"passed": True, "errors": []}):
                first = scoped.collect(self.plan, self.matrix, binding, cells[:1])
                self.assertTrue(first["completed_prefix_gates_passed"])
                self.assertFalse(first["all_selected_supported_cells_accepted"])
                self.assertEqual(first["comparisons"], [])
                final = scoped.collect(self.plan, self.matrix, binding, cells)
                self.assertTrue(final["all_selected_supported_cells_accepted"])
                self.assertEqual(len(final["comparisons"]), 2)
                self.assertFalse(final["all_matrix_requirements_accepted"])
                self.assertFalse(final["release_gates_satisfied"])
            with patch.object(self.matrix, "cell_evidence_errors", return_value=[]), \
                 patch.object(self.matrix, "compare", return_value={"passed": False, "errors": [{"token_ids": True}]}):
                self.assertFalse(scoped.collect(self.plan, self.matrix, binding, cells)["all_selected_supported_cells_accepted"])

    def test_exact_output_and_strict_backend_cache_axes(self):
        baseline = comparator_fixtures.TokenEvidenceTests().fixture()
        baseline["requested_backend"] = "contiguous"
        candidate = copy.deepcopy(baseline)
        candidate.update(requested_backend="paged", resolved_backend="paged")
        self.assertTrue(self.matrix.compare(baseline, candidate, axis="backend")["passed"])
        candidate["rows"][0]["token_ids"] = [12, 999]
        self.assertFalse(self.matrix.compare(baseline, candidate, axis="backend")["passed"])
        cache_off = comparator_fixtures.TokenEvidenceTests().fixture()
        cache_on = copy.deepcopy(cache_off); cache_on["rows"][0]["token_ids"] = [12, 999]
        self.assertFalse(self.matrix.compare(cache_off, cache_on, True, "cache")["passed"])

    def test_actual_width_overlap_and_sustained_gates(self):
        for width in (1, 2, 4):
            report = shape_report(width)
            self.assertTrue(self.matrix.actual_model_width_verified(report))
            self.assertTrue(self.matrix.required_width_observed(report, width, 10))
            self.assertEqual(self.matrix.long_decode_errors(self.plan["workloads"]["sustained"], report, width), [])
            for row in report["rows"]:
                row.update(completion_tokens=512, finish="stop")
            self.assertTrue(self.matrix.long_decode_errors(self.plan["workloads"]["sustained"], report, width))
        serial = shape_report(4)
        for batch in serial["batches"]:
            batch["forward_shapes"] = shape_fixtures.packet(rows=1, columns=4)
        self.assertFalse(self.matrix.actual_model_width_verified(serial))

    def test_expired_prompt_date_refused(self):
        with self.assertRaisesRegex(ValueError, "prompt date expired"):
            self.matrix.require_current_prompt_date(self.plan, "2026-09-07")

    def test_partial_collection_binding_order_and_width_fail_closed(self):
        cells = scoped.select(self.plan, scoped.PILOT)
        with tempfile.TemporaryDirectory() as directory:
            binding = {"results_root": directory, "_binding_sha256": "fixture"}
            for index, cell in enumerate(cells):
                output = Path(directory) / cell["id"]
                write_json(output / "report.json", shape_report())
                write_json(output / "metadata.json", {"status": "completed", "exit_code": 0,
                           "matrix_host": {"id": "m5"}, "matrix_binding_sha256": "fixture",
                           "started_unix": index * 10, "ended_unix": index * 10 + 1})
            metadata_path = Path(directory) / cells[1]["id"] / "metadata.json"
            original = scoped.read(metadata_path)
            with patch.object(self.matrix, "cell_evidence_errors", return_value=[]), \
                 patch.object(self.matrix, "compare", return_value={"passed": True, "errors": []}):
                for key, value in (("matrix_binding_sha256", "wrong"), ("started_unix", 0),
                                   ("started_unix", float("nan"))):
                    changed = dict(original); changed[key] = value; write_json(metadata_path, changed)
                    result = scoped.collect(self.plan, self.matrix, binding, cells)
                    self.assertFalse(result["completed_prefix_gates_passed"])
                    self.assertEqual(result["repeated_pair_summaries"], [])
                write_json(metadata_path, original)
                report = shape_report()
                for batch in report["batches"]:
                    batch["forward_shapes"] = shape_fixtures.packet(rows=1, columns=2)
                write_json(Path(directory) / cells[1]["id"] / "report.json", report)
                self.assertFalse(scoped.collect(self.plan, self.matrix, binding, cells)["completed_prefix_gates_passed"])
            with self.assertRaisesRegex(ValueError, "schedule order"):
                scoped.collect(self.plan, self.matrix, binding, list(reversed(cells)))

    def test_foreign_or_failed_result_root_refused(self):
        with tempfile.TemporaryDirectory() as directory:
            _, binding, ack = self.binding_fixture(Path(directory))
            (Path(binding["results_root"]) / "retained-failure").mkdir(parents=True)
            with patch.object(self.matrix, "command") as native:
                with self.assertRaisesRegex(ValueError, "result root"):
                    scoped.command(self.plan, self.matrix, binding, scoped.select(self.plan)[0]["id"], ack)
                native.assert_not_called()

    def test_collection_cli_failure_is_not_a_success_exit(self):
        with tempfile.TemporaryDirectory() as directory:
            path, _, _ = self.binding_fixture(Path(directory))
            argv = ["qwen_plan.py", "collect", "--bindings", str(path), "--cohort", scoped.PILOT]
            output = io.StringIO()
            with patch.object(sys, "argv", argv), contextlib.redirect_stdout(output):
                self.assertEqual(scoped.main(), 1)
            self.assertFalse(json.loads(output.getvalue())["all_selected_supported_cells_accepted"])

    def test_ownership_entry_checks_do_not_auto_ready(self):
        import importlib.util
        spec = importlib.util.spec_from_file_location("qwen_owner_fixture", scoped.ROOT / "ownership/owner_helper.py")
        owner = importlib.util.module_from_spec(spec); spec.loader.exec_module(owner)
        cool = {"gpu_temperature_c": 30, "load1": 1, "free_bytes": 200 * (1 << 30),
                "unexpected_processes": [], "owned_processes": []}
        self.assertEqual(owner.entry_refusal(cool), (None, False))
        for key, value in (("gpu_temperature_c", 43), ("load1", 5), ("gpu_temperature_c", float("nan")),
                           ("free_bytes", 100 * (1 << 30)), ("unexpected_processes", [123]), ("owned_processes", [456])):
            changed = dict(cool); changed[key] = value
            with self.subTest(key=key):
                self.assertIsNotNone(owner.entry_refusal(changed)[0])

    def test_frozen_predecessor_tree_unchanged(self):
        predecessor = Path(scoped.read(scoped.ROOT / "scope-change.json")["frozen_predecessor"])
        expected = scoped.read(scoped.ROOT / "provenance/frozen-tree-before.json")
        actual = {str(path.relative_to(predecessor)): {"bytes": path.stat().st_size, "sha256": scoped.digest(path)}
                  for path in predecessor.rglob("*") if path.is_file()}
        self.assertEqual(actual, expected)


if __name__ == "__main__":
    unittest.main()
