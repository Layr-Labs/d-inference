import json
C=json.loads('{"remote": "/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http6-q38", "output": "/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http6-q38/runs/qwen38-paged-off-b1-run", "review_sha": "91a25b23cb7be34e6bc3f35a63a2bc680bfaad96490cde7e4f1c3c5a385b6e35", "manifest_sha": "82e81db534ea14e80b3f3f2502949b25bc77768e887fdb2755fdab674dddbd0e", "binding_sha": "401c59e24a3acf88186e03eef9b48c86bbce372fefa6e1c7c9238ef693044b82"}')
from pathlib import Path
import hashlib,json
root=Path(C['output'])
launch=json.loads((root/'launch.json').read_text())
assert launch['status'] in ('completed','failed'), 'Remote cell may still be live; inspect its existing handle'
files={}
for name in ['launch.json','connected.log','evidence/report.json']:
 p=root/name
 if p.is_file():files[name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'root':str(root),'launch_status':launch['status'],'files':files},indent=2))
