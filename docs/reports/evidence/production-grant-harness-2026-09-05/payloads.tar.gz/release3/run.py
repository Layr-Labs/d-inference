from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,time
out=Path('/tmp/darkbloom-final-serving-build3');src=Path('/tmp/darkbloom-production-grant-harness-validation1');ws=src/'workspace';scratch=Path('/tmp/darkbloom-final-serving-build1/build');benchmark=out/'radix-engine';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();info=json.loads((out/'integration.json').read_text());results=[];environment=os.environ.copy();environment.update(info['environment'])
ns={};exec((src/'run.py').read_text().split("assert (policy / 'manifest.json').exists()")[0],ns)
def verify():
 verified=ns['verify']();assert sha(src/'manifest.json')==info['semantic_manifest_sha256']
 for p,row in json.loads((out/'compile-source-manifest.json').read_text())['files'].items():assert sha(out/p)==row['sha256'],p
 return verified
(out/'source-verified-before.json').write_text(json.dumps(verify(),indent=2)+'\n')
def run(name,command,cwd):
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:result=subprocess.run(command,cwd=cwd,env=environment,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'command':command,'cwd':str(cwd),'seconds':time.monotonic()-start,'exit_code':result.returncode};results.append(row);(out/'execution.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(row),flush=True)
 graph=scratch/'release.yaml'
 if graph.exists():(out/(name+'-graph.yaml.gz')).write_bytes(gzip.compress(graph.read_bytes(),mtime=0))
 state=scratch/'workspace-state.json'
 if state.exists():shutil.copy2(state,out/(name+'-package-state.json'))
 (out/(name+'-source-verified.json')).write_text(json.dumps(verify(),indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
 graph_text=graph.read_text();actuals=[ws/'provider-swift/Sources/ProviderCore/Inference/EngineV2Factory+BenchmarkGrant.swift',ws/'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVSegments.swift',Path(info['swift_source'])/'Source/MLX/AllocationFootprint.swift',Path(info['swift_source'])/'Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp']
 if name=='radix-release':actuals.append(benchmark/'Sources/radix-engine/BenchmarkOptions.swift')
 matches=[]
 for p in actuals:
  match=next((str(q) for q in [p,p.resolve(),Path(str(p).replace('/private/tmp/','/tmp/',1))] if str(q) in graph_text),None);assert match is not None,str(p);matches.append(match)
 assert '/checkouts/mlx-swift/Source/' not in graph_text
 for path,h in json.loads((src/'jinja-source-manifest.json').read_text())['files'].items():assert sha(scratch/'checkouts/swift-jinja'/path)==h,path
 (out/(name+'-actual-source-proof.json')).write_text(json.dumps({'matched_paths':matches,'remote_mlx_compile_source_absent':True,'exact_jinja_inputs_verified':27},indent=2)+'\n')
run('radix-release',['swift','build','-c','release','--scratch-path',str(scratch),'--jobs','4','--disable-automatic-resolution','--product','radix-engine'],benchmark)
release=scratch/'arm64-apple-macosx/release';artifact=out/'artifact';artifact.mkdir(exist_ok=True);metallib=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated/provider-swift/.build/arm64-apple-macosx/debug/mlx.metallib');shutil.copy2(metallib,release/'mlx.metallib')
for p in [release/'darkbloom',release/'radix-engine',release/'mlx.metallib',*sorted(release.glob('*.bundle'))]:
 if p.is_dir():shutil.copytree(p,artifact/p.name,dirs_exist_ok=True)
 else:shutil.copy2(p,artifact/p.name)
for name in ['darkbloom','radix-engine']:
 (out/(name+'-dylibs.txt')).write_text(subprocess.check_output(['otool','-L',str(artifact/name)],text=True))
files={str(p.relative_to(artifact)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(artifact.rglob('*')) if p.is_file()};(out/'artifact-manifest.json').write_text(json.dumps({'files':files,'metallib_source':str(metallib),'scope':'Exact candidate CLI/probe and beside-executable SwiftPM resource bundles.'},indent=2)+'\n');(out/'source-verified-after.json').write_text(json.dumps(verify(),indent=2)+'\n');print('RELEASE BINARIES AND SOURCES VERIFIED',flush=True)
