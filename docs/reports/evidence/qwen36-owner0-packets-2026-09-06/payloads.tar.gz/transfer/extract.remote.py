import json
C=json.loads('{"remote": "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1", "archive_sha": "f9824eba3447507da1670a7ca9c8c4243b14f25dbb789cbdb4fe8bd19cc4ac16", "manifest_sha": "21467d42b7e710d8303cb2690f79edb16d793241b919fa303d6acea888660fce", "review_sha": "bcef01db59932780e017de10bc6e3ed132f1a80fe6dbc6fd89659ef50cfce4cd", "binding_sha": "48cea7e3daa6fb0676ccc069891eb93170885d7ae85dc6540a155d4454df2cdc", "resources_copy_source": "/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact"}')
from pathlib import Path
import hashlib,json,stat,tarfile
root=Path(C['remote'])
assert hashlib.sha256((root/'binding-root-review.json').read_bytes()).hexdigest()==C['review_sha']
assert hashlib.sha256((root/'runtime-binding.json').read_bytes()).hexdigest()==C['binding_sha']
archive=root/'plan-package.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==C['archive_sha']
with tarfile.open(archive) as tar:
 members=tar.getmembers()
 assert len(members)==30 and len({m.name for m in members})==30
 for member in members:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  assert not (root/member.name).exists()
 tar.extractall(root)
assert hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()==C['manifest_sha']
manifest=json.loads((root/'manifest.json').read_text())
for name,item in manifest['files'].items():
 p=root/name;assert stat.S_ISREG(p.lstat().st_mode) and p.stat().st_size==item['bytes']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256'],name
(root/'runtime').mkdir(exist_ok=False)
print(json.dumps({'verified_plan_files':len(manifest['files']),'remote_root':str(root),'manifest_sha256':C['manifest_sha'],'inference_launched':False},indent=2))
