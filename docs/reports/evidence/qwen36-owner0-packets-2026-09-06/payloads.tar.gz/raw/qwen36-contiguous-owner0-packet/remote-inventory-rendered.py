import json
CONFIG = json.loads('{"output": "/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-packet1/runs/qwen36-contiguous-owner0-packet"}')
# Inventory only known evidence files; no prefix-cache/key payloads are copied.
from pathlib import Path
import hashlib
import json
import stat

root = Path(CONFIG['output']); files = {}; directories = {}; errors = []
allowed = {'input.json','report.json','metadata.json','engine.log','telemetry.jsonl'}
packet_files = {'packet.json','attention-metadata.json','queries.bin','incoming-keys.bin',
                'incoming-values.bin','stored-keys.bin','stored-values.bin','output.bin'}

def record(p):
    name = str(p.relative_to(root)); mode = p.lstat().st_mode
    if not stat.S_ISREG(mode): errors.append('nonregular evidence: '+name); return
    if p.stat().st_size > 64*1024*1024: errors.append('evidence file exceeds bounded transfer: '+name); return
    files[name] = {'bytes':p.stat().st_size,'mode':oct(stat.S_IMODE(mode)),
                   'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}

if root.exists():
    for p in sorted(root.iterdir()):
        if p.name in allowed: record(p)
        elif p.name == 'report.attention-packet':
            mode = p.lstat().st_mode
            if not stat.S_ISDIR(mode): errors.append('non-directory packet path'); continue
            directories[p.name] = {'mode':oct(stat.S_IMODE(mode))}
            for child in sorted(p.iterdir()):
                if child.name in packet_files: record(child)
                else: errors.append('unexpected packet member: '+child.name)
        elif p.name != 'prefix-cache': errors.append('unexpected run member: '+p.name)
print(json.dumps({'files':files,'directories':directories,'errors':errors}))
