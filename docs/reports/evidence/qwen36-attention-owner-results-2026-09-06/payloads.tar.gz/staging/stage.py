from pathlib import Path
import hashlib
import json
import shlex
import subprocess
import tarfile

OUT = Path('/tmp/darkbloom-q36-attention-owner-identity-staging1')
SOURCE = Path('/tmp/darkbloom-q36-attention-owner-identity-plan1')
REMOTE = '/Users/gaj/autoresearch/radix-prefix-cache/090-q36-attention-owner-identity1'
HOST = 'gaj@100.124.35.99'
OPTIONS = ['-i', '/Users/gaj/.ssh/darkbloom_testbox', '-o', 'IdentitiesOnly=yes',
           '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15']
SSH = ['ssh'] + OPTIONS + [HOST]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def remote(name, code):
    result = subprocess.run(SSH + ['python3 -B -'], input=code, text=True, capture_output=True)
    (OUT / (name + '.stdout')).write_text(result.stdout)
    (OUT / (name + '.stderr')).write_text(result.stderr)
    assert result.returncode == 0, name + ': ' + result.stderr
    return json.loads(result.stdout)


def main():
    manifest = SOURCE / 'manifest.json'
    assert sha(manifest) == 'ab6907c6e6d2efed1fbe56f0b0168964713fa95022d1783ca3b8aa00f2a29a48'
    inventory = dict(json.loads(manifest.read_text())['files'])
    inventory['manifest.json'] = {'bytes': manifest.stat().st_size, 'sha256': sha(manifest)}
    for name, row in inventory.items():
        path = SOURCE / name
        assert path.is_file() and not path.is_symlink()
        assert sha(path) == row['sha256'] and path.stat().st_size == row['bytes'], name
        assert path.stat().st_mode & 0o777 == int(row['mode'], 8) if 'mode' in row else True
        row['mode'] = path.stat().st_mode & 0o777
    (OUT / 'file-inventory.json').write_text(json.dumps(inventory, indent=2, sort_keys=True) + '\n')
    package = OUT / 'plan-package.tar.gz'
    with tarfile.open(package, 'x:gz') as tar:
        for name in sorted(inventory):
            tar.add(SOURCE / name, arcname=name, recursive=False)
    guards = '''from pathlib import Path
import datetime,json,os,shutil,subprocess,time
root=Path(ROOT)
processes=[]
for row in subprocess.check_output(['ps','-axo','pid=,ppid=,pgid=,args='],text=True).splitlines():
 parts=row.strip().split(None,3)
 if len(parts)!=4:continue
 markers=('Runner.Worker','benchctl measure-job','measure-job.sh','radix-engine','run_radix_engine.py','connected-e2e.test','run_connected_fixture.py')
 role=next((marker for marker in markers if marker in parts[3]),None)
 if role is None and Path(parts[3].split()[0]).name=='darkbloom':role='darkbloom'
 if role:processes.append({'pid':int(parts[0]),'ppid':int(parts[1]),'pgid':int(parts[2]),'role':role})
temp=json.loads(subprocess.check_output(['/Users/gaj/bench-runner/bin/macmon','pipe','-s','1','-i','200'],text=True,timeout=10).splitlines()[0])['temp']['gpu_temp_avg']
state={'unix_time':time.time(),'utc_date':datetime.datetime.now(datetime.timezone.utc).date().isoformat(),'processes':processes,'gpu_temp_c':temp,'load':os.getloadavg(),'free_bytes':shutil.disk_usage('/Users/gaj').free,'root_absent':not root.exists()}
print(json.dumps(state,indent=2))
assert not processes
assert temp<=42 and state['load'][0]<=4 and state['free_bytes']>100*1024**3
assert state['utc_date']=='2026-09-06' and state['root_absent']
'''.replace('ROOT', repr(REMOTE))
    preflight = remote('preflight', guards)
    remote('create', "from pathlib import Path\nimport json\nr=Path(" + repr(REMOTE) + ")\nr.mkdir(exist_ok=False)\nprint(json.dumps({'created':str(r),'runtime_bound':False}))\n")
    result = subprocess.run(['scp'] + OPTIONS + [str(package), HOST + ':' + REMOTE + '/plan-package.tar.gz'], text=True, capture_output=True)
    (OUT / 'scp.stdout').write_text(result.stdout)
    (OUT / 'scp.stderr').write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    verify = '''from pathlib import Path
import hashlib,json,tarfile
root=Path(ROOT);package=root/'plan-package.tar.gz';expected=INVENTORY
assert hashlib.sha256(package.read_bytes()).hexdigest()==PACKAGE_SHA
with tarfile.open(package,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(expected)
 assert {m.name for m in members}==set(expected)
 for member in members:
  assert member.isfile() and member.mode&0o777==expected[member.name]['mode']
  dest=root/member.name;assert not dest.exists()
  data=tar.extractfile(member).read();item=expected[member.name]
  assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);dest.chmod(item['mode'])
for name,item in expected.items():
 path=root/name;assert path.stat().st_size==item['bytes'] and path.stat().st_mode&0o777==item['mode']
 assert hashlib.sha256(path.read_bytes()).hexdigest()==item['sha256']
assert json.loads((root/'plan.json').read_text())['runtime_binding'] is None
assert not (root/'runtime').exists()
print(json.dumps({'files_verified':len(expected),'sha256_bytes_modes_match':True,'package_sha256':PACKAGE_SHA,'runtime_bound':False,'model_invoked':False},indent=2))
'''.replace('ROOT', repr(REMOTE)).replace('INVENTORY', repr(inventory)).replace('PACKAGE_SHA', repr(sha(package)))
    verified = remote('verify', verify)
    (OUT / 'receipt.json').write_text(json.dumps({'plan_manifest_sha256':sha(manifest),'remote_root':REMOTE,'preflight':preflight,'verification':verified,'package_bytes':package.stat().st_size},indent=2) + '\n')
    files = {str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(OUT.iterdir()) if p.is_file()}
    (OUT / 'manifest.json').write_text(json.dumps({'status':'plan staged only; runtime unbound; no model invocation','files':files},indent=2,sort_keys=True)+'\n')
    print(json.dumps({'root':str(OUT),'manifest_sha256':sha(OUT/'manifest.json'),'preflight':preflight,'verification':verified},indent=2))


if __name__ == '__main__':
    main()
