from pathlib import Path
import hashlib,json,shutil
out=Path('/tmp/darkbloom-final-serving-build8');provider=Path('/tmp/darkbloom-receipt-diagnostic-provider-validation1');harness=Path('/tmp/darkbloom-q36-diagnostic-harness-validation1');base=Path('/tmp/darkbloom-final-serving-build7');ws=out/'workspace'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,v):(out/name).write_text(json.dumps(v,indent=2)+'\n')
ws.mkdir();shutil.copytree(provider/'candidate/workspace/provider-swift',ws/'provider-swift');(ws/'libs').mkdir()
for name in ['mlx-swift','mlx-swift-lm']:(ws/'libs'/name).symlink_to((provider/'candidate/workspace/libs'/name).resolve(),target_is_directory=True)
shutil.copytree(harness/'radix-engine',out/'radix-engine')
shutil.copy2(provider/'candidate/provider-source-manifest.json',out/'provider-source-manifest.json')
for name in ['native-source-manifest.json','ancillary-package-manifest.json','dependency-source-manifest.json','jinja-source-manifest.json']:shutil.copy2(provider/name,out/name)
shutil.copy2(harness/'compile-source-manifest.json',out/'compile-source-manifest.json')
freezes=['/tmp/darkbloom-q36-logit-diagnostic-source/freeze2/manifest.json','/tmp/darkbloom-prefix-receipt-pump-ownership2/manifest.json','/tmp/darkbloom-logit-wrapper-forwarding1/manifest.json','/tmp/darkbloom-logit-wrapper-independent-review1/review.json','/tmp/darkbloom-q36-logit-diagnostic-validation3/manifest.json']
write('integration.json',{'scope':'Exact reviewed diagnostic native + benchmark + provider receipt fix; default policy and production kernels unchanged. Distinct coherent release probe and CLI, both rebuilt. No live model proof.','source_freezes':{x:sha(Path(x)) for x in freezes},'baseline_artifact_manifest':str(base/'artifact-manifest.json'),'baseline_artifact_manifest_sha256':sha(base/'artifact-manifest.json'),'provider_validation':str(provider),'harness_validation':str(harness),'scratch':'/tmp/darkbloom-final-serving-build1/build','environment':{'RADIX_SOURCE_ROOT':str(ws),'RADIX_CANDIDATE_BUILD':'1'},'remote_artifact_directory':'/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact','status':'prepared; release runner must require both validation PASS verdicts'})
write('package-resolution-inputs.json',{'files':{str(p):{'sha256':sha(p)} for p in [ws/'provider-swift/Package.resolved',out/'radix-engine/Package.resolved']}})
print('Prepared exact build8 union; no compilation run.')
