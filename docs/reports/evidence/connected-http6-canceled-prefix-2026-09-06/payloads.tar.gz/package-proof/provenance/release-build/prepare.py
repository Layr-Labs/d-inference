from pathlib import Path
import difflib, hashlib, io, json, shutil, subprocess, tarfile

out = Path(__file__).resolve().parent
primary = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
parent_commit = '98103b39741a48f9d47026be7393362318a2ab0a'
native_commit = 'dcf39f6b43effaa2b483211c97d7d3a3e7c0269b'
packet_native = Path('/tmp/darkbloom-attention-packet-native-validation1')
packet_harness = Path('/tmp/darkbloom-attention-packet-benchmark-validation1')
packet_source = Path('/tmp/darkbloom-attention-packet-capture-source1')
cancellation = Path('/tmp/darkbloom-provider-cancel-settlement-source6')
owner_probe = Path('/tmp/darkbloom-q36-attention-owner-identity-release-probe1')
local_mlx = Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift')
scratch = Path('/tmp/darkbloom-final-serving-build1/build')
workspace = out/'workspace'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value):
    (out/name).write_text(json.dumps(value, indent=2)+'\n')

def verify_manifest(path, expected):
    assert sha(path) == expected, path
    rows = json.loads(path.read_text())['files']
    if isinstance(rows, dict):
        rows = [{'path': name, **row} for name, row in rows.items()]
    for row in rows:
        payload = path.parent/row['path']
        assert sha(payload) == row['sha256'], payload
        if 'bytes' in row: assert payload.stat().st_size == row['bytes'], payload

freezes = {
    str(packet_native/'manifest.json'): 'beaf85286316000be32d3168dc2dce4c3db92e3038964de536e6ecbe2d26b875',
    str(packet_harness/'manifest.json'): '5bc73dabe7754c4bfb75556c8a1b827afb0fb172f63c47108790218e877950c0',
    str(packet_source/'manifest.json'): '45e11082b4422bac8d7b008e4cf6b046cde972d28ef5b3218348217cfda58982',
    str(cancellation/'manifest.json'): '793a46d46adf075e1d6c2e1abc6898c7c6b945b7e5b69eba9024739fd91c9498',
}
for path, digest in freezes.items(): verify_manifest(Path(path), digest)
assert json.loads((packet_native/'verdict.json').read_text())['status'].startswith('PASS')
assert json.loads((packet_harness/'verdict.json').read_text())['status'].startswith('PASS')
# Verify the banked cancellation archive, retaining the final reviewed test report.
evidence = primary/'docs/reports/evidence/canceled-prefix-settlement-2026-09-06'
assert sha(evidence/'manifest.json') == '12472f028fefacb846b587a70b7856f7c5f1b304c30cdc92e37913791b030ff3'
bank = json.loads((evidence/'manifest.json').read_text())
archive = evidence/bank['archive']['path']
assert sha(archive) == bank['archive']['sha256']
with tarfile.open(archive) as packed:
    expected = {row['path']: row for row in bank['files']}
    members = {m.name: m for m in packed.getmembers() if m.isfile()}
    assert set(members) == set(expected)
    for name, row in expected.items():
        data = packed.extractfile(members[name]).read()
        assert hashlib.sha256(data).hexdigest() == row['sha256'] and len(data) == row['bytes'], name
        if name in ['review/exact-test-results.json', 'review/integration-correspondence.json']:
            (out/('cancellation-'+Path(name).name)).write_bytes(data)
shutil.copy2(evidence/'manifest.json', out/'cancellation-banked-manifest.json')
shutil.copy2(primary/'docs/reports/2026-09-06-canceled-prefix-settlement.md', out/'cancellation-validation-scope.md')

def extract(repo, commit, destination, tree=None, prefix=None):
    args = ['git', 'archive']
    if prefix: args += ['--prefix='+prefix]
    args += [commit + (':'+tree if tree else '')]
    payload = subprocess.check_output(args, cwd=repo)
    with tarfile.open(fileobj=io.BytesIO(payload)) as packed:
        packed.extractall(destination, filter='data')

def rows(root, relative):
    return {str(p.relative_to(relative)): sha(p) for p in sorted(root.rglob('*')) if p.is_file()}

workspace.mkdir()
extract(primary, parent_commit, workspace, 'provider-swift', 'provider-swift/')
extract(primary, parent_commit, out, 'scripts/benchmarks/radix-engine', 'radix-engine/')
(out/'native').mkdir()
extract(primary/'libs/mlx-swift-lm', native_commit, out/'native')
canonical_provider = rows(workspace/'provider-swift', workspace)
canonical_native = rows(out/'native', out/'native')
canonical_harness = rows(out/'radix-engine', out)
assert canonical_native == json.loads((packet_native/'native-source-manifest.json').read_text())['canonical_files']
assert canonical_harness == json.loads((packet_harness/'harness-source-manifest.json').read_text())['canonical_files']
old_provider = json.loads((packet_harness/'provider-source-manifest.json').read_text())['canonical_files']
delta = {name: {'before_sha256': old_provider.get(name), 'after_sha256': canonical_provider.get(name)}
         for name in sorted(set(old_provider)|set(canonical_provider))
         if old_provider.get(name) != canonical_provider.get(name)}
assert len(delta) == 8, delta
for name, row in delta.items():
    frozen = cancellation/'candidate'/name
    assert frozen.is_file() and sha(frozen) == row['after_sha256'], name
    row['bytes'] = frozen.stat().st_size
    row['matches_cancellation_source6'] = True
write('provider-delta-from-packet-validation.json', delta)
# Overlays affect dependency resolution only; native and serving source bytes stay banked.
for name, package, old in [
    ('provider', workspace/'provider-swift/Package.swift', '.package(path: "../libs/mlx-swift")'),
    ('native', out/'native/Package.swift', '.package(url: "https://github.com/Layr-Labs/mlx-swift.git", branch: "main")'),
]:
    before = package.read_text()
    assert before.count(old) == 1, (name, old)
    after = before.replace(old, '.package(path: "'+str(local_mlx)+'")')
    package.write_text(after)
    (out/(name+'-package-compile-only-overlay.patch')).write_text(''.join(difflib.unified_diff(
        before.splitlines(keepends=True), after.splitlines(keepends=True),
        fromfile='canonical/'+name+'/Package.swift', tofile='compiled/'+name+'/Package.swift')))
provider_pin = packet_harness/'workspace/provider-swift/Package.resolved'
native_pin = packet_native/'native/Package.resolved'
assert sha(provider_pin) == 'b2b12d24d48bbedc4583d8831e0b81fe68b96d641804e0ebc56715cd2d88a7ea'
assert sha(native_pin) == '4bf9d78d1ce65d7458d881a7f27854da04c728fff7f6fe429a9255e9245ebaef'
for target, origin in [(workspace/'provider-swift/Package.resolved', provider_pin),
                       (out/'radix-engine/Package.resolved', provider_pin),
                       (out/'native/Package.resolved', native_pin)]: shutil.copy2(origin, target)
(workspace/'libs').mkdir()
(workspace/'libs/mlx-swift').symlink_to(local_mlx, target_is_directory=True)
(workspace/'libs/mlx-swift-lm').symlink_to(out/'native', target_is_directory=True)
groups = {}
for name, root, relative, canonical, commit in [
    ('provider', workspace/'provider-swift', workspace, canonical_provider, parent_commit),
    ('native', out/'native', out/'native', canonical_native, native_commit),
    ('harness', out/'radix-engine', out, canonical_harness, parent_commit),
]:
    actual = rows(root, relative)
    write(name+'-source-manifest.json', {'commit': commit, 'canonical_files': canonical, 'files': actual})
    groups[name] = {'commit': commit, 'canonical_inputs': len(canonical), 'compile_inputs': len(actual)}
for name in ['dependency-source-manifest.json', 'jinja-source-manifest.json', 'pinned-availability-api.json']:
    shutil.copy2(packet_native/name, out/name)
deps = json.loads((out/'dependency-source-manifest.json').read_text())
for key, digest in deps['files'].items():
    alias, name = key.split('/', 1)
    assert sha(Path(deps['repositories'][alias])/name) == digest, key
for name, digest in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():
    assert sha(scratch/'checkouts/swift-jinja'/name) == digest, name
for row in json.loads((out/'pinned-availability-api.json').read_text())['files'].values():
    assert sha(Path(row['path'])) == row['sha256']
shutil.copy2(owner_probe/'runtime-resource-inputs.json', out/'runtime-resource-inputs.json')
for name, row in json.loads((out/'runtime-resource-inputs.json').read_text()).items():
    p = Path('/tmp/darkbloom-final-serving-build8/artifact')/name
    assert sha(p) == row['sha256'] and p.stat().st_size == row['bytes'], name
for name, root in [('native-validation', packet_native), ('harness-validation', packet_harness),
                   ('packet-source', packet_source), ('cancellation-source', cancellation)]:
    shutil.copy2(root/'manifest.json', out/(name+'-manifest.json'))
write('package-resolution-inputs.json', {'files': {str(p): {'sha256': sha(p)} for p in [
    workspace/'provider-swift/Package.resolved', out/'native/Package.resolved', out/'radix-engine/Package.resolved']}})
write('source-union.json', {
    'parent_commit': parent_commit, 'native_commit': native_commit, 'groups': groups,
    'native_and_harness_match_packet_validation_canonical_sources_exactly': True,
    'provider_delta_from_packet_validation': 'provider-delta-from-packet-validation.json',
    'provider_delta_matches_banked_cancellation_source6': True,
    'validation_scope': 'Packet native: 77 functions/162 cases, benchmark:18 functions, wrappers:14. Cancellation:76 function executions/73 distinct against native5cb; separate frozen evidence. This exact combined provider981/native dcf union has not yet had a real-model HTTP or packet run.',
    'namespace_included': False, 'uncommitted_candidates_included': False,
})
write('integration.json', {
    'status': 'PREPARED_NO_SWIFT_PROCESS_STARTED', 'parent_commit': parent_commit,
    'native_commit': native_commit, 'scratch': str(scratch), 'source_freezes': freezes,
    'banked_cancellation_manifest': str(evidence/'manifest.json'),
    'banked_cancellation_manifest_sha256': sha(evidence/'manifest.json'),
    'banked_cancellation_archive': str(archive), 'banked_cancellation_archive_sha256': sha(archive),
    'environment': {'RADIX_SOURCE_ROOT': str(workspace), 'RADIX_CANDIDATE_BUILD': '1'},
    'products': ['radix-engine', 'darkbloom'], 'resources': 6,
    'authorization_requirement': 'Explicit root source-union review AND sole Swift lane handoff before run.py. No remote/model/key/default operations.',
})
print(json.dumps({'status': 'PREPARED_NO_SWIFT_PROCESS_STARTED', 'groups': groups,
                  'cancellation_delta': len(delta), 'dependency_inputs': len(deps['files'])}, indent=2))
