# Packet native validation preparation

Source only: no Swift invocation has occurred. Root must explicitly hand off the
local Swift lane before `run.py` executes.

The package is the archived native e972340 commit plus exactly 15 source1 files.
All before/after bytes match the approved freeze and live candidate. There are
906 canonical files and one pinned Package.resolved. The only compile overlay
replaces the remote MLX package reference with the previously validated local
dependency path. Dependencies (1,356 files), Jinja (27), and five availability,
native-copy and asyncEval implementation files were independently rehashed.

Thirteen selected native filters cover the new packet roundtrip/lifetime/actual
engine suites, owner mapping and metadata controls, ordinary logits/recurrent
state, and existing paged dtype/kernel/segment suites. Expected selection is
77 functions; successful execution and expanded cases will be read from raw logs.
The build graph must contain every changed source plus the pinned Cmlx/MLX
implementation sources, without a remote MLX source tree. Header identity is
checked separately. Graph membership is not a claim that every source is linked
into the selected product.

Build failure stops the driver before any test or stale binary can be accepted.
Every filter's actual nonzero selection and lack of skips is verified. Source
hashes are checked before compilation, after compilation and after all tests.
The established metallib hash is checked before copying it beside the test binary.

`freeze.py` can run only after all expected filters pass. Any source correction
requires preserving this attempt and preparing a newly reviewed successor.
