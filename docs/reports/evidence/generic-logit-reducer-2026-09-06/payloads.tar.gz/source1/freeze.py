from pathlib import Path
import hashlib,json,re,subprocess

out=Path(__file__).resolve().parent
worktree=Path('/Users/gaj/Documents/DarkbloomDev/wt/logit-diagnostic-generic-reducer')
native=worktree/'libs/mlx-swift-lm'
base='dcf39f6b43effaa2b483211c97d7d3a3e7c0269b'
sha=lambda b:hashlib.sha256(b).hexdigest()

def original(path):return subprocess.check_output(['git','show',base+':'+path],cwd=native)
old=original('Libraries/MLXLLM/Models/Qwen35MTPTopTwo.swift').decode()
new=(native/'Libraries/MLXLMCommon/ContinuousBatchingV2/CBv2TopTwo.swift').read_text()
old_strings=re.findall(r'"""(.*?)"""',old,re.S);new_strings=re.findall(r'"""(.*?)"""',new,re.S)
assert len(old_strings)==len(new_strings)==3 and old_strings==new_strings
old_names=re.findall(r'name: "([^"]+)"',old);new_names=re.findall(r'name: "([^"]+)"',new)
assert old_names==new_names and len(old_names)==2
old_body=old.split('func qwen35MTPTopTwoRows',1)[1].split('{',1)[1]
new_body=new.split('package func cbv2TopTwoRows',1)[1].split('{',1)[1]
normalized=old_body.replace('qwen35MTPTopTwoPartialKernel','cbv2TopTwoPartialKernel').replace('qwen35MTPTopTwoFinalizeKernel','cbv2TopTwoFinalizeKernel')
assert normalized==new_body
proof={'metal_multiline_strings_byte_identical':True,'metal_string_sha256':[sha(s.encode()) for s in old_strings],
 'pipeline_names_unchanged':old_names,'launch_and_return_body_exact_after_private_host_symbol_rename':True,
 'kernel_algorithm_ties_NaN_strides_grid_threads_output_dtypes_unchanged':True}
(out/'kernel-extraction-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
paths=subprocess.check_output(['git','diff','--name-only',base],cwd=native,text=True).splitlines()
assert len(paths)==9,paths
files={}
for name in paths:
 result=subprocess.run(['git','show',base+':'+name],cwd=native,stdout=subprocess.PIPE,stderr=subprocess.DEVNULL)
 current=(native/name).read_bytes()
 files[name]={'before_sha256':sha(result.stdout) if result.returncode==0 else None,'after_sha256':sha(current),'bytes':len(current)}
 target=out/'sources'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(current)
 if result.returncode==0:
  before=out/'before'/name;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes(result.stdout)
unchanged=['Libraries/MLXLLM/Models/Qwen35.swift','Libraries/MLXLLM/Models/Gemma4.swift',
 'Libraries/MLXLMCommon/ContinuousBatchingV2/MTP/MTPContractsV2.swift',
 'Libraries/MLXLMCommon/ContinuousBatchingV2/MTP/CBv2MTPRoundDriver.swift',
 'Libraries/MLXLMCommon/ContinuousBatchingV2/MTP/EngineLoopV2+MTPExecution.swift',
 'Libraries/MLXLMCommon/ContinuousBatchingV2/MTP/EngineLoopV2+MTPTargetVerification.swift',
 'Libraries/MLXLMCommon/ContinuousBatchingV2/SteppableAdapterV2.swift']
identity={}
for name in unchanged:
 b=original(name);assert b==(native/name).read_bytes();identity[name]={'sha256':sha(b),'bytes':len(b)}
(out/'policy-and-model-source-unchanged.json').write_text(json.dumps(identity,indent=2)+'\n')
(out/'native.patch').write_bytes(subprocess.check_output(['git','diff','--binary',base],cwd=native))
(out/'source-proof.json').write_text(json.dumps({'parent_base':'1be058a6b14945ee50ef3b376a57bdf34946aad0','native_base':base,'worktree':str(worktree),'files':files},indent=2)+'\n')
check=subprocess.run(['git','diff','--check'],cwd=native,text=True,capture_output=True)
(out/'diff-check.txt').write_text(check.stdout+check.stderr);assert check.returncode==0
print(json.dumps({'changed_files':len(files),'kernel_extraction':proof,'Swift_started':False},indent=2))
