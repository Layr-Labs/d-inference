from pathlib import Path
import gzip,hashlib,json,re,shutil
out=Path('/tmp/darkbloom-q35-mtp-useful-tail-validation1');native=out/'native';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
results=json.loads((out/'execution.json').read_text());assert len(results)==11 and all(x['exit_code']==0 and x['nonzero_no_skips'] for x in results)
ids=[x.strip() for x in (out/'identifiers.log').read_text().splitlines() if x.startswith('MLXLMTests.')]
selected={};cases=0
for name in json.loads((out/'filters.json').read_text()):
 rows=[x for x in ids if name in x];assert rows
 body=(out/(name+'.log')).read_text();swift=re.findall(r'Test run with (\d+) tests?(?: in (\d+) suites?)? passed',body);xct=re.findall(r'Executed (\d+) tests?, with 0 failures',body)
 count=max([int(x[0]) for x in swift]+[int(x) for x in xct]+[0]);assert count==len(rows),(name,count,len(rows))
 assert not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',body,re.M)
 selected[name]={'identifiers':rows,'function_count':count,'case_count':count,'log_sha256':sha(out/(name+'.log')),'framework':'XCTest' if name=='CBv2MTPCaptureVerifyTests' else 'Swift Testing'};cases+=count
unique={x for group in selected.values() for x in group['identifiers']};assert len(unique)==cases==126
(out/'selected-identifiers.json').write_text(json.dumps(selected,indent=2)+'\n')
manifest=json.loads((out/'native-source-manifest.json').read_text());deps=json.loads((out/'dependency-source-manifest.json').read_text());known={str((native/name).resolve()):{'sha256':digest,'group':'native'} for name,digest in manifest['files'].items()}
for key,digest in deps['files'].items():
 alias,name=key.split('/',1);known[str((Path(deps['repositories'][alias])/name).resolve())]={'sha256':digest,'group':'dependency'}
for name,digest in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():known[str((Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift/checkouts/swift-jinja')/name).resolve())]={'sha256':digest,'group':'jinja'}
graph=gzip.decompress((out/'actual-build-graph.yaml.gz').read_bytes()).decode();matched={}
for path in re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',graph):
 p=Path(path);row=known.get(str(p.resolve()))
 if row is None:continue
 assert sha(p)==row['sha256'],path;matched[path]={'resolved_frozen_source':str(p.resolve()),**row}
(out/'all-owned-graph-source-proof.json').write_text(json.dumps({'scope':'Planned compiler inputs under frozen source maps match exact bytes; executed selected tests are recorded separately.','counts':{g:sum(x['group']==g for x in matched.values()) for g in ['native','dependency','jinja']},'files':matched},indent=2)+'\n')
owned=[]
for row in manifest['candidate_changes']:
 path=row['path'];assert sha(native/path)==row['after']['sha256'];target=out/'owned'/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(native/path,target);owned.append({'path':path,'before_sha256':row['before']['sha256'] if row['before'] else None,'after_sha256':row['after']['sha256'],'tested_source':str(native/path)})
(out/'canonical-owned-manifest.json').write_text(json.dumps({'base':manifest['base'],'files':owned,'source_patch_sha256':sha(out/'useful-tail.patch')},indent=2)+'\n')
summary={'status':'PASS','scope':'Useful output-tail common planner bounds and requested hermetic native MTP regression suites. No exact-fleet model, HTTP, latency, or normal-Q35 parity success is claimed.','test_functions':126,'test_cases':126,'new_policy_tests':5,'existing_regression_tests':121,'failed':0,'skipped':0,'source_changes':2,'native_inputs':481,'dependency_inputs':1356,'jinja_inputs':27,'build_seconds':results[0]['seconds'],'source_corrections':[],'prior_baseline_logs_retained':8,'original_normal_q35_parity_gate':'not rerun; remains unresolved','next_gate':'Distinct serving probe using exact build5 harness and this native candidate; normal MTP Q35 off/SSD pairs at maxTokens32 and longer output.'}
(out/'verdict.json').write_text(json.dumps(summary,indent=2)+'\n')
files={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.relative_to(out).parts[0]!='native' and p.relative_to(out)!=Path('manifest.json')}
(out/'manifest.json').write_text(json.dumps({'schema':1,'status':'PASS: native unit validation only','files':files,'source_patch_sha256':sha(out/'useful-tail.patch'),'test_binary':json.loads((out/'test-binary.json').read_text())},indent=2)+'\n')
print(json.dumps({'manifest_sha256':sha(out/'manifest.json'),'payloads':len(files),'verdict':summary},indent=2))
