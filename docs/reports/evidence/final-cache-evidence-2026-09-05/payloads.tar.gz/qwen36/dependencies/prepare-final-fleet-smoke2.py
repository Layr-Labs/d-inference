from pathlib import Path
import copy,hashlib,json,subprocess,base64
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out=Path('/tmp/darkbloom-final-fleet-smoke2');out.mkdir(exist_ok=False);(out/'inputs').mkdir()
original=Path('/tmp/darkbloom-0.9-validation/inputs/qwen35-serial-smoke.json');base=json.loads(original.read_text())
plan=copy.deepcopy(json.loads(Path('/tmp/darkbloom-final-fleet-smoke1/plan.json').read_text()))
for model in plan['models']:
 source=copy.deepcopy(base);source['rows']=source['rows'][:2]
 source['purpose']='Exact fleet first serving smoke with complete original longer prompt, exact repeat, normal MTP, tenant controls and primed restore cancellation. Actual runtime token count is authoritative.'
 source['source_input']={'path':str(original),'sha256':sha(original),'transformation':'Keep complete original first/repeat messages without truncation, set max_tokens32 and exact model ID; case names only changed.'}
 for i,row in enumerate(source['rows']):
  row['case']={'id':'long-'+('first' if i==0 else 'repeat'),'kind':'first' if i==0 else 'repeat','target_length':None,'max_tokens':32}
  if i:row['case']['equal_to']='long-first'
  row['request']['model']=model['model_id'];row['request']['max_tokens']=32
 p=out/'inputs'/f"{model['label']}.json";p.write_text(json.dumps(source,indent=2,sort_keys=True)+'\n')
 model['input']=str(p);model['input_sha256']=sha(p)
plan['threshold']='Full original 35273-character user prompt; runtime actual token counts authoritative. Normal Qwen MoE solo stripe 2048, dense Qwen stripe4096. Capture requires an interior aligned chunk boundary, independently of SSD minimum1024. Require actual restored cancellation evidence; no fabricated captured-token metric.'
plan['prior_expected_cold']='smoke1 wrapper1 had1607 tokens, one prefill chunk, zero writes/hits; SSD construction passed but reuse gate failed. It remains preserved and is not a positive cache proof.'
(out/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
old=Path('/tmp/run-final-model-cell-fixed1.py').read_text()
new=old.replace("local=Path('/tmp/darkbloom-final-fleet-smoke1')","local=Path('/tmp/darkbloom-final-fleet-smoke2')").replace("-b1-wrapper1'","-b1-smoke2'").replace("pkg+'/inputs/'+label+'.json'","remote+'/smoke2-inputs/'+label+'.json'")
assert new!=old
Path('/tmp/run-final-model-cell-smoke2.py').write_text(new)
files={p.name:{'sha256':sha(p),'data':base64.b64encode(p.read_bytes()).decode()} for p in (out/'inputs').glob('*.json')}
remote='/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-smoke1/smoke2-inputs'
code="""from pathlib import Path
import hashlib,json,base64
root=Path(REMOTE);root.mkdir(exist_ok=False)
files=FILES
for name,item in files.items():
 assert Path(name).name==name
 data=base64.b64decode(item['data']);assert hashlib.sha256(data).hexdigest()==item['sha256']
 (root/name).write_bytes(data)
print(json.dumps({'root':str(root),'files':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in root.iterdir()}},indent=2))
""".replace('REMOTE',repr(remote)).replace('FILES',repr(files))
ssh=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99','python3 -']
r=subprocess.run(ssh,input=code,capture_output=True,text=True);(out/'input-transfer.stdout').write_text(r.stdout);(out/'input-transfer.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr
proof=json.loads(r.stdout)
for name,item in files.items():assert proof['files'][name]['sha256']==item['sha256']
(out/'input-transfer.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({'plan':str(out/'plan.json'),'sha256':sha(out/'plan.json'),'inputs':len(files),'transfer':'verified'},indent=2))
