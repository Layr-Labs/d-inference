from pathlib import Path
import copy
import json
import subprocess
import tempfile
import unittest
from unittest.mock import patch

import controller
from bind_runtime import candidate_binding
from common import ROOT, digest, identity, read_json
from compare_contexts import collect_comparison, compare_reports
from test_fixtures import fixture, invocation, save


def artifact_fixture(root):
    template = read_json(ROOT / 'binding-template.json')
    artifact = root / 'artifact'
    artifact.mkdir()
    for name, mode in template['expected_runtime_modes'].items():
        path = artifact / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(('CPU fixture only, never executed: ' + name).encode())
        path.chmod(mode)
    manifest = {'source': template['expected_runtime_source'],
                'files': {name: identity(artifact / name) for name in template['expected_runtime_modes']}}
    manifest_path = root / 'artifact-manifest.json'
    save(manifest_path, manifest)
    review_path = root / 'root-review.json'
    save(review_path, {'source': manifest['source'], 'artifact_manifest_sha256': digest(manifest_path)})
    return template, artifact, manifest_path, review_path


def scoring_fixture():
    value = {'promptTokens': [1, 2], 'continuation': [3, 4]}
    model = {'model_id': 'cpu-fixture', 'input_sha256': 'fixture-input', 'prompt_tokens': 2, 'continuation_tokens': 2}
    left = {'input': value, 'inputSHA256': model['input_sha256'], 'resolvedBackend': 'contiguous',
            'diagnostic': {'records': [{'index': index, 'contextLength': 2 + index, 'forcedToken': forced,
                                        'argMaxID': 7, 'nllBits': 1056964608, 'forcedLogProbabilityBits': 3204448256}
                                       for index, forced in enumerate(value['continuation'])]},
            'meanForcedTokenNLL': 0.5, 'activity': [{'prefillChunks': 1, 'decodeForwards': 1}] * 3}
    right = copy.deepcopy(left)
    right['resolvedBackend'] = 'paged'
    return model, value, left, right


class PreparationTests(unittest.TestCase):
    def test_binding_records_real_fixture_hashes_but_cannot_self_approve(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            template, artifact, manifest, review = artifact_fixture(root)
            result = candidate_binding(template, artifact, manifest, review, digest(review),
                                       '/remote/new-runtime', '/remote/new-runtime-manifest.json')
            self.assertEqual(result['state'], 'awaiting_peer_review')
            self.assertEqual(result['runtime']['source'], template['expected_runtime_source'])
            self.assertEqual(result['runtime']['files'], read_json(manifest)['files'])
            self.assertEqual(result['required_metallib_sha256'], digest(artifact / 'mlx.metallib'))
            self.assertIsNone(template['runtime'])
            self.assertIsNone(template['required_metallib_sha256'])

    def test_binding_refuses_wrong_source_review_and_changed_artifact(self):
        for fault in ('source', 'review-source', 'review-manifest', 'review-hash', 'artifact-byte', 'inventory', 'mode'):
            with self.subTest(fault=fault), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary).resolve()
                template, artifact, manifest, review = artifact_fixture(root)
                m, r = read_json(manifest), read_json(review)
                if fault == 'source':
                    m['source']['native'] = 'f' * 40
                    save(manifest, m)
                    r['source'] = m['source']
                    r['artifact_manifest_sha256'] = digest(manifest)
                elif fault == 'review-source':
                    r['source']['native'] = 'f' * 40
                elif fault == 'review-manifest':
                    r['artifact_manifest_sha256'] = 'f' * 64
                elif fault == 'artifact-byte':
                    (artifact / 'darkbloom').write_bytes(b'changed')
                elif fault == 'inventory':
                    m['files'].pop('radix-engine')
                    save(manifest, m)
                    r['artifact_manifest_sha256'] = digest(manifest)
                elif fault == 'mode':
                    (artifact / 'darkbloom').chmod(0o644)
                    m['files']['darkbloom'] = identity(artifact / 'darkbloom')
                    save(manifest, m)
                    r['artifact_manifest_sha256'] = digest(manifest)
                save(review, r)
                review_hash = 'f' * 64 if fault == 'review-hash' else digest(review)
                with self.assertRaises(ValueError):
                    candidate_binding(template, artifact, manifest, review, review_hash,
                                      '/remote/new-runtime', '/remote/new-runtime-manifest.json')

    def test_backend_differences_are_observations_but_contexts_must_match(self):
        model, value, left, right = scoring_fixture()
        right['diagnostic']['records'][0].update(argMaxID=8, nllBits=1065353216)
        result = compare_reports(model, value, left, right)
        self.assertEqual(result['argmax_mismatch_indices'], [0])
        self.assertEqual(result['records'][0]['paged_minus_contiguous_nll'], 0.5)
        self.assertNotIn('passed', result)
        self.assertNotIn('threshold', result)
        right['diagnostic']['records'][0]['contextLength'] += 1
        with self.assertRaises(ValueError):
            compare_reports(model, value, left, right)

    def test_comparison_revalidates_all_four_cpu_fixture_cells(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            plan, binding = fixture(root)
            for cell in plan['cells']:
                completed = subprocess.run(invocation(root, cell['id']), capture_output=True, text=True, timeout=30)
                self.assertEqual(completed.returncode, 0, completed.stderr)
            with patch.object(controller, 'ROOT', root):
                report = collect_comparison(root, plan, binding, digest(root / 'binding.json'))
                self.assertEqual(report['status'], 'observed')
                self.assertEqual(len(report['cell_evidence']), 4)
                self.assertEqual(set(report['models']), {'qwen36', 'gemma-qat4'})
                # Even the final cell must retain its complete receipt, not just an observed summary.
                (root / 'results/gemma-qat4-paged/report.json').unlink()
                with self.assertRaises((ValueError, FileNotFoundError)):
                    collect_comparison(root, plan, binding, digest(root / 'binding.json'))


if __name__ == '__main__':
    unittest.main()
