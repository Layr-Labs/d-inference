from pathlib import Path
import gzip,hashlib,json,re,shutil
out=Path('/tmp/darkbloom-final-serving-build5');freeze=Path('/tmp/darkbloom-benchmark-coherent-idle/freeze1');base=Path('/tmp/darkbloom-production-grant-harness-validation1');ws=out/'workspace'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=json.loads((out/'execution.json').read_text());assert [x['name'] for x in rows]==['tests','release'];assert all(x['exit_code']==0 for x in rows)
assert json.loads((out/'test-verdict.json').read_text())['test_functions']==8
known={}
def add(path,digest,group):
 key=str(path.resolve());prior=known.get(key);assert prior is None or prior['sha256']==digest,key
 known[key]={'sha256':digest,'group':group}
for path,digest in json.loads((out/'provider-source-manifest.json').read_text())['files'].items():add(ws/path,digest,'provider')
for path,digest in json.loads((base/'native-source-manifest.json').read_text())['files'].items():add(ws/'libs/mlx-swift-lm'/path,digest,'native')
deps=json.loads((base/'dependency-source-manifest.json').read_text())
for path,digest in deps['files'].items():
 alias,relative=path.split('/',1);add(Path(deps['repositories'][alias])/relative,digest,'dependency')
for path,digest in json.loads((base/'jinja-source-manifest.json').read_text())['files'].items():add(Path('/tmp/darkbloom-final-serving-build1/build/checkouts/swift-jinja')/path,digest,'jinja')
for path,row in json.loads((out/'compile-source-manifest.json').read_text())['files'].items():add(out/path,row['sha256'],'harness')
for label in ['tests','release']:
 graph=gzip.decompress((out/(label+'-graph.yaml.gz')).read_bytes()).decode();entries={}
 for literal in re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',graph):
  path=Path(literal);key=str(path.resolve())
  if key not in known:continue
  row=known[key];assert sha(path)==row['sha256'],literal
  entries[literal]={'resolved_frozen_source':key,**row}
 assert any('BenchmarkIdleObservation.swift' in path for path in entries)
 if label=='tests':assert any('BenchmarkIdleObservationTests.swift' in path for path in entries)
 counts={group:sum(row['group']==group for row in entries.values()) for group in ['provider','native','dependency','jinja','harness']}
 (out/(label+'-all-owned-graph-source-proof.json')).write_text(json.dumps({'scope':'Every graph source input under the explicitly frozen source maps resolves to matching bytes. Graph membership is planned compilation input, not a claim that every package target ran. Actual test/build commands and logs are retained separately.','counts':counts,'files':entries},indent=2)+'\n')
canonical=[]
for row in json.loads((freeze/'source-hashes.json').read_text()):
 path=row['path'];tested=out/'radix-engine'/Path(path).relative_to('scripts/benchmarks/radix-engine');assert sha(tested)==row['after_sha256']
 owned=out/'owned'/path;owned.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(tested,owned)
 canonical.append({**row,'tested_source':str(tested),'frozen_owned_source':str(owned)})
(out/'canonical-owned-manifest.json').write_text(json.dumps({'files':canonical,'source_patch_sha256':sha(freeze/'source.patch')},indent=2)+'\n')
shutil.copy2(freeze/'source.patch',out/'idle-after-final-harness.patch')
art=json.loads((out/'artifact-manifest.json').read_text())
for path,row in art['files'].items():assert sha(out/'artifact'/path)==row['sha256']
summary={'status':'PASS','scope':'Eight focused pure Swift idle-observation tests plus final standalone release compilation; no model or HTTP execution. Serving sources unchanged from build4.','tests':{'functions':8,'cases':8,'failed':0,'skipped':0},'execution':rows,'standalone_binary':art['files']['radix-engine'],'source_patch_sha256':sha(out/'idle-after-final-harness.patch'),'canonical_paths':len(canonical),'provider_inputs':677,'native_inputs':480,'dependency_inputs':1356,'jinja_inputs':27,'runtime_resource_files':len(art['files'])-1,'no_cli_rebuild':True,'no_model_run':True}
(out/'verdict.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
for path in sorted(out.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(out)
 if rel.parts[0] in ['workspace','artifact','radix-engine'] or rel.name=='manifest.json':continue
 files[str(rel)]={'sha256':sha(path),'bytes':path.stat().st_size}
(out/'manifest.json').write_text(json.dumps({'schema':1,'status':'PASS: focused Swift tests and standalone release; real models pending','files':files,'runtime_artifacts':art,'source_patch_sha256':summary['source_patch_sha256']},indent=2)+'\n')
print(json.dumps({'manifest_sha256':sha(out/'manifest.json'),'payloads':len(files),'verdict':summary},indent=2))
