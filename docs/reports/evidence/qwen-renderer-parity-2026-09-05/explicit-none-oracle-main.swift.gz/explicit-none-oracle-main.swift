import Foundation
import Jinja
struct Row: Codable { let template: String; let output: String?; let error: String? }
var rows: [Row] = []
for source in CommandLine.arguments.dropFirst() {
    do { rows.append(Row(template: source, output: try Template(source).render([:]), error: nil)) }
    catch { rows.append(Row(template: source, output: nil, error: String(describing: error))) }
}
let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys, .prettyPrinted]
print(String(decoding: try encoder.encode(rows), as: UTF8.self))
