# Corrected recurrent teacher diagnostic execution6

**All four cells produced valid ordinary teacher-forced observations, and the final comparison completed. M5 was released at 2026-09-06T09:13:26.501996+00:00.** The final audit checked 26 exact owned PIDs and found none still running. No model cell was relaunched.

| Model | Forced positions | Backend argmax differences | Contiguous mean NLL | Paged mean NLL | Fully equal score records |
| --- | ---: | ---: | ---: | ---: | ---: |
| qwen36 | 83 | 2 | 0.220221462020 | 0.228223662779 | 4 |
| gemma-qat4 | 61 | 0 | 0.240459160727 | 0.234078547994 | 1 |

Qwen's zero-based mismatch indices are 53 and 59 (context lengths 5576 and 5582). At 53, contiguous selects token 7244 and paged selects 2919; their top-two values are 26.875/26.75 and 26.875/26.875. At 59, contiguous selects 26533 and paged selects 10897; the top-two values are 21.75/21.5 and 21.625/21.625. The paged ties and selected lower token IDs are descriptive observations, not proof that the differences are harmless. Full values and forced-token NLL deltas are retained in `qwen-mismatch-details.json`, `comparison.json` and `score-deltas.csv`.

Gemma argmax IDs agree at all 61 forced positions, but only one complete score record agrees exactly. Qwen has four exact complete records out of 83. These observations do not imply general cross-kernel bitwise equality, model-wide quality, normal-generation/MTP parity, storage/lifecycle correctness or release acceptance. No threshold or oracle changed.

## Identity and controls

- Parent `38b674d53267018df35338bc4acee176de45c853`; native `a834412931d7dadb8929b2b6b4f3365ccbc5e48b`; Swift `c06149b4f7defa1b958c1e175f6c9a12c86c8a4f`; core `fab0f39f69140393b454c32d6f4bf7a9b32f9dcc`; C `d4328f2d8d54d711d5419e07ab9fa2f07b512a48`.
- Activated binding SHA256: `a7eb36c38980ad771bef6e438040dc12879f26a246c58a297d68912acbab2bc0`.
- Activation manifest SHA256: `242b1a496e33f7259018d43cb48c57db4704563d0906694365aa4f92becfd995`.
- Runtime artifact manifest SHA256: `84e5b6d9df7345fa70ddd9b1558dcd9b389ed5a4263dd071eaf4640f31a763b4`.
- CLI SHA256: `e812330b54c144d652acdfd50024f34fac7dcf40f7606f254818132268d5a11e`; metallib SHA256: `1c8e612c9c54e8652669c582aad6124438c77f1dce2dc0b1eb50dce1bf083565`.
- The exact retained contexts are unchanged: Qwen 5523+83 and Gemma QAT4 5418+61. Both backends use the same forced input per model, original TOML and seven explicit serving flags.
- Every cell passed exact within-backend plain/diagnostic/repeated-diagnostic checks. Each control used 11 prefill chunks, followed by 82 Qwen or 60 Gemma decode forwards. B1, MTP off, zero assistant-weight charge, both prefix-cache tiers off, model/runtime/config identities and production grant checks remained enforced.
- The complete predecessor proofs, readiness, hardware, Foundation home and model file-link checks passed. All native/controller processes exited zero with successful group cleanup and no signal errors.

## Handles

| Operation | Controller PID | Native PID | Outcome |
| --- | ---: | ---: | --- |
| qwen36-contiguous | 47481 | 47509 | observed / retired |
| qwen36-paged | 47544 | 47567 | observed / retired |
| gemma-qat4-contiguous | 47609 | 47640 | observed / retired |
| gemma-qat4-paged | 47673 | 47696 | observed / retired |
| comparison | 47725 | — | observed / retired |

A pending-terminal-receipt polling error was fixed by restarting only the local observer. The same Qwen controller PID 47481 and native PID 47509 continued; no remote process was signaled or relaunched. The original failed Qwen PID 44303 remains preserved as `refused`, exit -5. All 32 original failure payloads and the 36 prepared execution5 payloads verified unchanged.

The remote root remains `/Users/gaj/autoresearch/radix-prefix-cache/090-teacher-forced-ordinary3-recurrent38b`, with reports, runtime, model-file links and control receipts retained. The local collection contains 162 verified evidence files; no model-weight bytes were copied. Thirty-eight controller metadata files and eight runtime files were reverified after execution. The private teacher SSH control connection was closed. No dev, local GPU/build, workflow dispatch or publication action occurred.
