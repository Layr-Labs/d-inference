#!/bin/sh
set -eu
umask 077
cd /home/gaj.guest/prompt-proof
sudo -n apk add --no-cache bash ca-certificates curl file musl-dev gcc g++ make python3 xz
mkdir -p toolchain source inputs
printf '%s  %s\n' '2828f7fba4777fef6c0a4cd800319f6a3ee07847e0c69ae502263443e6227795' 'cargo-1.88.0-aarch64-unknown-linux-musl.tar.xz' | sha256sum -c -
tar -xJf 'cargo-1.88.0-aarch64-unknown-linux-musl.tar.xz'
sh 'cargo-1.88.0-aarch64-unknown-linux-musl/install.sh' --prefix=/home/gaj.guest/prompt-proof/toolchain --disable-ldconfig
printf '%s  %s\n' '0e688fc032cdd828f4a448edbf109dc27e4cd13ef54c91633a32a153070d13b6' 'rustc-1.88.0-aarch64-unknown-linux-musl.tar.xz' | sha256sum -c -
tar -xJf 'rustc-1.88.0-aarch64-unknown-linux-musl.tar.xz'
sh 'rustc-1.88.0-aarch64-unknown-linux-musl/install.sh' --prefix=/home/gaj.guest/prompt-proof/toolchain --disable-ldconfig
printf '%s  %s\n' 'b1562ce0836d5071abbbeaf52e3db9ce0d37fa432f5202b8f661aa4881b4c3e4' 'rust-std-1.88.0-aarch64-unknown-linux-musl.tar.xz' | sha256sum -c -
tar -xJf 'rust-std-1.88.0-aarch64-unknown-linux-musl.tar.xz'
sh 'rust-std-1.88.0-aarch64-unknown-linux-musl/install.sh' --prefix=/home/gaj.guest/prompt-proof/toolchain --disable-ldconfig
printf '%s  %s\n' '6448aea754dbdd58f6fb2c6e3180f2a7a513762d6e443823d83fc84b154b54b7' 'source.tar' | sha256sum -c -
printf '%s  %s\n' 'd1e9c770510a22effe3a93003141c0c26c96a7a799027412a7a0dfc53bcbcdd0' 'linux-inputs.tar.gz' | sha256sum -c -
tar -xf source.tar -C source
tar -xzf linux-inputs.tar.gz -C inputs
python3 - <<'VERIFY'
from pathlib import Path
import json,hashlib
base=Path('/home/gaj.guest/prompt-proof')
manifest=json.loads((base/'linux-input-manifest.json').read_text())
for name,meta in manifest['files'].items():
 p=base/'inputs'/name
 assert p.is_file() and not p.is_symlink(),name
 b=p.read_bytes(); assert len(b)==meta['bytes'] and hashlib.sha256(b).hexdigest()==meta['sha256'],name
print('All',len(manifest['files']),'Linux input files verified')
VERIFY
./toolchain/bin/rustc --version --verbose
./toolchain/bin/cargo --version
uname -a
cat /etc/alpine-release
apk info -v
