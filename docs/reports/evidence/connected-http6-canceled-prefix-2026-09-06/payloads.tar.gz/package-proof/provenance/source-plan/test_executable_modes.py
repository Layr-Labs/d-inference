import hashlib
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest import mock

from run_connected_fixture import preflight, verify_executable
from verify_package import verify_package


class ExecutableModeTests(unittest.TestCase):
    def test_runnable_regular_file_passes_and_lost_execute_bit_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            binary = Path(tmp)/'binary'
            binary.write_bytes(b'fixture')
            binary.chmod(0o755)
            self.assertEqual(verify_executable(binary), 0o755)
            binary.chmod(0o644)
            with self.assertRaisesRegex(ValueError, 'not a runnable regular file'):
                verify_executable(binary)

    def test_symlink_directory_and_denied_execute_access_are_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            binary = root/'binary'
            binary.write_bytes(b'fixture')
            binary.chmod(0o755)
            link = root/'link'
            link.symlink_to(binary)
            for path in [link, root]:
                with self.subTest(path=path), self.assertRaises(ValueError):
                    verify_executable(path)
            with mock.patch('run_connected_fixture.os.access', return_value=False):
                with self.assertRaises(ValueError):
                    verify_executable(binary)

    def test_each_lost_executable_bit_refuses_preflight_before_model_io_or_launch(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            binaries = [root/'connected-e2e.test', root/'provider', root/'sidecar']
            for binary in binaries:
                binary.write_bytes(b'fixture')
                binary.chmod(0o755)
            data = {'provider_binary':str(binaries[1]), 'sidecar_binary':str(binaries[2])}
            with (mock.patch('run_connected_fixture.assert_idle') as idle,
                  mock.patch('run_connected_fixture.digest') as digest,
                  mock.patch('run_connected_fixture.verify_discovery') as discovery,
                  mock.patch('run_connected_fixture.verify_snapshot') as model,
                  mock.patch('run_connected_fixture.subprocess.Popen') as launch):
                for binary in binaries:
                    binary.chmod(0o644)
                    with self.subTest(binary=binary), self.assertRaisesRegex(
                            ValueError, 'not a runnable regular file'):
                        preflight(root, {}, {}, data)
                    binary.chmod(0o755)
                for operation in [idle, digest, discovery, model, launch]:
                    operation.assert_not_called()

    def test_package_checks_execute_permission_and_declared_payload_modes(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            binary = root/'connected-e2e.test'
            binary.write_bytes(b'fixture')
            binary.chmod(0o755)
            resource = root/'resource'
            resource.write_bytes(b'data')
            resource.chmod(0o644)
            files = {p.name: {'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),
                             'bytes':p.stat().st_size, 'mode':p.stat().st_mode & 0o7777}
                     for p in [binary, resource]}
            (root/'package-manifest.json').write_text(json.dumps({'files':files, 'source_commit':'fixture'}))
            self.assertEqual(verify_package(root)['verified_files'], 2)
            binary.chmod(0o644)
            with self.assertRaisesRegex(ValueError, 'not a runnable regular file'):
                verify_package(root)
            binary.chmod(0o755)
            resource.chmod(0o600)
            with self.assertRaisesRegex(ValueError, 'package mismatch: resource'):
                verify_package(root)


if __name__ == '__main__':
    unittest.main()
