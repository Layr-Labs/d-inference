"""Freeze small public corpus sources. No model, tokenizer, build or host execution."""
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import urllib.request

ROOT = Path(__file__).resolve().parent
SEED = "darkbloom-representative-quality-v1-2026-09-06"
CODE_POOL = ["Lib/argparse.py", "Lib/fractions.py", "Lib/functools.py", "Lib/statistics.py"]


def fetch(url):
    request = urllib.request.Request(url, headers={"User-Agent": "Darkbloom-public-corpus-preparation/1"})
    with urllib.request.urlopen(request, timeout=30) as response:
        data = response.read(8 * (1 << 20) + 1)
        if len(data) > 8 * (1 << 20):
            raise ValueError("public corpus download exceeds 8 MiB")
        return data, {"requested_url": url, "resolved_url": response.url,
                      "etag": response.headers.get("ETag"),
                      "last_modified": response.headers.get("Last-Modified")}


def commit(repository, ref):
    data, _ = fetch(f"https://api.github.com/repos/{repository}/commits/{ref}")
    value = json.loads(data)
    return value["sha"]


def main():
    lock = ROOT / "source-lock.json"
    if lock.exists():
        raise SystemExit("Source lock already exists; do not overwrite a frozen corpus")
    selected = sorted(CODE_POOL, key=lambda name: hashlib.sha256((SEED + "|code|" + name).encode()).hexdigest())[:2]
    selection = {"seed": SEED, "code_candidate_paths": CODE_POOL, "selected_code_paths": selected,
                 "rule": "Sort SHA256(seed + |code| + path), take two; no model outputs consulted"}
    (ROOT / "selection-before-download.json").write_text(json.dumps(selection, indent=2) + "\n")
    cpython = commit("python/cpython", "v3.12.0")
    gsm = commit("openai/grade-school-math", "master")
    jobs = [
        ("gutenberg-11", "sources/gutenberg-11.txt", "https://www.gutenberg.org/ebooks/11.txt.utf-8", "public-domain-US", "ebook 11; content-addressed text revision"),
        ("gutenberg-35", "sources/gutenberg-35.txt", "https://www.gutenberg.org/ebooks/35.txt.utf-8", "public-domain-US", "ebook 35; content-addressed text revision"),
        ("cpython-license", "sources/cpython-LICENSE", f"https://raw.githubusercontent.com/python/cpython/{cpython}/LICENSE", "PSF-2.0 and bundled historical notices", cpython),
        ("gsm8k-license", "sources/gsm8k-LICENSE", f"https://raw.githubusercontent.com/openai/grade-school-math/{gsm}/LICENSE", "MIT", gsm),
        ("gsm8k-readme", "sources/gsm8k-README.md", f"https://raw.githubusercontent.com/openai/grade-school-math/{gsm}/README.md", "MIT", gsm),
        ("gsm8k-test", "sources/gsm8k-test.jsonl", f"https://raw.githubusercontent.com/openai/grade-school-math/{gsm}/grade_school_math/data/test.jsonl", "MIT", gsm),
    ]
    jobs.extend(("cpython-" + Path(name).stem, "sources/cpython-" + Path(name).name,
                 f"https://raw.githubusercontent.com/python/cpython/{cpython}/{name}",
                 "PSF-2.0 and bundled historical notices", cpython) for name in selected)
    (ROOT / "sources").mkdir()

    def download(job):
        identifier, path, url, license_name, revision = job
        data, response = fetch(url)
        (ROOT / path).write_bytes(data)
        return dict(id=identifier, path=path, sha256=hashlib.sha256(data).hexdigest(),
                    bytes=len(data), license=license_name, revision=revision, **response)

    with ThreadPoolExecutor(max_workers=4) as pool:
        records = list(pool.map(download, jobs))
    if "MIT License" not in (ROOT / "sources/gsm8k-LICENSE").read_text():
        raise ValueError("unexpected GSM8K license")
    if "PYTHON SOFTWARE FOUNDATION LICENSE VERSION 2" not in (ROOT / "sources/cpython-LICENSE").read_text():
        raise ValueError("unexpected CPython license")
    result = {"schema": 1, "frozen_at_utc": datetime.now(timezone.utc).isoformat(),
              "selection": selection, "cpython_tag": "v3.12.0", "cpython_commit": cpython,
              "gsm8k_commit": gsm, "files": records,
              "training_data_exclusion_claim": False,
              "scope": "Public source observations; held out only from listed local tuning fixtures"}
    lock.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps({"cpython": cpython, "gsm8k": gsm, "selected_code": selected,
                      "source_bytes": sum(row["bytes"] for row in records)}, indent=2))


if __name__ == "__main__":
    main()
