from build_common import *

EXPECTED = json.loads((ROOT / 'source-selection.json').read_text())['source']
ENV.update({'GIT_CONFIG_COUNT': '3', 'GIT_CONFIG_KEY_0': 'protocol.file.allow', 'GIT_CONFIG_VALUE_0': 'always',
    'GIT_CONFIG_KEY_1': 'url.' + str(REPOS['core']) + '.insteadOf',
    'GIT_CONFIG_VALUE_1': 'https://github.com/Layr-Labs/mlx.git',
    'GIT_CONFIG_KEY_2': 'url.' + str(REPOS['c']) + '.insteadOf',
    'GIT_CONFIG_VALUE_2': 'https://github.com/Layr-Labs/mlx-c.git'})
SUITES = ['EngineV2KVBackendPolicyTests', 'EngineV2KVBackendGateTests', 'EngineV2PagedPoolDTypeEnvTests',
    'PrefixCachePolicyTests', 'EngineV2PrefixCacheUsageTests', 'EngineV2FP32PagedRateTests',
    'EngineV2SlotBuildTests', 'EngineV2ReslicingWiringTests', 'EngineV2RequestRoutingTests',
    'EngineV2RuntimeGuardTests', 'EngineV2KVBackendFallbackHeartbeatTests', 'PrefillDeadlineProductionConfigTests',
    'EngineV2ResliceTests', 'EngineV2ResliceUnwindTests', 'SegmentedProductionGrantTests',
    'DoctorClearBackendGuardTests', 'KVBackendGuardDiagnosticsTests', 'KVBackendPostureTests',
    'BenchmarkSweepExitTests', 'MTPBenchmarkTests', 'SSDCheckpointFileCoordinatorTests',
    'SSDCheckpointFileCoordinatorPathTests', 'SSDCheckpointRecencyCoordinationTests',
    'SSDHybridCheckpointCoordinationTests', 'SSDHybridCheckpointRecencyTests', 'SSDHybridCheckpointStoreTests',
    'SSDBlockStreamingTests', 'SSDSharedProcessCheckpointTests', 'SSDCheckpointLookupTests',
    'SSDCheckpointStageReservationTests']


def require(condition, message):
    if not condition:
        raise ValueError(message)


def verify_pins(name, lock):
    raw = json.loads((ROOT / (name + '-dependency-checkouts.json')).read_text())
    observed = {key.lower(): value for key, value in raw.items()}
    expected = {row['identity']: row for row in json.loads(lock.read_text())['pins']}
    require(len(observed) == len(raw) and set(observed) == set(expected), 'dependency identity mismatch')
    for key, row in expected.items():
        require(observed[key]['revision'] == row['state']['revision'] and not observed[key]['dirty'],
                'dependency source drift: ' + key)
    write(ROOT / (name + '-pin-proof.json'), {'lock': identity(lock), 'count': len(expected), 'exact_and_clean': True})


try:
    require(MANIFEST['source'] == EXPECTED, 'source selection differs')
    print(json.dumps({'event': 'controller_started', 'pid': os.getpid(), 'source': EXPECTED}), flush=True)
    state({'state': 'VERIFYING_SOURCE', 'controller_pid': os.getpid(), 'source': EXPECTED, 'real_model_run': False})
    observation = owner_helper.observe({'macmon_path': '/Users/gaj/bench-runner/bin/macmon',
        'macmon': {'bytes': 1633864, 'mode': 493, 'sha256': '495da8787023c9ebcd62d19e348cd6f1dec5dba3ef2d4f1ff55d9e2079860e19'}})
    owner_helper.require_entry(observation)
    require(observation['hardware_model'] == 'Mac17,6', 'wrong build host')
    write(ROOT / 'entry-observation.json', observation)
    write(ROOT / 'source-before-build.json', verify_sources())
    command('toolchain', ['sh', '-c', 'xcodebuild -version && xcrun swift --version && xcrun --sdk macosx --show-sdk-version && sw_vers'], ROOT, 120)
    provider = SOURCE / 'provider-swift'
    command('provider-build-tests', ['swift', 'build', '--build-tests', '--scratch-path', str(TEST_BUILD),
        '--jobs', '4', '--disable-automatic-resolution'], provider, 3600)
    graph_proof('provider-tests', TEST_BUILD, [SOURCE])
    verify_pins('provider-tests', provider / 'Package.resolved')
    stage_test_metallib()
    test_results = {}
    for suite in SUITES:
        log = command('test-' + suite, ['bash', str(SOURCE / 'scripts/run-nested-suite.sh'), suite,
            '--no-parallel', '--scratch-path', str(TEST_BUILD), '--disable-automatic-resolution'], provider, 1200)
        counts = [int(value) for groups in re.findall(r'Test run with (\d+) tests?(?: in \d+ suites?)? passed|Executed (\d+) tests?', log.read_text())
                  for value in groups if value]
        require(counts and max(counts) > 0, 'empty suite: ' + suite)
        test_results[suite] = {'log': str(log), 'counts': counts, 'nonempty_no_skips_guard_passed': True}
        write(ROOT / 'provider-test-results.json', test_results)
    write(ROOT / 'source-after-tests.json', verify_sources())
    for product, directory in [('radix-engine', SOURCE / 'scripts/benchmarks/radix-engine'), ('darkbloom', provider)]:
        command('release-' + product, ['swift', 'build', '-c', 'release', '--scratch-path', str(RELEASE),
            '--jobs', '4', '--disable-automatic-resolution', '--product', product], directory, 3600)
        graph_name = product + '-verified'
        graph_proof(graph_name, RELEASE, [SOURCE])
        verify_pins(graph_name, directory / 'Package.resolved')
        shutil.copy2(RELEASE / 'arm64-apple-macosx/release' / product, ARTIFACT / product)
        (ARTIFACT / product).chmod(0o755)
        write(ROOT / ('source-after-' + product + '.json'), verify_sources())
    release = RELEASE / 'arm64-apple-macosx/release'
    for name in ['mlx-swift-lm_MLXLMCommon.bundle/pagedattention.metal', 'swift-crypto_Crypto.bundle/PrivacyInfo.xcprivacy',
                 'swift-nio_NIOPosix.bundle/PrivacyInfo.xcprivacy', 'swift-transformers_Hub.bundle/gpt2_tokenizer_config.json',
                 'swift-transformers_Hub.bundle/t5_tokenizer_config.json']:
        target = ARTIFACT / name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(release / name, target)
        target.chmod(0o644)
    locks = {path: identity(SOURCE / path) for path in ['scripts/benchmarks/radix-engine/Package.resolved', 'provider-swift/Package.resolved']}
    require(locks == json.loads((ROOT / 'locks-before.json').read_text()), 'source lock bytes changed')
    write(ROOT / 'locks-after-build.json', locks)
    for product in ['darkbloom', 'radix-engine']:
        command(product + '-codesign', ['codesign', '--verify', '--strict', '--verbose=2', str(ARTIFACT / product)], ROOT, 120)
        command(product + '-signature', ['codesign', '-d', '--verbose=4', str(ARTIFACT / product)], ROOT, 120)
        command(product + '-dylibs', ['otool', '-L', str(ARTIFACT / product)], ROOT, 120)
    command('cli-help', [str(ARTIFACT / 'darkbloom'), '--help'], ROOT, 60)
    files = {str(path.relative_to(ARTIFACT)): identity(path) for path in ARTIFACT.rglob('*') if path.is_file()}
    require(len(files) == 8, 'runtime resource inventory differs')
    write(ROOT / 'artifact-manifest.json', {'source': EXPECTED, 'files': files, 'canonical_swiftpm_build': True,
        'manual_object_link': False, 'M5_built': True, 'real_model_run': False, 'provider_tests': test_results,
        'root_artifact_review_required': True, 'shader_reuse_proof': 'shader-reuse-proof.json'})
    state({'state': 'BUILD_AND_PROVIDER_TESTS_COMPLETE_ROOT_ARTIFACT_REVIEW_REQUIRED', 'source': EXPECTED,
        'artifact_manifest': str(ROOT / 'artifact-manifest.json'), 'real_model_run': False})
except BaseException as error:
    state({'state': 'FAILED', 'error': type(error).__name__ + ': ' + str(error), 'completed_steps': EXECUTIONS,
           'real_model_run': False})
    raise
