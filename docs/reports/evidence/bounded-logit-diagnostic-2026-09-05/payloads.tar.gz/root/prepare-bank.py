import collections
import gzip
import hashlib
import io
import json
import subprocess
import tarfile
from pathlib import Path

root = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
destination = root / 'docs/reports/evidence/bounded-logit-diagnostic-2026-09-05'
assert not destination.exists()
payloads = {}

def add(name, path):
    assert name not in payloads
    raw = path.read_bytes()
    assert raw[:4] not in [b'\x7fELF', b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf']
    payloads[name] = raw

def frozen(label, directory):
    directory = Path(directory)
    manifest = json.loads((directory / 'manifest.json').read_text())
    for name, spec in manifest['files'].items():
        raw = (directory / name).read_bytes()
        assert len(raw) == spec['bytes']
        assert hashlib.sha256(raw).hexdigest() == spec['sha256']
        add(label + '/' + name, directory / name)
    add(label + '/manifest.json', directory / 'manifest.json')

for label, directory in [
    ('source', '/tmp/darkbloom-q36-logit-diagnostic-source/freeze2'),
    ('native-attempt1', '/tmp/darkbloom-q36-logit-diagnostic-validation1'),
    ('native-attempt2', '/tmp/darkbloom-q36-logit-diagnostic-validation2'),
    ('native-pass', '/tmp/darkbloom-q36-logit-diagnostic-validation3'),
    ('harness-pass', '/tmp/darkbloom-q36-diagnostic-harness-validation1'),
    ('wrapper-source', '/tmp/darkbloom-logit-wrapper-forwarding1'),
]:
    frozen(label, directory)

independent = Path('/tmp/darkbloom-logit-wrapper-independent-review1')
review = json.loads((independent / 'review.json').read_text())
for name, digest in review['python_source_hashes'].items():
    path = independent / 'python' / name
    assert hashlib.sha256(path.read_bytes()).hexdigest() == digest
    add('wrapper-independent/python/' + name, path)
for name in ['review.json', 'tests.stdout', 'tests.stderr']:
    add('wrapper-independent/' + name, independent / name)
for name in ['darkbloom-q36-logit-diagnostic-native-root-review.json',
             'darkbloom-q36-diagnostic-harness-root-review.json']:
    add('root/' + name, Path('/tmp') / name)
add('root/prepare-bank.py', Path(__file__))

native = root / 'libs/mlx-swift-lm'
native_commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=native, text=True).strip()
source_manifest = json.loads(Path('/tmp/darkbloom-q36-logit-diagnostic-source/freeze2/manifest.json').read_text())
source_matches = {}
for name, spec in source_manifest['files'].items():
    for prefix, target in [('files/native/', native), ('files/harness/', root)]:
        if name.startswith(prefix):
            relative = name[len(prefix):]
            actual = hashlib.sha256((target / relative).read_bytes()).hexdigest()
            assert actual == spec['sha256'], relative
            source_matches[str((target / relative).relative_to(root))] = actual
wrapper_manifest = json.loads(Path('/tmp/darkbloom-logit-wrapper-forwarding1/manifest.json').read_text())
for name, spec in wrapper_manifest['files'].items():
    if name.startswith('files/'):
        relative = name[6:]
        actual = hashlib.sha256((root / relative).read_bytes()).hexdigest()
        assert actual == spec['sha256'], relative
        source_matches[relative] = actual
payloads['root/applied-source-proof.json'] = (json.dumps({
    'native_commit': native_commit,
    'files': source_matches,
    'scope': 'Applied bytes exactly match reviewed and tested source; no release/model/default acceptance.'
}, indent=2) + '\n').encode()

destination.mkdir(parents=True)
archive = destination / 'payloads.tar.gz'
with archive.open('wb') as output:
    with gzip.GzipFile(fileobj=output, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, raw in sorted(payloads.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                tar.addfile(entry, io.BytesIO(raw))
entries = {name: {'sha256': hashlib.sha256(raw).hexdigest(), 'bytes': len(raw)}
           for name, raw in sorted(payloads.items())}
evidence = {
    'schema': 1,
    'scope': 'Bounded actual target-logit diagnostic: native139 functions/143 cases, benchmark11, Python53; no fleet result or performance claim',
    'native_commit': native_commit,
    'files': entries,
    'payload_count': len(entries),
    'payload_bytes': sum(len(raw) for raw in payloads.values()),
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archive_bytes': archive.stat().st_size,
    'excluded': 'Compiled executables and model weights; source and binary identities remain in validation evidence',
}
(destination / 'manifest.json').write_text(json.dumps(evidence, indent=2) + '\n')
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(entries)
    for member in tar:
        raw = tar.extractfile(member).read()
        assert len(raw) == entries[member.name]['bytes']
        assert hashlib.sha256(raw).hexdigest() == entries[member.name]['sha256']
summary = {key: value for key, value in evidence.items() if key != 'files'}
summary['manifest_sha256'] = hashlib.sha256((destination / 'manifest.json').read_bytes()).hexdigest()
Path('/tmp/darkbloom-logit-diagnostic-bank-root-review.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
