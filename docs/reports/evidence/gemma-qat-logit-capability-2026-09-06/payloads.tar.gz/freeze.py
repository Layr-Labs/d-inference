from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile

OUT=Path('/tmp/darkbloom-qat-actual-logits-attempt1-freeze');OUT.mkdir(exist_ok=False)
PAYLOAD=OUT/'payloads';PAYLOAD.mkdir()
entries=[]

def sha(data):return hashlib.sha256(data).hexdigest()
def add(name,data,source=None):
    dest=PAYLOAD/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
    row={'path':name,'bytes':len(data),'sha256':sha(data)}
    if source:row['original_path']=str(source)
    entries.append(row)
def put(name,path):
    assert path.is_file() and not path.is_symlink(),path
    add(name,path.read_bytes(),path)
def group(name,path,manifest='manifest.json'):
    rows=json.loads((path/manifest).read_text())['files']
    for rel,row in rows.items():
        p=path/rel;data=p.read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'],p
        put(name+'/'+rel,p)
    put(name+'/'+manifest,path/manifest)

group('plan',Path('/tmp/darkbloom-qat-actual-logits-plan1'))
group('execution-preparation1',Path('/tmp/darkbloom-qat-actual-logits-execution1'),'preparation-manifest.json')
root=Path('/tmp/darkbloom-qat-actual-logits-execution2')
group('execution-preparation2',root,'preparation-manifest.json')
for p in sorted(root.iterdir()):
    if p.is_dir() and p.name.startswith('gemma-qat4-'):group('results/'+p.name,p)
group('template-fix',Path('/tmp/darkbloom-qat-template-fix1'),'source-manifest.json')
group('staging-resume',Path('/tmp/darkbloom-qat-actual-logits-staging-resume1'))
group('runtime-transfer',Path('/tmp/darkbloom-qat-actual-logits-runtime-transfer1'))
group('remote-helper-tests',Path('/tmp/darkbloom-qat-actual-logits-helper-validation1'))
put('postflight.json',Path('/tmp/darkbloom-qat-actual-logits-stopped-postflight1.json'))
put('runtime-binding.json',Path('/tmp/darkbloom-qat-actual-logits-runtime-binding1.json'))
put('freeze.py',Path(__file__))

primary=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
native=primary/'libs/mlx-swift-lm';commit='e972340a7ba6e22fda5d8be1a7af918f9bf67b03'
paths=['Libraries/MLXLMCommon/ContinuousBatchingV2/EngineLoopV2.swift',
       'Libraries/MLXLMCommon/ContinuousBatchingV2/CBv2LogitDiagnostic.swift',
       'Libraries/MLXLMCommon/ContinuousBatchingV2/SteppableAdapterV2.swift',
       'Libraries/MLXLMCommon/ContinuousBatchingV2/MTP/CBv2MTPRoundDriver.swift',
       'Libraries/MLXLLM/Models/Qwen35MTPTopTwo.swift']
for path in paths:
    add('source-native-e972/'+path,subprocess.check_output(['git','-C',str(native),'show',commit+':'+path]))
add('source-native-e972/top-two-provider-grep.txt',subprocess.check_output(['git','-C',str(native),'grep','-n','CBv2MTPPolicyTopTwoProviding',commit,'--','Libraries']))
path='scripts/benchmarks/radix-engine/Sources/radix-engine/BenchmarkLogitDiagnostic.swift'
add('source-parent384/'+path,subprocess.check_output(['git','-C',str(primary),'show','384c321aa7565864182c02210fc4d212efc6501b:'+path]))
report={
 'status':'ONE_CONTROL_PASS_ONE_DIAGNOSTIC_CAPABILITY_FAILURE_TWO_UNRUN',
 'scope':'Normal-MTP QAT c153 same-build four-cell attempt stopped at contiguous trace installation. No actual selected logits, no numerical or performance acceptance.',
 'control':{'prompt_tokens':5418,'output_tokens':61,'index7':42392,'historical_all7_trajectories_exact':True},
 'trace':{'error':'topTwoUnavailable','warmup_completed_tokens':8,'main_rows':'both not_run','selected_capture':None,
          'shutdown_active_requests':0,'shutdown_waiting_requests':0,'shutdown_kv_in_use':0,'shutdown_kv_reserved':0},
 'cause':'Engine diagnostic configuration requires the MTP-policy top-two provider. Adapter availability delegates to the underlying model; only Qwen provides it, so Gemma rejects before main inference.',
 'engineering_limit':'Adding Gemma MTP-policy conformance could change marginal-policy eligibility. Any diagnostic support must preserve existing normal policy and pass a meaningful non-Qwen engine regression and same-build model controls.',
 'common_reducer_inspection':'No current common top-two reducer. Existing Qwen35MTPTopTwoRows is a generic lazy two-stage MLX kernel with deterministic ties and NaNs last; extraction can be considered separately without changing its algorithm or Gemma policy eligibility.',
 'preserved':'Original pre-extraction template SyntaxError, its negative-control fix tests, source1/source2 preparations, strict failed report and all raw evidence retained. No failed model stage was retried.',
 'remaining_cells':'paged trace-off and trace-on unrun; no further QAT launch authorized after this failure.'}
add('analysis.json',(json.dumps(report,indent=2,sort_keys=True)+'\n').encode())
assert len(entries)==len({r['path'] for r in entries})
archive=OUT/'payloads.tar.gz'
with archive.open('wb') as f:
    with gzip.GzipFile(fileobj=f,mode='wb',mtime=0,filename='') as gz:
        with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
            for row in sorted(entries,key=lambda r:r['path']):
                item=tarfile.TarInfo(row['path']);item.size=row['bytes'];item.mode=0o644;item.mtime=0
                tar.addfile(item,io.BytesIO((PAYLOAD/row['path']).read_bytes()))
manifest={'status':report['status'],'payload_count':len(entries),'files':sorted(entries,key=lambda r:r['path']),
          'archive':{'path':archive.name,'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},
          'scope':report['scope'],'excluded':'No runtime executable, metallib, model weight or key. The nested failed-stage archive contains only the reviewed source/input plan.'}
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
print(json.dumps({'payloads':len(entries),'manifest_sha256':sha((OUT/'manifest.json').read_bytes()),'archive':manifest['archive']},indent=2))
