from pathlib import Path
import hashlib,json,stat
BASE=Path('/tmp/darkbloom-q36-attention-packet-execution1');PLAN=Path('/tmp/darkbloom-q36-attention-packet-plan1');RELEASE=Path('/tmp/darkbloom-attention-packet-release-build1')
OUT=Path('/tmp/darkbloom-q36-attention-packet-binding-prep1');OUT.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def record(p):return {'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(stat.S_IMODE(p.stat().st_mode))}
def save(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
def verify(root,manifest,expected):
 assert sha(root/manifest)==expected
 d=json.loads((root/manifest).read_text())
 for name,row in d['files'].items():
  actual=record(root/name);assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256']
  if 'mode' in row:assert actual['mode']==row['mode']
 return len(d['files'])
counts={'controller':verify(BASE,'preparation-manifest.json','439897e585fd160a1c0314becacbb4b72fa6c5e9844db9395954cfd7f92e763c'),'plan':verify(PLAN,'manifest.json','21467d42b7e710d8303cb2690f79edb16d793241b919fa303d6acea888660fce')}
artifact_review=Path('/tmp/darkbloom-attention-packet-root-release-review1.json');assert sha(artifact_review)=='a7496912570228710c5a119317c671db54a5675fbf9e9acc001394943ead45ea'
controller_review=Path('/tmp/darkbloom-q36-attention-packet-root-controller-review1.json');assert sha(controller_review)=='c25fc0d6dbcc45767ef475576e535afa7deb22ff7258946f724b9f4365641303'
artifacts=json.loads(artifact_review.read_text())['artifacts'];artifacts={k:v for k,v in artifacts.items() if k!='darkbloom'};assert len(artifacts)==7
for name,row in artifacts.items():assert record(RELEASE/'artifact'/name)==row,name
b=json.loads((BASE/'runtime-binding.template.json').read_text());before=json.loads(json.dumps(b));p=json.loads((PLAN/'plan.json').read_text())
b.update(state='REVIEWED_ARTIFACTS_BOUND_PENDING_ROOT_BINDING_REVIEW',controller_manifest_sha256=sha(BASE/'preparation-manifest.json'),artifact_review=str(artifact_review),artifact_review_sha256=sha(artifact_review),controller_review=str(controller_review),controller_review_sha256=sha(controller_review),artifacts=artifacts)
assert len(p['cells'])==len(b['commands'])==4
for cell,command in zip(p['cells'],b['commands']):
 assert command['cell']==cell['id'] and command['wrapper_argv']==cell['argv'] and command['expected_observed_native_argv']==cell['native_argv_after_date_pin']
 assert command['expected_observed_native_argv'][2].endswith('/runs/'+cell['id']+'/input.json')
assert b['commands']==before['commands']
target=BASE/'runtime-binding.json';assert not target.exists();save(target,b)
(OUT/'bind.py').write_bytes(Path(__file__).read_bytes());(OUT/'runtime-binding.json').write_bytes(target.read_bytes())
save(OUT/'review.json',{'state':'BOUND_PENDING_ROOT_REVIEW_NO_REMOTE_CALL','binding_path':str(target),'binding':record(target),'verified_source_payload_counts':counts,'exact_runtime_files':artifacts,'template_commands_unchanged':True,'explicit_copied_run_input_substitution':True,'changed_binding_fields':[k for k in b if b[k]!=before[k]],'scope':'Binding only; no source edits, repeated CPU suite or model invocation. Existing 26-controller CPU tests and root source review remain exact.'})
save(OUT/'manifest.json',{'files':{f.name:record(f) for f in sorted(OUT.iterdir()) if f.is_file()}});print(json.dumps({'binding_sha256':sha(target),'preparation_manifest_sha256':sha(OUT/'manifest.json'),'counts':counts},indent=2))
