# Build7 release CLI

This isolated build uses the exact frozen build6 provider/native/dependency inputs, proven against primary `9e49059a1806e265fd9ceab420c1b82216a5d785` and native `a932d38cee0beca41ca1a0e71c1e867913a65353`. All 677 provider and 481 native inputs match the committed sources except the two documented, compile-only Package.swift local MLX dependency substitutions. Dependency manifests cover the established 1,356 selected MLX/MLX-C sources and 27 pinned Jinja inputs. No primary source is compiled or modified.

Only `darkbloom` is rebuilt. The artifact directory carries the byte-identical build6 `radix-engine` probe and its six previously verified resources. The copied probe is not a second build or a new model validation. New CLI HTTP validation remains separate. Use artifact-manifest.json to transfer and verify every file beside the executable; preserve prior CLI/probe packages and complete paired runs with one runtime identity.

Before/after/final source hashes, actual command, package state, compressed compiler graph, source-path correspondence, toolchain/hardware and dylib dependencies are retained. The full graph proof distinguishes planned input membership from the executed release product recorded in the command/log. The five existing negative argument guards run on the unchanged build6 probe; the newly built CLI must pass `--help`. These checks do not load real models.

The initial precompile audit incorrectly expected native Package.swift to contain a relative MLX path. The committed native file uses the known Layr-Labs URL and branch. `preparation-failure.json`, original prepare.py and corrected prepare-resume.py preserve that audit correction. Frozen compiler inputs were already correct; no provider/native/dependency source correction was made.

No production configuration, cache-default promotion, signing key, deployment or coordinator activation is changed by this artifact build. Native 126-case unit evidence and prior model-pair evidence remain in their own immutable freezes; this record establishes the CLI/source correspondence required for subsequent connected tests.
