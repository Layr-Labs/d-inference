# Packet benchmark validation preparation

Source only: no Swift invocation has occurred. This driver runs only after the
explicit Swift lane handoff and successful native packet validation.

Provider source is archived parent384c321aa (683 files), with only its established
local dependency path overlay. The harness is that same parent plus the exact
five reviewed Swift files: 18 canonical files and one pinned Package.resolved.
Both reviewed Python wrapper files are retained separately, not compiled into
the harness. The provider has no packet production changes. The local native
dependency points to the prepared packet package, never the primary worktree.

Five filters select 18 functions: packet options and host export (four), metadata
options (three), logit options (three), and idle observations (eight). These tests
do not run real target model weights. Failed builds stop before stale artifacts
or tests are accepted. Native/provider/harness/dependency hashes and the actual
source graph are retained, with before/after verification and raw suite output.

No optimized executable, target model, remote operation, key operation or cache
default change is authorized by this preparation. Namespace and cancellation
candidates are excluded from both packages.
