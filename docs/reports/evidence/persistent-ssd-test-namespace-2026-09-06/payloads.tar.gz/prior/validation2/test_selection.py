"""Exact Swift Testing identifiers; only the already reviewed filters are allowed."""
import re

IN_MEMORY_FUNCTIONS = {
    'kekLoadOrCreateGeneratesOnFirstCall', 'kekPersistsAcrossActorInstances',
    'kekConcurrentFirstUseAdoptsSingleKEK', 'saveIfAbsentDoesNotOverwriteExisting',
}
SUITES = {
    'provider': ('ProviderCoreTests', {'SSDPersistentTestKeyNamespaceTests', 'SSDPrefixCacheModeTests'}),
    'benchmark': ('RadixEngineBenchmarkTests', {'BenchmarkPersistentTestKeysTests',
        'BenchmarkAttentionMetadataOptionsTests', 'BenchmarkLogitDiagnosticOptionsTests', 'BenchmarkIdleObservationTests'}),
}


def selected_identifiers(listing, selector, phase):
    module, suites = SUITES[phase]
    if phase == 'provider' and selector in IN_MEMORY_FUNCTIONS:
        pattern = re.escape(module + '.' + selector + '()')
    elif selector in suites:
        pattern = re.escape(module + '.' + selector + '/') + r'[A-Za-z_][A-Za-z0-9_]*\([^()\r\n]*\)'
    else:
        raise ValueError('selector is outside the reviewed test scope')
    return [line.strip() for line in listing.splitlines() if re.fullmatch(pattern, line.strip())]


def exact_filter(identifiers):
    if not identifiers or len(set(identifiers)) != len(identifiers):
        raise ValueError('test selection is empty or duplicated')
    return '^(?:' + '|'.join(re.escape(identifier) for identifier in identifiers) + ')$'
