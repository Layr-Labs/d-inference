# Recurrent teacher peak-capacity correction

Commit: `c3fd66987919c12f7d119104734c0347e95f080d`.
Base: `8344e8bdc44c57e09527467a5dc5c415a8f90010`.
Worktree: `/Users/gaj/Documents/DarkbloomDev/wt/teacher-recurrent-capacity-native` (clean).

Status: implementation complete; focused local GPU tests passed; root review pending. The primary worktree and original `8344` handoff are unchanged. The M3 compiler/GPU lane is released; no owned build/test process remains.

## Accounting rationale

`AdmissionV2.reserveUnscheduledRequest` creates a call-owned lease without using a scheduler request ID. It reuses `allocatedBytesChecked` and `nonBackendBytesChecked`, so it inherits the engine's already-resolved recurrent generation peak, allocator-footprint projection, and configured auxiliary headroom. This deliberately keeps normal conservative pricing; it does not substitute a smaller teacher-specific estimate or relax capacity.

The full request span is reserved. The target component is at least the private row's observed backend reservation delta, and the auxiliary component remains additive. For segmented storage, target bytes offset the existing backend physical floor exactly as ordinary target reservations do. Watermarks, external reservations, shrink-debt rules, and the process-memory owner charge use the existing admission mechanisms. The temporary target component is separated in capacity telemetry to avoid counting it again as auxiliary storage.

The loop acquires this lease after allocating the private KV row and before creating/binding recurrent state or forwarding tokens. On a failed reservation, its existing defer retires the KV row. On success or later failure, cleanup synchronizes recurrent work, drops the evaluation, discards pending state, releases committed state, restores the paged fault boundary when needed, drops cache bindings, releases the KV row, and clears the local row aliases before refunding the lease. Lease release is idempotent.

Ordinary request reservation methods and scheduling are unchanged. The new accounting fields remain zero outside private teacher calls. A bare recurrent `EngineLoopV2` without an `AdmissionV2` now refuses teacher scoring rather than bypassing peak accounting; normal `EngineV2` construction always installs the required admission ledger.

## Regressions

- Both contiguous and paged teacher paths refuse a budget where KV plus one recurrent generation fits but KV plus two does not. No model forward occurs; KV and transient reservations return to zero.
- Growing the budget permits scoring. Each actual forward observes the peak obligation. Success, geometry failure, and subsequent scoring restore all private accounting and fresh recurrent state.
- A metadata-only admission test checks the shared physical floor, watermark, external overhead, target/auxiliary telemetry split, atomic rejection, and idempotent refund.
- The existing paged teacher dtype-fault test now covers recurrent false/true and faults on the first or second forward. A counter proves that recurrent variants entered the explicit recurrent forward; their write fault occurs before `evaluation.evaluate()`, leaving an open binding for cleanup. All cases recover on the same engine with no retained private reservation or poisoned write latch.
- The original real-Qwen hybrid fixture needed an explicit observed native dtype table for its paged backend. It now uses the existing native KV probe with fresh caches. Probe calls do not enter the observed model wrapper used for teacher call-count assertions. The new synthetic capacity fixture declares its known BF16 native table.

## Validation

All seven selected suites passed, with nonempty execution and zero skips: **45 test functions / 59 expanded cases**.

| Suite | Functions | Expanded cases |
|---|---:|---:|
| CBv2TeacherForcedCapacityTests | 2 | 3 |
| CBv2TeacherForcedRecurrentTests | 1 | 4 |
| CBv2PagedRuntimeDTypeEngineTests | 2 | 8 |
| CBv2TeacherForcedScoringTests | 8 | 8 |
| CBv2TeacherForcedScoreDiagnosticTests | 6 | 9 |
| CBv2PagedAdmissionTests | 11 | 12 |
| CBv2RecurrentStateTests | 15 | 15 |

The tested native source hashes match the committed source. One named scratch, `/tmp/darkbloom-teacher-recurrent-capacity1/build`, was used with four build jobs. The final test bundle was built from exact corrected MLX Swift `c06149b4f7defa1b958c1e175f6c9a12c86c8a4f`, MLX core `fab0f39f69140393b454c32d6f4bf7a9b32f9dcc`, and C API `d4328f2d8d54d711d5419e07ab9fa2f07b512a48`. The graph includes the corrected generated QMV source and excludes remote MLX source. The colocated metallib SHA-256 is `1c8e612c9c54e8652669c582aad6124438c77f1dce2dc0b1eb50dce1bf083565`.

The native snapshot used a compile-only local dependency path; canonical `Package.swift` was not changed. No full model, M5, remote runtime, or dev environment run was performed.

Two failed attempts remain preserved: `build1.log` records absolute paths in the relocated module cache (resolved by moving that cache aside), and `CBv2TeacherForcedCapacityTests.log` records the missing explicit native dtype table in the initial paged fixture. The final successful build is `build3.log`; final suite logs have suffix `-2.log`.

## Integration and evidence

Apply `8344e8bdc44c57e09527467a5dc5c415a8f90010`, then `c3fd66987919c12f7d119104734c0347e95f080d` to primary `30ca217c5072c727d0eff29dc92789af5e98f2c9`. A temporary-index check confirmed that this sequence applies cleanly and preserves primary's corrected MLX Swift pin. No primary files or index were changed.

- `final-source.patch`: correction relative to `8344`.
- `combined-with-recurrent-routing.patch`: combined routing/capacity correction relative to `32206d9`, applicable to `30ca217` without replacing its package pin.
- `committed-source.json`: exact commit, clean worktree, and tested file hashes.
- `compiler-source-proof-2.json`, `test-binary-2.json`, `sources-before2.json`: source and runtime provenance.
- `tests-2.json`, `test-counts.json`: commands, exits, no-skip/nonempty guards, counts, and log hashes.
- `integration-check.json`: clean temporary-index integration and retained dependency pin.
- `owned-process-check.json`: final lane-release check.
- `status.json`: machine-readable final handoff.
