from pathlib import Path
import gzip,hashlib,json,os,shutil,subprocess,time
out=Path('/tmp/darkbloom-final-serving-build4');base=Path('/tmp/darkbloom-production-grant-harness-validation1');ws=out/'workspace';scratch=Path('/tmp/darkbloom-final-serving-build1/build');info=json.loads((out/'integration.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();env=os.environ.copy();env.update(info['environment']);ns={};exec((base/'run.py').read_text().split("assert (policy / 'manifest.json').exists()")[0],ns)
def verify():
 prior=ns['verify']();m=json.loads((out/'provider-source-manifest.json').read_text())
 for name,expected in m['files'].items():assert sha(ws/name)==expected,name
 for name in m['deleted_files']:assert not (ws/name).exists(),name
 for name,row in json.loads((out/'compile-source-manifest.json').read_text())['files'].items():assert sha(out/name)==row['sha256'],name
 return {'baseline_unchanged':prior,'diagnostic_provider_inputs':len(m['files']),'only_delta':m['delta'],'standalone_source_inputs':19}
(out/'source-verified-before.json').write_text(json.dumps(verify(),indent=2)+'\n');command=['swift','build','-c','release','--scratch-path',str(scratch),'--jobs','4','--disable-automatic-resolution','--product','radix-engine'];start=time.monotonic()
with (out/'build.log').open('w') as log:r=subprocess.run(command,cwd=out/'radix-engine',env=env,stdout=log,stderr=subprocess.STDOUT)
result={'command':command,'cwd':str(out/'radix-engine'),'seconds':time.monotonic()-start,'exit_code':r.returncode};(out/'execution.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result),flush=True);graph=scratch/'release.yaml';(out/'release-graph.yaml.gz').write_bytes(gzip.compress(graph.read_bytes(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'package-state.json');(out/'source-verified-after.json').write_text(json.dumps(verify(),indent=2)+'\n');assert r.returncode==0
text=graph.read_text();expected=[ws/'provider-swift/Sources/ProviderCore/Inference/EngineV2Factory+BenchmarkSession.swift',ws/'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/Paged/PagedKVSegments.swift',ws/'libs/mlx-swift/Source/MLX/AllocationFootprint.swift',ws/'libs/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp',out/'radix-engine/Sources/radix-engine/BenchmarkOptions.swift'];rows=[]
for path in expected:
 candidates={str(path),str(path.resolve()),str(path).replace('/tmp/','/private/tmp/',1),str(path.resolve()).replace('/private/tmp/','/tmp/',1)}
 actual=next((Path(value) for value in candidates if value in text),None);assert actual is not None,str(path);assert actual.resolve()==path.resolve();rows.append({'actual_compile_path':str(actual),'resolved_source':str(path.resolve()),'sha256':sha(path)})
assert '/checkouts/mlx-swift/Source/' not in text
for name,h in json.loads((base/'jinja-source-manifest.json').read_text())['files'].items():assert sha(scratch/'checkouts/swift-jinja'/name)==h,name
(out/'actual-source-proof.json').write_text(json.dumps({'paths':rows,'remote_mlx_compile_source_absent':True,'jinja_inputs_verified':27},indent=2)+'\n');artifact=out/'artifact';artifact.mkdir();shutil.copy2(scratch/'arm64-apple-macosx/release/radix-engine',artifact/'radix-engine');(out/'artifact-manifest.json').write_text(json.dumps({'scope':'Diagnostic probe only; original verified beside-executable resources retained and separately hash checked. No CLI rebuild or model success claimed.','files':{'radix-engine':{'sha256':sha(artifact/'radix-engine'),'bytes':(artifact/'radix-engine').stat().st_size}}},indent=2)+'\n');print('DIAGNOSTIC PROBE BUILD PASS',flush=True)
