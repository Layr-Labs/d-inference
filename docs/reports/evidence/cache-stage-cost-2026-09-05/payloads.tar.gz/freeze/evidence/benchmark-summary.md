| Benchmark | Baseline ns/op | Candidate ns/op | Candidate allocs/op |
|---|---:|---:|---:|
| BenchmarkCacheServiceCost/useful_hit-14 | 50.670 | 48.660 | 0 |
| BenchmarkCacheServiceCost/expensive_stage-14 | 46.630 | 48.620 | 0 |
| BenchmarkCacheServiceCost/stale_hint-14 | 40.920 | 39.240 | 0 |
| BenchmarkSelectRoutingCandidate/providers=1/cache=false-14 | 4.620 | 4.437 | 0 |
| BenchmarkSelectRoutingCandidate/providers=1/cache=true-14 | 4.621 | 4.414 | 0 |
| BenchmarkSelectRoutingCandidate/providers=32/cache=false-14 | 106.800 | 98.810 | 0 |
| BenchmarkSelectRoutingCandidate/providers=32/cache=true-14 | 67.840 | 73.230 | 0 |
| BenchmarkSelectRoutingCandidate/providers=350/cache=false-14 | 1134.000 | 1343.000 | 0 |
| BenchmarkSelectRoutingCandidate/providers=350/cache=true-14 | 895.500 | 963.800 | 0 |
| BenchmarkCacheHolderIndex/providers=16/boundaries=64/holders=4/content_index-14 | 42320.000 | 41745.000 | 1166 |
| BenchmarkCacheHolderIndex/providers=128/boundaries=64/holders=4/content_index-14 | 44005.000 | 42866.000 | 1166 |
| BenchmarkCacheHolderIndex/providers=512/boundaries=64/holders=4/content_index-14 | 50979.000 | 47929.000 | 1166 |
