from pathlib import Path
import copy
import json
import os
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

import controller
import readiness
from common import ROOT, digest, identity, read_json
from runtime_identity import runtime_files, stage_snapshot, validate_snapshot
from test_fixtures import fixture, invocation, save
from validation import REQUIRED_FILES, check_previous, readiness_checks


def running(pid):
    result = subprocess.run(['ps', '-p', str(pid), '-o', 'stat='], capture_output=True, text=True, timeout=3)
    return result.returncode == 0 and result.stdout.strip() and not result.stdout.strip().startswith('Z')


class RegressionTests(unittest.TestCase):
    def test_exact_plan_remains_runtime_unbound_without_launch(self):
        plan = controller.plan_inputs()
        self.assertEqual(len(plan['cells']), 4)
        binding = read_json(ROOT / 'binding-template.json')
        self.assertIsNone(binding['runtime'])
        self.assertIsNone(binding['required_metallib_sha256'])
        self.assertEqual(len(binding['expected_runtime_modes']), 8)
        self.assertEqual(binding['expected_runtime_source'], read_json(ROOT / 'source-cut.json'))
        self.assertEqual(binding['state'], 'awaiting_peer_review')

    def test_wrong_hash_size_mode_file_and_directory_symlinks_refuse(self):
        for fault in ('hash', 'size', 'mode', 'file_link', 'directory_link', 'extra_file'):
            with self.subTest(fault=fault), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary).resolve()
                _, binding = fixture(root)
                runtime_files(binding)
                executable = root / 'artifact/darkbloom'
                if fault == 'hash':
                    content = executable.read_bytes()
                    executable.write_bytes(content[:-1] + b'!')
                elif fault == 'size':
                    executable.write_bytes(executable.read_bytes() + b'!')
                elif fault == 'mode':
                    executable.chmod(0o600)
                elif fault == 'file_link':
                    other = root / 'external'
                    executable.rename(other)
                    executable.symlink_to(other)
                elif fault == 'directory_link':
                    other = root / 'external'
                    other.mkdir()
                    (other / 'pagedattention.metal').write_text('unbound')
                    (root / 'artifact/mlx-swift-lm_MLXLMCommon.bundle').symlink_to(other, target_is_directory=True)
                else:
                    (root / 'artifact/extra').write_text('unbound')
                with self.assertRaises(ValueError):
                    runtime_files(binding)

    def test_plan_input_hash_and_shape_refuse_before_process(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            plan, _ = fixture(root)
            with patch.object(controller, 'ROOT', root), patch.object(controller, 'run_owned') as launched:
                controller.plan_inputs()
                path = root / plan['models']['qwen36']['input']
                path.write_text('{}')
                with self.assertRaises(ValueError):
                    controller.plan_inputs()
                launched.assert_not_called()

    def test_snapshot_uses_real_directories_and_only_file_symlinks(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            plan, _ = fixture(root)
            model = plan['models']['qwen36']
            target = Path(model['model_directory'])
            (target / 'subdir').mkdir()
            (target / 'subdir/tokenizer.json').write_text('{}')
            snapshot = root / 'owned/snapshot'
            stage_snapshot(model, snapshot)
            validate_snapshot(model, snapshot)
            self.assertTrue((snapshot / 'subdir').is_dir())
            self.assertFalse((snapshot / 'subdir').is_symlink())
            self.assertTrue((snapshot / 'weights.safetensors').is_symlink())
            self.assertEqual((snapshot / 'weights.safetensors').resolve(), target / 'weights.safetensors')
            (snapshot / 'subdir/tokenizer.json').unlink()
            with self.assertRaises(ValueError):
                validate_snapshot(model, snapshot)

    def test_clean_environment_has_exact_home_and_seven_key_profile(self):
        plan = controller.plan_inputs()
        with patch.dict(os.environ, {'MLX_FOREIGN_OVERRIDE': '1', 'DARKBLOOM_MEM_CAP_FRACTION': '1', 'PYTHONOPTIMIZE': '2'}):
            value = controller.environment(plan, Path('/owned/cell'))
        self.assertNotIn('HOME', value)
        self.assertNotIn('MLX_FOREIGN_OVERRIDE', value)
        self.assertNotIn('DARKBLOOM_MEM_CAP_FRACTION', value)
        self.assertNotIn('PYTHONOPTIMIZE', value)
        self.assertEqual(value['CFFIXED_USER_HOME'], '/owned/cell/fixture-home')
        self.assertEqual({key: value[key] for key in controller.GEMMA_KEYS}, plan['effective_gemma_environment'])

    def test_wrong_host_invalid_heat_load_or_disk_refuse(self):
        binding = read_json(ROOT / 'binding-template.json')
        ready = {'processes': [], 'gpu_temp_c': 30, 'load': [0, 0, 0], 'free_disk_bytes': 100 << 30,
                 'username': 'gaj', 'ipv4_addresses': ['100.124.35.99'], **binding['host_identity']}
        readiness_checks(ready, binding)
        faults = {'username': 'other', 'ipv4_addresses': ['127.0.0.1'], 'hardware_model': 'wrong', 'memory_bytes': 1,
                  'gpu_temp_c': -1, 'load': [float('nan')], 'free_disk_bytes': 20 << 30, 'processes': [123]}
        for key, value in faults.items():
            with self.subTest(fault=key):
                with self.assertRaises(ValueError):
                    readiness_checks(dict(ready, **{key: value}), binding)

    def test_readiness_subcommands_and_outer_probes_have_timeouts(self):
        with patch.object(readiness.subprocess, 'check_output', return_value='ok') as child:
            readiness.capture(['ps'])
            self.assertEqual(child.call_args.kwargs['timeout'], 5)
        with tempfile.TemporaryDirectory() as temporary:
            output = Path(temporary) / 'probe'
            with self.assertRaises(ValueError):
                controller.probe([sys.executable, '-c', 'import time;time.sleep(120)'], controller.controller_environment(), output, .03)
            record = read_json(output / 'process.json')
            self.assertIn('TimeoutExpired', record['failure'])
            self.assertTrue(record['group_cleanup_complete'])
            self.assertFalse(running(record['pid']))

    def test_empty_observed_predecessor_and_failed_predecessor_refuse(self):
        for status in ('refused', 'observed'):
            with self.subTest(status=status), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary).resolve()
                plan, binding = fixture(root)
                cell = plan['cells'][0]
                previous = root / 'results' / cell['id']
                previous.mkdir(parents=True)
                save(previous / 'summary.json', {'schema': 2, 'status': status, 'cell': cell['id'], 'files': {},
                                                'binding_sha256': digest(root / 'binding.json'), 'plan_sha256': binding['plan_sha256']})
                save(previous / 'binding.json', binding)
                with self.assertRaises(ValueError):
                    check_previous(root, plan, cell, binding, digest(root / 'binding.json'), [], {})

    def test_success_requires_complete_report_and_retirement_and_allows_next_cell(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary).resolve()
            plan, binding = fixture(root)
            first = subprocess.run(invocation(root), capture_output=True, text=True, timeout=30)
            self.assertEqual(first.returncode, 0, first.stderr)
            output = root / 'results/qwen36-contiguous'
            summary = read_json(output / 'summary.json')
            self.assertEqual(summary['status'], 'observed')
            self.assertEqual(set(summary['files']), REQUIRED_FILES)
            live = read_json(output / 'live.json')
            save(output / 'live.json', dict(live, pid=live['pid'] + 1))
            summary['files']['live.json'] = identity(output / 'live.json')
            save(output / 'summary.json', summary)
            with self.assertRaises(ValueError):
                check_previous(root, plan, plan['cells'][0], binding, digest(root / 'binding.json'), read_json(output / 'command.json')['argv'], read_json(output / 'command.json')['environment'])
            save(output / 'live.json', live)
            summary['files']['live.json'] = identity(output / 'live.json')
            save(output / 'summary.json', summary)
            second = subprocess.run(invocation(root, 'qwen36-paged'), capture_output=True, text=True, timeout=30)
            self.assertEqual(second.returncode, 0, second.stderr)
            report = read_json(output / 'report.json')
            report['activity'][0]['decodeForwards'] += 1
            save(output / 'report.json', report)
            summary['files']['report.json'] = identity(output / 'report.json')
            save(output / 'summary.json', summary)
            argv = read_json(output / 'command.json')['argv']
            env = read_json(output / 'command.json')['environment']
            with self.assertRaises(ValueError):
                check_previous(root, plan, plan['cells'][0], binding, digest(root / 'binding.json'), argv, env)

    def test_nonzero_and_malformed_report_retain_failed_summary(self):
        for mode in ('nonzero', 'malformed'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary).resolve()
                fixture(root, mode)
                result = subprocess.run(invocation(root), capture_output=True, text=True, timeout=30)
                self.assertNotEqual(result.returncode, 0)
                output = root / 'results/qwen36-contiguous'
                self.assertEqual(read_json(output / 'summary.json')['status'], 'refused')
                self.assertTrue(read_json(output / 'process.json')['group_cleanup_complete'])
                self.assertTrue((output / 'report.json').is_file())

    def test_normal_exit_timeout_and_signals_retire_ignoring_descendants(self):
        for mode, signum in [('descendant', None), ('timeout', None), ('signals', signal.SIGTERM), ('signals', signal.SIGHUP)]:
            with self.subTest(mode=mode, signal=signum), tempfile.TemporaryDirectory() as temporary:
                root = Path(temporary).resolve()
                fixture(root, mode)
                owner = subprocess.Popen(invocation(root), stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
                descendants = None
                try:
                    deadline = time.monotonic() + 8
                    while owner.poll() is None and not (root / 'descendant.json').exists() and time.monotonic() < deadline:
                        time.sleep(.01)
                    self.assertTrue((root / 'descendant.json').is_file())
                    descendants = read_json(root / 'descendant.json')
                    time.sleep(.05)
                    if signum:
                        owner.send_signal(signum)
                    _, stderr = owner.communicate(timeout=35)
                    output = root / 'results/qwen36-contiguous'
                    summary = read_json(output / 'summary.json')
                    record = read_json(output / 'process.json')
                    self.assertTrue(record['group_cleanup_complete'], stderr.decode())
                    self.assertEqual(record['signal_errors'], [])
                    self.assertIn(int(signal.SIGKILL), record['signals_sent'])
                    self.assertFalse(running(descendants['leader']))
                    self.assertFalse(running(descendants['child']))
                    self.assertEqual(summary['status'], 'observed' if mode == 'descendant' else 'refused')
                    self.assertEqual(owner.returncode == 0, mode == 'descendant')
                finally:
                    if descendants:
                        try:
                            os.killpg(descendants['leader'], signal.SIGKILL)
                        except ProcessLookupError:
                            pass
                    if owner.poll() is None:
                        owner.kill()
                        owner.communicate(timeout=3)

    def test_peer_review_gate_refuses_before_runtime_or_output(self):
        result = subprocess.run([sys.executable, '-B', *(['-O'] if sys.flags.optimize else []), str(ROOT / 'controller.py'), 'qwen36-contiguous',
                                 '--binding', str(ROOT / 'binding-template.json'), '--binding-sha256', digest(ROOT / 'binding-template.json')],
                                capture_output=True, text=True, timeout=10)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn('peer review', result.stderr)
        self.assertFalse((ROOT / 'results').exists())


if __name__ == '__main__':
    unittest.main()
