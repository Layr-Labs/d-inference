from pathlib import Path
import difflib, hashlib, io, json, shutil, subprocess, tarfile

out = Path(__file__).resolve().parent
source = Path('/tmp/darkbloom-segment-dispatch-cache-source1')
primary = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated/libs/mlx-swift-lm')
candidate = Path('/Users/gaj/Documents/DarkbloomDev/wt/segmented-dispatch-metadata-cache/libs/mlx-swift-lm')
prior = Path('/tmp/darkbloom-attention-packet-native-validation1')
scratch = Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift')
local_mlx = Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value):
    (out/name).write_text(json.dumps(value, indent=2)+'\n')

assert sha(source/'manifest.json') == '8b576163354e1ee9597cb4e7bac0665d0d19f5ff8190c9797bce5a19edc280bd'
for name, row in json.loads((source/'manifest.json').read_text())['files'].items():
    assert sha(source/name) == row['sha256'], name
proof = json.loads((source/'source-proof.json').read_text())
base = proof['native_base']
assert base == '7d32d43977a5774f223b6892ecfbbaa844047600'
package = out/'native'
package.mkdir()
archive = subprocess.check_output(['git', 'archive', base], cwd=primary)
with tarfile.open(fileobj=io.BytesIO(archive)) as packed:
    packed.extractall(package, filter='data')
before_after = {}
for name, row in proof['files'].items():
    path = package/name
    before = sha(path) if path.is_file() else None
    assert before == row['before_sha256'], name
    frozen = source/'sources'/name
    assert sha(frozen) == sha(candidate/name) == row['after_sha256'], name
    assert frozen.stat().st_size == row['bytes'], name
    before_after[name] = {'archived_base_before_sha256': before, 'live_candidate_after_sha256': sha(candidate/name), 'matched': True}
    path.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(frozen, path)
write('before-after-check.json', before_after)
canonical = {str(p.relative_to(package)): sha(p) for p in sorted(package.rglob('*')) if p.is_file()}
before = (package/'Package.swift').read_text()
old = '.package(url: "https://github.com/Layr-Labs/mlx-swift.git", branch: "main")'
assert before.count(old) == 1
after = before.replace(old, '.package(path: "'+str(local_mlx)+'")')
(package/'Package.swift').write_text(after)
(out/'package-compile-only-overlay.patch').write_text(''.join(difflib.unified_diff(
    before.splitlines(keepends=True), after.splitlines(keepends=True),
    fromfile='canonical/Package.swift', tofile='compiled/Package.swift')))
resolved = prior/'native/Package.resolved'
assert sha(resolved) == '4bf9d78d1ce65d7458d881a7f27854da04c728fff7f6fe429a9255e9245ebaef'
shutil.copy2(resolved, package/'Package.resolved')
for name in ['dependency-source-manifest.json', 'jinja-source-manifest.json', 'run-nested-suite.sh']:
    shutil.copy2(prior/name, out/name)
deps = json.loads((out/'dependency-source-manifest.json').read_text())
for key, digest in deps['files'].items():
    alias, name = key.split('/', 1)
    assert sha(Path(deps['repositories'][alias])/name) == digest, key
for name, digest in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():
    assert sha(scratch/'checkouts/swift-jinja'/name) == digest, name
availability = json.loads((prior/'pinned-availability-api.json').read_text())
for name, row in availability['files'].items():
    assert sha(Path(row['path'])) == row['sha256'] == deps['files'][name], name
shutil.copy2(prior/'pinned-availability-api.json', out/'pinned-availability-api.json')
actual = {str(p.relative_to(package)): sha(p) for p in sorted(package.rglob('*')) if p.is_file()}
write('native-source-manifest.json', {'base_commit': base, 'canonical_files': canonical,
                                    'files': actual, 'candidate_changes': proof['files']})
shutil.copy2(source/'filters.json', out/'filters.json')
shutil.copy2(source/'manifest.json', out/'approved-source-manifest.json')
write('integration.json', {
    'status': 'PREPARED_ONLY_NO_SWIFT_PROCESS_STARTED', 'package': str(package), 'scratch': str(scratch),
    'native_base': base, 'canonical_inputs': len(canonical), 'native_inputs': len(actual),
    'source_manifest': str(source/'manifest.json'), 'source_manifest_sha256': sha(source/'manifest.json'),
    'package_resolved_sha256': sha(package/'Package.resolved'),
    'dependency_inputs_verified': len(deps['files']), 'availability_api_inputs_verified': len(availability['files']),
    'compile_policy': 'Root authorized isolated source1 and targeted validation under sole local Swift; jobs4, disable automatic resolution, pinned metallib. No optimized build or real-model run.',
    'other_unintegrated_candidates_included': False,
})
print(json.dumps({'package': str(package), 'native_inputs': len(actual), 'canonical_inputs': len(canonical),
                  'source_changes': len(proof['files']), 'swift_started': False}, indent=2))
