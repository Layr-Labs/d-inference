import Foundation
struct Row: Codable { let id: String; let bits: String?; let template: String; let output: String }
let templates = ["{{ value | tojson }}", "{{ value | tojson(2, false) }}"]
var accentKeys: [String: Any] = [:]
accentKeys["é"] = 1
accentKeys["e\u{301}"] = 2
let edge: [(String, Value)] = [
    ("numeric_keys", .object(["2": .int(2), "10": .int(10), "01": .int(1), "1": .int(3)])),
    ("unicode_keys", .object(["e": .int(1), "e\u{300}": .int(2), "e\u{302}": .int(3), "é": .int(4), "êx": .int(5)])),
    ("canonical_collision_last_assignment", try Value(any: accentKeys)),
    ("infinity_array", .array([.double(.infinity), .int(1)])),
    ("nan", .double(.nan)), ("minus_infinity", .double(-.infinity)),
    ("nan_object", .object(["nested": .object(["a": .int(1), "b": .double(.nan)])])),
    ("minus_infinity_array", .array([.array([.double(-.infinity)]), .int(1)])),
    ("positional_unicode", .object(["猫": .string("雪 🐱 /")]))
]
var rows: [Row] = []
for (id, value) in edge {
    for (i, source) in templates.enumerated() {
        rows.append(Row(id: id + "_\(i)", bits: nil, template: source, output: try Template(source).render(["value": value])))
    }
}
var bits: UInt64 = 0xd4b1090920260905
for i in 0 ..< 512 {
    bits = bits &* 6364136223846793005 &+ 1442695040888963407
    let value = Double(bitPattern: bits)
    guard value.isFinite else { continue }
    rows.append(Row(id: "finite_\(i)", bits: String(bits, radix: 16), template: templates[0], output: try Template(templates[0]).render(["value": .double(value)])))
}
let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys, .prettyPrinted]
print(String(decoding: try encoder.encode(rows), as: UTF8.self))
