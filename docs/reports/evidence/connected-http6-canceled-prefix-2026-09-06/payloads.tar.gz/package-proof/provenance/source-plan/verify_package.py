#!/usr/bin/env python3
"""Verify frozen package bytes and modes without invoking providers or services."""
from pathlib import Path
import json
import stat
from temporary_model_alias import digest
from run_connected_fixture import verify_executable


def verify_package(base):
    verify_executable(base/'connected-e2e.test')
    manifest = json.loads((base/'package-manifest.json').read_text())
    for name, item in manifest['files'].items():
        rel = Path(name)
        if rel.is_absolute() or '..' in rel.parts:
            raise ValueError('nonlocal package path')
        path = base/rel
        info = path.lstat()
        if (not stat.S_ISREG(info.st_mode) or stat.S_IMODE(info.st_mode) != item['mode']
                or info.st_size != item['bytes'] or digest(path) != item['sha256']):
            raise ValueError('package mismatch: ' + name)
    return {'verified_files':len(manifest['files']), 'source_commit':manifest['source_commit'],
            'scope':'package byte/mode integrity only; no connected execution'}


if __name__ == '__main__':
    print(json.dumps(verify_package(Path(__file__).resolve().parent), indent=2))
