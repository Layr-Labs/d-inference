import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock

from run_connected_fixture import preflight


class FlatRuntimeTests(unittest.TestCase):
    def test_actual_flat_resources_and_external_sidecar_are_rechecked(self):
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp).resolve()
            runtime = root/'artifact'
            runtime.mkdir()
            target = root/'target'
            target.mkdir()
            (target/'config.json').write_bytes(b'{}')
            (root/'.config/darkbloom').mkdir(parents=True)
            config = root/'.config/darkbloom/provider.toml'
            config.write_bytes(b'canonical')
            sidecar = root/'separate-sidecar'
            sidecar.write_bytes(b'sidecar')
            sidecar.chmod(0o755)
            go = root/'connected-e2e.test'
            go.write_bytes(b'go-test')
            go.chmod(0o755)
            files = {}
            for name in ['darkbloom', 'mlx.metallib', 'runtime.bundle/resource']:
                path = runtime/name
                path.parent.mkdir(exist_ok=True)
                path.write_bytes(name.encode())
                if name == 'darkbloom':
                    path.chmod(0o755)
                files['bin/'+name] = {'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
            digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
            files['bin/promptsidecar'] = {'sha256': digest(sidecar)}
            files['bin/radix-engine'] = {'sha256': 'probe-is-not-a-connected-runtime'}
            (root/'source-inputs').mkdir()
            (root/'source-inputs/payload--transfer-manifest.json').write_text(json.dumps({'files':files}))
            manifest = {'aggregate_sha256':'target-aggregate', 'files':[
                {'path':'config.json', 'size_bytes':2, 'sha256':digest(target/'config.json')}]}
            (root/'target-manifest.json').write_text(json.dumps(manifest))
            plan = {'expected_request_date_utc':datetime.datetime.now(datetime.timezone.utc).date().isoformat(),
                    'canonical_config_sha256':digest(config)}
            cell = {'model_directory':str(target), 'model_manifest':'target-manifest.json'}
            data = {'artifact':{'model_id':'target'}, 'provider_binary':str(runtime/'darkbloom'),
                    'provider_sha256':digest(runtime/'darkbloom'),
                    'metallib_sha256':digest(runtime/'mlx.metallib'),
                    'sidecar_binary':str(sidecar), 'sidecar_sha256':digest(sidecar)}
            with (mock.patch.dict(os.environ, {}, clear=True),
                  mock.patch('run_connected_fixture.Path.home', return_value=root),
                  mock.patch('run_connected_fixture.assert_idle'),
                  mock.patch('run_connected_fixture.verify_discovery', return_value=str(target)),
                  mock.patch('run_connected_fixture.subprocess.run', return_value=subprocess.CompletedProcess([],0,''))):
                self.assertEqual(preflight(root,plan,cell,data)['manifest_files_verified'],1)
                resource = runtime/'runtime.bundle/resource'
                original = resource.read_bytes()
                resource.write_bytes(b'changed')
                with self.assertRaisesRegex(ValueError, 'colocated runtime identity mismatch'):
                    preflight(root,plan,cell,data)
                resource.write_bytes(original)
                sidecar.write_bytes(b'changed')
                with self.assertRaisesRegex(ValueError, 'runtime digest differs'):
                    preflight(root,plan,cell,data)


if __name__ == '__main__':
    unittest.main()
