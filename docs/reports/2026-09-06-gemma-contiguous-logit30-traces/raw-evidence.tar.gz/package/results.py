from pathlib import Path
import sys
from common import ROOT, MANDATORY, check_file, digest, read_json, require, safe_file

sys.path.insert(0, str(ROOT / 'runner'))
from compare_radix_engine import mismatch
from control_validation import control_errors, trajectories
from radix_engine_evidence import report_errors

def result_errors(directory, cell, binding, manifest_sha):
    directory = Path(directory)
    report = read_json(directory / 'report.json')
    original = read_json(ROOT / 'inputs/reference-prompt-ids.json')
    for name in ['input.json', 'native-argv.json', 'environment.json', 'preflight.json', 'postflight.json', 'terminal.json', 'metadata.json']:
        require((directory / name).is_file(), 'mandatory receipt missing: ' + name)
    errors = []
    observed = report
    if cell.get('trace'):
        # Keep the original control validator unchanged; validate the real trace too.
        observed = dict(report)
        observed.pop('logit_diagnostic', None)
        errors += report_errors(report)
        if report.get('logit_diagnostic', {}).get('status') != 'captured':
            errors.append({'required_logit_trace_missing': True})
    if cell['projection']:
        observed = dict(report)
        observed.pop('gemma_projection', None)
        if report.get('gemma_projection_tokens_requested') != [529, 62203] or report.get('gemma_projection', {}).get('status') != 'captured':
            errors.append({'projection_capture_missing': True})
    errors += control_errors(observed, cell['backend'], cell['mode'], binding['runtime'], original)
    metadata = read_json(directory / 'metadata.json')
    terminal = read_json(directory / 'terminal.json')
    environment = read_json(directory / 'environment.json')
    expected_environment = {'HOME': '/Users/gaj', 'PATH': '/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
        'PYTHONDONTWRITEBYTECODE': '1', **binding['profile'],
        'DARKBLOOM_PREFIX_CACHE_TEST_ROOT': binding['root'] + '/runs/' + cell['id'] + '/prefix-cache',
        'DARKBLOOM_PREFIX_CACHE_ALLOW_EPHEMERAL': '1', 'DARKBLOOM_PREFIX_CACHE_TEST_PERSISTENT_KEY': '0'}
    if environment != expected_environment or read_json(directory / 'native-argv.json') != cell['native_argv']:
        errors.append({'wrong_effective_environment_or_native_argv': True})
    if (metadata.get('manifest_sha256') != manifest_sha or metadata.get('cell') != cell['id']
            or metadata.get('native_argv') != cell['native_argv'] or metadata.get('effective_environment') != expected_environment
            or digest(directory / 'input.json') != binding['input_sha256']):
        errors.append({'wrong_cell_receipt_binding': True})
    if (terminal.get('exit_code') != 0 or terminal.get('failure') is not None or terminal.get('stop_requested')
            or terminal.get('group_cleanup_complete') is not True or not metadata.get('model_ready_observed')
            or metadata.get('telemetry_exit_before_cleanup') is not None
            or metadata.get('telemetry_cleanup', {}).get('group_cleanup_complete') is not True):
        errors.append({'owned_process_or_readiness_failure': True})
    for phase in ['preflight', 'postflight']:
        value = read_json(directory / (phase + '.json'))
        if value.get('passed') is not True or value.get('host_identity') != binding['host_identity']['sha256']:
            errors.append({'invalid_prepost_verification': phase})
    tenants = report.get('tenant_checks', [])
    if len(tenants) != 3 or any(mismatch(tenants[0], row) for row in tenants[1:]):
        errors.append({'tenant_output_mismatch': True})
    assistant = report.get('metrics_loaded', {}).get('assistant_identity', {})
    if cell['mode'] != 'off':
        if (assistant.get('config_sha256') != binding['assistant']['files']['config.json']['sha256']
                or assistant.get('weight_sha256.model.safetensors') != binding['assistant']['files']['model.safetensors']['sha256']):
            errors.append({'wrong_original_assistant_identity': True})
    for label, row in trajectories(report) + [('cancelled', report.get('cancelled', {}))]:
        after = row.get('metrics_after', {})
        if after.get('memory_cache_enabled') or after.get('resident_bank_budget_bytes', 0):
            errors.append({'unexpected_resident_cache': label})
    return errors

def verify_completed(directory, cell, binding, manifest_sha):
    directory = Path(directory)
    inventory = read_json(directory / 'manifest.json')['files']
    require(MANDATORY <= set(inventory), 'incomplete predecessor evidence inventory')
    for name, row in inventory.items():
        check_file(safe_file(directory, name), row)
    summary = read_json(directory / 'summary.json')
    require(summary.get('execution_valid') is True and summary.get('cell') == cell['id']
            and summary.get('manifest_sha256') == manifest_sha, 'predecessor did not complete')
    require(not result_errors(directory, cell, binding, manifest_sha), 'predecessor fails fresh validation')
