from pathlib import Path
import hashlib,json,shutil

out=Path('/tmp/darkbloom-q36-logit-diagnostic-validation3')
old=Path('/tmp/darkbloom-q36-logit-diagnostic-validation2')
source=Path('/tmp/darkbloom-q36-logit-diagnostic-source/freeze2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for root in [old,source]:
 for name,row in json.loads((root/'manifest.json').read_text())['files'].items():assert sha(root/name)==row['sha256'],name
shutil.copytree(old/'native',out/'native')
for name in ['native-source-manifest.json','ancillary-package-manifest.json','dependency-source-manifest.json','jinja-source-manifest.json','run-nested-suite.sh','filters.json']:
 shutil.copy2(old/name,out/name)
name='Tests/MLXLMTests/CBv2QwenMTPIntegrationTests.swift'
correction=json.loads((source/'correction.json').read_text())
assert sha(out/'native'/name)==correction['before_sha256']
shutil.copy2(source/'files/native'/name,out/'native'/name)
m=json.loads((out/'native-source-manifest.json').read_text());m['files'][name]=sha(out/'native'/name);m['candidate_changes'][name]['after_sha256']=m['files'][name];m['candidate_changes'][name]['bytes']=(out/'native'/name).stat().st_size
(out/'native-source-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
info=json.loads((old/'integration.json').read_text());info['native']=str(out/'native');info['source_manifest']=str(source/'manifest.json');info['source_manifest_sha256']=sha(source/'manifest.json');info['preserved_test_compile_failure']={'manifest':str(old/'manifest.json'),'sha256':sha(old/'manifest.json')};info['correction']='Test-only inner try; no implementation/assertion change'
(out/'integration.json').write_text(json.dumps(info,indent=2)+'\n')
(out/'run.py').write_text((old/'run.py').read_text().replace("out=Path('/tmp/darkbloom-q36-logit-diagnostic-validation2')","out=Path('/tmp/darkbloom-q36-logit-diagnostic-validation3')"))
print('Prepared one-token test syntax correction; native implementation unchanged.')
