import json, os, re, resource, subprocess, time
from build_proof import OUT, WS, sha, write, verify, executable

assert (OUT/'source-verified-final.json').exists()
verify()
for product in ['radix-engine', 'darkbloom']:
    assert executable(OUT/'artifact'/product) == json.loads((OUT/(product+'-binary.json')).read_text())
fixture = OUT/'empty-report-for-argument-guards.json'
fixture.write_text('{"rows":[]}\n')
model = OUT/'model-must-not-exist'
report = OUT/'model-report-must-not-exist.json'
packet_directory = OUT/'model-report-must-not-exist.attention-packet'
assert not any(p.exists() for p in [model, report, packet_directory])
base = [str(OUT/'artifact/radix-engine'), str(model), str(fixture), str(report),
        'cache-off', 'mtp-off', 'paged', 'ssd', 'ephemeral-key', '--production-kv-grant']
metadata = ['--attention-metadata-position', '62']
logits = ['--logit-diagnostic-position', '62', '--logit-diagnostic-candidates', '1928,6829']
packet = ['--attention-packet-position', '62', '--attention-packet-layer', '0']
cases = []
for backend in ['contiguous', 'paged']:
    args = base.copy(); args[6] = backend
    for label, flags in [('default', []), ('packet-only', packet), ('all-diagnostics', metadata+logits+packet)]:
        cases.append((backend+'-'+label, args+flags, 'invalid/empty report', False))
mtp = base.copy(); mtp[5] = 'mtp-on'
concurrent = base+['--concurrency', '2']
probe = base[:-1]+['--native-kv-probe-only']
for kind, flags in [('metadata', metadata), ('packet', packet)]:
    for label, args in [('mtp', mtp), ('concurrent', concurrent), ('native-probe', probe)]:
        cases.append((kind+'-'+label+'-refused', args+flags,
                      'attention '+kind+' requires the B1, MTP-off serving SSD path', False))
cases += [
    ('metadata-zero-refused', base+['--attention-metadata-position', '0'], 'invalidConfiguration', False),
    ('metadata-duplicate-refused', base+metadata+metadata, 'missing, duplicate or invalid benchmark option', False),
    ('packet-no-layer-refused', base+packet[:2], 'attention packet requires both position and storage layer', False),
    ('packet-no-position-refused', base+packet[2:], 'attention packet requires both position and storage layer', False),
    ('packet-zero-refused', base+['--attention-packet-position', '0', '--attention-packet-layer', '0'], 'invalidConfiguration', False),
    ('packet-owner-bound-refused', base+['--attention-packet-position', '62', '--attention-packet-layer', '1024'], 'invalidConfiguration', False),
    ('packet-duplicate-refused', base+packet+packet, 'missing, duplicate or invalid benchmark option', False),
]
version_source = (WS/'provider-swift/Sources/ProviderCore/ProviderCore.swift').read_text()
version = re.search(r'(?:static let|static var) version\s*=\s*"([^"]+)"', version_source).group(1)
cases += [('cli-version', [str(OUT/'artifact/darkbloom'), '--version'], version, True),
          ('cli-help', [str(OUT/'artifact/darkbloom'), '--help'], 'USAGE: darkbloom', True)]
assert len(cases) == 21

def no_core(): resource.setrlimit(resource.RLIMIT_CORE, (0, 0))

env = {'PATH': '/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
       'HOME': os.environ['HOME'], 'DARKBLOOM_NO_UPDATE_CHECK': '1'}
rows = []
for name, command, expected, should_succeed in cases:
    started = time.monotonic()
    result = subprocess.run(command, env=env, text=True, stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, timeout=15, preexec_fn=no_core)
    (OUT/(name+'.log')).write_text(result.stdout)
    passed = ((result.returncode == 0) == should_succeed and expected in result.stdout
              and not any(p.exists() for p in [model, report, packet_directory])
              and 'radix-model-ready' not in result.stdout)
    if name == 'cli-version': passed = passed and result.stdout.strip() == version
    rows.append({'name': name, 'command': command, 'exit_code': result.returncode,
                 'seconds': time.monotonic()-started, 'expected_message': expected,
                 'expected_success': should_succeed, 'passed': passed})
    write('smoke-progress.json', rows)
    assert passed, (name, result.returncode, result.stdout)
for product in ['radix-engine', 'darkbloom']:
    assert executable(OUT/'artifact'/product) == json.loads((OUT/(product+'-binary.json')).read_text())
write('smoke-verdict.json', {
    'status': 'PASS_ARGUMENT_AND_CLI_PARSE_SMOKES_ONLY', 'checks': rows,
    'checks_passed': len(rows), 'all_passed': True, 'real_models_run': False,
    'provider_serve_or_runtime_smoke_invoked': False, 'cli_commands': ['--version', '--help'],
    'scope': 'Six valid probe flag combinations reach the owned empty-input guard; thirteen invalid flag combinations refuse earlier. CLI version/help exit successfully before subcommand execution. No model or serving job.',
})
print(json.dumps({'checks_passed': len(rows), 'model_or_serve_jobs': False}), flush=True)
