from pathlib import Path
import hashlib,json,subprocess

out=Path('/tmp/darkbloom-q36-logit-diagnostic-source/freeze2')
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/q36-logit-diagnostic-090')
native=root/'libs/mlx-swift-lm'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):(out/name).write_text(json.dumps(value,indent=2)+'\n')
owned={}
for label,tree,base in [('native',native,'a932d38cee0beca41ca1a0e71c1e867913a65353'),('harness',root,'9e49059a1806e265fd9ceab420c1b82216a5d785')]:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=tree,text=True).strip()==base
 paths=subprocess.check_output(['git','diff','--name-only'],cwd=tree,text=True).splitlines()
 paths=[p for p in paths if p!='libs/mlx-swift-lm']
 assert len(paths)==(11 if label=='native' else 4),(label,paths)
 subprocess.run(['git','diff','--check'],cwd=tree,check=True)
 (out/(label+'.patch')).write_bytes(subprocess.check_output(['git','diff','--binary','--',*paths],cwd=tree))
 owned[label]={'base':base,'tree':str(tree),'files':{}}
 for path in paths:
  destination=out/'files'/label/path;destination.parent.mkdir(parents=True,exist_ok=True)
  destination.write_bytes((tree/path).read_bytes())
  previous=subprocess.run(['git','show',base+':'+path],cwd=tree,capture_output=True)
  owned[label]['files'][path]={'before_sha256':hashlib.sha256(previous.stdout).hexdigest() if previous.returncode==0 else None,'after_sha256':sha(destination),'bytes':destination.stat().st_size}
write('source-proof.json',owned)
write('STATUS.json',{'status':'SOURCE_REVIEW_REQUIRED_NOT_COMPILED','provider_base':owned['harness']['base'],'native_base':owned['native']['base'],'native_paths':11,'harness_paths':4,'primary_mutated':False,'real_models_run':False,'compiles_run':False,'tests_run':False,'timing_performance_evidence':False,'full_logits_export':False,'actual_query_dtype_measured':False,'next':'Root source review, then isolated local validation; coordinated provider receipt fix remains a separate source scope.'})
files={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
write('manifest.json',{'schema':1,'status':'SOURCE_REVIEW_REQUIRED_NOT_COMPILED','files':files})
for path,row in files.items():assert sha(out/path)==row['sha256']
print(json.dumps({'manifest':str(out/'manifest.json'),'sha256':sha(out/'manifest.json'),'payloads':len(files),'native_patch_sha256':sha(out/'native.patch'),'harness_patch_sha256':sha(out/'harness.patch')},indent=2))
