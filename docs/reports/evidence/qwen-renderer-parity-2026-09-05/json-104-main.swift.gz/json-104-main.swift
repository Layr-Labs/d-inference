import Foundation

struct Row: Codable { let id: String; let template: String; let output: String }
let values: [(String, Value)] = [
    ("nested", .object(["z": .array([.object(["y": .int(2), "a": .int(1)])]), "a": .object(["B": .int(3), "a": .int(4)])])),
    ("unicode", .object(["z": .string("é 🐱 日本語 / slash < > & ' \" \\ \u{2028}\u{2029}"), "é": .string("line\nreturn\rtab\tback\u{08}form\u{0c}\u{01}")])),
    ("numbers", .array([.double(1), .double(-0.0), .double(0.000001), .double(0.0000001), .double(1e20), .double(1e21), .double(1.25), .double(100000000000000000000.0), .double(1e15), .double(1e16), .double(1.2345678901234567), .int(9007199254740993), .int(Int.max), .int(Int.min)])),
    ("keysort", .object(["Z": .int(1), "a": .int(2), "_": .int(3), "é": .int(4), "e": .int(5), "A": .int(6), "中": .int(7)])),
    ("transitions", .array([.double(1e-3), .double(1e-4), .double(1e-5), .double(1e14), .double(1e15), .double(1e16), .double(1.2345e-4), .double(1.2345e-5), .double(1.23456789e15), .double(1.23456789e16), .double(0), .double(-0.0), .double(Double.leastNonzeroMagnitude), .double(Double.greatestFiniteMagnitude)])),
    ("unicode_order", .object(["\u{E000}": .int(1), "\u{10000}": .int(2)])),
    ("empty", .object(["object": .object([:]), "array": .array([])])),
    ("primitives", .array([.boolean(true), .boolean(false), .null, .string("")])),
]
var rows: [Row] = []
for (id, value) in values {
    for (option, source) in [("default", "{{ value | tojson }}"), ("unicode", "{{ value | tojson(ensure_ascii=false) }}"), ("ascii_zero", "{{ value | tojson(ensure_ascii=0) }}"), ("ascii_string", "{{ value | tojson(ensure_ascii='false') }}"), ("ascii_empty", "{{ value | tojson(ensure_ascii='') }}"), ("indent_null", "{{ value | tojson(indent=none) }}"), ("indent0", "{{ value | tojson(indent=0) }}"), ("indent1", "{{ value | tojson(indent=1) }}"), ("indent2", "{{ value | tojson(indent=2) }}"), ("indent4", "{{ value | tojson(indent=4, ensure_ascii=false) }}"), ("indent_true", "{{ value | tojson(indent=true) }}"), ("indent_minus1", "{{ value | tojson(indent=-1) }}"), ("indent_string", "{{ value | tojson(indent='4') }}")] {
        let template = try Template(source)
        rows.append(Row(id: id + "_" + option, template: source, output: try template.render(["value": value])))
    }
}
let encoder = JSONEncoder(); encoder.outputFormatting = [.sortedKeys, .prettyPrinted]
print(String(decoding: try encoder.encode(rows), as: UTF8.self))
