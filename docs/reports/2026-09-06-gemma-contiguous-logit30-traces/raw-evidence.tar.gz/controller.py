import argparse
import json
import os
from pathlib import Path
import selectors
import shlex
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
PACKAGE = ROOT / 'package'
sys.path.insert(0, str(PACKAGE))
import owner_host
from common import check_file, digest, read_json, require, safe_file, verify_package, write_json
from results import verify_completed

OPTIONS = ['-T', '-i', '/Users/gaj/.ssh/darkbloom_testbox', '-o', 'IdentitiesOnly=yes',
           '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=30', '-o', 'ServerAliveInterval=5', '-o', 'ServerAliveCountMax=3',
           '-o', 'ControlMaster=no', '-o', 'ControlPath=none']
SIGNALS = (signal.SIGTERM, signal.SIGHUP, signal.SIGINT)

def command(binding, cell, expected_sha, inventory=False):
    argv = ['/usr/bin/env', '-i', 'HOME=/Users/gaj', 'PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin',
            'PYTHONDONTWRITEBYTECODE=1', '/Applications/Xcode.app/Contents/Developer/usr/bin/python3', '-B',
            binding['root'] + '/remote_owner.py', '--manifest-sha256', expected_sha, '--cell', cell['id']]
    if inventory:
        argv.append('--inventory')
    return ['ssh'] + OPTIONS + [binding['host'], shlex.join(argv)]

def launch(binding, cell, expected_sha, output):
    process = None
    previous = {sig: signal.getsignal(sig) for sig in SIGNALS}
    record = {'argv': command(binding, cell, expected_sha), 'failure': None, 'exit_code': None}
    selector = selectors.DefaultSelector()
    def interrupted(signum, frame):
        for sig in SIGNALS:
            signal.signal(sig, signal.SIG_IGN)
        raise InterruptedError('local controller signal ' + str(signum))
    for sig in SIGNALS:
        signal.signal(sig, interrupted)
    try:
        with (output / 'ssh.stderr').open('xb') as stderr, (output / 'events.jsonl').open('xb') as events:
            mask = signal.pthread_sigmask(signal.SIG_BLOCK, SIGNALS)
            try:
                process = subprocess.Popen(record['argv'], stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                    stderr=stderr, start_new_session=True,
                    preexec_fn=lambda: signal.pthread_sigmask(signal.SIG_SETMASK, mask))
                record['pid'] = process.pid
                write_json(output / 'ssh-live.json', {'pid': process.pid, 'pgid': process.pid, 'argv': record['argv']})
            finally:
                signal.pthread_sigmask(signal.SIG_SETMASK, mask)
            selector.register(process.stdout, selectors.EVENT_READ)
            deadline = time.monotonic() + binding['limits']['control_seconds']
            last_ping = 0
            native_started = None
            ready = False
            pending = b''
            request_id = 0
            control_closed = False
            while process.poll() is None:
                now = time.monotonic()
                require(now < deadline, 'overall cell deadline expired')
                require(native_started is None or ready or now - native_started <= binding['limits']['startup_seconds'] + 5,
                        'model readiness deadline expired')
                if not control_closed and now - last_ping >= 2:
                    request_id += 1
                    frame = {'command': 'observe', 'id': request_id} if native_started is not None else {'command': 'ping'}
                    try:
                        process.stdin.write((json.dumps(frame) + '\n').encode()); process.stdin.flush()
                    except BrokenPipeError:
                        control_closed = True
                    last_ping = now
                if not selector.select(0.25):
                    continue
                chunk = os.read(process.stdout.fileno(), 8192)
                if not chunk:
                    break
                events.write(chunk); events.flush(); pending += chunk
                require(len(pending) <= 1 << 20, 'control event exceeds limit')
                while b'\n' in pending:
                    line, pending = pending.split(b'\n', 1)
                    event = json.loads(line, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
                    if event.get('event') == 'started':
                        require(type(event.get('pid')) is int and event['pid'] > 0, 'invalid owned PID')
                        native_started = time.monotonic()
                    elif event.get('event') == 'observation':
                        ready = ready or event.get('observation', {}).get('model_ready') is True
            record['exit_code'] = process.wait(timeout=10)
    except Exception as error:
        record['failure'] = type(error).__name__ + ': ' + str(error)
    finally:
        for sig in SIGNALS:
            signal.signal(sig, signal.SIG_IGN)
        try:
            if process is not None:
                if process.stdin is not None:
                    try:
                        process.stdin.close()
                    except OSError:
                        pass
                if process.poll() is None:
                    try:
                        process.wait(timeout=220)
                    except subprocess.TimeoutExpired:
                        pass
                owner_host.retire_group(process, record)
        except Exception as error:
            record['group_cleanup_complete'] = False
            record['failure'] = (record['failure'] or '') + ' cleanup: ' + str(error)
        finally:
            selector.close()
            write_json(output / 'local-process.json', record)
            for sig, handler in previous.items():
                signal.signal(sig, handler)
    return record

def collect(binding, cell, expected_sha, output):
    inventory = subprocess.run(command(binding, cell, expected_sha, inventory=True), text=True,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=180)
    (output / 'inventory.stdout').write_text(inventory.stdout)
    (output / 'inventory.stderr').write_text(inventory.stderr)
    require(inventory.returncode == 0, 'remote result inventory failed')
    value = json.loads(inventory.stdout)
    require(value.get('exists') is True, 'remote result root missing')
    for name, row in value['files'].items():
        path = safe_file(output, name)
        require(bool(__import__('re').fullmatch('[A-Za-z0-9_./-]+', name)), 'unsafe collected filename')
        require(row['bytes'] <= binding['limits']['max_file_bytes'], 'collected file too large')
        path.parent.mkdir(parents=True, exist_ok=True)
        argv = ['scp', '-q', '-p'] + OPTIONS[1:] + [binding['host'] + ':' + binding['root'] + '/runs/' + cell['id'] + '/' + name, str(path)]
        result = subprocess.run(argv, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=90)
        require(result.returncode == 0, 'result transfer failed: ' + result.stderr)
        check_file(path, row)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--cell', required=True)
    parser.add_argument('--collect-only', action='store_true')
    args = parser.parse_args()
    binding = verify_package(args.manifest_sha256, PACKAGE, local=True)
    require(binding.get('state') == 'peer_reviewed', 'root review and hardware handoff required before SSH or execution')
    require(digest(Path(__file__)) == digest(PACKAGE / 'local-controller.py'), 'local controller source changed')
    cell = next((value for value in binding['cells'] if value['id'] == args.cell), None)
    require(cell is not None, 'unknown cell')
    results = ROOT / 'results'
    for prior in binding['cells'][:binding['cells'].index(cell)]:
        verify_completed(results / prior['id'], prior, binding, args.manifest_sha256)
    output = results / cell['id']
    if args.collect_only:
        require(output.is_dir(), 'collection requires the existing local receipt root')
    else:
        output.mkdir(parents=True, exist_ok=False)
        launch(binding, cell, args.manifest_sha256, output)
    collect(binding, cell, args.manifest_sha256, output)
    record = read_json(output / 'local-process.json')
    require(record.get('exit_code') == 0 and record.get('failure') is None
            and record.get('group_cleanup_complete') is True, 'local owned SSH execution failed')
    verify_completed(output, cell, binding, args.manifest_sha256)
    print('Execution integrity verified: ' + cell['id'])

if __name__ == '__main__':
    main()
