"""Resume only the owned archive-only root left by the pre-extraction syntax failure."""
from pathlib import Path
import hashlib
import importlib.util
import json
import subprocess

OUT = Path('/tmp/darkbloom-qat-actual-logits-staging-resume1')
SOURCE = Path('/tmp/darkbloom-qat-actual-logits-staging1')
REMOTE = '/Users/gaj/autoresearch/radix-prefix-cache/090-qat-actual-logits1'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    OUT.mkdir(exist_ok=False)
    spec = importlib.util.spec_from_file_location('fixed_stage', SOURCE / 'stage.py')
    stage = importlib.util.module_from_spec(spec); spec.loader.exec_module(stage)
    stage.OUT = OUT
    package = SOURCE / 'plan-package.tar.gz'
    assert sha(package) == '5797cdd70e0ea3fe695d83006482d8b03e4d5a7b7d2bc5683e91767ba58b7801'
    inventory = json.loads((SOURCE / 'file-inventory.json').read_text())
    constants = {'root': REMOTE, 'archive_sha256': sha(package), 'archive_bytes': package.stat().st_size,
                 'inventory': inventory}
    code = 'CONFIG=' + repr(constants) + '\n' + '''from pathlib import Path
import datetime,hashlib,json,tarfile
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-09-06'
root=Path(CONFIG['root']);package=root/'plan-package.tar.gz';expected=CONFIG['inventory']
assert root.is_dir() and not root.is_symlink()
assert {p.name for p in root.iterdir()}=={'plan-package.tar.gz'}, 'Refuse any extracted/runtime/unowned entry'
assert package.is_file() and not package.is_symlink() and package.stat().st_size==CONFIG['archive_bytes']
assert hashlib.sha256(package.read_bytes()).hexdigest()==CONFIG['archive_sha256']
with tarfile.open(package,'r:gz') as tar:
 members=tar.getmembers();assert len(members)==len(expected) and {m.name for m in members}==set(expected)
 for member in members:
  assert member.isfile() and member.mode&0o777==expected[member.name]['mode']
  dest=root/member.name;assert not dest.exists()
  data=tar.extractfile(member).read();item=expected[member.name]
  assert len(data)==item['bytes'] and hashlib.sha256(data).hexdigest()==item['sha256']
  dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);dest.chmod(item['mode'])
for name,item in expected.items():
 p=root/name;assert p.stat().st_size==item['bytes'] and p.stat().st_mode&0o777==item['mode']
 assert hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
assert json.loads((root/'plan.json').read_text())['state']=='SOURCE_ONLY_PENDING_ROOT_REVIEW'
assert not (root/'runtime').exists()
print(json.dumps({'verified_files':len(expected),'bytes_hashes_modes_match':True,'owned_archive_only_resume':True,'runtime_present':False,'model_invoked':False},indent=2))
'''
    compile(code, '<resume-remote>', 'exec')
    (OUT / 'rendered-remote.py').write_text(code)
    ready = subprocess.run(['python3', '-B', '/tmp/darkbloom-qat-actual-logits-execution2/preflight.py',
                            str(OUT / 'ownership-before.json')], capture_output=True, text=True)
    (OUT / 'ownership-before.log').write_text(ready.stdout + ready.stderr)
    assert ready.returncode == 0, ready.stderr
    state = json.loads((OUT / 'ownership-before.json').read_text())
    assert not state['processes'] and state['free_disk_bytes'] > 100 * 1024**3
    verified = stage.remote('verify', code)
    (OUT / 'receipt.json').write_text(json.dumps({'preflight':state,'verification':verified,
                    'original_archive_sha256':sha(package)},indent=2)+'\n')
    files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in OUT.iterdir() if p.is_file()}
    (OUT / 'manifest.json').write_text(json.dumps({'status':'staging resumed and verified; no model invocation','files':files},indent=2,sort_keys=True)+'\n')
    print(json.dumps({'manifest_sha256':sha(OUT/'manifest.json'),**verified},indent=2))


if __name__ == '__main__':
    main()
