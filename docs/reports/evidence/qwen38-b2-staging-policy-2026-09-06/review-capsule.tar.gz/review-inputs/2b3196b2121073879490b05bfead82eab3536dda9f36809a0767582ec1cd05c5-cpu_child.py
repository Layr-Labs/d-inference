"""Harmless process fixtures only; never imports or invokes a model runner."""
import os
from pathlib import Path
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pilot
import pilot_core as core


def main():
    mode, root = sys.argv[1], Path(sys.argv[2])
    if mode == "supervise":
        scenario = sys.argv[3]
        step = root / "steps/1"; step.mkdir(parents=True)
        argv = [sys.executable, "-B", str(pilot.ROOT / "tracked_runner.py"), str(step / "children.jsonl"),
                str(Path(__file__).resolve()), scenario, str(root)]
        accepted = pilot.supervise(argv, core.ENV, root, sys.stdin.buffer,
                                   lease=float(sys.argv[4]), deadline=float(sys.argv[5]))
        if accepted:
            core.write_new(root / "worker-verdict.json", {"accepted": True, "cpu_fixture": True})
        return 0 if accepted else 1
    step = root / "steps/1"
    core.write_new(step / "wrapper.json", {"pid": os.getpid(), "allowed_executables": [sys.executable]})
    if mode == "complete":
        time.sleep(.2)
        return 0
    process = subprocess.Popen([sys.executable, "-B", "-c", "import time; time.sleep(60)"], start_new_session=True)
    core.write_new(root / "cpu-child.json", {"pid": process.pid, "birth": pilot.birth(process.pid)})
    process.wait()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
