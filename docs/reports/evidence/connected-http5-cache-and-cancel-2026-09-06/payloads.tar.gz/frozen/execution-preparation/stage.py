from pathlib import Path
import hashlib
import json
import subprocess
import sys

review = Path(sys.argv[1])
review_sha = sys.argv[2]
assert hashlib.sha256(review.read_bytes()).hexdigest() == review_sha
out = Path('/tmp/darkbloom-connected-http5-transfer1')
out.mkdir(exist_ok=False)
archive = Path('/tmp/darkbloom-connected-m5-bundle5.tar.gz')
archive_sha = '06eef81c7d1e03c93d59b0e0d330ecb4bd06c921702bf23b7b778fa546406101'
manifest_sha = '7c04de0ebc0064d31ce6aa642044d1075704bcf29779334c6d0a9d32aaa4efda'
remote = '/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http5'
ssh = ['ssh', '-i', '/Users/gaj/.ssh/darkbloom_testbox', '-o', 'IdentitiesOnly=yes', '-o', 'BatchMode=yes', '-o', 'ConnectTimeout=15', 'gaj@100.124.35.99']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == archive_sha

def run(argv, label, code=None):
    result = subprocess.run(argv, input=code, text=True, capture_output=True)
    (out / (label + '.stdout')).write_text(result.stdout)
    (out / (label + '.stderr')).write_text(result.stderr)
    (out / (label + '.command.json')).write_text(json.dumps({'argv': argv, 'exit_code': result.returncode}, indent=2) + '\n')
    assert result.returncode == 0, (label, result.returncode, result.stderr)
    return result.stdout

run(['python3', '-B', '/tmp/darkbloom-fleet-smoke-continuation/preflight.py', str(out / 'ownership-before.json')], 'ownership-before')
create = """from pathlib import Path
import datetime, shutil
root=Path(REMOTE)
assert datetime.datetime.now(datetime.timezone.utc).date().isoformat()=='2026-09-06'
assert shutil.disk_usage(root.parent).free>100*(1<<30)
root.mkdir(exist_ok=False)
""".replace('REMOTE', repr(remote))
run(ssh + ['python3 -B -'], 'create', create)
scp = ['scp', '-i', '/Users/gaj/.ssh/darkbloom_testbox', '-o', 'IdentitiesOnly=yes', '-o', 'BatchMode=yes']
run(scp + [str(archive), 'gaj@100.124.35.99:' + remote + '/transfer.tar.gz'], 'archive-transfer')
run(scp + [str(review), 'gaj@100.124.35.99:' + remote + '/approved-root-review.json'], 'review-transfer')
verify = """from pathlib import Path
import hashlib,json,os,stat,subprocess,tarfile
root=Path(REMOTE)
assert hashlib.sha256((root/'approved-root-review.json').read_bytes()).hexdigest()==REVIEW_SHA
archive=root/'transfer.tar.gz'
assert hashlib.sha256(archive.read_bytes()).hexdigest()==ARCHIVE_SHA
with tarfile.open(archive) as tar:
 members=tar.getmembers()
 assert len(members)==1383 and len({m.name for m in members})==1383
 for member in members:
  assert member.isfile() and not Path(member.name).is_absolute() and '..' not in Path(member.name).parts
  assert not (root/member.name).exists()
 tar.extractall(root)
assert hashlib.sha256((root/'package-manifest.json').read_bytes()).hexdigest()==MANIFEST_SHA
subprocess.run(['python3','-B',str(root/'verify_package.py')],check=True)
mode=stat.S_IMODE((root/'connected-e2e.test').lstat().st_mode)
assert mode==0o755 and os.access(root/'connected-e2e.test',os.X_OK)
print(json.dumps({'remote_root':str(root),'archive_sha256':ARCHIVE_SHA,'manifest_sha256':MANIFEST_SHA,'review_sha256':REVIEW_SHA,'go_mode_octal':oct(mode),'inference_launched':False},indent=2))
""".replace('REMOTE', repr(remote)).replace('REVIEW_SHA', repr(review_sha)).replace('ARCHIVE_SHA', repr(archive_sha)).replace('MANIFEST_SHA', repr(manifest_sha))
print(run(ssh + ['python3 -B -'], 'verify', verify))
(out / 'approved-root-review.json').write_bytes(review.read_bytes())
(out / 'stage.py').write_bytes(Path(__file__).read_bytes())
files = {p.name: {'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.iterdir()) if p.is_file()}
(out / 'manifest.json').write_text(json.dumps({'scope':'Approved HTTP5 package staging; no inference or existing root mutation','files':files},indent=2)+'\n')
