import argparse
import json
import os
from pathlib import Path
import pwd
import re
import shutil
import subprocess
import time

from common import checked_file, read_json


def capture(arguments, timeout=5):
    return subprocess.check_output(arguments, text=True, timeout=timeout)


def observe(binding):
    raw = capture(['ps', '-axo', 'pid=,ppid=,comm=,args='])
    markers = ('Runner.Worker', 'benchctl measure-job', 'measure-job.sh', 'radix-engine', 'run_radix_engine.py', 'connected-e2e.test')
    processes = []
    for line in raw.splitlines():
        fields = line.strip().split(None, 3)
        if len(fields) > 2 and (any(marker in line for marker in markers) or Path(fields[2]).name == 'darkbloom'):
            processes.append({'pid': fields[0], 'ppid': fields[1], 'command': fields[2]})
    tool = binding['readiness_tool']
    checked_file(Path(tool['path']), tool['file'])
    temperature = json.loads(capture([tool['path'], 'pipe', '-s', '1', '-i', '200'], timeout=10).splitlines()[0])['temp']['gpu_temp_avg']
    addresses = re.findall(r'\binet\s+(\d+\.\d+\.\d+\.\d+)\b', capture(['/sbin/ifconfig', '-a']))
    return {'unix_time': time.time(), 'processes': processes, 'gpu_temp_c': temperature, 'load': os.getloadavg(),
            'free_disk_bytes': shutil.disk_usage(Path.home()).free, 'username': pwd.getpwuid(os.getuid()).pw_name,
            'ipv4_addresses': sorted(set(addresses)), 'hardware_model': capture(['sysctl', '-n', 'hw.model']).strip(),
            'memory_bytes': int(capture(['sysctl', '-n', 'hw.memsize']).strip())}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--binding', required=True, type=Path)
    print(json.dumps(observe(read_json(parser.parse_args().binding)), allow_nan=False))
