from pathlib import Path
import hashlib,json,shutil,subprocess

out=Path(__file__).parent
primary=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
package=Path('/tmp/darkbloom-connected-m5-bundle5')
digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def add(source,relative):
 source=Path(source);target=out/relative
 assert source.is_file() and not source.is_symlink()
 assert source.read_bytes()[:4] not in (b'\xcf\xfa\xed\xfe',b'\xfe\xed\xfa\xcf',b'\x7fELF',b'MTLB')
 assert source.suffix not in ('.safetensors','.metallib','.dylib','.o','.a')
 target.parent.mkdir(parents=True,exist_ok=True)
 assert not target.exists();shutil.copyfile(source,target)
def frozen(path,label,expected=None):
 path=Path(path)
 if expected:assert digest(path)==expected
 manifest=json.loads(path.read_text())
 for rel,item in manifest['files'].items():
  source=path.parent/rel;assert source.stat().st_size==item['bytes'] and digest(source)==item['sha256']
  add(source,Path(label)/rel)
 add(path,Path(label)/path.name)

frozen('/tmp/darkbloom-connected-http5-results/qwen38-paged-off-b1/manifest.json','raw/off','b5da6249056233fbb4560d1365ff70f28bf6a7840c80409610fba870e035453a')
frozen('/tmp/darkbloom-connected-http5-results/qwen38-paged-ssd-b1/manifest.json','raw/ssd','a12d8ee3e01b5f12168ccaebd21e9eb57ef37fc38e5db8b709b1635c20a72639')
for name in ['qwen38-paired-comparison.json','qwen38-paired-comparison-command.json','qwen38-paired-comparison.stderr']:
 add(Path('/tmp/darkbloom-connected-http5-results')/name,Path('comparison')/name)
for path,label in [('/tmp/darkbloom-connected-http5-execution-prep1/manifest.json','execution-preparation'),('/tmp/darkbloom-connected-http5-transfer1/manifest.json','staging'),('/tmp/darkbloom-connected-http5-remote-helper-validation1/manifest.json','remote-helper-tests'),('/tmp/darkbloom-connected-bundle5-freeze1/manifest.json','package-preparation')]:frozen(path,label)
for source,name in [('/tmp/darkbloom-connected-bundle5-root-review.json','root-package-review.json'),('/tmp/darkbloom-connected-bundle5-root-review.py','root-package-review.py'),('/tmp/darkbloom-connected-http5-q38-postflight1.json','ownership-postflight.json'),('/tmp/darkbloom-connected-http5-q38-first-hit-live-observation1.json','live-first-hit-observation.json'),('/tmp/darkbloom-connected-http5-status.py','status.py')]:add(source,Path('review')/name)
selected=[]
for source in sorted(package.rglob('*')):
 if not source.is_file():continue
 rel=source.relative_to(package)
 # Runtime build8 provenance is already banked in the actual-logit milestone.
 # Preserve helper recovery, execution contracts and Go compile identity here.
 if len(rel.parts)==1 and source.suffix in ('.py','.json','.md') or rel.parts[0] in ('inputs','manifests','go-build-evidence','reviews','preparation'):
  add(source,Path('approved-package')/rel);selected.append(str(rel))
source_files=[
 'provider-swift/Sources/ProviderCore/ProviderLoop+InferenceHandler.swift',
 'provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge+Events.swift',
 'provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge+Lifecycle.swift',
 'provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge+PrefixCache.swift',
 'provider-swift/Sources/ProviderCore/Inference/EngineV2Bridge+Submission.swift',
 'provider-swift/Sources/ProviderCore/Inference/PrefixCacheReceipts.swift',
 'provider-swift/Sources/ProviderCore/Inference/PrefixCacheEvidenceSequencer.swift',
 'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/EngineLoopV2.swift',
 'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/EngineV2.swift',
 'libs/mlx-swift-lm/Libraries/MLXLMCommon/ContinuousBatchingV2/CBv2Contracts.swift',
]
for rel in source_files:add(primary/rel,Path('source')/rel)
report=json.loads((out/'raw/ssd/evidence/report.json').read_text())
baseline=json.loads((out/'raw/off/evidence/report.json').read_text())
assert baseline['state']=='completed' and all(c['status']=='passed' for c in baseline['cases'])
assert report['state']=='failed' and [c['status'] for c in report['cases']]==['passed']*7+['failed','not_run','not_run']
assert report['wire_dropped']==baseline['wire_dropped']==0
cancel=report['cases'][7]
terminal=[e for e in cancel['wire'] if e['type']=='inference_complete'];assert len(terminal)==1
profile=terminal[0]['fields']['profile'];usage=terminal[0]['fields']['usage']
assert not any(e['type']=='prefix_cache_lookup_v2' for e in cancel['wire'])
assert not any(k in usage for k in ['cache_outcome','cache_tier','cached_tokens','prefill_tokens_saved'])
observations=[]
for row in report['cases']:
 events=row.get('wire',[])
 terminals=[e['fields'] for e in events if e['type']=='inference_complete']
 observations.append({'name':row['name'],'status':row['status'],'error':row.get('error'),'usage':[v.get('usage') for v in terminals],'ready_positions':[e['fields'].get('ready_positions') for e in events if e['type']=='prefix_cache_ready_v2'],'lookup_count':sum(e['type']=='prefix_cache_lookup_v2' for e in events),'ssd_donation_delta':row.get('after',{}).get('lifecycle',{}).get('ssd_donations',0)-row.get('before',{}).get('lifecycle',{}).get('ssd_donations',0),'ssd_hit_delta':row.get('after',{}).get('lifecycle',{}).get('ssd_hits',0)-row.get('before',{}).get('lifecycle',{}).get('ssd_hits',0),'http_first_content_ms':row['http'].get('first_content_ms')})
summary={'scope':'HTTP5 Q38 cache pair: off ten PASS; SSD seven PASS, cancellation FAIL, two unrun. Strict pair FAIL; no backend or release acceptance.','source_parent':subprocess.check_output(['git','rev-parse','HEAD'],cwd=primary,text=True).strip(),'source_native':subprocess.check_output(['git','rev-parse','HEAD'],cwd=primary/'libs/mlx-swift-lm',text=True).strip(),'package_sha256':digest(package/'package-manifest.json'),'runtime_cli_sha256':report['input']['provider_sha256'],'observations':observations,'cancellation':{'profile':profile,'usage':usage,'http_cancelled_by_client':cancel['http']['cancelled_by_client'],'lookup_missing':True,'coordinator_lookups_before_after':[cancel['before']['lifecycle']['ssd_lookups'],cancel['after']['lifecycle']['ssd_lookups']],'coordinator_hits_before_after':[cancel['before']['lifecycle']['ssd_hits'],cancel['after']['lifecycle']['ssd_hits']],'limits':'Staging125930us and projected5552-1456=4096 savings are observations, not authoritative completed native adoption proof. No terminal cache detail or lookup receipt exists for this canceled request.'},'package_payload_selection':selected,'remaining_model_cells':'All ten other HTTP5 cells unrun; execution stopped after cancellation failure.','postflight':'No owned model jobs; no cleanup signals; runtime/model/config postflight passed; roots retained.'}
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
(out/'DIAGNOSIS.md').write_text('''# HTTP5 Qwen3.8 canceled settlement evidence

The cache-off cell passes all ten cases. The SSD cell passes its first seven, including an accepted durable Ready at4096, native4096-token reuse, tenant isolation, continuation on the second provider, original-prefix routing, tools and vision. Cancellation fails the unchanged native SSD usage gate; recovery and sidecar-outage cases remain unrun. The strict pair remains failed.

The canceled request sends an encrypted checkpoint-scoped dispatch, receives one content-bearing chunk, and has a correlated cancel and one partial inference_complete. It has no lookup receipt and no cache fields in UsageInfo. Coordinator lookup/hit counts remain6/2. Profile records SSD stage125930us, projected prefill1456 for prompt5552, and cancel during decode. Those values do not prove completed native adoption.

Source trace: EngineV2Bridge+Events.pump records EngineV2RequestUsageSignal only on native .finished. ProviderLoop+InferenceHandler breaks its frame loop on cancellation and may construct its partial terminal before that event, reading a still-nil lookupResult. PrefixCacheLookupReceiptFinalizer.sendTerminal finalizes its once-only resolver with a policy fallback lacking tier/promptAnchor. PrefixCacheEvidenceSequencer.handleLookup refuses that incomplete V2 proof; the resolver is nevertheless marked resolved, so a later engine-derived callback cannot replace it. This explains the missing metadata and lookup path without authorizing synthetic hit accounting. A deterministic native regression is still required to verify the ordering and repair it.

The package permission fix is exercised: all1382 payload modes/bytes verify on M5, executable0755, and20 Python helper tests pass before inference. Build8 identity is unchanged. Test trust and cache keys are ephemeral; two providers share one M5. Persistent restart, independent-machine behavior, B2/B4, other models and final release acceptance remain unproved. No production, key or daemon changes occurred.
''')
files={str(p.relative_to(out)):{'bytes':p.stat().st_size,'sha256':digest(p)} for p in sorted(out.rglob('*')) if p.is_file()}
(out/'manifest.json').write_text(json.dumps({'scope':summary['scope'],'files':files},indent=2)+'\n')
print(json.dumps({'payloads':len(files),'manifest_sha256':digest(out/'manifest.json'),'payload_bytes':sum(x['bytes'] for x in files.values())},indent=2))
