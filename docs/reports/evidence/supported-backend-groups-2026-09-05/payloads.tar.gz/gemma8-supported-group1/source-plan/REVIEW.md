# Repeated performance plan — source-only, not runtime-bound

This retains the existing **180 cells**: five exact target artifacts × contiguous/paged × cache-off/SSD × B1/B2/B4 × three ordered process repetitions. The independent production Gemma QAT supplement adds **36 pending cells** (216 if both are required). `plan.json` lists every named cell and matched comparison. No benchmark was run during preparation; no runtime, including build6, is selected here.

The four Python files in `runner/` are unchanged banked files from primary `9e49059a1806e265fd9ceab420c1b82216a5d785`. `matrix_cells.py` only prints commands, inspects status, and collects reports with those validators. It does not execute processes, retry, schedule GPU work, delete cache payloads, or change the repository. The frozen fleet matrix is historical context, not the live controller or a current claim that all its statuses remain unchanged.

## Exact workload

Original inputs come from `darkbloom-final-fleet-smoke2/inputs`. Every request and case retains its original semantics except `max_tokens: 32 → 128` and pinned request date `2026-09-05`. The 35,273-character user prompt is unchanged. It is approximately 5,500 prompt tokens; actual per-model tokenizer IDs/counts are the authority. `128` is a cap, not a forced generation length. Natural EOS remains enabled: the separately validated build6 Q35 128-cap pair stopped at 74, which is not a 128-token decode measurement.

Each cell starts a fresh process and cache root, runs one short eight-token warmup, two main input cohorts, then three tenant controls and completed cancellation donor/cancel/recovery. Main cohorts contain B identical concurrently submitted requests. The first cohort fully completes before the repeat cohort starts. Do not label every first-cohort row cold: another row in that cohort could become a donor. Each row retains actual hit and saved-work fields; the repeat cohort must prove authenticated restore.

Order is fixed: model order in the plan, B1/B2/B4, repetitions 1/2/3, then contiguous off/on and paged off/on. Preserve the first attempted result, including failure, and the order of each comparison. Each quartet has two cache comparisons and two backend comparisons. An unsupported combination remains recorded and cannot pass or generate a timing comparison. Independent supported pairs may run while blocked cells remain pending, retaining their original ordered repetition labels.

| Scope | Cells | Main requests | Other controls | Warmups | Total requests | Conservative output-token cap |
|---|---:|---:|---:|---:|---:|---:|
| Original five | 180 | 840 | 1,080 | 180 | 2,100 | 247,200 |
| Pending QAT supplement | 36 | 168 | 216 | 36 | 420 | 49,440 |
| Both | 216 | 1,008 | 1,296 | 216 | 2,520 | 296,640 |

Per cell there are `2B+7` requests and at most `(2B+6)*128+8` generated tokens. These bounds conservatively allow the cancelled request to reach the cap; observed cancellation/EOS normally reduces it. Setup has the existing 240-second readiness bound and the wrapper retains its 1,800-second process watchdog. There is no predicted model runtime or speedup.

## Current eligibility and rollout dependencies

- **18 original contiguous+SSD cells are unsupported**: nine GPT and nine Gemma 8-bit cells. Historical complete checkpoints require `kind == .paged`; the returned disabled/unsupportedLayout preparation suppresses the legacy fallback. They are preserved as blocked, not disguised as cache-enabled cold runs. Root will review whether separately recorded expected cold/rollback controls plus paged off/on fulfill migration scope; this plan does not add a legacy implementation or waive the SSD acceptance gate. The QAT supplement has nine analogous restrictions.
- Original Gemma is **8-bit** `gemma-4-26b`, hash `a4722b6020adb1894c700b45ddcd58bc0e0f033abe7139f86cbbbfe60cba4eb6`. Production warm-pool/TPS entries target **`gemma-4-26b-qat-4bit`**, hash `2468a0cb3049a871f42052f4d9f9380bf12a0792f64c7a29f768559fc7d28785`, 15,641,239,295 bytes, prefix `v2/gemma-4-26b-qat-4bit--69619d858022/2026-06-08-r1`. Its 36 cells remain unbound until exact manifest, download, and identity audit. An 8-bit pass does not establish QAT rollout safety. Root owns acquisition.
- Qwen models use normal configured MTP. GPT uses its normal no-assistant configuration. Gemma uses the exact normal assistant through the corrected **two-file** local override (only config.json and model.safetensors). `provenance/gemma-two-file-fixture-proof.json` pins both hashes and the known M5 path. The original directory containing manifest.json is invalid for that override and remains preserved.
- A separate reviewed runtime binding must name one probe, source evidence manifest and all six resources by exact absolute paths and SHA-256. The same runtime must serve both arms and all three repetitions. Root reported normal Q35 build6 32- and 128-cap strict pair passes; its 128-cap proof is `/tmp/darkbloom-build6-q35-output128-freeze1`, manifest SHA `fe8b7060f7a301da1f64f884dc3995ddfa7031056d39e3180b5ee522526f2cc2`. This does not automatically bind build6 as a final release runtime.
- Full release acceptance still needs the separately scoped connected HTTP/coordinator, tools, supported vision, branching/turn-two/window-boundary, 12K capacity/co-residency, persistent-key restart and rollout gates from the original matrix. Ephemeral process-local tests here cannot establish encrypted restart persistence. No default/deployment/key change is included.

## Evidence gates and timing interpretation

`compare_radix_engine.py` and `radix_engine_evidence.py` remain the strict gate for complete generated IDs, prompts, finish/count integrity, runtime/input identity, production single-slot grant arithmetic, configured active MTP, process C/M/U and paged memory accounting, idle retirement, tenant isolation, cancellation and exact recovery. The helper additionally binds the named cell to metadata, requires protocol 2 and coherent `idle_observation.status == ready`, checks donor/repeat identity, and requires warm repeat/tenant/cancel/recovery native `hit`, `staged`, matched/saved > 0 and increasing authenticated stage-read bytes.

B2/B4 require actual overlap and all submitted rows complete. **Requested B4 with measured peak two is overlap, not evidence of four admitted rows.** Collection records requested width, observed peak, waiting peak, completion/failure and separate overlap/full-width flags. Preserve refusal and partial-cohort evidence; do not remove slow or refused rows. Four-wide admission, if a release requirement, remains pending until its own evidence exists.

TTFT is first nonempty delta latency. Decode throughput excludes **all tokens in the first nonempty MTP delta** and divides subsequent emitted tokens by first-to-last nonempty delta time. Serving elapsed, completion cleanup and batch elapsed stop before coherent-idle waiting. Idle wait duration is retained separately in metric snapshots. Keep initial-cohort and warm-repeat timings distinct, with raw chunk and terminal evidence. The existing comparator's optional aggregate only targets rows named `kind=decode`; these inputs are `first/repeat`, so its null aggregate is inapplicable. The helper computes descriptive min/median/max of paired per-repetition changes only after all three exact corresponding comparisons pass. No p99 or statistical confidence is inferred from three trials. Batch throughput/capacity samples remain separately available; historical capture/pause timers are not invented.

## Storage and safe resumption

Original cells create up to **90 separate SSD roots**, QAT adds 18. Production default policy is `min(100 GiB, available space/2)`, with writes refusing below `max(20 GiB, 5% of volume capacity)`. This is a quota for the currently enforced cache hierarchy, not an allocation estimate and not a global cap over independent archived test roots. Never infer that retaining every cell consumes at most 100 GiB.

Before runtime binding, root must record a storage/retention decision and minimum free-byte threshold. Work one quartet at a time and inspect real free space and cache usage before each process. Preserve inputs, metadata, logs, telemetry, report, verdict and payload/source identities. Failed/partial runs remain intact. Any removal or external archiving of successful **owned test cache payloads** occurs only after paired acceptance and a recorded retention decision, preserving the evidentiary files; this helper never deletes. No disk or model-memory consumption estimate is asserted. The command also checks the reviewed threshold and default write-floor geometry immediately before emitting its invocation; the existing runner still owns actual process/load/temperature checks.

Copy this whole frozen directory to the dedicated host. Create a separate binding file outside the freeze; fill the explicit null fields from the final reviewed artifact/identity records. `binary` and `runtime_source_manifest` are `{path, sha256}` objects; `resources` maps the six relative resource names to `{path, sha256}`. Bind exact original model paths from plan hints and a retained identity-audit file by path/hash. The probe re-verifies the expected target aggregate. Assistant contents are checked by hash before the command is emitted. The generated command uses a clean environment with HOME/PATH only, preventing inherited diagnostic SERIAL, fixed-depth, grant or cache switches from altering normal-policy cells.

Example commands after root review, using the M5 copy of this directory:

```sh
python3 -B matrix_cells.py status --bindings /absolute/reviewed-matrix-binding.json
python3 -B matrix_cells.py command --bindings /absolute/reviewed-matrix-binding.json --cell qwen36-b1-r1-contiguous-cache-off > /absolute/owned-evidence/command-qwen36-b1-r1-contiguous-cache-off.json
python3 -B matrix_cells.py command --bindings /absolute/reviewed-matrix-binding.json --cell qwen36-b1-r1-contiguous-cache-off --format shell
python3 -B matrix_cells.py collect --bindings /absolute/reviewed-matrix-binding.json > /absolute/owned-evidence/collection-attempt1.json
```

Execute the printed, shell-quoted wrapper command under the existing fleet lane owner. Do not run a general all-cell loop or parallel probes. `status` distinguishes untouched, blocked, completed-unvalidated and retained failed/partial directories. Any existing directory is refused, including a preflight failure with no metadata. For an approved retry, create a new binding/results root and retain the original attempt and reason; compare a newly matched pair instead of selecting its fastest surviving arm. Collect each attempt root separately so failures remain visible. For QAT, first create a reviewed successor plan with its exact manifest/audit and the eligibility decision; do not edit this freeze to unlock its blocked cells.

## Source-only validation

Eight pure unittest functions passed: full topology/blocked cells, original input semantic diff, unreviewed runtime refusal, existing/partial attempt preservation, file corruption, authenticated native-hit requirements, requested B4 vs actual admission, and whole-first-MTP-delta decode exclusion. No Swift/Metal compilation, model inference, remote command, download or production modification occurred in this preparation. A one-shot preparation initially lacked its new inputs directory; the local writer was corrected to create parent directories before these final checks. No existing or frozen source was changed.
