"""Execute only after root explicitly hands over the sole local Swift lane."""
from pathlib import Path
import argparse
import gzip
import hashlib
import json
import os
import re
import shutil
import subprocess
import time
from test_selection import selected_identifiers, exact_filter, canonical_identifiers

RESULTS = Path(__file__).resolve().parent
OUT = Path('/tmp/darkbloom-persistent-test-namespace-swift-validation1')
INFO = json.loads((OUT / 'integration.json').read_text())
WORKSPACE = Path(INFO['workspace'])
SCRATCH = Path(INFO['scratch'])
EXPECTED_FUNCTIONS = {'SSDPersistentTestKeyNamespaceTests': 9, 'SSDPrefixCacheModeTests': 6,
    'kekLoadOrCreateGeneratesOnFirstCall': 1, 'kekPersistsAcrossActorInstances': 1,
    'kekConcurrentFirstUseAdoptsSingleKEK': 1, 'saveIfAbsentDoesNotOverwriteExisting': 1,
    'BenchmarkPersistentTestKeysTests': 6, 'BenchmarkAttentionMetadataOptionsTests': 3,
    'BenchmarkLogitDiagnosticOptionsTests': 3, 'BenchmarkIdleObservationTests': 8}


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path, value): path.write_text(json.dumps(value, indent=2) + '\n')
def tracked_inputs(root):
    return {str(p.relative_to(root)): sha(p) for p in root.rglob('*') if p.is_file()
            and not any(part in {'.build', '.swiftpm'} for part in p.relative_to(root).parts)}


def verify():
    totals = {}
    for label, root in (('provider', WORKSPACE / 'provider-swift'),
                        ('harness', WORKSPACE / 'scripts/benchmarks/radix-engine'), ('native', OUT / 'native')):
        expected = json.loads((OUT / (label + '-source-manifest.json')).read_text())['files']
        assert tracked_inputs(root) == expected, (label, 'source membership or hash drift')
        totals[label] = len(expected)
    dependencies = json.loads((OUT / 'dependency-source-manifest.json').read_text())
    for name, digest in dependencies['files'].items():
        alias, relative = name.split('/', 1)
        assert sha(Path(dependencies['repositories'][alias]) / relative) == digest, name
    jinja = json.loads((OUT / 'jinja-source-manifest.json').read_text())
    for name, digest in jinja['files'].items():
        assert sha(SCRATCH / 'checkouts/swift-jinja' / name) == digest, name
    totals.update(dependencies=len(dependencies['files']), jinja=len(jinja['files']))
    return totals


def save_graph(result, label):
    for name in ('debug.yaml', 'workspace-state.json'):
        source = SCRATCH / name
        if source.exists():
            raw = source.read_bytes()
            suffix = '.gz' if name.endswith('.yaml') else ''
            (result / (label + '-' + name + suffix)).write_bytes(gzip.compress(raw, mtime=0) if suffix else raw)


def prove_compiler_sources(result, phase):
    graph = (SCRATCH / 'debug.yaml').read_text()
    graph_paths = sorted(set(re.findall(r'"(/[^"\n]+)"', graph)))
    changed = json.loads((OUT / 'source-correspondence.json').read_text())
    paths = [WORKSPACE / item['path'] for item in changed
             if item['path'].endswith('.swift') and not item['path'].endswith('Package.swift')
             and item['path'].startswith('provider-swift/')
             and (phase == 'provider' or '/Tests/' not in item['path'])]
    if phase == 'benchmark':
        paths += [WORKSPACE / item['path'] for item in changed
                  if item['path'].endswith('.swift') and not item['path'].endswith('Package.swift')
                  and item['path'].startswith('scripts/benchmarks/radix-engine/')]
    paths += [OUT / 'native/Libraries/MLXLMCommon/ContinuousBatchingV2/CBv2AttentionMetadata.swift',
              OUT / 'native/Libraries/MLXLMCommon/ContinuousBatchingV2/EngineV2.swift']
    proof = []
    for path in paths:
        match = next((candidate for candidate in graph_paths
                      if candidate.endswith('/' + path.name) and Path(candidate).resolve() == path.resolve()), None)
        assert match, ('compiler graph missing reviewed source', str(path))
        proof.append({'actual_path': match, 'resolved_path': str(path.resolve()), 'sha256': sha(path)})
    assert '/checkouts/mlx-swift/Source/' not in graph
    write(result / 'actual-compiler-source-proof.json', {'paths': proof,
          'native_commit': INFO['native'], 'scope': 'Declared compiler graph paths and exact source hashes; not a claim that every graph path is linked into the selected test binary.'})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', choices=('provider', 'benchmark'), required=True)
    parser.add_argument('--execute-after-lane-handoff', action='store_true', required=True)
    args = parser.parse_args()
    if args.phase == 'benchmark':
        assert json.loads((RESULTS / 'provider-result/verdict.json').read_text())['status'] == 'PASS', 'Provider validation must pass first'
    result = RESULTS / (args.phase + '-result')
    result.mkdir()  # Preserve every previous attempt; a retry needs a successor.
    package = Path(INFO[args.phase + '_package'])
    environment = os.environ.copy()
    if args.phase == 'benchmark': environment.update(INFO['benchmark_environment'])
    write(result / 'source-verified-before.json', verify())
    write(result / 'execution-environment.json', {key: value for key, value in environment.items()
          if key.startswith(('RADIX_', 'DARKBLOOM_PREFIX_CACHE', 'DARKBLOOM_CBV2_', 'MLX_'))})
    records = []
    def run(name, argv, is_test=False):
        started = time.monotonic()
        path = result / (name + '.log')
        with path.open('x') as log:
            completed = subprocess.run(argv, cwd=package, env=environment, stdout=log, stderr=subprocess.STDOUT)
        text = path.read_text()
        nonzero = bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test', text))
        skipped = bool(re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test', text, re.M))
        row = {'name': name, 'argv': argv, 'cwd': str(package), 'exit_code': completed.returncode,
               'seconds': time.monotonic() - started, 'nonzero_no_skips': not is_test or nonzero and not skipped,
               'log_sha256': sha(path)}
        records.append(row); write(result / 'execution.json', records); print(json.dumps(row), flush=True)
        return row, text
    try:
        if args.phase == 'provider':
            previous = Path('/tmp/darkbloom-persistent-test-namespace-swift-validation2/provider-result')
            binary_receipt = json.loads((previous / 'test-binary.json').read_text())
            assert sha(Path(binary_receipt['path'])) == binary_receipt['sha256'], 'Previously built provider binary drift'
            assert json.loads((previous / 'source-verified-after.json').read_text()) == verify()
            write(result / 'reused-provider-build.json', {
                'previous_result': str(previous), 'test_binary': binary_receipt,
                'scope': 'Reuse exact provider binary after source/dependency revalidation; prior tests selected zero.'})
            save_graph(result, 'before-reused-binary')
        else:
            built, _ = run('build', ['swift', 'build', '--scratch-path', str(SCRATCH), '--build-tests',
                                    '--jobs', '4', '--disable-automatic-resolution'])
            save_graph(result, 'after-build')
            write(result / 'source-verified-postcompile.json', verify())
            assert built['exit_code'] == 0, 'Swift build failed; preserve logs and review source before retry'
        prove_compiler_sources(result, args.phase)
        debug = SCRATCH / 'arm64-apple-macosx/debug'
        name = 'DarkbloomProviderPackageTests' if args.phase == 'provider' else 'RadixEngineBenchmarkPackageTests'
        bundle = debug / (name + '.xctest/Contents/MacOS')
        binary = bundle / name
        metallib = Path(INFO['metallib']); assert sha(metallib) == INFO['metallib_sha256']
        for target in (debug / 'mlx.metallib', bundle / 'mlx.metallib'):
            shutil.copy2(metallib, target); assert sha(target) == INFO['metallib_sha256']
        binary_hash = sha(binary)
        write(result / 'test-binary.json', {'path': str(binary), 'sha256': binary_hash,
              'bytes': binary.stat().st_size, 'metallib_sha256': INFO['metallib_sha256']})
        listed, listing = run('identifiers', ['swift', 'test', 'list', '--skip-build', '--scratch-path',
                                              str(SCRATCH), '--disable-automatic-resolution'])
        assert listed['exit_code'] == 0
        canonical_run, canonical_listing = run('canonical-identifiers', ['swift', 'test', '-v', 'list',
            '--skip-build', '--scratch-path', str(SCRATCH), '--disable-automatic-resolution'])
        assert canonical_run['exit_code'] == 0
        selected = {}
        runtime_selected = {}
        execution_filters = {}
        for selector in json.loads((OUT / 'filters.json').read_text())[args.phase]:
            identifiers = selected_identifiers(listing, selector, args.phase)
            assert len(identifiers) == EXPECTED_FUNCTIONS[selector], (selector, identifiers)
            assert not any('ViaSecureEnclave' in line or 'ViaKeychainStorage' in line for line in identifiers)
            selected[selector] = identifiers
            runtime_selected[selector] = canonical_identifiers(identifiers, canonical_listing)
            execution_filters[selector] = exact_filter(identifiers + runtime_selected[selector])
            assert [line for line in listing.splitlines() if re.search(execution_filters[selector], line)] == identifiers
            assert [line for line in canonical_listing.splitlines() if re.search(execution_filters[selector], line)] == runtime_selected[selector]
        write(result / 'selected-identifiers.json', selected)
        write(result / 'canonical-selected-identifiers.json', runtime_selected)
        write(result / 'execution-filters.json', execution_filters)
        for selector in selected:
            row, _ = run(selector, ['swift', 'test', '--skip-build', '--scratch-path', str(SCRATCH),
                                    '--disable-automatic-resolution', '--filter', execution_filters[selector]], is_test=True)
            assert row['exit_code'] == 0 and row['nonzero_no_skips'], ('test failure or missing/skipped test', selector)
        assert sha(binary) == binary_hash
        write(result / 'verdict.json', {'status': 'PASS', 'test_functions': sum(map(len, selected.values())),
              'scope': 'Source/spy and explicitly in-memory regressions only; not persistent restart proof'})
    except BaseException as error:
        write(result / 'verdict.json', {'status': 'FAIL', 'error': str(error)})
        raise
    finally:
        write(result / 'source-verified-after.json', verify())
        save_graph(result, 'after')


if __name__ == '__main__': main()
