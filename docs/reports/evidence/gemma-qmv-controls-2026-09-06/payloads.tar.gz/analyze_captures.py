"""CPU-only analysis of retained receipts, projection bytes, and reference outputs."""
from pathlib import Path
import ast
import hashlib
import json
import sys
import numpy as np

ROOT = Path(__file__).resolve().parent
OLD = Path('/tmp/darkbloom-gemma-verifier-execution2')
REVIEW = Path('/tmp/darkbloom-qmv-float-promotion-independent-review1')
REFERENCE = Path('/tmp/darkbloom-gemma-projection-cpu-reference1')
PACKAGE_SHA = 'bf33caa41d54916d3a30114060be91ccebba2b7364402c55ab734e4abeb271b0'
CELL = 'gemma-qat4-paged-projection-529-62203'
SESSIONS = [74173, 85307, 16372, 31144, 67024, 13692, 36929]
sys.path.insert(0, str(ROOT / 'package'))
from common import verify_package

def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(name, value): (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n')
def verify_manifest(root, expected):
    path = root / 'manifest.json'
    assert sha(path) == expected, path
    for name, row in read(path)['files'].items():
        path = root / name
        assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], path

binding = verify_package(PACKAGE_SHA, ROOT / 'package')
verify_manifest(REVIEW, 'd0eb579af0d03780881db5ac2d78112481f11dc7ecef2abc2a144715db36a9df')
verify_manifest(REFERENCE, '510fe6e1e194430d63344ea95a88bda8585211ea7544ae98c6334fb7a856a235')
# Load only pure numerical definitions; do not execute the reference's model-read driver.
source = ast.parse((REFERENCE / 'compute.py').read_text())
selected = {'bf16_values', 'round_bf16_bits', 'ordered_bf16', 'error_metrics', 'check_rounding'}
module = ast.Module(body=[node for node in source.body if isinstance(node, ast.FunctionDef) and node.name in selected], type_ignores=[])
ns = {'np': np}
exec(compile(module, str(REFERENCE / 'compute.py'), 'exec'), ns)
ns['check_rounding']()
arrays = np.load(REFERENCE / 'reference-outputs.npz', allow_pickle=False)
new_root = ROOT / 'results' / CELL / 'report.gemma-projection'
old_root = OLD / 'results' / CELL / 'report.gemma-projection'
new, old = read(new_root / 'projection.json'), read(old_root / 'projection.json')
assert new['token_ids'] == old['token_ids'] == [529, 62203]
assert new['parameter_identities'] == old['parameter_identities']
assert new['verified_model_sha256'] == old['verified_model_sha256']
assert new['quantization'] == old['quantization']
checks = {}
for name, d in new['tensors'].items():
    p = new_root / d['file']
    assert p.stat().st_size == d['byte_count'] and sha(p) == d['sha256'] and d['dtype'] == 'bfloat16'
    before = old['tensors'][name]
    checks[name] = {'sha256': sha(p), 'byte_count': p.stat().st_size, 'same_as_old_full_tensor': p.read_bytes() == (old_root / before['file']).read_bytes()}
    if name.endswith(('.q', '.k', '.v')):
        checks[name]['same_as_reviewed_corrected_m3_full_tensor'] = p.read_bytes() == (REVIEW / 'outputs' / d['file']).read_bytes()
assert all(row.get('same_as_reviewed_corrected_m3_full_tensor', True) for row in checks.values())
for name in ['m1.embedding','m2.embedding','m1.normalized','m2.normalized']:
    assert checks[name]['same_as_old_full_tensor'], name
projections = {}
for name in ['q','k','v']:
    bits = {width: np.frombuffer((new_root / new['tensors'][f'm{width}.{name}']['file']).read_bytes(), dtype='<u2').reshape(new['tensors'][f'm{width}.{name}']['shape'])[0, 0] for width in [1,2]}
    diff = np.flatnonzero(bits[1] != bits[2])
    projections[name] = {
        'first_column_mismatch_count': int(len(diff)),
        'differing_elements': [{'index': int(i), 'm1': float(ns['bf16_values'](bits[1])[i]), 'm2': float(ns['bf16_values'](bits[2])[i]), 'ideal_affine_f64': float(arrays[name + '_ideal_affine_f64'][i])} for i in diff],
        'references': {f'm{width}': {kind: ns['error_metrics'](bits[width], arrays[name + '_' + kind]) for kind in ['ideal_affine_f64','bf16_rounded_dequant_f64','bf16_quartet_input_bias_sum_f64']} for width in [1,2]},
        'old_first_column': old['first_column_comparisons'][name],
        'corrected_first_column': new['first_column_comparisons'][name],
    }
write('projection-native-byte-validation.json', {
    'scope': 'Existing local capture bytes and saved CPU references only; no model, GPU, SSH, source build, or model-parameter read.',
    'all_ten_parameter_identities_match_old': True,
    'same_model_input_quantization': True,
    'tensor_checks': checks,
    'projections': projections,
    'kernel_observation': new['kernel_observation'],
    'path_conclusion': 'All six official M5 Q/K/V output tensors match the independently reviewed corrected M3 replay byte-for-byte; the promoted-bias arithmetic is reproduced. This is behavior and provenance evidence, not a runtime kernel trace.',
    'reference_manifest_sha256': sha(REFERENCE / 'manifest.json'),
    'independent_review_manifest_sha256': sha(REVIEW / 'manifest.json'),
})
comparison = read(ROOT / 'corrected-complete-comparison.json')
cell_summaries = []
for session, cell in zip(SESSIONS, binding['cells']):
    d = ROOT / 'results' / cell['id']
    report, terminal, post, local = [read(d / name) for name in ['report.json','terminal.json','postflight.json','local-process.json']]
    events = [json.loads(line) for line in (d/'events.jsonl').read_text().splitlines()]
    pid = next(event['pid'] for event in events if event['event']=='started')
    telemetry = read(d/'telemetry-live.json')
    rows=[]
    for row in report['rows']:
        counts={k:row['metrics_after'].get('mtp',{}).get(k,0)-row['metrics_before'].get('mtp',{}).get(k,0) for k in ['rounds','rectangular_rounds','serial_rounds']}
        rows.append({'id':row['id'],'prompt_tokens':row['prompt_tokens'],'tokens':len(row['token_ids']),'finish':row['finish'],**counts})
    cell_summaries.append({'cell':cell['id'],'tool_session':session,'native_pid':pid,'telemetry':telemetry,
        'terminal':terminal,'local_execution':{k:local[k] for k in ['pid','exit_code','failure','group_cleanup_complete']},
        'postflight_observation':post['observation'],'postflight_passed':post['passed'],'main_rows':rows})

def compact(pair):
    result={k:v for k,v in pair.items() if k!='rows'}
    result['rows']=[]
    for row in pair['rows']:
        i=row['first_difference_index']
        result['rows'].append({k:v for k,v in row.items() if k not in ['before_ids','after_ids']} | {
            'before_count':len(row['before_ids']),'after_count':len(row['after_ids']),
            'before_token_at_difference':row['before_ids'][i] if i is not None and i<len(row['before_ids']) else None,
            'after_token_at_difference':row['after_ids'][i] if i is not None and i<len(row['after_ids']) else None})
    return result
write('actual-model-results.json', {
    'status':'ALL_7_EXECUTIONS_VALID_AUTOMATIC_TOKEN_GATE_FAILED_BACKEND_PARITY_PASSED',
    'package_manifest_sha256':PACKAGE_SHA,
    'm5_released_to_root':True,
    'cells':cell_summaries,
    'corrected_comparisons':[compact(pair) for pair in comparison['corrected_comparisons']],
    'before_after':[compact(pair) for pair in comparison['before_after']],
    'projection_versus_control':compact(comparison['projection_versus_control']),
    'execution_integrity_valid':comparison['execution_integrity_valid'],
    'baseline_failures_preserved':comparison['baseline_failures_preserved'],
    'performance_conclusion':None,
    'profile':binding['profile'],'runtime_source':binding['runtime']['source'],
})
print(json.dumps({'all_six_qkv_tensors_match_reviewed_corrected_m3':all(v.get('same_as_reviewed_corrected_m3_full_tensor',True) for v in checks.values()),'projection_differences':{k:v['differing_elements'] for k,v in projections.items()},'all_7_collected':len(cell_summaries)==7,'projection_vs_control_exact_all_seven':comparison['projection_versus_control']['exact_all_seven']},indent=2))
