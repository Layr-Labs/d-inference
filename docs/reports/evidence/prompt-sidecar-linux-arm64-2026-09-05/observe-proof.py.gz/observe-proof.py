import json, pathlib, subprocess, time
base=pathlib.Path('/home/gaj.guest/prompt-proof')
binary=str(base/'source/coordinator/promptsidecar/target/aarch64-unknown-linux-musl/release/promptsidecar')
start=time.monotonic(); observed={}
with (base/'result.json').open('w') as stdout, (base/'proof.stderr').open('w') as stderr:
    process=subprocess.Popen(['sh',str(base/'run-proof-guest.sh')],stdout=stdout,stderr=stderr)
    while process.poll() is None:
        for proc in pathlib.Path('/proc').iterdir():
            if not proc.name.isdecimal(): continue
            try:
                if str((proc/'exe').resolve()) != binary: continue
                limits=(proc/'limits').read_text()
                address=next(line for line in limits.splitlines() if line.startswith('Max address space'))
                parts=address.split()
                if parts[3:5] != ['1073741824','1073741824']: continue
                status=(proc/'status').read_text()
                row=observed.setdefault(proc.name,{'limits':limits,'max_vm_size_kib':0,'max_vm_rss_kib':0,'max_threads':0})
                for line in status.splitlines():
                    columns=line.split()
                    field={'VmSize:':'max_vm_size_kib','VmRSS:':'max_vm_rss_kib','Threads:':'max_threads'}.get(columns[0])
                    if field: row[field]=max(row[field],int(columns[1]))
            except (OSError,StopIteration,IndexError,ValueError): pass
        time.sleep(.1)
code=process.wait()
record={'scope':'Local native ARM Linux diagnostic, observer reads /proc every100ms; native amd64 CI still pending','elapsed_seconds':time.monotonic()-start,'proof_exit_code':code,'observed_children':observed}
(base/'observed-limits.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'proof_exit_code':code,'observed_limited_children':len(observed),'elapsed_seconds':record['elapsed_seconds']}))
if code != 0: raise SystemExit(code)
if len(observed)<2: raise SystemExit('Did not observe hard1GiB RLIMIT_AS in both proof children')
