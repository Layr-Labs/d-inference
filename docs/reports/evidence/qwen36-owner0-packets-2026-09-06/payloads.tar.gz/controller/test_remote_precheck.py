import contextlib
import datetime
import hashlib
import io
import json
from pathlib import Path
import tempfile
import unittest
from evidence_files import remote_script

class RemotePrecheckTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name)
        runtime=self.root/'runtime';runtime.mkdir()
        artifacts={}
        for name in ['radix-engine','metal','privacy1','privacy2','tokenizer1','tokenizer2','resource6']:
            p=runtime/name;p.write_bytes(name.encode());p.chmod(0o755 if name=='radix-engine' else 0o644)
            artifacts[name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':oct(p.stat().st_mode&0o777)}
        self.binding={'artifacts':artifacts};self.write('runtime-binding.json',self.binding)
        self.plan={'cells':[{'id':'selected','argv':['ROOT','SOURCE_ONLY_PENDING_ROOT_REVIEW']}],'guards':{'minimum_free_bytes':0}}
        self.write('plan.json',self.plan);p=self.root/'plan.json'
        self.write('manifest.json',{'files':{'plan.json':{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}}})
        self.config={'root':str(self.root),'output':str(self.root/'fresh'),
            'date':datetime.datetime.now(datetime.timezone.utc).date().isoformat(),
            'plan_manifest_sha256':self.sha('manifest.json'),'binding_sha256':self.sha('runtime-binding.json'),
            'cell':'selected','argv':self.plan['cells'][0]['argv']}
    def tearDown(self):self.temp.cleanup()
    def write(self,name,value):(self.root/name).write_text(json.dumps(value))
    def sha(self,name):return hashlib.sha256((self.root/name).read_bytes()).hexdigest()
    def run_check(self):
        code=remote_script((Path(__file__).parent/'remote_precheck.py').read_text(),self.config)
        with contextlib.redirect_stdout(io.StringIO()) as stream:exec(code,{})
        return json.loads(stream.getvalue())
    def test_fresh_hashed_seven_artifacts_pass_without_network(self):self.assertTrue(self.run_check()['fresh_output_root'])
    def test_nonexecutable_probe_refuses_before_model_work(self):
        (self.root/'runtime/radix-engine').chmod(0o644)
        with self.assertRaises(AssertionError):self.run_check()
    def test_wrong_date_and_existing_output_refuse(self):
        self.config['date']='2000-01-01'
        with self.assertRaisesRegex(AssertionError,'Date rollover'):self.run_check()
        self.config['date']=datetime.datetime.now(datetime.timezone.utc).date().isoformat();(self.root/'fresh').mkdir()
        with self.assertRaisesRegex(AssertionError,'Fresh output'):self.run_check()
    def test_runtime_byte_drift_and_manifest_drift_refuse(self):
        (self.root/'runtime/metal').write_bytes(b'corrupt')
        with self.assertRaises(AssertionError):self.run_check()
        self.config['plan_manifest_sha256']='0'*64
        with self.assertRaises(AssertionError):self.run_check()

if __name__=='__main__':unittest.main()
