from pathlib import Path
import hashlib,json,sys
OUT=Path(__file__).parent
transport=json.loads((OUT/'transport.json').read_text())
COMMON=Path('/tmp/darkbloom-connected-http6-execution-prep2')
assert hashlib.sha256((COMMON/'common.py').read_bytes()).hexdigest()==transport['reviewed_transport_common_sha256']
sys.path.insert(0,str(COMMON))
from common import sha,save,item,run,render,ownership,freeze,SSH,SCP,ENV,PYTHON,shlex
import remote_staging as source

def main():
 binding=Path('/tmp/darkbloom-q36-attention-packet-execution1/runtime-binding.json');review=Path('/tmp/darkbloom-q36-attention-packet-root-binding-review1.json')
 assert sha(binding)==transport['binding_sha256'] and sha(review)==transport['binding_review_sha256']
 archive=OUT/'plan-package.tar.gz';assert sha(archive)==transport['archive_sha256']
 remote=transport['remote_root'];result=Path('/tmp/darkbloom-q36-attention-packet-transfer1');result.mkdir(exist_ok=False)
 constants={'remote':remote,'archive_sha':sha(archive),'manifest_sha':transport['plan_manifest_sha256'],'review_sha':sha(review),'binding_sha':sha(binding),'resources_copy_source':'/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact'}
 try:
  ownership(result,'ownership-before')
  run(result,SSH+['python3 -B -'],'create',render(source.CREATE,constants))
  for local,name in [(archive,'plan-package.tar.gz'),(binding,'runtime-binding.json'),(review,'binding-root-review.json')]:
   run(result,SCP+[str(local),'gaj@100.124.35.99:'+remote+'/'+name],'transfer-'+name)
  run(result,SSH+['python3 -B -'],'extract',render(source.EXTRACT,constants))
  binary=Path('/tmp/darkbloom-attention-packet-release-build1/artifact/radix-engine');expected=json.loads(binding.read_text())['artifacts']['radix-engine']
  assert item(binary)==dict(expected,mode=int(expected['mode'],8))
  run(result,SCP+['-p',str(binary),'gaj@100.124.35.99:'+remote+'/runtime/radix-engine'],'probe-transfer')
  receipt=run(result,SSH+['python3 -B -'],'runtime',render(source.RUNTIME,constants));(result/'runtime-transfer-receipt.json').write_text(receipt)
  command=ENV+[PYTHON,'-B','-m','unittest','-v','test_run_radix_engine']
  run(result,SSH+['cd '+shlex.quote(remote+'/runner')+' && '+shlex.join(command)],'remote-wrapper-tests')
  ownership(result,'ownership-after')
  save(result/'status.json',{'status':'STAGED_RUNTIME_VERIFIED_NO_MODEL_RUN','constants':constants})
 finally:freeze(result,'Approved Q36 packet plan/runtime staging only, fresh root, no model execution.')
 print(result/'manifest.json')
if __name__=='__main__':main()
