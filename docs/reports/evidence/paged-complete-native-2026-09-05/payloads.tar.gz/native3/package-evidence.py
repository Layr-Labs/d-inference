from pathlib import Path
import difflib,gzip,hashlib,json,re,shutil,subprocess,tarfile
exec(Path('/tmp/darkbloom-checkpoint-native-validation3/verify.py').read_text())
assert (out/'source-verified-after-native.json').exists();verified=verify()
filters=json.loads((out/'native-filters.json').read_text());execution=json.loads((out/'native-execution.json').read_text());assert len(execution)==len(filters)+2
ids=[s for s in (out/'native-identifiers.log').read_text().splitlines() if s.startswith('MLXLMTests.')]
selected={};summaries={};failures={}
for name in filters:
 body=(out/(name+'.log')).read_text();row=next(x for x in execution if x['name']==name)
 summaries[name]={'exit_code':row['exit_code'],'selected_count_verified':row['selected_count_verified']}
 if row['exit_code'] or not row['selected_count_verified']:
  failures[name]=[s for s in body.splitlines() if 'recorded an issue' in s or '✘' in s or ': error:' in s or 'Fatal error' in s or 'failed' in s.lower()];continue
 sw=re.findall(r'Test run with (\d+) tests?',body);swift=int(sw[-1]) if sw else 0;xc=max(map(int,re.findall(r'Executed (\d+) tests?',body)),default=0);extra=sum(int(n)-1 for n in re.findall(r'with (\d+) test cases passed',body))
 matches=[s for s in ids if name in s]
 if name=='CBv2PagedBackendTests':matches += [s for s in ids if 'CBv2PagedSpeculativeRowTests/' in s]
 if name=='CBv2PagedPrefixReuse':matches += [s for s in ids if 'CBv2PrefixReusePagedFrozenFullTests/' in s]
 assert len(matches)==swift+xc,(name,len(matches),swift+xc)
 assert not re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test|recorded an issue|[✘]',body,re.M),name
 selected[name]=sorted(matches);summaries[name].update(functions=swift+xc,actual_cases=swift+xc+extra,failures=0,skips=0)
unique=sorted(set(x for group in selected.values() for x in group));assert len(unique)==sum(x.get('functions',0) for x in summaries.values())
(out/'selected-identifiers.json').write_text(json.dumps({'passed_by_filter':selected,'unique_passed_identifiers':unique},indent=2)+'\n')
scratch=Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift');graph=(scratch/'debug.yaml').read_text();assert str(dep/'Source/MLX/AllocationFootprint.swift') in graph;assert str(package/'Tests/MLXLMTests/CBv2AuxiliaryFootprintTests.swift') in graph or str((package/'Tests/MLXLMTests/CBv2AuxiliaryFootprintTests.swift').resolve()) in graph;assert '/checkouts/mlx-swift/Source/' not in graph
(out/'native-actual-build-graph-final.yaml.gz').write_bytes(gzip.compress(graph.encode(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'native-actual-package-state-final.json')
binary=scratch/'arm64-apple-macosx/debug/mlx-swift-lmPackageTests.xctest/Contents/MacOS/mlx-swift-lmPackageTests';(out/'test-binary.json').write_text(json.dumps({'path':str(binary),'sha256':sha(binary),'bytes':binary.stat().st_size},indent=2)+'\n')
owned=json.loads((out/'owned-manifest.json').read_text())['files'];patches={};base='a486a55d032deae001190bf9795ece1cb3d9a609';changed={}
with tarfile.open(out/'owned-source.tar.gz','w:gz') as t:
 for p,h in owned.items():
  current=package/p;assert sha(current)==h;t.add(current,arcname=p)
  result=subprocess.run(['git','show',base+':'+p],cwd=package,stdout=subprocess.PIPE,stderr=subprocess.PIPE);before=result.stdout.decode() if result.returncode==0 else '';after=current.read_text()
  if before!=after:
   changed[p]=h;patches[p]=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+p if result.returncode==0 else '/dev/null',tofile='b/'+p))
patch=out/'native-after-allocator-foundation.patch';patch.write_text(''.join(patches.values()));numstat=subprocess.check_output(['git','apply','--numstat',str(patch)],cwd=package,text=True);assert sorted(s.split('\t')[2] for s in numstat.splitlines())==sorted(changed)
(out/'incremental-owned-manifest.json').write_text(json.dumps({'base':base,'count':len(changed),'files':changed},indent=2)+'\n')
lineage={}
for n in [1,2]:
 p=Path('/tmp/darkbloom-checkpoint-native-validation'+str(n)+'/partial-manifest.json');lineage[str(p)]={'sha256':sha(p),'role':'Preserved compilation failure; later source corrections explicitly recorded.'}
(out/'evidence-lineage.json').write_text(json.dumps(lineage,indent=2)+'\n')
verdict={'status':'pass' if not failures else 'failed','native_base':'990475e3ae6f93615bebe0fc36e352aa601ea4a5','banked_foundation_base':base,'owned_files':len(owned),'incremental_paths_after_foundation':len(changed),'source_verified':verified,'build_seconds_reported':float(re.findall(r'Build complete! \(([0-9.]+)s\)',(out/'native-build.log').read_text())[-1]),'selected_filters':len(filters),'passed_unique_functions':len(unique),'passed_unique_cases':sum(x.get('actual_cases',0) for x in summaries.values()),'by_filter':summaries,'failure_details':failures,'scope':'Native union checkpoint codec, process ownership, auxiliary bounds, direct export and historical window capture/retirement with existing paged/runtime/MTP regressions. Exact local policy dependency source. No production defaults or fleet model runs.','limits':['Hermetic tiny models only; no exact fleet-model performance or HTTP evidence.','Native ownership fakes and real buffers prove scoped transitions, not whole provider U+sum(C-M) across actual model workloads.','Provider union and separate harness overlay not compiled in this gate.','Existing external metallib reused; selected native JIT paged kernel resource compiled by normal runtime; allocator policy C++/Swift tests carried by previous milestone, not repeated here.'],'compiler_source_paths':{'native':str(package),'mlx_swift':str(dep)}}
(out/'verdict.json').write_text(json.dumps(verdict,indent=2)+'\n');(out/'environment.txt').write_text(subprocess.check_output(['swift','--version'],text=True,stderr=subprocess.STDOUT)+subprocess.check_output(['sw_vers'],text=True)+subprocess.check_output(['uname','-a'],text=True))
files={str(p.relative_to(out)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and 'native' not in p.relative_to(out).parts and p.name not in ['manifest.json','partial-manifest.json']};(out/'manifest.json').write_text(json.dumps({'scope':verdict['scope'],'files':files},indent=2)+'\n');print(json.dumps({'status':verdict['status'],'passed_functions':len(unique),'passed_cases':verdict['passed_unique_cases'],'failed_filters':list(failures),'payloads':len(files),'manifest_sha256':sha(out/'manifest.json')},indent=2))
