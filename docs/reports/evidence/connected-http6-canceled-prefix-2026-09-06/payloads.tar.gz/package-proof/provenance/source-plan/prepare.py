"""Source-only strict Q38 rerun plan; CLI binding and execution are deliberately absent."""
from pathlib import Path
import hashlib,json,shutil,subprocess

OLD=Path('/tmp/darkbloom-connected-m5-bundle5')
ROOT=Path('/tmp/darkbloom-connected-http6-q38-plan1')
PRIMARY=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
REMOTE='/Users/gaj/autoresearch/radix-prefix-cache/090-connected-http6-q38'
ROOT.mkdir(exist_ok=False)

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):
    p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def copy(name,source=None):
    p=source or OLD/name;dest=ROOT/name
    assert p.is_file() and not p.is_symlink(),p
    dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)

assert sha(OLD/'package-manifest.json')=='7c04de0ebc0064d31ce6aa642044d1075704bcf29779334c6d0a9d32aaa4efda'
package=json.loads((OLD/'package-manifest.json').read_text())
rows=package['files'];rows=dict(rows) if isinstance(rows,list) else rows
for name,row in rows.items():
    p=OLD/name
    assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes'],p
    if 'mode' in row:assert p.stat().st_mode&0o777==(int(row['mode'],8) if isinstance(row['mode'],str) else row['mode']),p

helpers=['run_connected_fixture.py','verify_package.py','temporary_model_alias.py',
         'compare_connected_cache_http.py','verify_prompt_counts.py','test_connected_bundle.py',
         'test_executable_modes.py','test_flat_runtime.py','test_local_assistant.py','test_temporary_model_alias.py']
for name in helpers:copy(name)
for name in ['go-source-manifest.json','manifests/qwen38.json','assets/cube-hero.png',
             'tokenizer-plan.json','paired-input-validation.json','go-build-evidence/artifact.json',
             'go-build-evidence/bank-proof.json','go-build-evidence/commands.json',
             'reviews/bundle5-helper-root-review.json']:
    copy(name)
copy('provenance/http5-package-manifest.json',OLD/'package-manifest.json')
copy('provenance/http5-plan.json',OLD/'bundle-plan.json')
copy('provenance/http5-failure-manifest.json',Path('/tmp/darkbloom-connected-http5-q38-cancel-failure1/manifest.json'))
copy('provenance/http5-failure-diagnosis.md',Path('/tmp/darkbloom-connected-http5-q38-cancel-failure1/DIAGNOSIS.md'))

go=json.loads((OLD/'go-source-manifest.json').read_text())['files']
proof=[]
for name,expected in go.items():
    assert sha(OLD/'go-source'/name)==expected==sha(PRIMARY/name),name
    proof.append({'path':name,'sha256':expected})
assert len(proof)==988
for p in sorted((OLD/'go-source/e2e').glob('connected_cache*')):
    if p.is_file():copy('oracle-source/e2e/'+p.name,p)

oldplan=json.loads((OLD/'bundle-plan.json').read_text())
cells=[next(c for c in oldplan['cells'] if c['cell']=='qwen38-paged-'+mode+'-b1') for mode in ['off','ssd']]
bodyproof=[];templates=[]
for c in cells:
    oldpath=OLD/c['input'];data=json.loads(oldpath.read_text());before=dict(data)
    copy('provenance/'+Path(c['input']).name,oldpath)
    data['provider_binary']=REMOTE+'/runtime/darkbloom'
    data['provider_sha256']=None
    data['vision_png']=REMOTE+'/assets/cube-hero.png'
    changed=[k for k in data if data[k]!=before[k]]
    assert set(changed)=={'provider_binary','provider_sha256','vision_png'}
    name='inputs/'+c['cell']+'.template.json';dump(ROOT/name,data)
    bodyproof.append({'cell':c['cell'],'changed_fields':changed,'original_input_sha256':sha(oldpath),
                      'template_sha256':sha(ROOT/name),
                      'prompt_bytes_unchanged':data['prompt']==before['prompt'],
                      'tools_catalog_artifact_unchanged':all(data[k]==before[k] for k in ['tools_request','catalog','artifact']),
                      'request_date_utc':'2026-09-06','provider_sha256':'unbound until reviewed packet-integrated CLI',
                      'all_other_input_fields_equal':True})
    templates.append(data)
assert {k for k in templates[0] if templates[0][k]!=templates[1][k]}=={'cache_mode'}

names=['cold_donor_a','same_prompt_a','tenant_isolation_a','continuation_b','original_after_continuation','tools','vision','cancel','after_cancel','sidecar_unavailable']
fixture=(OLD/'go-source/e2e/connected_cache_http_test.go').read_text()
assert all('"'+name+'"' in fixture for name in names)
gobin=OLD/'connected-e2e.test'
assert sha(gobin)==oldplan['go_test_binary_sha256']=='6e30a1e53cc26ac1bb7953216b6d0af835b8b08a29f1920b2df07999c0e2bc8f'
assert gobin.stat().st_mode&0o777==0o755
parent=subprocess.check_output(['git','-C',str(PRIMARY),'rev-parse','HEAD'],text=True).strip()
bundle={**oldplan,'remote_bundle_root':REMOTE,'cells':cells,
        'source_inputs_sha256':{},'state':'SOURCE_TEMPLATE_RUNTIME_UNBOUND_DO_NOT_STAGE',
        'additional_unrun_controls':oldplan['additional_unrun_controls']}
dump(ROOT/'bundle-plan.template.json',bundle)
dump(ROOT/'source-input-correspondence.json',{'current_parent_at_preparation':parent,'old_package_files_verified':len(rows),
     'go_files_verified':proof,'Go_binary':{'path':str(gobin),'bytes':gobin.stat().st_size,'mode':'0o755','sha256':sha(gobin)},
     'helper_bytes_unchanged':{n:sha(ROOT/n) for n in helpers},'paired_inputs':bodyproof,
     'only_cache_mode_differs_between_templates':True,'oracle_changed':False,
     'commands_run':'Static byte/hash/source comparisons only; no Go/Swift build, provider launch, staging, or remote call.'})
dump(ROOT/'execution-plan.json',{
    'state':'SOURCE_ONLY_RUNTIME_UNBOUND','remote_root':REMOTE,'provider_runtime_binding':None,
    'required_provider_source':'Packet-integrated primary 98103b397 with native dcf39f6, including cancellation4d53. Exact full source/artifact binding pending reviewed CLI build; later docs-only commits do not change runtime bytes.',
    'scope':'Fresh strict Q38 connected HTTP cache-off then default SSD, paged B1 and normal MTP, all ten original cases.',
    'sequence':[c['cell'] for c in cells],'ordered_cases':names,
    'wrapper_argv_preview':[['/usr/bin/env','-i','HOME=/Users/gaj','PATH=/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','PYTHONDONTWRITEBYTECODE=1','/Applications/Xcode.app/Contents/Developer/usr/bin/python3','-B',REMOTE+'/run_connected_fixture.py','run','--cell',c['cell']] for c in cells],
    'actual_Go_argv':[REMOTE+'/connected-e2e.test','-test.run','^TestIntegrationConnectedCacheHTTP$','-test.v','-test.timeout','45m','-test.parallel','1'],
    'binding_steps':['Root reviews forthcoming packet-integrated provider CLI build graph, commit/native/dependency pins and unentitled artifact bytes/modes.',
        'Bind provider_sha256 and seven colocated runtime resources into fresh final inputs/source-inputs/payload--transfer-manifest.json; preserve unchanged sidecar hash.',
        'Require fresh package root absent, full package/runtime/model hashes+modes, canonical config unchanged, sole M5 idle, GPU<=42C/load1<=4/free>100GiB, exact UTC request date.',
        'Run off all10; stop on any failed/incomplete case. Run SSD all10 only after complete off. Stop on any failed/incomplete case; retain both raw reports.',
        'Run unchanged compare_connected_cache_http.py; require both completed, no dropped wire, all10passed, exact paired requests/output/usage except transport-dependent cancel length.',
        'Freeze all raw logs, authoritative native hit/lookup/terminal/cancel profile proofs, timing/counters/telemetry and final owned-process cleanup.'],
    'cancellation_gate':'Actual SSD saved-token usage plus lookup/receipt and native received/aborted evidence, exactly one provider terminal. Never infer hit from staged checkpoint or Ready projection.',
    'limits':['No oracle relaxation, synthetic hit, preoutput cancellation substitution, timeout increase, request/capacity/temperature/tool/MTP change.',
              'Same-host two-provider HTTP fixture; no independent-machine or signed-restart claim.',
              'Old HTTP5 strict failure remains immutable. Source/input plan itself proves no model result.'],
    'runtime_reuse_candidates':{'Go_binary_sha256':sha(gobin),'sidecar_binary':templates[0]['sidecar_binary'],
                               'sidecar_sha256':templates[0]['sidecar_sha256'],'metallib_sha256':templates[0]['metallib_sha256']}})
copy('prepare.py',Path(__file__))
files={str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p),'mode':oct(p.stat().st_mode&0o777)} for p in sorted(ROOT.rglob('*')) if p.is_file()}
dump(ROOT/'manifest.json',{'state':'SOURCE_ONLY_RUNTIME_UNBOUND','files':files})
print(json.dumps({'root':str(ROOT),'payload_count':len(files),'manifest_sha256':sha(ROOT/'manifest.json'),
                  'go_sources_unchanged':len(proof),'helpers_unchanged':len(helpers),'paired_request_fields_equal':True,
                  'runtime_bound':False,'remote_calls':False,'model_launched':False},indent=2))
