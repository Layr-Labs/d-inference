from pathlib import Path
import difflib, hashlib, io, json, shutil, subprocess, tarfile

out = Path(__file__).resolve().parent
primary = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
candidate = Path('/Users/gaj/Documents/DarkbloomDev/wt/q36-attention-owner-identity')
native_validation = Path('/tmp/darkbloom-q36-attention-owner-identity-native-validation1')
source = Path('/tmp/darkbloom-q36-attention-owner-identity-source1')
build8 = Path('/tmp/darkbloom-final-serving-build8')
workspace = out/'workspace'
local_mlx = Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift')
scratch = Path('/tmp/darkbloom-process-memory-telemetry-swift-validation1/build')
review = Path('/tmp/darkbloom-q36-attention-owner-identity-root-source-review.json')
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def write(name, value):
    (out/name).write_text(json.dumps(value, indent=2)+'\n')

assert sha(source/'manifest.json') == 'd7d8d892e076df4bc90d6ffbc346d22108ba7a04463bb5a4036938b642506743'
for name, row in json.loads((source/'manifest.json').read_text())['files'].items():
    assert sha(source/name) == row['sha256'], name
assert sha(review) == '2b67d45f2a03923144e087a4f13a0c784c565252113413e54368d8922c027350'
parent = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=primary, text=True).strip()
assert parent == 'c9bd3ab7886675ce9fc79a483e5c93ed60a8ae12', parent
archive = subprocess.check_output(['git', 'archive', parent, 'provider-swift'], cwd=primary)
workspace.mkdir()
with tarfile.open(fileobj=io.BytesIO(archive)) as packed:
    packed.extractall(workspace, filter='data')
provider = workspace/'provider-swift'
changes = json.loads((source/'source-proof.json').read_text())['parent']['files']
before_after = {}
for name, row in changes.items():
    before = sha(primary/name) if (primary/name).exists() else None
    assert before == row['before_sha256'], name
    assert sha(candidate/name) == row['after_sha256'], name
    assert (candidate/name).stat().st_size == row['bytes'], name
    before_after[name] = {'primary_before_sha256': before, 'candidate_after_sha256': sha(candidate/name), 'matched': True}
    shutil.copy2(candidate/name, workspace/name)
write('live-before-after-check.json', before_after)
canonical = {str(p.relative_to(workspace)): sha(p) for p in sorted(provider.rglob('*')) if p.is_file()}
before = (provider/'Package.swift').read_text()
old = '.package(path: "../libs/mlx-swift")'
assert before.count(old) == 1
after = before.replace(old, '.package(path: "'+str(local_mlx)+'")')
(provider/'Package.swift').write_text(after)
(out/'provider-package-compile-only-overlay.patch').write_text(''.join(difflib.unified_diff(
    before.splitlines(keepends=True), after.splitlines(keepends=True),
    fromfile='canonical/provider-swift/Package.swift', tofile='compiled/provider-swift/Package.swift')))
resolved = build8/'workspace/provider-swift/Package.resolved'
assert sha(resolved) == 'b2b12d24d48bbedc4583d8831e0b81fe68b96d641804e0ebc56715cd2d88a7ea'
shutil.copy2(resolved, provider/'Package.resolved')
(workspace/'libs').mkdir()
(workspace/'libs/mlx-swift').symlink_to(local_mlx, target_is_directory=True)
(workspace/'libs/mlx-swift-lm').symlink_to(native_validation/'native', target_is_directory=True)
for name in ['native-source-manifest.json', 'dependency-source-manifest.json', 'jinja-source-manifest.json']:
    shutil.copy2(native_validation/name, out/name)
for name, digest in json.loads((out/'native-source-manifest.json').read_text())['files'].items():
    assert sha(workspace/'libs/mlx-swift-lm'/name) == digest, name
deps = json.loads((out/'dependency-source-manifest.json').read_text())
for name, digest in deps['files'].items():
    alias, relative = name.split('/', 1)
    assert sha(Path(deps['repositories'][alias])/relative) == digest, name
jinja = json.loads((out/'jinja-source-manifest.json').read_text())
for name, digest in jinja['files'].items():
    assert sha(scratch/'checkouts/swift-jinja'/name) == digest, name
actual = {str(p.relative_to(workspace)): sha(p) for p in sorted(provider.rglob('*')) if p.is_file()}
write('provider-source-manifest.json', {'source_commit': parent, 'canonical_files': canonical,
                                      'files': actual, 'candidate_changes': changes})
shutil.copy2(review, out/'root-source-review.json')
write('filters.json', ['AttentionMetadataProductionOwnerTests'])
write('integration.json', {
    'status': 'Prepared source union only; no Swift process started',
    'parent_commit': parent, 'native_baseline': '847e32076abd1c7f2b28660b7deed902f5dec692',
    'source_manifest': str(source/'manifest.json'), 'source_manifest_sha256': sha(source/'manifest.json'),
    'root_source_review': str(review), 'root_source_review_sha256': sha(review),
    'native_validation': str(native_validation), 'workspace': str(workspace),
    'scratch': str(scratch), 'provider_inputs': len(actual), 'canonical_inputs': len(canonical),
    'policy': 'Only approved owner identity fix and one provider regression; pinned dependency-only overlays. Native tests must pass before provider build.',
    'other_unintegrated_candidates_included': False,
})
print(json.dumps({'provider_inputs': len(actual), 'canonical_inputs': len(canonical),
                  'parent_commit': parent, 'dependency_inputs_verified': len(deps['files']),
                  'jinja_inputs_verified': len(jinja['files'])}, indent=2))
