"""Canonical owned M5 build/tests; no real-model pilot or serving process."""
from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time,sys
import owner_helper
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'workspace'; ARTIFACT=ROOT/'artifact'; RELEASE=ROOT/'release-build'; TEST_BUILD=ROOT/'native-test-build2'
MANIFEST=json.loads((ROOT/'source-manifest.json').read_text())
REPOS={row['name']:SOURCE/row['relative_path'] for row in MANIFEST['repositories']}
ENV={'HOME':str(Path.home()),'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','TMPDIR':'/private/tmp',
     'DEVELOPER_DIR':'/Applications/Xcode.app/Contents/Developer','RADIX_SOURCE_ROOT':str(SOURCE),'RADIX_CANDIDATE_BUILD':'1',
     'MAKEFLAGS':'-j4','METALLIB_CACHE_DIR':str(ROOT/'metallib-cache')}
EXECUTIONS=[]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def identity(path):
 p=Path(path);return {'sha256':sha(p),'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777}
def write(path,value):
 p=Path(path);tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n');tmp.replace(p)
def state(value):
 write(ROOT/'native3-build-status.json',value)
def verify_sources():
 for name,repo in REPOS.items():
  head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
  dirty=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)
  if head!=MANIFEST['source'][name] or dirty:raise ValueError('canonical source drift: '+name+' '+dirty)
  for relative,expected in MANIFEST['files'][name].items():
   if identity(repo/relative)!=expected:raise ValueError('payload drift: '+name+'/'+relative)
 return {'source':MANIFEST['source'],'all_canonical_sources_clean':True}
def command(name,argv,cwd=SOURCE,timeout=3600):
 step=ROOT/'steps'/name;step.mkdir(mode=0o700)
 started=time.time();state({'state':'starting','step':name,'argv':argv,'cwd':str(cwd)})
 def emit(event):
  value=dict(event,step=name,role='build_or_native_test',log=str(step/'provider.log'))
  if event.get('event')=='started':state(dict(value,state='running',argv=argv,cwd=str(cwd),started_unix=started))
  print(json.dumps(value),flush=True)
 previous=Path.cwd()
 try:
  os.chdir(cwd)
  record=owner_helper.run_owner(argv,ENV,step,sys.stdin.buffer,emit,lease_seconds=30,deadline_seconds=timeout)
 finally:
  os.chdir(previous)
  if (step/'provider.log').exists():shutil.copy2(step/'provider.log',ROOT/'logs'/(name+'.log'))
 result=dict(record,step=name,argv=argv,cwd=str(cwd),seconds=time.time()-started)
 EXECUTIONS.append(result);write(ROOT/'native3-executions.json',EXECUTIONS)
 if record['failure'] is not None or record['exit_code']!=0 or not record['group_cleanup_complete'] or record['stop_requested']:
  raise RuntimeError('owned command failed: '+name)
 return ROOT/'logs'/(name+'.log')

def graph_proof(name,scratch,source_roots):
 candidates=[scratch/'release.yaml',scratch/'debug.yaml'];graph=next((p for p in candidates if p.is_file()),None)
 if graph is None:raise ValueError('SwiftPM build graph missing: '+name)
 text=graph.read_text();(ROOT/(name+'-graph.yaml.gz')).write_bytes(gzip.compress(graph.read_bytes(),mtime=0))
 if '/checkouts/mlx-swift/Source/' in text or str(SOURCE/'libs/mlx/') in text:raise ValueError('noncanonical MLX source entered graph')
 paths={}
 for value in re.findall(r'"(/[^"\n]+\.(?:swift|cpp|cc|c|h|hpp|metal|mm|modulemap))"',text):
  p=Path(value)
  if p.is_file() and any(p.resolve().is_relative_to(x.resolve()) for x in source_roots):paths[str(p)]=identity(p)
 for suffix in ['quantized.cpp','ForwardShapeV2.swift','ForwardShapeDispatchV2.swift','EngineLoopV2+ForwardShapes.swift']:
  if not any(p.endswith(suffix) for p in paths):raise ValueError('required source absent from graph: '+suffix)
 write(ROOT/(name+'-source-graph.json'),{'source':MANIFEST['source'],'files':paths,'local_mlx_only':True})
 if (scratch/'workspace-state.json').exists():shutil.copy2(scratch/'workspace-state.json',ROOT/(name+'-workspace-state.json'))
 checkouts={}
 for repo in sorted((scratch/'checkouts').glob('*')):
  if (repo/'.git').exists():checkouts[repo.name]={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'dirty':subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)}
 write(ROOT/(name+'-dependency-checkouts.json'),checkouts)

def purge_owned_resources(roots):
 removed=[]
 for base in roots:
  if not base.exists():continue
  for p in sorted(base.rglob('mlx.metallib')):
   if p.is_file():removed.append(str(p));p.unlink()
  for p in sorted(base.glob('*-apple-macosx/*/*.bundle')):
   if p.is_dir():removed.append(str(p));shutil.rmtree(p)
 return removed

def stage_test_metallib():
 destinations=[TEST_BUILD/'arm64-apple-macosx/debug/mlx.metallib']
 debug=TEST_BUILD/'arm64-apple-macosx/debug'
 for bundle in debug.glob('*PackageTests.xctest'):
  macos=bundle/'Contents/MacOS'
  if macos.is_dir():destinations.append(macos/'mlx.metallib')
 if len(destinations)<2:raise ValueError('native xctest bundle not discovered')
 for p in destinations:shutil.copy2(ARTIFACT/'mlx.metallib',p)
 copies={str(p):identity(p) for p in destinations}
 if any(v['sha256']!=sha(ARTIFACT/'mlx.metallib') for v in copies.values()):raise ValueError('test metallib mismatch')
 write(ROOT/'test-metallib-copies.json',copies)

ENV.update({'GIT_CONFIG_COUNT':'3','GIT_CONFIG_KEY_0':'protocol.file.allow','GIT_CONFIG_VALUE_0':'always','GIT_CONFIG_KEY_1':'url.'+str(REPOS['core'])+'.insteadOf','GIT_CONFIG_VALUE_1':'https://github.com/Layr-Labs/mlx.git','GIT_CONFIG_KEY_2':'url.'+str(REPOS['c'])+'.insteadOf','GIT_CONFIG_VALUE_2':'https://github.com/Layr-Labs/mlx-c.git'})
def pins(path,exclude=()):
 return {p['identity']:p for p in json.loads(path.read_text())['pins'] if p['identity'] not in exclude}
def lock_receipt(stage,path):
 write(ROOT/('native3-lock-'+stage+'.json'),{'identity':identity(path),'lock':json.loads(path.read_text())})
def assert_native_pins(path):
 actual=pins(path,exclude=['mlx-swift']);expected=pins(ROOT/'native-seed.resolved',exclude=['mlx-swift'])
 if actual!=expected:raise ValueError('native dependency revisions drifted from reviewed projection')
try:
 assert json.loads((ROOT/'native2-build-status.json').read_text())['state']=='NATIVE_PINNED_LOCAL_EDIT_READY'
 assert json.loads((ROOT/'build-status.json').read_text())['state']=='RELEASE_BUILD_COMPLETE_NATIVE_TESTS_PENDING'
 test_source=ROOT/'native-tests2/workspace';lock=test_source/'Package.resolved'
 assert_native_pins(lock);write(ROOT/'native3-source-before.json',verify_sources())
 command('native3-build-tests',['swift','build','--build-tests','--scratch-path',str(TEST_BUILD),'--jobs','4','--disable-automatic-resolution'],test_source,3600)
 lock_receipt('built',lock);assert_native_pins(lock)
 graph_proof('native-tests',TEST_BUILD,[SOURCE,test_source]);stage_test_metallib()
 for suite in ['CBv2ForwardShapeTests','CBv2ForwardShapeEngineTests','GPTOSSCompiledExpertsTests','CBv2MTPRoundSmokeTests']:
  log=command('native3-test-'+suite,['bash',str(SOURCE/'scripts/run-nested-suite.sh'),suite,'--scratch-path',str(TEST_BUILD),'--disable-automatic-resolution'],test_source,1800)
  if suite=='CBv2ForwardShapeEngineTests' and 'firstScopeRefusesDiscardedChainedWorkBeforeItsReadback' not in log.read_text():raise ValueError('activation regression did not execute')
 for relative,expected in MANIFEST['files']['native'].items():
  if identity(test_source/relative)!=expected:raise ValueError('native test source drift: '+relative)
 write(ROOT/'source-final.json',verify_sources());assert_native_pins(lock)
 for product in ['darkbloom','radix-engine']:
  command(product+'-codesign',['codesign','--verify','--strict','--verbose=2',str(ARTIFACT/product)],ROOT,120)
  command(product+'-signature',['codesign','-d','--verbose=4',str(ARTIFACT/product)],ROOT,120)
  command(product+'-dylibs',['otool','-L',str(ARTIFACT/product)],ROOT,120)
 command('cli-help',[str(ARTIFACT/'darkbloom'),'--help'],ROOT,60)
 files={str(p.relative_to(ARTIFACT)):identity(p) for p in ARTIFACT.rglob('*') if p.is_file()}
 if len(files)!=8:raise ValueError('canonical artifact must contain eight files')
 write(ROOT/'artifact-manifest.json',{'source':MANIFEST['source'],'files':files,'canonical_swiftpm_build':True,'manual_object_link':False,'M5_built':True,'real_model_pilot':False,'shader_reuse_proof':'shader-reuse-proof.json','lock_proof':'lock-proof.json'})
 state({'state':'BUILD_AND_NATIVE_TESTS_COMPLETE_ARTIFACT_REVIEW_REQUIRED','source':MANIFEST['source'],'artifact_manifest':str(ROOT/'artifact-manifest.json'),'model_pilot_performed':False})
except BaseException as error:
 state({'state':'FAILED','error':type(error).__name__+': '+str(error),'completed_steps':EXECUTIONS,'model_pilot_performed':False})
 raise
