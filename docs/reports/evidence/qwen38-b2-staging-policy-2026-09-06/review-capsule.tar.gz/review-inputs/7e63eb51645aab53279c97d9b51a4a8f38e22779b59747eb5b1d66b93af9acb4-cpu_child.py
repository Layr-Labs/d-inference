"""Harmless process fixtures only; never imports or invokes a model runner."""
import os
from pathlib import Path
import subprocess
import sys
import time
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import pilot
import pilot_core as core
import ssh_controller


def main():
    mode, root = sys.argv[1], Path(sys.argv[2])
    if mode == "outer":
        scenario, lease = sys.argv[3], float(sys.argv[4])
        activation = {"run_root": str(root / "attempt"), "dependencies": {}}
        activation_path = root / "activation.json"; core.write_new(activation_path, activation)
        original_popen = subprocess.Popen
        def fake_owned(argv, **kwargs):
            if "_owned" in argv:
                argv = [sys.executable, "-B", str(Path(__file__).resolve()), "supervise", activation["run_root"],
                        scenario, "30", "60"]
            return original_popen(argv, **kwargs)
        with patch.object(core, "verify_activation", return_value=(activation, None)), \
             patch.object(core, "snapshot_reviews"), patch.object(pilot.subprocess, "Popen", side_effect=fake_owned), \
             patch.object(pilot, "LEASE", lease):
            return pilot.run(activation_path)
    if mode == "relay":
        argv = [sys.executable, "-B", str(Path(__file__).resolve()), "outer", str(root), sys.argv[3], "1.2"]
        with patch.object(ssh_controller, "PING_INTERVAL", .05), patch.object(ssh_controller, "CLEANUP_GRACE", 5):
            return ssh_controller.relay(argv, root / "local-controller")
    if mode == "supervise":
        scenario = sys.argv[3]
        step = root / "steps/1"; step.mkdir(parents=True)
        argv = [sys.executable, "-B", str(pilot.ROOT / "tracked_runner.py"), str(step / "children.jsonl"),
                str(Path(__file__).resolve()), scenario, str(root)]
        accepted = pilot.supervise(argv, core.ENV, root, sys.stdin.buffer,
                                   lease=float(sys.argv[4]), deadline=float(sys.argv[5]))
        if accepted:
            core.write_new(root / "worker-verdict.json", {"accepted": True, "cpu_fixture": True})
        return 0 if accepted else 1
    step = root / "steps/1"
    core.write_new(step / "wrapper.json", {"pid": os.getpid(), "allowed_executables": [sys.executable]})
    if mode == "complete":
        time.sleep(.2)
        return 0
    seconds = 2 if mode == "sequence" else 60
    process = subprocess.Popen([sys.executable, "-B", "-c", "import time; time.sleep(" + str(seconds) + ")"], start_new_session=True)
    core.write_new(root / "cpu-child.json", {"pid": process.pid, "birth": pilot.birth(process.pid)})
    process.wait()
    if mode == "sequence":
        pilot.require_caller_live(root)
        core.write_new(root / "successor-started.json", {"cpu_fixture_only": True})
        time.sleep(60)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
