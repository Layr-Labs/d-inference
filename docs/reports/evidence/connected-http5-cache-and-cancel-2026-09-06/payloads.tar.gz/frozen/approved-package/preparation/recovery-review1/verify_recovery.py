#!/usr/bin/env python3
"""Verify the recovered preparation without launching any runtime."""
import ast
import hashlib
import json
from pathlib import Path
import stat
import tarfile

BASE = Path('/tmp/darkbloom-connected-m5-bundle5')
OLD = Path('/tmp/darkbloom-connected-m5-bundle4')
OUT = Path(__file__).resolve().parent


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def check_manifest(base, name='manifest.json'):
    files = load(base/name)['files']
    for name, item in files.items():
        path = base/name
        assert path.is_file() and not path.is_symlink(), path
        assert sha(path) == item['sha256'], path
        size = item.get('bytes', item.get('size_bytes'))
        if size is not None:
            assert path.stat().st_size == size, path
    return len(files)


def main():
    assert sha(OLD/'package-manifest.json') == '6547b2099ab603494de95fff68c73deb525690a21ba738c90103078525b198e1'
    old_files = check_manifest(OLD, 'package-manifest.json')
    old_archive = Path('/tmp/darkbloom-connected-m5-bundle4.tar.gz')
    assert sha(old_archive) == '4bdfef43ef976a5024afb0be567670b69b5f13a48d37c66fe8fbf51be1344ab8'
    with tarfile.open(old_archive) as archive:
        old_mode = archive.getmember('connected-e2e.test').mode
    assert old_mode == 0o644
    assert stat.S_IMODE((OLD/'connected-e2e.test').stat().st_mode) == 0o644
    binary = BASE/'connected-e2e.test'
    assert sha(binary) == '6e30a1e53cc26ac1bb7953216b6d0af835b8b08a29f1920b2df07999c0e2bc8f'
    assert stat.S_IMODE(binary.stat().st_mode) == 0o755
    helper = Path('/tmp/darkbloom-connected-bundle5-helper-review1')
    helper_files = check_manifest(helper)
    for name, item in load(helper/'review.json')['changed_files'].items():
        assert sha(BASE/name) == item['after_sha256'], name
    for path in BASE.glob('*.py'):
        ast.parse(path.read_text(), feature_version=(3, 9))
    go = load(BASE/'go-source-manifest.json')['files']
    for name, item in go.items():
        actual = BASE/'go-source'/name
        expected = item if isinstance(item, str) else item['sha256']
        assert sha(actual) == expected, name
        assert actual.read_bytes() == (OLD/'go-source'/name).read_bytes(), name
    assert len(go) == 988
    prior = BASE/'previous-package/september5-unfrozen-draft'
    draft_files = check_manifest(prior)
    old_plan, plan = load(prior/'bundle-plan.json'), load(BASE/'bundle-plan.json')
    assert old_plan['expected_request_date_utc'] == '2026-09-05'
    assert plan['expected_request_date_utc'] == '2026-09-06'
    assert {k for k in plan if plan[k] != old_plan[k]} == {'expected_request_date_utc'}
    pairs = []
    for off, on in zip(plan['cells'][::2], plan['cells'][1::2]):
        a, b = load(BASE/off['input']), load(BASE/on['input'])
        assert a['cache_mode'] == 'off' and b['cache_mode'] == 'ssd'
        assert {k: v for k, v in a.items() if k != 'cache_mode'} == {k: v for k, v in b.items() if k != 'cache_mode'}
        for cell in [off, on]:
            data = load(BASE/cell['input'])
            assert (BASE/cell['input']).read_bytes() == (prior/cell['input']).read_bytes()
            assert data['provider_sha256'] == '7345c5b29369a8ff168b1230254c0a164a6ccc97a0fb0baca380475acda43363'
            assert data['tools_request']['max_tokens'] == 512
            assert data['mtp_mode'] == ('off' if data['artifact']['model_id'] == 'gpt-oss-20b' else 'on')
            previous = load(OLD/cell['input'])
            changed = {k for k in data if data[k] != previous[k]}
            assert changed == ({'vision_png'} if 'vision_png' in data else set())
            if 'vision_png' in data:
                assert data['vision_png'] == previous['vision_png'].replace('090-connected-http4/', '090-connected-http5/')
        pairs.append({'off': off['cell'], 'ssd': on['cell'], 'paired_identity': True,
                      'vs_bundle4_changed_fields': sorted(changed),
                      'off_input_sha256': sha(BASE/off['input']), 'ssd_input_sha256': sha(BASE/on['input'])})
    assert len(pairs) == 6
    old_tokens, new_tokens = load(prior/'tokenizer-plan.json'), load(BASE/'tokenizer-plan.json')
    assert new_tokens['status'] == old_tokens['status'] == 'passed'
    assert len(new_tokens['rows']) == 6
    token_deltas = []
    for a, b in zip(old_tokens['rows'], new_tokens['rows']):
        changed = {k for k in b if b[k] != a[k]}
        assert changed == {'normalized_body_sha256'}
        token_deltas.append({'model_id': b['model_id'], 'changed_fields': sorted(changed),
                             'before_normalized_body_sha256': a['normalized_body_sha256'],
                             'after_normalized_body_sha256': b['normalized_body_sha256'],
                             'prompt_tokens_unchanged': b['prompt_tokens'],
                             'last_boundary_unchanged': b['last_boundary']})
    result = {'status': 'PASS', 'previous_package_files_reverified': old_files,
              'previous_go_executable_mode': '0644', 'corrected_go_executable_mode': '0755',
              'go_source_files_unchanged': len(go), 'helper_review_files_reverified': helper_files,
              'preserved_draft_files_verified': draft_files, 'python39_parse': 'PASS',
              'source_patch': str(helper/'helper.patch'),
              'date_delta': {'before': '2026-09-05', 'after': '2026-09-06',
                             'bundle_plan_changed_fields': ['expected_request_date_utc'],
                             'all_twelve_input_files_byte_identical_to_preserved_draft': True,
                             'cpu_tokenizer_plan_rows': token_deltas},
              'pairs': pairs, 'HTTP_cells': 'all twelve unrun; no provider runtime launched',
              'scope': 'CPU preparation and source integrity; no remote jobs, builds, inference, signing, keys, configuration or production changes'}
    (OUT/'recovery-validation.json').write_text(json.dumps(result, indent=2)+'\n')
    paired = {'status': 'PASS', 'request_date_utc': '2026-09-06', 'pairs': pairs,
              'CLI8_model_tool512_MTP_defaults_unchanged': True,
              'date_delta_evidence': 'preparation/recovery-review1/recovery-validation.json'}
    (BASE/'paired-input-validation.json').write_text(json.dumps(paired, indent=2)+'\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
