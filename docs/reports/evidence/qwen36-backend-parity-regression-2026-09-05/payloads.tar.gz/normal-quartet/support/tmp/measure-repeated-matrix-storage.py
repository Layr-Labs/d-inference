from pathlib import Path
import json,subprocess,sys
out=Path(sys.argv[1]);assert not out.exists()
ssh=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99']
code='''from pathlib import Path
import json,shutil,stat,time
root=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-repeated-matrix1');runs=root/'runs';cells=[]
for cell in sorted(runs.iterdir()) if runs.exists() else []:
 count=logical=allocated=0;symlinks=[]
 for p in cell.rglob('*'):
  s=p.lstat()
  if stat.S_ISLNK(s.st_mode):symlinks.append(str(p.relative_to(cell)));continue
  if stat.S_ISREG(s.st_mode):count+=1;logical+=s.st_size;allocated+=s.st_blocks*512
 cells.append({'cell':cell.name,'files':count,'logical_bytes':logical,'allocated_bytes':allocated,'symlinks_not_followed':symlinks})
space=shutil.disk_usage(root)
print(json.dumps({'unix_time':time.time(),'root':str(root),'free_bytes':space.free,'total_volume_bytes':space.total,'reviewed_min_free_bytes':100*(1<<30),'cells':cells,'owned_logical_bytes':sum(c['logical_bytes'] for c in cells),'owned_allocated_bytes':sum(c['allocated_bytes'] for c in cells),'retention':'All failed/partial/accepted payloads and evidence retained; no deletion or mutation'},indent=2))
'''
r=subprocess.run(ssh+['python3 -'],input=code,text=True,capture_output=True);assert r.returncode==0,r.stderr;out.write_text(r.stdout);data=json.loads(r.stdout);print(r.stdout);assert data['free_bytes']>max(data['reviewed_min_free_bytes'],int(data['total_volume_bytes']*.05),20*(1<<30))
