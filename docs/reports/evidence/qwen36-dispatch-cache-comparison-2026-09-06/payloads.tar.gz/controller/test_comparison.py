from pathlib import Path
import copy,hashlib,importlib.util,json,shutil,sys,tempfile,unittest
from unittest.mock import patch
from types import SimpleNamespace
from strict_results import matched_errors,chunk_timing,result_errors
ROOT=Path(__file__).resolve().parent
PLAN=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-plan1')
BINDING=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-binding1.json')
PRIOR=Path('/tmp/darkbloom-q36-attention-packet-execution1/qwen36-paged-control')

def load(path):return json.loads(path.read_text())
class ComparisonTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.addCleanup(self.temp.cleanup);self.root=Path(self.temp.name)
  self.plan=load(PLAN/'plan.json');self.binding=load(BINDING);self.cell=self.plan['cells'][0];self.report=load(PRIOR/'report.json')
  a=self.binding['variants']['baseline']['artifacts'];self.report['runtime_identity']['binary_sha256']=a['radix-engine']['sha256']
  meta=load(PRIOR/'metadata.json');meta['binary_sha256']=a['radix-engine']['sha256'];meta['command']=self.binding['commands'][0]['expected_observed_native_argv']
  (self.root/'metadata.json').write_text(json.dumps(meta));shutil.copy2(PRIOR/'input.json',self.root/'input.json')
 def errors(self):return result_errors(self.root,self.cell,self.plan,self.binding,self.report,self.root)
 def test_bound_control_fixture(self):self.assertEqual(self.errors(),[])
 def test_wrong_binary_refuses(self):
  self.report['runtime_identity']['binary_sha256']='0'*64;self.assertIn('native report runtime differs from bound artifacts',self.errors())
 def test_wrong_mode_diagnostics_fallback_refuse(self):
  self.report['mtp']='on; production configured assistant';self.report['attention_metadata']={};self.report['backend_fallback']='planted'
  self.assertIn('serving mode mismatch',self.errors());self.assertIn('uninstrumented control emitted diagnostics',self.errors());self.assertIn('backend/fallback mismatch',self.errors())
 def test_all_seven_trajectories_compared(self):
  for group in ['rows','tenant_checks','cancel_donor','recovered']:
   rows=self.report[group]if isinstance(self.report[group],list)else[self.report[group]]
   for index in range(len(rows)):
    other=copy.deepcopy(self.report);items=other[group]if isinstance(other[group],list)else[other[group]]
    items[index]['token_ids'][0]+=1
    self.assertEqual(len(matched_errors(self.report,other)),1)
 def test_prefix_of_recovery_required(self):
  self.report['cancelled']['token_ids'][0]+=1;self.assertIn('canceled output is not its own recovery prefix',self.errors())
 def test_multi_token_first_chunk_rate_and_straddled_prefix(self):
  r={'chunks':[{'tokens':[1,2,3],'elapsed_s':2.0},{'tokens':[4,5,6],'elapsed_s':3.0},{'tokens':[7],'elapsed_s':4.0}],'token_ids':list(range(1,8)),'ttft_s':2.,'elapsed_s':4.1,'decode_tps':2.,'terminal_tail_s':.1}
  t=chunk_timing(r,5);self.assertEqual(t['delivered_tokens_per_s'],2.);self.assertEqual(t['after_first_chunk_tokens'],4);self.assertTrue(t['prefix']['straddled']);self.assertEqual(t['prefix']['delivered_tokens_at_chunk'],6)
 def test_unordered_or_wrong_chunk_tokens_refuse(self):
  r=copy.deepcopy(self.report['rows'][0]);r['chunks'][1]['elapsed_s']=-1
  with self.assertRaises(AssertionError):chunk_timing(r)
  r=copy.deepcopy(self.report['rows'][0]);r['chunks'][0]['tokens'][0]+=1
  with self.assertRaises(AssertionError):chunk_timing(r)
 def test_all_twelve_cells_render_guards_with_missing_report_stop(self):
  for index,cell in enumerate(self.plan['cells']):
   spec=importlib.util.spec_from_file_location('comparison_driver',ROOT/'run_cell.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
   target=self.root/str(index);target.mkdir();module.OUT=target
   for n in ['strict_results.py','preflight.py']:shutil.copy2(ROOT/n,target/n)
   for previous in self.plan['cells'][:index]:
    p=target/previous['id'];p.mkdir();raw=json.dumps({'exit_code':0,'report_integrity_passed':True}).encode();(p/'summary.json').write_bytes(raw)
    (p/'manifest.json').write_text(json.dumps({'files':{'summary.json':{'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}}}))
   rendered=[]
   def fake(argv,**kw):
    if 'input'in kw:
     code=kw['input'];compile(code,'<comparison-remote>','exec');rendered.append(code)
     self.assertNotIn('VARIANT',code)
    return SimpleNamespace(returncode=0,stdout='{"files":{}}',stderr='')
   with patch.object(module.subprocess,'run',side_effect=fake),patch.object(sys,'argv',['run_cell.py',cell['id']]):
    with self.assertRaises(SystemExit)as stopped:module.main()
   self.assertEqual(stopped.exception.code,1);self.assertEqual(len(rendered),2)
   self.assertEqual(load(target/cell['id']/'summary.json')['errors'],['report missing'])
if __name__=='__main__':unittest.main()
