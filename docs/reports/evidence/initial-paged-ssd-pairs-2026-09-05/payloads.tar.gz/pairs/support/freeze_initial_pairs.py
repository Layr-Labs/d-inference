"""Freeze the three strict initial B1 passes, preserving their setup failures."""

from pathlib import Path
import hashlib
import json
import shutil

source = Path('/tmp/darkbloom-fleet-smoke-continuation')
smoke = Path('/tmp/darkbloom-final-fleet-smoke2')
out = Path('/tmp/darkbloom-initial-paged-pairs-freeze1')
out.mkdir(exist_ok=False)
mapping = {}


def digest(path):
    data = path.read_bytes()
    return {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def copy(path, relative):
    target = out / relative
    assert path.is_file() and not path.is_symlink()
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as handle:
        handle.write(path.read_bytes())
    assert digest(target) == digest(path)
    mapping[str(relative)] = {'source': str(path), **digest(target)}


cells = [
    'qwen38-paged-cache-off-b1-smoke2',
    'qwen38-paged-cache-on-b1-smoke2',
    'qwen38-paged-cache-on-b1-smoke2-retry1',
    'gpt-oss-20b-paged-cache-off-b1-smoke2',
    'gpt-oss-20b-paged-cache-on-b1-smoke2',
    'gemma-4-26b-paged-cache-off-b1-smoke2',
    'gemma-4-26b-paged-cache-off-b1-smoke2-assistant1',
    'gemma-4-26b-paged-cache-on-b1-smoke2-assistant1',
]
for name in cells:
    root = smoke / 'results' / name
    original = json.loads((root / 'manifest.json').read_text())
    for relative, expected in original['files'].items():
        assert digest(root / relative) == expected, str(root / relative)
    for path in sorted(root.iterdir()):
        if path.is_file():
            copy(path, Path('raw') / name / path.name)

for name in ('qwen38-paged-cache-pair', 'qwen38-hardened-comparator',
             'gpt-paged-cache-pair', 'gpt-hardened-comparator',
             'gemma-paged-cache-pair', 'gemma-hardened-comparator'):
    root = source / name
    for path in sorted(root.iterdir()):
        if path.is_file():
            copy(path, Path('verdicts') / name / path.name)

for name in ('handoff-artifact-preconditions.json', 'qwen38-hardened-bank-proof.json',
             'gpt-off-preflight.json', 'gpt-on-preflight.json', 'gemma-off-preflight.json',
             'gemma-off-assistant1-preflight.json', 'gemma-on-assistant1-preflight.json',
             'gemma-two-file-fixture-proof.json', 'gemma-assistant-post-pair.json',
             'gemma-corrected-driver-proof.json', 'summarize_pair.py', 'hardened_compare.py',
             'preflight.py', 'freeze_initial_pairs.py'):
    copy(source / name, Path('support') / name)
for name in ('plan.json', 'input-transfer.json'):
    copy(smoke / name, Path('input') / name)
for name in ('qwen38', 'gpt-oss-20b', 'gemma-4-26b'):
    copy(smoke / 'inputs' / (name + '.json'), Path('input') / (name + '.json'))
    copy(Path('/tmp/qwen35b-ssd-model-inventory') / (name + '-fleet-manifest.json'),
         Path('models') / (name + '-fleet-manifest.json'))
for path in (Path('/tmp/run-final-model-cell-smoke2-root.py'),
             Path('/tmp/run-final-model-cell-smoke2-gemma-assistant1.py'),
             Path('/tmp/darkbloom-0.9-validation/matrix.json')):
    copy(path, Path('support') / path.name)

provenance = {
    'scope': 'One ordered paged B1 cache-off/SSD pair each for exact Q38, GPT-OSS 20B, and Gemma 4 26B. Real M5 128 GiB; no repeated-performance, contiguous, B2/B4, HTTP, eviction, or persistent-restart acceptance.',
    'probe_sha256': '601bce0923cfb2e12410073fe193a08a9c73830b5afd74d7f72e2facb49be21c',
    'metallib_sha256': '4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0',
    'wrapper_sha256': 'b5166c413e72f871ff8ebe17493b4628a8f0479e9eba376b0090eb65e3db29a1',
    'strict_evaluator_commit': '437bea4fe89100d8b6773c1039e398f52a5569dc',
    'build_evidence': '/tmp/darkbloom-final-serving-build3/manifest.json',
    'build_evidence_sha256': '21ceabccb073eff8ad47c67d447023479f5456ba86fc04343d21dade0c90b5a0',
    'production_harness_bank': '06af2f5853d7890404729647a698d37ac0479bef',
    'wrapper_fix_bank': '1a4a4504b82631f41029636280dc3b65e671b700',
    'native_commit': 'aafe2069bcdeadef9250530eb511c598649c0355',
    'observed': {'Q38': {'prompt_tokens': 5523, 'saved_tokens': 4096, 'normal_mtp': True},
                 'GPT-OSS': {'prompt_tokens': 5472, 'saved_tokens': 4096, 'normal_mtp': False},
                 'Gemma': {'prompt_tokens': 5418, 'saved_tokens': 4096, 'normal_mtp': True}},
    'strict_pair_passes': 3,
    'retained_failures': [
        'Q38 first SSD attempt refused entry temperature before inference; later fresh retry supplies candidate.',
        'Gemma first cache-off attempt refused the three-file local assistant override before requests; new two-file fixture preserves identical config/weights and untouched provenance manifest.'
    ],
    'limits': [
        'Q36 immediate cold-control gauge issue and normal-adaptive Q35 final-token mismatch remain unresolved outside this three-model pass milestone.',
        'Ephemeral keys prove authenticated restore inside one process, not production signing or OS-process restart.',
        'Zero retired ownership/page gauges do not imply zero MLX cache, RSS, model-weight residency, or logical address capacity.',
        'Timing rows are raw single-pair observations, not banked release speedups.',
        'Original manifests retain absolute provenance paths; the outer mapping binds each immutable copied payload.'
    ]
}
(out / 'PROVENANCE.json').write_text(json.dumps(provenance, indent=2) + '\n')
mapping['PROVENANCE.json'] = {'source': 'generated by freeze_initial_pairs.py', **digest(out / 'PROVENANCE.json')}
manifest = {'scope': provenance['scope'], 'payload_count': len(mapping), 'files': mapping}
(out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'directory': str(out), 'payload_count': len(mapping),
    'payload_bytes': sum(item['bytes'] for item in mapping.values()),
    'manifest_sha256': digest(out / 'manifest.json')['sha256']}, indent=2))
