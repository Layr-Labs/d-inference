from pathlib import Path
import json,hashlib,shlex,subprocess,sys,time
cell=sys.argv[1];assert cell in ['qwen35-b1-r1-'+backend+'-cache-'+cache for backend in ('contiguous','paged') for cache in ('off','on')]
local=Path('/tmp/darkbloom-repeated-matrix-execution1')/cell;local.mkdir(parents=True,exist_ok=False);base='/Users/gaj/autoresearch/radix-prefix-cache/090-repeated-matrix1';binding=base+'/bindings.reviewed1.json';output=base+'/runs/'+cell;ssh=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99']
for tool,name in [('/tmp/darkbloom-fleet-smoke-continuation/preflight.py','external-preflight'),('/tmp/measure-repeated-matrix-storage.py','storage-before')]:
 r=subprocess.run(['python3','-B',tool,str(local/(name+'.json'))],capture_output=True,text=True);(local/(name+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,(name,r.stdout,r.stderr)
command=['python3','-B',base+'/plan/matrix_cells.py','command','--bindings',binding,'--cell',cell]
r=subprocess.run(ssh+[shlex.join(command)],capture_output=True,text=True);(local/'command.stdout').write_text(r.stdout);(local/'command.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr;c=json.loads(r.stdout);assert c['cell']==cell and c['bindings_sha256']=='bab4d1512a1bebb5cf305b2b019f9d084042c201161b7114bda56ada9d1ce47f';assert c['shell']==shlex.join(c['argv']);start=time.monotonic()
with (local/'ssh-run.log').open('x') as log:r=subprocess.run(ssh+[c['shell']],stdout=log,stderr=subprocess.STDOUT)
exit_code=r.returncode;(local/'execution.json').write_text(json.dumps({'cell':cell,'exit_code':exit_code,'seconds':time.monotonic()-start,'scope':'Reviewed candidate build6 first Q35 B1 repetition1 quartet; no final promotion or repeated summary yet'},indent=2)+'\n')
code='''from pathlib import Path
import hashlib,json
root=Path(ROOT);files={}
if root.exists():
 for p in sorted(root.iterdir()):
  if p.is_file() and not p.is_symlink():files[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'root':str(root),'exists':root.exists(),'files':files},indent=2))
'''.replace('ROOT',repr(output));check=subprocess.run(ssh+['python3 -'],input=code,text=True,capture_output=True);assert check.returncode==0,check.stderr;(local/'remote-inventory.json').write_text(check.stdout);inventory=json.loads(check.stdout)
for name,item in inventory['files'].items():
 assert all(x.isalnum() or x in '.-_' for x in name);p=local/name;r=subprocess.run(['scp','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','gaj@100.124.35.99:'+output+'/'+name,str(p)],text=True,capture_output=True);assert r.returncode==0,r.stderr;assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
collect=['python3','-B',base+'/plan/matrix_cells.py','collect','--bindings',binding];r=subprocess.run(ssh+[shlex.join(collect)],text=True,capture_output=True);(local/'collection.json').write_text(r.stdout);(local/'collection.stderr').write_text(r.stderr);(local/'collection-execution.json').write_text(json.dumps({'command':collect,'exit_code':r.returncode},indent=2)+'\n')
summary={'cell':cell,'wrapper_exit_code':exit_code,'collection_exit_code':r.returncode,'path':str(local)}
if r.returncode==0:
 collection=json.loads(r.stdout);item=next(x for x in collection['cells'] if x['id']==cell);summary.update(cell_status=item['status'],cell_errors=item.get('errors',[]),comparisons=[{k:p.get(k) for k in ('id','axis','passed','state','errors')} for p in collection['comparisons'] if p['baseline']==cell or p['candidate']==cell])
(local/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');files={str(p.relative_to(local)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(local.rglob('*')) if p.is_file()};(local/'manifest.json').write_text(json.dumps({'scope':'Raw immutable named cell; retain model failure and missing dependent comparisons separately','files':files},indent=2)+'\n');print(json.dumps(summary,indent=2));print('manifest_sha256',hashlib.sha256((local/'manifest.json').read_bytes()).hexdigest());sys.exit(exit_code or r.returncode)
