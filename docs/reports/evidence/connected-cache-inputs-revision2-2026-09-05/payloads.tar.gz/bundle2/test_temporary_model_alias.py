import hashlib
import json
from pathlib import Path
import tempfile
import unittest
import temporary_model_alias as alias


class AliasTests(unittest.TestCase):
    def fixture(self, root):
        cache, target = root/'cache', root/'exact-revision'
        cache.mkdir(); target.mkdir()
        (target/'config.json').write_bytes(b'exact')
        manifest = {'model_id': 'qwen3.5-35b-a3b', 'aggregate_sha256': 'a'*64,
                    'files': [{'path': 'config.json', 'size_bytes': 5,
                               'sha256': hashlib.sha256(b'exact').hexdigest()}]}
        return cache, target, manifest, root/'journal.json'

    def test_exact_create_cleanup_retains_target_and_journal(self):
        with tempfile.TemporaryDirectory() as tmp:
            cache, target, manifest, journal = self.fixture(Path(tmp).resolve())
            owner = alias.create_alias(cache, target, manifest, journal)
            link = Path(owner['model_root'])/'snapshots'/target.name
            self.assertEqual(link.resolve(), target)
            alias.cleanup_alias(journal); alias.cleanup_alias(journal)
            self.assertFalse(Path(owner['model_root']).exists())
            self.assertEqual((target/'config.json').read_bytes(), b'exact')
            self.assertTrue(journal.is_file())

    def test_existing_root_and_corruption_never_replaced(self):
        with tempfile.TemporaryDirectory() as tmp:
            cache, target, manifest, journal = self.fixture(Path(tmp).resolve())
            model = cache/'models--qwen3.5-35b-a3b'; model.mkdir()
            with self.assertRaises(FileExistsError):
                alias.create_alias(cache, target, manifest, journal)
            self.assertFalse(journal.exists()); model.rmdir()
            (target/'config.json').write_bytes(b'wrong')
            with self.assertRaises(ValueError):
                alias.create_alias(cache, target, manifest, journal)
            self.assertFalse(model.exists()); self.assertFalse(journal.exists())

    def test_changed_alias_or_foreign_entry_refuses_cleanup(self):
        with tempfile.TemporaryDirectory() as tmp:
            cache, target, manifest, journal = self.fixture(Path(tmp).resolve())
            owner = alias.create_alias(cache, target, manifest, journal)
            model = Path(owner['model_root']); link = model/'snapshots'/target.name
            link.unlink(); link.symlink_to(tmp)
            with self.assertRaises(ValueError): alias.cleanup_alias(journal)
            self.assertTrue(link.is_symlink())
            link.unlink(); link.symlink_to(target)
            (model/'foreign').write_bytes(b'leave')
            with self.assertRaises(ValueError): alias.cleanup_alias(journal)
            self.assertTrue(link.is_symlink()); self.assertEqual((model/'foreign').read_bytes(), b'leave')

    def test_changed_marker_refuses_cleanup(self):
        with tempfile.TemporaryDirectory() as tmp:
            cache, target, manifest, journal = self.fixture(Path(tmp).resolve())
            owner = alias.create_alias(cache, target, manifest, journal)
            marker = Path(owner['model_root'])/alias.MARKER
            marker.write_text('changed')
            with self.assertRaises(ValueError): alias.cleanup_alias(journal)
            self.assertTrue(marker.is_file())


if __name__ == '__main__': unittest.main()
