from pathlib import Path
import hashlib, json, subprocess

out = Path('/tmp/darkbloom-allocator-footprint-policy-validation1')
root = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
repos = {'swift': out / 'deps/mlx-swift', 'mlx': out / 'deps/mlx-swift/Source/Cmlx/mlx', 'mlx-c': out / 'deps/mlx-swift/Source/Cmlx/mlx-c', 'native': Path('/tmp/darkbloom-allocator-footprint-foundation6/native')}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()

def verify():
    owned = json.loads((out / 'owned-manifest.json').read_text())
    for key, expected in owned['files'].items():
        alias, path = key.split('/', 1)
        assert sha(repos[alias] / path) == expected, key
    deps = json.loads((out / 'dependency-source-manifest.json').read_text())
    for key, expected in deps['files'].items():
        alias, path = key.split('/', 1)
        assert sha(Path(deps['repositories'][alias]) / path) == expected, key
    native = json.loads((out / 'native-source-manifest.json').read_text())
    for path, expected in native['files'].items():
        assert sha(repos['native'] / path) == expected, path
    for row in json.loads((out / 'integration.json').read_text())['repositories']:
        assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=row['path'], text=True).strip() == row['base']
    return {'owned_inputs': len(owned['files']), 'dependency_inputs': len(deps['files']), 'frozen_native_inputs': len(native['files']), 'no_drift': True, 'mutable_primary_excluded_during_root_bank': True}
