from pathlib import Path
import json,subprocess
out=Path('/tmp/darkbloom-q36-actual-logits-postcheck1');out.mkdir(exist_ok=False);r=subprocess.run(['python3','-B','/tmp/darkbloom-fleet-smoke-continuation/preflight.py',str(out/'ownership.json')],text=True,capture_output=True);(out/'ownership.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
code='''from pathlib import Path
import hashlib,json,time,shutil,stat
root=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-q36-actual-logits1');plan=json.loads((root/'plan.json').read_text());m=json.loads((root/'source-proof/model-manifest.json').read_text());model=Path(plan['cells'][0]['argv'][plan['cells'][0]['argv'].index('--model-directory')+1]);start=time.monotonic()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
 return h.hexdigest()
assert {p.name for p in model.iterdir() if p.is_file()}=={x['path'] for x in m['files']};files=[]
for x in m['files']:
 p=model/x['path'];actual=sha(p);assert actual==x['sha256'] and p.stat().st_size==x['size_bytes'];files.append({'path':str(p),'bytes':p.stat().st_size,'sha256':actual})
am=json.loads((root/'runtime-proof/artifact-manifest.json').read_text());runtime={}
for name,item in am['files'].items():
 p=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact')/name;actual=sha(p);assert actual==item['sha256'];runtime[str(p)]=actual
payloads=[]
for p in sorted((root/'runs').iterdir()):
 allfiles=[f for f in p.rglob('*') if f.is_file() and not f.is_symlink()];payloads.append({'root':str(p),'files':len(allfiles),'logical_bytes':sum(f.stat().st_size for f in allfiles),'allocated_bytes':sum(f.stat().st_blocks*512 for f in allfiles)})
assert len(payloads)==4;free=shutil.disk_usage(root).free;assert free>100*(1<<30)
print(json.dumps({'scope':'Post-four-cell exact model/runtime hash verification; all failed/partial/successful raw output retained','seconds':time.monotonic()-start,'model_aggregate_sha256':m['aggregate_sha256'],'model_files':files,'runtime_sha256':runtime,'run_payloads':payloads,'free_bytes':free},indent=2))
''';ssh=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','gaj@100.124.35.99'];r=subprocess.run(ssh+['python3 -B -'],input=code,text=True,capture_output=True);(out/'postcheck.json').write_text(r.stdout);(out/'postcheck.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr;print(r.stdout)
