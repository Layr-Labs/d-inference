"""Project sealed125 receipts without prompts, outputs, credentials, binaries or weights."""
from pathlib import Path
import hashlib,json,tomllib
BASE=Path('/private/tmp/darkbloom-release090-qwen-default-discovery-execution1')
OUT=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def digest_value(value):return hashlib.sha256(json.dumps(value,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def read(p):return json.loads(p.read_text())
models=[]
for name in ('qwen36','qwen35','qwen38'):
 evidence=BASE/(name+'-evidence'); rp=evidence/'steps/1/http-evidence/evidence/report.json';r=read(rp);pre=read(BASE/(name+'-preflight.json'));post=read(BASE/(name+'-clean-postflight.json'))
 assert r['state']=='completed' and r['scope']=='release_defaults_b1_text' and r['wire_dropped']==0
 assert [c['name'] for c in r['cases']]==['cold','repeat']
 cfg=evidence/'steps/1/http-evidence/evidence/provider-config.toml';config=tomllib.loads(cfg.read_text())
 assert config['backend']=={'engine_v2_kv_backend':'auto','engine_v2_max_concurrent':1,'mtp_mode':'auto'}
 assert 'prefix_cache' not in config and 'prefix_cache_enabled' not in config['backend']
 assert pre['preflight']['policy_environment']=={}
 cases=[]
 for c in r['cases']:
  h=c['http'];s=c['slots_after'][0];slot=s['capacity']['slots'][0];cap=s['cache_capability'];usage=h['usage']
  assert c['status']=='passed' and h['http_status']==200 and h['done'] and not h['cancelled_by_client']
  assert h['finish_reason']=='length' and usage['prompt_tokens']>0 and usage['completion_tokens']==64 and usage['total_tokens']==usage['prompt_tokens']+64
  assert usage['completion_tokens_details']['reasoning_tokens']==64 and not h['content'] and h['reasoning'] and not h.get('tools')
  assert s['cache_status']['backend']=='paged' and s['cache_status']['state']=='ready' and slot['kv_backend']=='paged' and not slot.get('kv_backend_fallback_reason')
  assert cap['enabled'] and cap['ready'] and cap['model_id']==r['input']['artifact']['model_id'] and cap['model_aggregate_hash']==r['input']['artifact']['model_aggregate_sha256'] and cap['prompt_contract_id']==r['input']['artifact']['prompt_contract_id']
  assert not s.get('memory_capability') and slot['prefix_cache']['kind']=='complete_checkpoint'
  lookup=next(w['fields'] for w in c['wire'] if w['type']=='prefix_cache_lookup_v2')
  complete=next(w['fields'] for w in c['wire'] if w['type']=='inference_complete');profile=complete['profile'];engine=profile['engine'];wireusage=complete['usage']
  dispatch=next(w['fields'] for w in c['wire'] if w['type']=='inference_request')
  assert dispatch['encrypted_body_present'] and dispatch['cache_scope_present'] and dispatch['cache_receipt_nonce_present']
  assert lookup['tier']=='ssd' and profile['mtp_active'] and engine['mtp_rounds']>0 and engine['batch_rows_max']==1
  if c['name']=='repeat':assert lookup['outcome']=='hit' and lookup['matched_anchor_tokens']==4096 and wireusage['cached_tokens']==4096 and wireusage['prefill_tokens_saved']==4096
  else:assert lookup['outcome']=='miss_absent' and any(w['type']=='prefix_cache_ready_v2' for w in c['wire'])
  cases.append({'name':c['name'],'status':c['status'],'http_status':200,'usage':usage,'finish_reason':h['finish_reason'],'done':True,'cancelled_by_client':False,'output_projection':{'content_empty':not h['content'],'reasoning_utf8_bytes':len(h['reasoning'].encode()),'reasoning_sha256':hashlib.sha256(h['reasoning'].encode()).hexdigest(),'tools_empty':not h.get('tools')},'actual_backend':'paged','backend_fallback_reason':None,'cache_capability':{k:cap[k] for k in ('model_id','model_aggregate_hash','prompt_contract_id','enabled','ready','ready_boundary_mode')},'cache_store_kind':slot['prefix_cache']['kind'],'resident_cache_capability_present':False,'lookup':{k:v for k,v in lookup.items() if k not in ('cache_epoch','cache_seq')},'completion_cache_usage':{k:v for k,v in wireusage.items() if k.startswith('cache') or k=='prefill_tokens_saved'},'mtp':{'active':profile['mtp_active'],'rounds':engine['mtp_rounds'],'proposed':engine['mtp_proposed'],'accepted':engine['mtp_accepted']},'max_actual_batch_rows':engine['batch_rows_max'],'encrypted_dispatch':True,'first_delta_ms':h['first_content_ms'],'total_ms':h['total_ms']})
 for k in ('content','reasoning','tools','finish_reason'):
  assert r['cases'][0]['http'].get(k)==r['cases'][1]['http'].get(k)
 for k in ('prompt_tokens','completion_tokens','total_tokens'):
  assert r['cases'][0]['http']['usage'][k]==r['cases'][1]['http']['usage'][k]
 assert post['terminal']['accepted'] and post['supervisor']['accepted'] and post['cleanup']['complete'] and post['worker']['accepted'] and post['no_model_or_provider_process_remaining']
 models.append({'name':name,'artifact':r['input']['artifact'],'input_sha256':pre['input_sha256'],'binding_sha256':pre['binding_sha256'],'configured_backend':config['backend'],'cache_enablement_setting_present':False,'policy_environment':{},'raw_report_sha256':sha(rp),'provider_config_sha256':sha(cfg),'preflight_sha256':sha(BASE/(name+'-preflight.json')),'root_ack_sha256':sha(BASE/(name+'-root-ack.json')),'original_evidence_manifest_sha256':sha(evidence/'evidence-manifest.json'),'full_archive_sha256':post['collection']['archive_sha256'],'clean_postflight_sha256':sha(BASE/(name+'-clean-postflight.json')),'cases':cases,'cold_repeat_content_reasoning_tools_finish_and_counts_equal':True,'owner_accepted_and_retired':True,'discovery_projection':{'used':pre['preflight']['discovery_projection'] is not None,'all_manifest_files_verified':pre['preflight']['manifest_files_verified'],'model_aggregate_sha256':pre['preflight']['model_aggregate_sha256']}})
release=read(BASE/'m5-release.json');assert release['lane_released']
projection={'schema':1,'status':'THREE_QWEN_DEFAULT_HTTP_B1_PASSED','date_utc':'2026-09-06','scope':{'models':3,'http_requests':6,'max_concurrent':1,'max_completion_tokens':64,'single_provider_per_cell':True,'backend_setting':'auto','mtp_setting':'auto','cache_setting':'unset production default','cache_key_policy':'explicit ephemeral fixture keys, per-provider test roots','persistent_key_or_restart_validated':False,'semantic_quality_validated':False,'sustained_or_concurrency_validated':False,'routing_winner_validated':False,'release_ready':False},'runtime':{'candidate':'reviewed104 correctness runtime','native_reported_version':'0.8.16','final_0_9_0_version_only_rebuild_validated_here':False,'provider_sha256':r['input']['provider_sha256'],'metallib_sha256':r['input']['metallib_sha256'],'sidecar_sha256':r['input']['sidecar_sha256'],'go_test_sha256':'cdbde019a9cf1db44ca82afd728727968517d2c36f84e3fd3081c7dbd70f0506','source_manifest_sha256':'e7b769e2713e48c53fb62fbe74e449bb409c8fc1b7e5f036b14e808a7c3da3f5','runtime_review_sha256':'5bf7b2b054a9ac1bd512d7b3901eec10cfe0c1bc5286f265948ddfb51dca956e'},'controller':{'archive_sha256':'ffb3371bb27cc639024d45bd884baa705fce387f93b6419d05972bb51b1b7dce','bound_manifest_sha256':'c359b233836b9f8884dd142ce93b895729cc43ee61fbea1167a0eb72ee8e09ee','owner_manifest_sha256':'c3d808aa3db9092e1978603cc62076dfee1b91cab46b80398b9eb58c6b282e90','root_controller_review_sha256':sha(BASE/'root-controller-review.json'),'root_results_review_sha256':sha(BASE/'root-results-review.json'),'external_caller_heartbeat':True,'three_exact_cell_acks':True},'models':models,'lane_release':{'sha256':sha(BASE/'m5-release.json'),'observed_unix':release['observed_unix'],'observation':release['observation'],'lane_released':True,'both_owned_discovery_projections_retired':all(x['retired'] for x in release['owned_discovery_projections'].values())},'preserved_prior_failure':{'namespace':'107','model':'qwen36','http_requests_executed':0,'cause':'Fixture revision-directory symlink was skipped by actual Foundation discovery; provider exited with No models selected.','fix':'125 uses real revision directory, exact manifest-bound file links through its own blobs root; actual Foundation scanner and cleanup guards tested. No production scanner change.','failure_projection_sha256':sha(Path('/private/tmp/darkbloom-release090-qwen-default-http-prep1/qwen36-startup-failure-projection.json'))},'privacy':'Prompts, generated text, raw SSE, provider-config contents, credentials, binaries, weights and cache payloads omitted.'}
(OUT/'evidence.json').write_text(json.dumps(projection,indent=2)+'\n')
print(json.dumps({'models':len(models),'requests':sum(len(m['cases']) for m in models),'evidence_sha256':sha(OUT/'evidence.json')}))
