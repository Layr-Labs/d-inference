"""Qwen-only planning, command emission and strict collection; never launches work."""
import argparse
import hashlib
import importlib
import json
import math
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
LABELS = {"qwen35", "qwen36", "qwen38"}
PILOT = "qwen38-retained-b2-r1"
OLD_SOURCE = "2582177982f91cc8f945b2453dd57e00c24314360436a984f08890dd66449395"


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def object_digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def verify_package():
    inventory = read(ROOT / "manifest.json")["files"]
    require(bool(inventory), "empty package inventory")
    for relative, expected in inventory.items():
        path = ROOT / relative
        require(not Path(relative).is_absolute() and ".." not in Path(relative).parts,
                "unsafe package path")
        require(path.is_file() and not path.is_symlink()
                and path.stat().st_size == expected["bytes"]
                and digest(path) == expected["sha256"], "mutable package input refused: " + relative)


def engine():
    sys.path.insert(0, str(ROOT))
    return importlib.import_module("matrix_cells")


def validate_selection(plan):
    contract = read(ROOT / "selection-contract.json")
    for key, expected in contract.items():
        require(object_digest(plan[key]) == expected, "exact frozen selection changed: " + key)
    require({model["label"] for model in plan["models"]} == LABELS, "Qwen-only artifacts required")
    require(len(plan["cells"]) == 108 and len(plan["pairs"]) == 72, "Qwen topology changed")
    schedule = read(ROOT / "schedule.json")
    pilot = [cell["id"] for cell in plan["cells"] if cell["quartet"] == PILOT]
    expected = pilot + [cell["id"] for cell in plan["cells"] if cell["id"] not in pilot]
    require(schedule["execution_order"] == expected and schedule["pilot_cells"] == pilot,
            "Q38-first execution order changed")
    require(schedule["host_id"] == "m5" and schedule["gpu_ready"] is False
            and schedule["automatic_expansion"] is False, "no implicit hardware clearance")


def load_plan():
    verify_package()
    plan = read(ROOT / "plan.json")
    validate_selection(plan)
    matrix = engine()
    for model in plan["models"]:
        require(digest(ROOT / model["manifest"]) == model["manifest_sha256"], "model manifest changed")
        require(read(ROOT / model["manifest"])["aggregate_sha256"] == model["aggregate_sha256"],
                "model aggregate changed")
        for item in plan["workload_inputs"][model["label"]].values():
            require(digest(ROOT / item["input"]) == item["input_sha256"], "input changed")
            prepared = (json.dumps(read(ROOT / item["input"]), indent=2, sort_keys=True) + "\n").encode()
            require(hashlib.sha256(prepared).hexdigest() == item["prepared_input_sha256"],
                    "prepared input changed")
            require(digest(ROOT / item["canonical_plan"]) == item["canonical_plan_sha256"],
                    "canonical prompt changed")
    return plan, matrix


def identities(plan):
    return {model["label"]: {key: model[key] for key in ("model_id", "aggregate_sha256", "manifest_sha256")}
            for model in plan["models"]}


def review_record(matrix, record, status):
    value = read(matrix.verify_file(record))
    require(value.get("status") == status and value.get("review_id"), "missing exact review: " + status)
    return value


def verify_reviews(plan, matrix, binding):
    source = review_record(matrix, binding.get("source_review"), "QWEN_ONLY_SOURCE_REVIEWED")
    require(source.get("enabled_artifacts") == identities(plan), "source review artifact scope differs")
    matrix.verify_file(binding.get("runtime_source_manifest"))
    source_hash = binding["runtime_source_manifest"]["sha256"]
    require(source_hash != OLD_SOURCE, "historical GPT source cannot bind the new Qwen policy")
    require(source.get("runtime_source_manifest_sha256") == source_hash, "source review binding differs")
    runtime = review_record(matrix, binding.get("runtime_review"), "QWEN_ONLY_RUNTIME_REVIEWED")
    require(runtime.get("source_review_sha256") == binding["source_review"]["sha256"],
            "runtime/source review differs")
    require(isinstance(binding.get("binary"), dict) and isinstance(binding.get("resources"), dict),
            "runtime binary/resources unbound")
    require(runtime.get("binary_sha256") == binding["binary"].get("sha256"),
            "runtime binary review differs")
    require(runtime.get("resources") == {name: value["sha256"] for name, value in binding["resources"].items()},
            "runtime resource review differs")
    evidence = runtime.get("test_evidence")
    require(isinstance(evidence, dict) and {"native", "compiler"} <= set(evidence),
            "native/compiler test evidence unbound")
    for record in evidence.values():
        matrix.verify_file(record)
    require(runtime.get("tests_passed") is True, "native/compiler tests not accepted")


def verify_audit(plan, matrix, label, target):
    model = next(model for model in plan["models"] if model["label"] == label)
    require(target.get("assistant_directory") is None and target.get("directory") == model["model_directory_hint"],
            "exact model directory/inline assistant differs")
    require(target.get("live_identity_verified_for_this_run") is True, "live model identity unbound")
    audit = read(matrix.verify_file(target.get("identity_audit")))
    require(audit.get("model_id") == model["model_id"] and audit.get("directory") == target["directory"]
            and audit.get("manifest_sha256") == model["manifest_sha256"]
            and audit.get("aggregate_sha256") == model["aggregate_sha256"]
            and audit.get("all_manifest_file_hashes_verified") is True, "exact model audit differs")
    manifest = read(ROOT / model["manifest"])
    expected = {row["path"]: {"bytes": row["size_bytes"], "sha256": row["sha256"]} for row in manifest["files"]}
    actual = {name: {key: row.get(key) for key in ("bytes", "sha256")} for name, row in audit.get("files", {}).items()}
    require(actual == expected and audit.get("unmanifested_payloads") == [], "model file inventory differs")


def verified_binding(plan, matrix, path):
    binding = read(path)
    require(binding.get("state") == "reviewed", "source/runtime unbound: candidate is unreviewed")
    require(binding.get("host_id") == "m5" and binding.get("gpu_ready") is False,
            "M5 only; GPU readiness cannot be persisted or auto-promoted")
    require(set(binding.get("models", {})) == LABELS, "binding contains non-Qwen or missing artifacts")
    verify_reviews(plan, matrix, binding)
    binding = matrix.verified_bindings(path)
    order = read(ROOT / "schedule.json")["execution_order"]
    cleared = binding.get("reviewed_cell_ids", [])
    require(len(cleared) >= 3 and len(cleared) % 3 == 0 and cleared == order[:len(cleared)],
            "review must clear an exact Q38-first complete-triad prefix")
    for label in {cell["model"] for cell in plan["cells"] if cell["id"] in cleared}:
        verify_audit(plan, matrix, label, binding["models"][label])
    return binding


def select(plan, cohort=None):
    order = read(ROOT / "schedule.json")["execution_order"]
    by_id = {cell["id"]: cell for cell in plan["cells"]}
    cells = [by_id[name] for name in order if cohort is None or by_id[name]["quartet"] == cohort]
    require(bool(cells) and (cohort is None or len(cells) == 3), "unknown or out-of-scope Qwen cohort")
    return cells


def collect(plan, matrix, binding, cells):
    require(bool(cells) and all(cell in plan["cells"] for cell in cells), "out-of-scope collection")
    ids = {cell["id"] for cell in cells}
    require(cells == [cell for cell in select(plan) if cell["id"] in ids],
            "collection must preserve exact unique schedule order")
    scoped = dict(plan, pairs=[pair for pair in plan["pairs"] if {pair["baseline"], pair["candidate"]} <= ids])
    result = matrix.collect(scoped, binding, cells)
    errors = []
    previous_end = None
    for cell in cells:
        path = matrix.output_directory(binding, cell) / "metadata.json"
        if not path.exists():
            continue
        metadata = read(path)
        if metadata.get("matrix_binding_sha256") != binding["_binding_sha256"]:
            errors.append({"cell": cell["id"], "binding_hash_changed": True})
        start, end = metadata.get("started_unix"), metadata.get("ended_unix")
        if not all(type(value) in (int, float) and math.isfinite(value) for value in (start, end)):
            errors.append({"cell": cell["id"], "missing_process_times": True})
        elif end < start or (previous_end is not None and start < previous_end):
            errors.append({"cell": cell["id"], "scoped_order_changed": True})
        else:
            previous_end = end
    passed = (not errors and result["all_selected_supported_cells_accepted"])
    complete_triads = all(sum(cell["quartet"] == cohort for cell in cells) == 3
                          for cohort in {cell["quartet"] for cell in cells})
    result["completed_prefix_gates_passed"] = passed
    result["all_selected_supported_cells_accepted"] = passed and complete_triads
    result["qwen_matrix_accepted"] = passed and ids == {cell["id"] for cell in plan["cells"]}
    result["binding_and_order_errors"] = errors
    result["coverage"]["complete_six_model_scope"] = False
    result["coverage"]["complete_qwen_scope"] = len(ids) == 108
    for key in ("all_supported_matrix_cells_accepted", "all_matrix_requirements_accepted",
                "all_rollback_controls_accepted", "release_gates_satisfied"):
        result[key] = False
    if not passed:
        result["repeated_pair_summaries"] = []
    return result


def command(plan, matrix, binding, cell_id, ack_path):
    cells = select(plan)
    matches = [cell for cell in cells if cell["id"] == cell_id]
    require(len(matches) == 1, "unknown or out-of-scope cell; GPT/Gemma are deferred")
    ack = read(ack_path)
    require(ack.get("status") == "QWEN_EXECUTION_AUTHORIZED"
            and ack.get("binding_sha256") == binding["_binding_sha256"]
            and ack.get("only_cells") == binding["reviewed_cell_ids"] and ack.get("host_id") == "m5"
            and ack.get("review_id"), "exact ROOT execution acknowledgement missing")
    matrix.verify_file(ack.get("owned_controller_review"))
    require(cell_id in binding["reviewed_cell_ids"], "cell not cleared by ROOT")
    prior = cells[:cells.index(matches[0])]
    result_root = Path(binding["results_root"])
    require(not result_root.exists() or {path.name for path in result_root.iterdir()} == {cell["id"] for cell in prior},
            "result root is not the exact completed prefix; retain failed/unrelated attempts")
    if prior:
        require(collect(plan, matrix, binding, prior)["completed_prefix_gates_passed"],
                "prior cell/comparison failed or missing; dependent arm refused")
    return matrix.command(plan, binding, matches[0])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["status", "check-binding", "command", "collect"])
    parser.add_argument("--bindings", type=Path, default=ROOT / "bindings/m5.candidate.json")
    parser.add_argument("--cohort")
    parser.add_argument("--cell")
    parser.add_argument("--ack", type=Path)
    args = parser.parse_args()
    plan, matrix = load_plan()
    require(args.cohort is None or args.action == "collect", "--cohort applies only to collection")
    if args.action == "status":
        result = dict(read(ROOT / "schedule.json")["counts"], state=plan["state"], gpu_ready=False,
                      source_runtime_bound=False, execution_authorized=False,
                      pilot_cells=read(ROOT / "schedule.json")["pilot_cells"])
    else:
        binding = verified_binding(plan, matrix, args.bindings)
        if args.action == "command":
            require(args.cell and args.ack, "command requires exact --cell and separate --ack")
            result = {"argv": command(plan, matrix, binding, args.cell, args.ack),
                      "owned_execution_required": True, "gpu_ready": False, "launched": False}
        elif args.action == "collect":
            result = collect(plan, matrix, binding, select(plan, args.cohort))
        else:
            result = {"binding_verified": True, "execution_authorized": False, "gpu_ready": False}
    print(json.dumps(result, indent=2, sort_keys=True, allow_nan=False))
    return 1 if args.action == "collect" and not result["all_selected_supported_cells_accepted"] else 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, KeyError, TypeError) as error:
        raise SystemExit("REFUSED: " + str(error))
