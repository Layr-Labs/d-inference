from pathlib import Path
import hashlib,json,subprocess
out=Path(__file__).resolve().parent;candidate=Path('/Users/gaj/Documents/DarkbloomDev/wt/q36-attention-owner-identity');primary=Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(n,v):(out/n).write_text(json.dumps(v,indent=2)+'\n')
assert not (out/'manifest.json').exists()
roots={'parent':candidate,'native':candidate/'libs/mlx-swift-lm'}
review={};results=[]
for label,root in roots.items():
 names=subprocess.check_output(['git','diff','--name-only','--','.',':(exclude)libs/mlx-swift-lm'],cwd=root,text=True).splitlines() if label=='parent' else subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
 rows={}
 for name in names:
  before=subprocess.run(['git','show','HEAD:'+name],cwd=root,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  data=(root/name).read_bytes();rows[name]={'before_sha256':sha(before.stdout) if before.returncode==0 else None,'after_sha256':sha(data),'bytes':len(data)}
  target=out/'source'/label/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
  baseline=primary/name if label=='parent' else primary/'libs/mlx-swift-lm'/name
  assert (sha(baseline.read_bytes()) if baseline.exists() else None)==rows[name]['before_sha256'],name
 patch=subprocess.check_output(['git','diff','--binary','--',*names],cwd=root)
 (out/(label+'.patch')).write_bytes(patch)
 for command,cwd,logname in [(['git','diff','--check'],root,label+'-diff-check.log'),(['git','apply','--check',str(out/(label+'.patch'))],primary if label=='parent' else primary/'libs/mlx-swift-lm',label+'-apply-check.log')]:
  r=subprocess.run(command,cwd=cwd,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(out/logname).write_bytes(r.stdout);results.append({'command':command,'cwd':str(cwd),'exit_code':r.returncode,'log':logname});assert r.returncode==0
 review[label]={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'files':rows}
assert len(review['native']['files'])==5 and len(review['parent']['files'])==1
write('source-proof.json',review);write('checks.json',results)
(out/'REVIEW.md').write_text('The actual contiguous Q36 metadata run exposed a diagnostic identity defect: its production adapter constructs cache.layerIndex as model indices 3,7,...39, while the metadata state expected dense storage indices 0...9. Paged caches already expose dense indices. This patch registers each bound cache object with its explicit position and expected kind from the engine\'s ordered arrays, then records that dense storage identity and the original model identity separately. It never changes cache.layerIndex, cache construction, attention arithmetic, evaluation or sample lifecycle.\n\nBinding refuses unbound cache objects, wrong kinds/indices, repeated cache objects, repeated dense storage slots and repeated attention calls. The existing metadata fixtures now register owners explicitly and retain the ten bound caches for the binding lifetime. New native tests cover dense/original identity equivalence plus refusal cases. A provider test uses the real Qwen35MoE model, ProductionModelAdapter and contiguous preparation path with forty transformer layers / ten full owners; it compares unobserved and observed outputs and expects all ten dense/original owner identities.\n\nOnly source checks have run: both diff checks and apply checks against the current primary source passed. New and modified Swift tests remain UNRUN while another agent owns the Swift lane. Planned suites: CBv2AttentionOwnerIdentityTests, CBv2AttentionMetadataTests, CBv2OrdinaryAttentionMetadataTests, and AttentionMetadataProductionOwnerTests. Preserve the original real-run failure as baseline evidence; this source freeze does not claim a corrected real-model capture. Raw packet work remains isolated and excluded.\n')
write('verdict.json',{'status':'SOURCE_ONLY_AWAITING_REVIEW_AND_SWIFT_VALIDATION','native_files':5,'parent_files':1,'default_runtime_changed':False,'cache_indices_or_backend_arithmetic_changed':False,'packet_candidate_included':False,'new_native_test_functions':3,'new_native_expanded_cases':4,'new_provider_test_functions':1,'swift_tests_run':False,'model_runs':False})
files={str(p.relative_to(out)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(out.rglob('*')) if p.is_file() and p.name!='manifest.json'}
write('manifest.json',{'schema':1,'status':'SOURCE_ONLY_AWAITING_REVIEW','files':files})
print(json.dumps({'manifest':str(out/'manifest.json'),'sha256':sha((out/'manifest.json').read_bytes()),'payloads':len(files),'sources':{k:len(v['files']) for k,v in review.items()}},indent=2))
