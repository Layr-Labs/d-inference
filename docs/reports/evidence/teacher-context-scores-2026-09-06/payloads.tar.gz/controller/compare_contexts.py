"""Describe backend differences on identical forced contexts; introduce no numerical gate."""
from pathlib import Path
import argparse
import json
import struct

from common import ROOT, digest, identity, local_path, read_json, require
from controller import command, environment, plan_inputs
from runtime_identity import runtime_files
from validation import check_previous


def float32(bits):
    return struct.unpack('!f', struct.pack('!I', bits))[0]


def compare_reports(model, input_value, contiguous, paged):
    reports = {'contiguous': contiguous, 'paged': paged}
    for backend, report in reports.items():
        require(report['input'] == input_value and report['inputSHA256'] == model['input_sha256'], 'backend forced input differs')
        require(report['resolvedBackend'] == backend, 'backend identity differs')
        require(len(report['diagnostic']['records']) == model['continuation_tokens'], 'backend record count differs')
    rows = []
    for index, forced in enumerate(input_value['continuation']):
        left, right = (reports[backend]['diagnostic']['records'][index] for backend in ('contiguous', 'paged'))
        expected = (index, model['prompt_tokens'] + index, forced)
        for record in (left, right):
            require(tuple(record[key] for key in ('index', 'contextLength', 'forcedToken')) == expected, 'backend forced context differs')
        rows.append({'index': index, 'contextLength': expected[1], 'forcedToken': forced,
                     'contiguous_argmax': left['argMaxID'], 'paged_argmax': right['argMaxID'],
                     'argmax_equal': left['argMaxID'] == right['argMaxID'], 'complete_record_equal': left == right,
                     'contiguous_nll_bits': left['nllBits'], 'paged_nll_bits': right['nllBits'],
                     'paged_minus_contiguous_nll': float32(right['nllBits']) - float32(left['nllBits']),
                     'contiguous_forced_log_probability_bits': left['forcedLogProbabilityBits'],
                     'paged_forced_log_probability_bits': right['forcedLogProbabilityBits'],
                     'paged_minus_contiguous_forced_log_probability': float32(right['forcedLogProbabilityBits']) - float32(left['forcedLogProbabilityBits'])})
    return {'model_id': model['model_id'], 'input_sha256': model['input_sha256'],
            'prompt_tokens': model['prompt_tokens'], 'continuation_tokens': model['continuation_tokens'],
            'same_forced_contexts': True, 'argmax_mismatch_indices': [row['index'] for row in rows if not row['argmax_equal']],
            'complete_record_equal_count': sum(row['complete_record_equal'] for row in rows),
            'mean_forced_token_nll': {backend: report['meanForcedTokenNLL'] for backend, report in reports.items()},
            'control_activity': {backend: report['activity'] for backend, report in reports.items()},
            'records': rows}


def collect_comparison(root, plan, binding, binding_sha):
    require(binding.get('state') == 'peer_reviewed', 'final root-reviewed execution binding required')
    require(binding['plan_sha256'] == digest(root / 'plan.json'), 'comparison plan differs')
    require(str(root.resolve()) == str(Path(binding['execution_root']).resolve(strict=True)), 'comparison execution root differs')
    artifact = runtime_files(binding)
    reports, evidence = {}, {}
    for cell in plan['cells']:
        output = root / 'results' / cell['id']
        model = plan['models'][cell['model']]
        check_previous(root, plan, cell, binding, binding_sha,
                       command(artifact, model, cell, output), environment(plan, output))
        reports[cell['id']] = read_json(output / 'report.json')
        evidence[cell['id']] = {'summary': identity(output / 'summary.json'), 'report': identity(output / 'report.json')}
    models = {name: compare_reports(model, read_json(root / model['input']), reports[name + '-contiguous'], reports[name + '-paged'])
              for name, model in plan['models'].items()}
    return {'schema': 1, 'status': 'observed', 'scope': 'same_forced_context_backend_comparison',
            'interpretation': 'Descriptive observations only; no numerical threshold, release predicate or performance claim is introduced.',
            'binding_sha256': binding_sha, 'plan_sha256': binding['plan_sha256'], 'runtime_source': binding['runtime']['source'],
            'all_four_existing_validity_checks_passed': True, 'models': models, 'cell_evidence': evidence}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binding', type=Path, required=True)
    parser.add_argument('--binding-sha256', required=True)
    parser.add_argument('--output', default='comparison.json')
    arguments = parser.parse_args()
    require(digest(arguments.binding) == arguments.binding_sha256, 'comparison binding hash differs')
    output = local_path(ROOT, arguments.output)
    require(not output.exists() and not output.is_symlink(), 'comparison output already exists')
    value = collect_comparison(ROOT, plan_inputs(), read_json(arguments.binding), arguments.binding_sha256)
    with output.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({'status': value['status'], 'output': str(output), 'runtime_launched': False}))


if __name__ == '__main__':
    main()
