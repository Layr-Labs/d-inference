# Review contract and owned execution

This is a handoff, not an installed controller or an inference authorization.
Main owns policy and runtime build integration. The executor owns M5 exclusively.

## Separate reviewed binding (do not edit candidate/package)

All file records are absolute `{path, sha256}` records; executable/resource records
retain modes. `matrix_cells.verified_bindings` checks the package, source manifest,
executable/resources, storage floor, Python, profile and result root. The scoped
wrapper adds exact Qwen scope, source/runtime review and full file-audit checks.

1. Reuse the unchanged reviewed runtime100 source35fea/nativef2 artifact under
   a new Main B4 scope/binding review. Record exact source dependency graph and
   hashes; test native B1/B2/B4 forward telemetry and compiler integration. Bind
   `runtime_source_manifest`, `binary` and **all** frozen required resources.
2. `source_review`: JSON with nonempty `review_id`, status
   `QWEN_ONLY_SOURCE_REVIEWED`, `runtime_source_manifest_sha256` and
   `enabled_artifacts` exactly equal to `scope-change.json:enabled_exact_artifacts`.
   The review must establish Qwen-only production eligibility, no silent fallback,
   normal MTP and unchanged production grant; no policy implementation is here.
3. `runtime_review`: JSON with nonempty `review_id`, status
   `QWEN_ONLY_RUNTIME_REVIEWED`, `source_review_sha256`, `binary_sha256`,
   `resources` (resource-name -> SHA256), `tests_passed: true`, and `test_evidence`
   containing at least `native` and `compiler` file records. Review the actual
   passing logs and source-to-binary build provenance, not just status booleans.
4. Bind this `manifest.json`, new absolute empty results root, reviewed storage
   retention policy (>100 GiB and the helper's 5% volume/20 GiB floor), macmon and
   Python identities, exact seven-key profile, `host_id: m5`, `gpu_ready: false`,
   `state: reviewed`, `review_id`, and exactly the pilot IDs in `reviewed_cell_ids`.
   Future scope is an explicitly reviewed complete-triad schedule prefix, never
   automatic. A changed binding needs a new result root and its own full prefix;
   it cannot import old pilot metadata under a different binding hash. Retain the
   earlier pilot separately; repeat it only under that new explicit review.
   Maintain all three exact Qwen model records; live audit is required
   only for models cleared in that binding.
5. For each cleared model, hash **every** manifest file using the manifest already
   present here; check the exact directory/snapshot, inline assistant, config,
   tokenizer/template/index and weights. Reject unmanifested payloads and mutation
   during reading. Set `live_identity_verified_for_this_run: true` and bind an audit
   with `model_id`, `directory`, `manifest_sha256`, `aggregate_sha256`,
   `all_manifest_file_hashes_verified: true`, `unmanifested_payloads: []`, and
   `files` mapping each exact relative filename to at least `{bytes, sha256}`.
   Include inode/device/mtime/resolved-path before/after evidence for execution.
6. ROOT separately acknowledges the **final binding hash** in an external JSON:
   `status: QWEN_EXECUTION_AUTHORIZED`, nonempty `review_id`, `binding_sha256`,
   `host_id: m5`, `only_cells` exactly matching binding order, and
   `owned_controller_review: {path, sha256}`. The latter binds the separately
   reviewed controller, live-ownership grant and retirement contract. ACK is
   passed via `--ack`, not hashed into its own binding (avoid a hash cycle).

The old GPT source/build/ack cannot serve as new Qwen policy review. The historical
audit hash hints in the candidate are not fresh execution audit records.

## Reuse ownership, not hardcoded GPT launch scripts

`ownership/owner_helper.py` and `ownership/tracked_runner.py` are byte-identical
copies from `/private/tmp/darkbloom-forward-width-gpt-b2-pilot1`. Its
`remote_pilot2.py` is the inspected controller reference, **not copied or invoked**:
it embeds GPT IDs, hashes, paths, continuation state and earlier report reuse.
Do not import/run that script for Qwen. No SSH/staging/controller shortcut exists
in this package. A separately reviewed Qwen driver should reuse the helpers:

- Maintain a foreground control pipe with a 30-second lease; explicit ping/stop,
  EOF, signals, disconnect, deadline and prelaunch cancellation must retire only
  owned groups. Keep driver, wrapper, native and telemetry PID/PGID/birth/argv
  records and terminal proof. Detached children need the tracking wrapper and
  controller cleanup by verified birth/ownership, not process-name killing.
- A machine-readable exclusive M5 grant is required. Fresh `observe` +
  `entry_refusal` checks Mac17,6 / 137438953472 bytes, finite GPU <=42 C, load <=4,
  disk floor and no foreign/already-owned workers **before every cell**. Bounded
  thermal/load waiting may re-observe; no cached readiness or auto-ready flag.
  No M3 work, SSH/build here, resident bank, inherited debug toggles or extra job.
- Revalidate package/review/binding hashes and exact ROOT ACK immediately before
  every spawn. Preserve the emitted `env -i` argv and timeouts. Inject only the
  reviewed detached-child tracker around the frozen runner, not measurement flags.
- Rehash the exact model inventory before/after each cell (including failure),
  compare stable stat identities, and refuse changed data. Recheck immutable
  input/package/runtime files before/after; no model substitution or new token
  baseline. Input date is checked per cell. Stage a frozen read-only payload in
  the reviewed execution root and deny concurrent writers; hash checks alone
  are not a substitute for excluding writers during the spawn/measurement window.
- After cell 1, require its strict integrity, overlap and actual B4 width, but do
  not fail merely because future pair endpoints do not exist. After cell 2,
  require the backend edge. After cell 3, require the cache edge and full triad.
  Any failure gates dependent work. Do not repeat for performance after mismatch.
- Retain original report/metadata, full tokens, inputs, telemetry, comparisons,
  commands, review hashes, entry samples, model before/after and retirement proof.
  Never overwrite a failed root, auto-prune storage or borrow a previous arm.
  Return the three reports and two comparisons to ROOT before any expansion.

The CLI provides CPU gate checks/argv/collection only. Completing this ownership
adapter and its review is explicitly still needed for owned execution; no helper
copy, status result or successful CPU test grants a physical lane.

This successor clears only the three fresh Q38 retained B4 arms. B2 proof is a
checked prerequisite, not a reusable common arm. Cap 128 and natural EOS remain.
All runtime/path/ownership fields in the prepared candidate remain unbound.
