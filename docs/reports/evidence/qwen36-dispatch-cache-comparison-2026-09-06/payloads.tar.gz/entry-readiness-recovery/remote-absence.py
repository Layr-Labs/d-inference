from pathlib import Path
import json
p=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-q36-paged-plan-cache-comparison1/runs/qwen36-paged-mtp-off-candidate-rep3')
assert not p.exists()
print(json.dumps({'remote_output_absent':True,'root':str(p)}))
