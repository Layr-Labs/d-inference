# Corrected Gemma QAT normal-generation results

All seven sequential M5 processes completed with valid terminal, postflight, collection and local integrity receipts. M5 is released to ROOT. The complete comparison returned exit code 2 because automatic generation still fails exact equality with ordinary generation on both backends.

Paged/contiguous equality passes in each of the three tested modes across all seven complete trajectories. Serial target equals ordinary on both backends. Automatic differs from ordinary at zero-based token index 30 (ordinary 795, automatic 735) in every trajectory. The projection cell matches its paged automatic control across all seven trajectories.

| Cell | Tool session | Native PID | Telemetry PID | Main output | Selected rounds per main |
|---|---:|---:|---:|---|---|
| gemma-qat4-contiguous-off-b1-output128 | 74173 | 44594 | 44593 | Both 61 tokens, stop | 0 rectangular / 0 serial |
| gemma-qat4-contiguous-automatic-b1-output128 | 85307 | 44935 | 44934 | Both 61 tokens, stop | 34 rectangular / 0 serial |
| gemma-qat4-contiguous-serial-target-b1-output128 | 16372 | 45223 | 45222 | Both 61 tokens, stop | 0 rectangular / 34 serial |
| gemma-qat4-paged-off-b1-output128 | 31144 | 45585 | 45584 | Both 61 tokens, stop | 0 rectangular / 0 serial |
| gemma-qat4-paged-automatic-b1-output128 | 67024 | 45924 | 45923 | Both 61 tokens, stop | 34 rectangular / 0 serial |
| gemma-qat4-paged-serial-target-b1-output128 | 13692 | 46265 | 46264 | Both 61 tokens, stop | 0 rectangular / 34 serial |
| gemma-qat4-paged-projection-529-62203 | 36929 | 46603 | 46602 | Both 61 tokens, stop | 34 rectangular / 0 serial |

All fourteen main prompts used the same retained 5,418-token arrays, input SHA `1abb54db891314531df0b6ddfbe3cc3418c29fd014133cdf3837133c9e9a3080`, B1, cache off, production grant and output cap 128. All original serving-profile keys, budgets, dtype and acceptance rules remained bound. Every process used normal generation. No dev/shared-dev/prod action, teacher run, local GPU run or local Swift build was performed.

Final M5 postflight: no owned or unexpected processes, GPU 33.91666793823242°C, load1 1.83984375. The seventh tool session 36929 exited 0 after collection; generation had separately exited 0 as PID 46603 with process-group cleanup complete.

## Projection and arithmetic revision

Official corrected Q/K/V first-column mismatch counts are 1/0/0, versus old 2509/1251/1449. Q[1914] differs by 7.62939453125e-6; K and V are exact. Embedding and normalized inputs are exact across widths. All six full Q/K/V tensors match the independently reviewed corrected M3 replay byte-for-byte. The ten parameter descriptors match the old capture. The promoted-bias arithmetic is reproduced by the official staged runtime; kernel names remain uninstrumented.

Old→corrected contiguous ordinary changes index30 735→795, while automatic changes index30 795→735. Old→corrected paged automatic changes its first differing coordinate at index7 62203→42392 and grows from 38 to 61 main tokens. Complete before/after arrays and finish reasons are preserved in `corrected-complete-comparison.json`; these cross-revision comparisons are descriptive, not equality requirements.

## Runtime handoff

ROOT may reuse the already staged immutable runtime at `/Users/gaj/autoresearch/radix-prefix-cache/090-gemma-qmv-corrected-controls1/runtime` for its separate two-host validation. The full runtime identities remain:

- c: `d4328f2d8d54d711d5419e07ab9fa2f07b512a48`
- core: `fab0f39f69140393b454c32d6f4bf7a9b32f9dcc`
- native: `de30ef9892cbd247b219cfde891f180ffbf5f47a`
- parent: `53f3c3d0c0d0a09f4d89fe4346aa72ebdecbe4e6`
- swift: `c06149b4f7defa1b958c1e175f6c9a12c86c8a4f`

- CLI SHA: `14e40ee78bbabab31a69616fe2f2f631768812ed71cba97a463c0072ff6dbe9d`
- Probe SHA: `c0badb1908b6801273d3a9440174c9ba2b7fc9a269b6d31afa4d2c18eccf914c`
- Metallib SHA: `1c8e612c9c54e8652669c582aad6124438c77f1dce2dc0b1eb50dce1bf083565`
- Package SHA: `bf33caa41d54916d3a30114060be91ccebba2b7364402c55ab734e4abeb271b0`

## Retained evidence

`actual-model-results.json` summarizes all process handles, terminal/cleanup observations, per-main positive selected rounds and all seven trajectory comparisons. `corrected-complete-comparison.json` preserves full token arrays and finish reasons. `projection-native-byte-validation.json` verifies tensors and CPU reference metrics. `remaining-cause-diagnosis.md` separates observed facts, plausible causes and missing same-state logit evidence. `analyze_captures.py` reproduces local capture analysis with `/tmp/darkbloom-attention-packet-analysis-venv1/bin/python -B`.

The frozen old failure evidence remains intact and was revalidated. No throughput ratio or whole-model success claim is made. No M5 action remains for this agent.
