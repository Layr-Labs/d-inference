# Preserve measured SSD restore cost across Ready refreshes

Source and Go verification report, 2026-09-05. Isolated worktree `wt/cache-stage-measurement`, base `02f6af71a5a972a655608f3fa6063d47670c3878`. Four coordinator production paths, one regression test file, canonical cache-routing documentation and changelog. No provider/wire/config/default changes, primary edits, Swift/Metal/model execution or network latency claim.

## Problem and resulting behavior

An accepted SSD lookup supplies measured external restore time. A later valid Ready supplies only an estimated read time, but previously overwrote that same holder's measured value. With a 4,096-token endpoint on a 5,000-token/s provider, overwriting a measured 900 ms read with a 100 ms estimate could choose the SSD provider instead of the 4,800-token/s cold peer. The inverse also rejected a useful measured 100 ms hit when Ready estimated 900 ms. Both winner reversals are reproduced through validated request-bound receipts and real `ReserveProviderEx`.

The holder retains an optional immutable `cacheStageMeasurement`: observed milliseconds, the original lookup's expiry, and its exact advertised capability. A valid positive SSD hit creates a new sample. Ready updates the fallback estimate and holder availability; it preserves the sample only when the keyed bucket, provider connection pointer, exact anchor, recompute count and capability still match and both old holder and sample are fresh. It cannot extend the original measurement deadline. No sample is created by memory receipts, policy/capacity outcomes or Ready alone.

The query captures one timestamp in each `cacheRoutingMatch`, validates the current capability, then resolves the measured cost if unexpired or the latest Ready estimate otherwise. The resulting numeric hint is immutable through scan/reservation. Query also rejects an attached sample whose capability differs from the current one, even if the sample has expired: before a new valid receipt, the fallback may itself belong to the old lookup/contract. This handles the existing interval between capability publication and tracker cleanup without adding locks. A new current-capability Ready drops the mismatched sample and establishes a valid estimate.

```mermaid
flowchart LR
    L[Validated SSD hit] --> M[Measurement with fixed lookup expiry]
    M --> R[Later Ready refresh]
    R --> C{Same live holder and capability?}
    C -->|yes| K[Retain immutable measurement and latest estimate]
    C -->|no| E[Use new receipt estimate only]
    K --> Q{Sample fresh at query time?}
    Q -->|yes| O[Measured stage cost]
    Q -->|no| E
```

All ownership is inside existing holder lifetime/maps. No global measurement cache, timer, mutable shared sample or new synchronization is introduced. There is one sample allocation per validated positive SSD lookup; Ready refreshes reuse its immutable pointer. Normal TTL, definitive miss, eviction, connection/capability invalidation and configuration-generation replacement retire it. Full N admission, ordinary TTFT eligibility, queue/decode costs and positive-benefit caps remain unchanged.

## Wire scope

There is one StageMs scalar per Ready message; a multi-anchor message therefore carries one estimate for all endpoints. Current complete SSD publication computes the maximum committed file's fixed-rate estimate and sends cumulative anchors, so unmeasured shorter endpoints remain conservatively priced at that maximum.

A wire expansion is **not inherently required** to price endpoints separately: ordered singleton Ready messages, with increasing final anchor and sequence, can each carry their own StageMs. Existing `TestCacheServiceCostPricesProviderAlignedLongestCheckpoint` already accepts exactly that pattern. However, provider `PrefixCacheEvidenceSequencer.handleReady` currently coalesces pre-lookup publications to the furthest result. Merely splitting the producer's cumulative message could drop earlier proofs. A correct provider follow-up would preserve bounded per-endpoint pending evidence and ordered delivery. That follow-up is outside this coordinator-only slice. This clarifies the earlier release audit's overly strong suggestion that per-endpoint pricing would require a protocol change; its frozen artifacts are preserved.

## Regression coverage

The new test file uses production Prepare and validated receipt handlers with injected receipt/query times; it does not fabricate measured-holder fields.

- Both measured-cost overwrite directions and actual routing winner consequences.
- Multiple Ready refreshes, exact measurement deadline, latest fallback estimate, and normal holder expiry.
- A later valid lookup replaces both sample and expiry.
- Earlier/later endpoint separation.
- Epoch/mode changes, distinct connection objects, configuration generation replacement, tenant scope, legacy recompute differences, definitive miss, eviction and expired holder.
- Concurrent Ready/query and frozen-query observation.
- Same-epoch capability publication before tracker cleanup, for fresh **and expired** attached samples; current Ready positive controls.

Final exact counts and commands are in `verification.json`. The final full registry/API/protocol and broad cache/checkpoint/SSD/API race suites must pass; baseline and superseded-draft failures are retained as negative controls, not included as candidate passes.

Root source review found the query-before-cleanup gap after the first draft passed its narrower tests. `review1/` preserves those exact seven source files. Applying the final regression to that draft fails both fresh/expired subcases. The final candidate moves resolution after capability binding. Initial command working-directory mistakes and a fixture using a key-redacted config snapshot are also retained; the corrected fixture uses an explicit test key. No failure evidence is discarded or presented as successful acceptance.

## Integration

Apply `source.patch` over the stated base or a coordinator-identical later parent; root's `06b02df7a` changes capacity documentation only. The changed canonical cache-routing page has no known concurrent overlap. Use exact patch payloads and hashes, not whole older-base provider/source copies. No commits were created in this lane; root owns the reviewed milestone bank.
