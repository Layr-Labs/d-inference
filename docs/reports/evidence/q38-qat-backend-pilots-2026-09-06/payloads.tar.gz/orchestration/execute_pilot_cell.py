"""Execute exactly one reviewed pilot argv and retain operational evidence."""
from datetime import datetime, timezone
import json, os, re, shutil, signal, subprocess, sys, time
from pathlib import Path
ROOT=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-q38-qat-backend-pilots1')
sys.path.insert(0,str(ROOT)); import pilot_cells as pilot
m=pilot.matrix
cell_id=sys.argv[1]
plan=pilot.load_plan(); binding=m.verified_bindings(ROOT/'bindings.reviewed.json')
pilot.require_owned_results_root(binding)
assert m.sha256(ROOT/'bindings.reviewed.json')=='073dbc2123892971a4581c66a7abeeb5276fd749b639fa0756e0d4d253d23f28'
cell=next(c for c in plan['cells'] if c['id']==cell_id)
index=plan['cells'].index(cell)
for prior in plan['cells'][:index]:
 directory=m.output_directory(binding,prior)
 assert m.cell_status(binding,prior)=='completed_unvalidated','Prior cell not completed; stop for review'
 assert not m.cell_evidence_errors(plan,binding,prior,m.read(directory/'report.json'),m.read(directory/'metadata.json')),'Prior integrity failure; stop for review'

def processes():
 lines=subprocess.check_output(['ps','-axo','pid=,ppid=,command='],text=True).splitlines()
 return [line.strip() for line in lines if re.search(r'Runner\.Worker|benchctl measure-job|measure-job\.sh|(^|/)radix-engine( |$)|run_radix_engine\.py|run_radix_http\.py|(^|/)darkbloom( |$)|macmon pipe',line)]

def snapshot():
 active=processes()
 raw=subprocess.check_output(['/Users/gaj/bench-runner/bin/macmon','pipe','-s','1','-i','200'],text=True,timeout=10)
 space=shutil.disk_usage(ROOT)
 caches=[directory for directory in (ROOT/'runs').glob('*/prefix-cache')] if (ROOT/'runs').exists() else []
 return {'utc':datetime.now(timezone.utc).isoformat(),'unix_time':time.time(),'processes':active,
  'gpu_temp_c':json.loads(raw.splitlines()[0])['temp']['gpu_temp_avg'],'load':os.getloadavg(),
  'free_disk_bytes':space.free,'total_disk_bytes':space.total,
  'owned_cache_payload_bytes':sum(p.stat().st_size for d in caches for p in d.rglob('*') if p.is_file())}

def write_new(path,value):
 with path.open('x') as stream:json.dump(value,stream,indent=2); stream.write('\n')

ready=snapshot()
assert not ready['processes'] and ready['gpu_temp_c']<=42 and ready['load'][0]<=4,'Dedicated host readiness failed'
argv=m.command(plan,binding,cell)
preview=next(c for c in m.read(ROOT/'command-preview.json')['commands'] if c['cell']==cell_id)
assert argv==preview['argv'],'Reviewed argv changed'
write_new(ROOT/('readiness-'+cell_id+'.json'),ready)
print(json.dumps({'phase':'ready','cell':cell_id,**ready}),flush=True)
child=None

def interrupted(signum,frame):
 if child is not None and child.poll() is None:
  os.killpg(child.pid,signal.SIGTERM)
  child.wait(timeout=15)
 raise SystemExit(128+signum)
for sig in (signal.SIGTERM,signal.SIGHUP,signal.SIGINT):signal.signal(sig,interrupted)
with (ROOT/('wrapper-'+cell_id+'.log')).open('x') as log:
 child=subprocess.Popen(argv,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 write_new(ROOT/('launch-'+cell_id+'.json'),{'cell':cell_id,'argv':argv,'wrapper_pid':child.pid,'started_unix':time.time()})
 print(json.dumps({'phase':'running','cell':cell_id,'wrapper_pid':child.pid}),flush=True)
 last=0
 while child.poll() is None:
  if time.monotonic()-last>=15:
   last=time.monotonic()
   report_path=m.output_directory(binding,cell)/'report.json'
   status={'phase':'progress','cell':cell_id,'wrapper_pid':child.pid,'report_exists':report_path.exists()}
   if report_path.exists():
    try:
     report=m.read(report_path)
     status.update(status=report.get('status'),rows=[{'id':r.get('id'),'completion_tokens':r.get('completion_tokens'),'ttft_s':r.get('ttft_s')} for r in report.get('rows',[])])
    except (OSError,ValueError):status['report_read_pending']=True
   print(json.dumps(status),flush=True)
  time.sleep(1)
print(json.dumps({'phase':'wrapper_finished','cell':cell_id,'exit_code':child.returncode}),flush=True)
collection=pilot.collect(plan,binding)
write_new(ROOT/('collection-after-'+cell_id+'.json'),collection)
post=snapshot(); write_new(ROOT/('postflight-'+cell_id+'.json'),post)
current=next(c for c in collection['cells'] if c['id']==cell_id)
print(json.dumps({'phase':'postflight','cell':cell_id,'cell_evidence':current,'process_order_errors':collection['process_order_errors'],'host':post,
 'evaluated_comparisons':[{'id':p['id'],'passed':p['passed'],'errors':p.get('errors')} for p in collection['comparisons'] if p['state']=='evaluated']}),flush=True)
assert child.returncode==0,'Failed wrapper; stop for root review'
assert current['state']=='cell_integrity_pass_comparisons_pending','Failed cell integrity; stop for root review'
assert not post['processes'] and not collection['process_order_errors'],'Postflight or process ordering failed; stop for review'
print(json.dumps({'phase':'cell_integrity_pass','cell':cell_id}),flush=True)
