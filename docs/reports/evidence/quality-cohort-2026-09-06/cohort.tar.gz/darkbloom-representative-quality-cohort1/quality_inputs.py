"""Strict loader for the real frozen payloads; input validation never claims quality."""
from collections import Counter
from pathlib import Path
import hashlib
import struct

from cohort_common import checked, digest, local_path, read_json, require, token_digest
from corpus_cases import build
from prepare_payloads import continuation_start

FLEET = {
    'qwen36': ('qwen3.6-35b-a3b-vl-mtp-mxfp8', 'd932e96b00404b0575fff47e2dac8ed113056b3f22d0040c3c8d3f9ef25b09ed'),
    'qwen35': ('qwen3.5-35b-a3b', '95811153b3bb2ed78bf44b3248b07b52fce637706107de8b0fddf21796ade01c'),
    'qwen38': ('EigenLabs/Qwen3.8-27B-4bit-mtp', 'bbd0e0adcfe74e095073fefd0b9e116e4311d606ad9989cf81f8175e8ac18463'),
    'gpt-oss-20b': ('gpt-oss-20b', '61bfc04e4016a7fa487eb10e29f79360047e302487229f298da3681984aec512'),
    'gemma-4-26b': ('gemma-4-26b', 'a4722b6020adb1894c700b45ddcd58bc0e0f033abe7139f86cbbbfe60cba4eb6'),
    'gemma-4-26b-qat-4bit': ('gemma-4-26b-qat-4bit', '2468a0cb3049a871f42052f4d9f9380bf12a0792f64c7a29f768559fc7d28785'),
}
SOURCE_SHA = '252ccfb94c7fa8c47a9eb35214e7e5e187d945b2'


def validate_coverage(models, cases, records):
    require({model['label'] for model in models} == set(FLEET) and len(models) == 6, 'six exact fleet artifacts required')
    for model in models:
        require((model['model_id'], model['aggregate_sha256']) == FLEET[model['label']], 'fleet model identity differs')
        require(model['normal_mtp'] is (model['label'] != 'gpt-oss-20b'), 'normal fleet MTP posture differs')
        if model['label'].startswith('gemma-4-26b'):
            require(model['assistant']['aggregate_sha256'] == 'd8c5fae1f4b7a07376c9f0b92f3ec283ba276d57ec3b675d8cf758a79d73bd34', 'Gemma assistant identity differs')
        else:
            require(model['assistant'] is None, 'unexpected external assistant')
    require(len(cases) == len({case['id'] for case in cases}) == 12, 'twelve unique logical cases required')
    require(Counter((case['domain'], case['length']) for case in cases) ==
            Counter({(domain, length): 2 for domain in ['prose', 'code', 'reasoning'] for length in ['short', 'long']}),
            'domain/length strata differ')
    expected = {(model['label'], case['id']) for model in models for case in cases}
    require(len(records) == 72 and {(row['model'], row['case_id']) for row in records} == expected,
            'complete unique model/case coverage required')
    for case in cases:
        require(case['reference_text'] not in case['prompt_text'], 'reference leaked into serving prompt')
        if case['domain'] == 'reasoning':
            require(case['selection']['target_row'] not in case['selection']['demonstration_rows'], 'target used as demonstration')


def validate_plan_tokens(tokens, plan, contract, scope):
    require(plan['prompt_contract_id'] == contract and plan['prompt_token_count'] == len(tokens), 'canonical token count/contract differs')
    parent, boundaries = bytes(32), []
    field = lambda value: len(value).to_bytes(4, 'big') + value
    for index in range((len(tokens)-1)//256):
        block = tokens[index*256:(index+1)*256]
        encoded = (b'darkbloom.prefix-block-chain.v1' + field(contract.encode()) + field(scope.encode())
                   + parent + index.to_bytes(4, 'big') + b''.join(struct.pack('>I', value) for value in block))
        parent = hashlib.sha256(encoded).digest()
        boundaries.append({'token_count': (index+1)*256, 'chain_hash': parent.hex()})
    require(plan['block_boundaries'] == boundaries, 'canonical complete-block hash differs')
    require(plan['last_complete_block_hash'] == (parent.hex() if boundaries else None), 'canonical final complete-block hash differs')


def contract_id(contract):
    field = lambda value: len(value).to_bytes(4, 'big') + value
    artifacts = sorted(contract['artifacts'], key=lambda row: (row['role'], row['path'], row['sha256']))
    value = field(b'darkbloom.prompt-contract.v1') + len(artifacts).to_bytes(4, 'big')
    for row in artifacts:
        value += field(row['role'].encode()) + field(row['path'].encode()) + field(bytes.fromhex(row['sha256']))
    for name in ['normalization', 'renderer', 'tokenizer', 'block_hash']:
        value += field(name.encode()) + field(contract['versions'][name].encode())
    value += field(b'block_size') + contract['versions']['block_size'].to_bytes(4, 'big')
    return hashlib.sha256(value).hexdigest()


def load_payload(root, record, model, case, prompt_date):
    require((record['domain'], record['length'], record['source_sha256']) ==
            (case['domain'], case['length'], case['source_sha256']), 'case source/stratum attribution differs')
    serving = read_json(checked(root, record['serving']), maximum=1 << 20)
    teacher = read_json(checked(root, record['teacher']), maximum=1 << 20)
    canonical = read_json(checked(root, record['canonical']))
    require(isinstance(canonical['reference_full_token_ids'], list) and 1 <= len(canonical['reference_full_token_ids']) <= 32768,
            'canonical reference token bound differs')
    require(set(teacher) == {'modelID', 'expectedModelAggregateSHA256', 'promptTokens', 'continuation'}, 'teacher input schema differs')
    require(teacher['modelID'] == model['model_id'] and teacher['expectedModelAggregateSHA256'] == model['aggregate_sha256'], 'teacher identity differs')
    prompt, continuation = teacher['promptTokens'], teacher['continuation']
    require(isinstance(prompt, list) and isinstance(continuation, list) and 1 <= len(prompt) <= 32768 and len(continuation) == 64,
            'teacher token bounds differ')
    all_tokens = prompt + continuation + canonical['reference_full_token_ids']
    require(all(type(token) is int and 0 <= token < model['vocabulary_size'] for token in all_tokens), 'invalid token ID')
    require(prompt == canonical['prompt_token_ids'] and continuation == canonical['continuation_token_ids'], 'teacher/canonical token identity differs')
    require(canonical['model'] == model['label'] and canonical['case_id'] == case['id']
            and canonical['prompt_contract_id'] == model['prompt_contract_id'], 'canonical case/model differs')
    start, alignment = continuation_start(prompt, canonical['reference_full_token_ids'], model)
    require(start == canonical['reference_token_start'] and alignment == canonical['reference_alignment']
            and continuation == canonical['reference_full_token_ids'][start:start+64], 'reference token span differs')
    require(token_digest(prompt) == record['prompt_token_sha256'] and token_digest(continuation) == record['continuation_token_sha256'], 'token fingerprint differs')
    require(record['prompt_tokens'] == len(prompt) and record['continuation_tokens'] == 64
            and record['output_token_cap'] == case['output_token_cap'], 'recorded token/cap counts differ')
    low, high = (128, 2048) if case['length'] == 'short' else (3072, 12288)
    require(low <= len(prompt) <= high and len(prompt) + max(64, case['output_token_cap']) <= model['declared_context_limit'], 'context plus cap exceeds bounds')
    expected_body = {'model': model['model_id'], '_darkbloom_prompt_date': prompt_date,
        'chat_template_kwargs': {'enable_thinking': False}, 'messages': [{'role': 'user', 'content': case['prompt_text']}],
        'max_tokens': case['output_token_cap']}
    require(serving.get('quality_case_id') == case['id'] and len(serving.get('rows', [])) == 2, 'serving case/repeat coverage differs')
    for row, kind in zip(serving['rows'], ['first', 'repeat']):
        require(row['case'] == {'id': 'long-'+kind, 'kind': kind, 'max_tokens': case['output_token_cap'], 'target_length': None}, 'serving case contract differs')
        require(row['request'] == expected_body, 'serving prompt/date/model/cap differs')
    validate_plan_tokens(prompt, canonical['plan'], model['prompt_contract_id'], canonical['scope_id'])
    validate_plan_tokens(canonical['reference_full_token_ids'], canonical['full_reference_plan'], model['prompt_contract_id'], canonical['scope_id'])
    return {'serving': serving, 'teacher': teacher, 'canonical': canonical}


def load(root):
    root = Path(root)
    cases_document = read_json(root/'cases.json')
    require(cases_document == build(root), 'deterministic corpus selection/content differs')
    require(cases_document['training_data_exclusion_claim'] is False, 'unsupported training-data holdout claim')
    fleet = read_json(root/'fleet.json')['models']
    records = read_json(root/'payload-index.json')
    require(records['source_commit'] == SOURCE_SHA and records['model_or_gpu_execution'] is False, 'input preparation source/scope differs')
    validate_coverage(fleet, cases_document['cases'], records['records'])
    cases = {case['id']: case for case in cases_document['cases']}
    models = {model['label']: model for model in fleet}
    for model in fleet:
        contract = read_json(checked(root, model['contract_file']))
        config = read_json(checked(root, model['config_file']))
        registry = read_json(checked(root, model['manifest']))
        text = config.get('text_config', config)
        require(contract['model_id'] == model['model_id'] and contract['model_aggregate_sha256'] == model['aggregate_sha256']
                and contract['prompt_contract_id'] == model['prompt_contract_id'], 'fleet contract differs')
        require(contract_id(contract) == model['prompt_contract_id'] and contract['artifacts'] == model['prompt_artifacts'], 'prompt contract digest differs')
        roles = {'config', 'template', 'tokenizer'}
        registered = {row['path']: {key: row[key] for key in ['path', 'role', 'size_bytes', 'sha256']}
                      for row in registry['files'] if row['role'] in roles}
        require(registered == {row['path']: row for row in contract['artifacts']}, 'tokenizer artifacts differ from fleet manifest')
        config_artifact = next(row for row in contract['artifacts'] if row['path'] == 'config.json')
        require(model['config_file']['sha256'] == config_artifact['sha256']
                and model['contract_file']['sha256'] == model['cached_contract_sha256'], 'cached source identity differs')
        require(model['vocabulary_size'] == text['vocab_size'] and model['declared_context_limit'] == text['max_position_embeddings'], 'fleet vocabulary/context declaration differs')
    payloads = {}
    for record in records['records']:
        key = (record['model'], record['case_id'])
        payloads[key] = load_payload(root, record, models[key[0]], cases[key[1]], records['prompt_date'])
    for model in models:
        for case in cases.values():
            if case['length'] == 'short':
                long_id = case['id'][:-len('short')] + 'long'
                require(payloads[(model, case['id'])]['teacher']['continuation'] == payloads[(model, long_id)]['teacher']['continuation'],
                        'paired short/long reference tokens differ')
    gates = read_json(root/'inherited-gates.json')
    require(gates['new_numerical_tolerances'] == [], 'new numerical tolerance introduced')
    for row in gates['files_and_functions']:
        if 'path' in row:
            checked(root, row)
    require(digest(root/'teacher_checks.py') == gates['teacher_checks_file']['sha256'], 'teacher gate code differs')
    require(digest(root/'teacher_commands.py') == gates['teacher_commands_file']['sha256'], 'teacher argv builder differs')
    return {'models': models, 'cases': cases, 'records': records['records'], 'payloads': payloads,
            'prompt_date': records['prompt_date'], 'root': root}
