"""Owned parse/refusal smokes only: no valid packet or MLX operation is supplied."""
from pathlib import Path
import json,os,resource,subprocess
from build_proof import OUT,sha,write

def run(binary):
 root=OUT/'smokes';root.mkdir();small=root/'small.json';small.write_text('{}')
 oversized=root/'oversized.json';oversized.write_bytes(b' '*(256*1024+1))
 link=root/'symlink.json';link.symlink_to(small)
 cases=[('missing-options',[], 'four explicit paired replay options required'),
        ('invalid-arm',['--input',str(small),'--input-sha256',sha(small),'--output',str(root/'invalid-arm-output'),'--arm','unknown'],'unsupported replay arm'),
        ('invalid-hash',['--input',str(small),'--input-sha256','bad','--output',str(root/'invalid-hash-output'),'--arm','nativeSDPA'],'invalid input hash'),
        ('wrong-transfer-hash',['--input',str(small),'--input-sha256','a'*64,'--output',str(root/'wrong-transfer-hash-output'),'--arm','nativeSDPA'],'validated transfer hash mismatch'),
        ('symlink-input',['--input',str(link),'--input-sha256',sha(small),'--output',str(root/'symlink-input-output'),'--arm','nativeSDPA'],'cannot open regular input'),
        ('oversized-input',['--input',str(oversized),'--input-sha256',sha(oversized),'--output',str(root/'oversized-input-output'),'--arm','nativeSDPA'],'input length or file type')]
 env=os.environ.copy();env['SWIFT_BACKTRACE']='enable=no';records=[]
 def no_core():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 for name,args,expected in cases:
  path=root/(name+'.log');command=[str(binary)]+args
  with path.open('x') as log:r=subprocess.run(command,stdout=log,stderr=subprocess.STDOUT,env=env,timeout=20,preexec_fn=no_core)
  text=path.read_text();row={'name':name,'argv':command,'exit_code':r.returncode,'expected_message':expected,'message_present':expected in text,'output_absent':not (root/(name+'-output')).exists(),'log_sha256':sha(path)}
  records.append(row);write('smoke-results.json',records)
  assert r.returncode!=0 and row['message_present'] and row['output_absent'],row
 write('smoke-verdict.json',{'status':'PASS','cases':6,'scope':'Host parse/input refusal only; no valid packet, model, key or attention operator executed'})
