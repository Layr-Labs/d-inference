import json
import os
from pathlib import Path
import tempfile
import subprocess
import sys
import unittest
from run_connected_fixture import refuse_inherited_policy, verify_discovery, drain_owned_group


class BundleTests(unittest.TestCase):
    def test_policy_overrides_refused_without_mutating_environment(self):
        for key in ['DARKBLOOM_PREFIX_CACHE_ALLOW_EPHEMERAL', 'DARKBLOOM_PREFIX_CACHE_SSD_MAX_STAGE_MS',
                    'DARKBLOOM_CBV2_MAX_PARTIAL_PREFILLS', 'DARKBLOOM_MEM_CAP_FRACTION',
                    'DARKBLOOM_MTP_FORCE_SERIAL', 'MLX_METAL_FAST_SYNCH',
                    'DARKBLOOM_MLX_MEMORY_RESERVE_GB', 'DARKBLOOM_ADAPTIVE_PREFILL_ALLOW_8192',
                    'DARKBLOOM_GEMMA4_PREFILL_TAIL_ROWS', 'DARKBLOOM_MAX_IMAGE_MEGAPIXELS']:
            env = {'PATH':'/usr/bin', key:'1'}
            with self.assertRaises(ValueError): refuse_inherited_policy(env)
            self.assertEqual(env[key], '1')
        refuse_inherited_policy({'PATH':'/usr/bin', 'LANG':'en_US.UTF-8'})

    def test_newer_different_snapshot_refused(self):
        with tempfile.TemporaryDirectory() as tmp:
            home = Path(tmp).resolve(); folder = home/'.cache/huggingface/hub/models--exact/snapshots'
            folder.mkdir(parents=True); target = home/'target'; target.mkdir()
            (folder/'pinned').symlink_to(target)
            self.assertEqual(verify_discovery(home, 'exact', target), str(folder/'pinned'))
            other = folder/'other'; other.mkdir()
            os.utime(other, ns=(target.stat().st_atime_ns, target.stat().st_mtime_ns+1000000000))
            with self.assertRaises(ValueError): verify_discovery(home, 'exact', target)

    def test_owned_descendant_is_drained_and_unrelated_group_survives(self):
        unrelated = subprocess.Popen([sys.executable, '-c', 'import time;time.sleep(30)'], start_new_session=True)
        with tempfile.TemporaryDirectory() as tmp:
            pidfile = Path(tmp)/'child.pid'
            descendant = "import signal,time;signal.signal(signal.SIGINT,signal.SIG_IGN);signal.signal(signal.SIGTERM,signal.SIG_IGN);time.sleep(30)"
            parent = "import subprocess,sys,time,pathlib;p=subprocess.Popen([sys.executable,'-c'," + repr(descendant) + "]);pathlib.Path(" + repr(str(pidfile)) + ").write_text(str(p.pid));time.sleep(.2);sys.exit(7)"
            owned = subprocess.Popen([sys.executable, '-c', parent], start_new_session=True)
            try:
                self.assertEqual(owned.wait(timeout=5),7)
                actions = drain_owned_group(owned.pid, (.2,.2,2))
                self.assertEqual(actions, ['SIGINT','SIGTERM','SIGKILL'])
                self.assertIsNone(unrelated.poll())
            finally:
                unrelated.terminate();unrelated.wait(timeout=5)

    def test_normal_completed_group_gets_no_signal(self):
        child = subprocess.Popen([sys.executable, '-c', 'pass'], start_new_session=True)
        self.assertEqual(child.wait(timeout=5),0)
        self.assertEqual(drain_owned_group(child.pid), [])

    def test_twelve_inputs_have_equal_pairs_normal_mtp_and_supported_tool_mode(self):
        base = Path(__file__).parent
        plan = json.loads((base/'bundle-plan.json').read_text())
        self.assertEqual(len(plan['cells']),12)
        for off, ssd in zip(plan['cells'][::2],plan['cells'][1::2]):
            a = json.loads((base/off['input']).read_text()); b = json.loads((base/ssd['input']).read_text())
            self.assertEqual(a.pop('cache_mode'),'off');self.assertEqual(b.pop('cache_mode'),'ssd')
            self.assertEqual(a,b);self.assertEqual(a['tools_request']['tool_choice'],'auto')
            self.assertEqual(a['tools_request']['max_tokens'],512)
            self.assertEqual(a['mtp_mode'], 'off' if a['artifact']['model_id']=='gpt-oss-20b' else 'on')
            self.assertEqual(a['catalog'][0]['Manifest']['aggregate_sha256'],a['artifact']['model_aggregate_sha256'])


if __name__ == '__main__': unittest.main()
