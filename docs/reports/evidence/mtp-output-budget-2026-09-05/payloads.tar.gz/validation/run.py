from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time
out=Path('/tmp/darkbloom-q35-mtp-useful-tail-validation1');package=out/'native';scratch=Path('/tmp/darkbloom-allocator-footprint-foundation1/build-swift')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,data):(out/name).write_text(json.dumps(data,indent=2)+'\n')
def verify():
 native=json.loads((out/'native-source-manifest.json').read_text());deps=json.loads((out/'dependency-source-manifest.json').read_text());info=json.loads((out/'integration.json').read_text())
 for name,digest in native['files'].items():assert sha(package/name)==digest,name
 for key,digest in deps['files'].items():
  alias,name=key.split('/',1);assert sha(Path(deps['repositories'][alias])/name)==digest,key
 for name,digest in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():assert sha(scratch/'checkouts/swift-jinja'/name)==digest,name
 assert sha(package/'Package.resolved')==json.loads((out/'baseline-source-verified.json').read_text())['package_resolved_sha256']
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=package,text=True).strip()==info['baseline_commit']
 assert sha(out/'run-nested-suite.sh')==info['nested_suite_runner_sha256']
 return {'native_inputs':len(native['files']),'dependency_inputs':len(deps['files']),'jinja_inputs':27,'no_drift':True,'primary_and_build5_excluded':True}
def proof():
 graph=scratch/'debug.yaml';text=graph.read_text();(out/'actual-build-graph.yaml.gz').write_bytes(gzip.compress(graph.read_bytes(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'actual-package-state.json')
 expected=[package/'Libraries/MLXLMCommon/ContinuousBatchingV2/MTP/EngineLoopV2+MTPPlanning.swift',package/'Tests/MLXLMTests/CBv2MTPOutputBudgetTests.swift',Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift/Source/MLX/AllocationFootprint.swift'),Path('/tmp/darkbloom-allocator-footprint-policy-validation1/deps/mlx-swift/Source/Cmlx/mlx/mlx/backend/metal/allocator.cpp')];rows=[]
 for p in expected:
  candidates=[str(p),str(p.resolve()),str(p).replace('/tmp/','/private/tmp/',1),str(p.resolve()).replace('/private/tmp/','/tmp/',1)]
  actual=next((Path(x) for x in candidates if x in text),None);assert actual is not None,str(p);assert actual.resolve()==p.resolve()
  rows.append({'actual_compile_path':str(actual),'resolved_frozen_source':str(p.resolve()),'sha256':sha(p)})
 assert '/checkouts/mlx-swift/Source/' not in text
 write('actual-compiler-source-proof.json',{'paths':rows,'remote_mlx_source_absent':True})
results=[]
def run(name,cmd,test=False):
 started=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=package,stdout=log,stderr=subprocess.STDOUT)
 body=(out/(name+'.log')).read_text();nonzero=bool(re.search(r'Test run with [1-9][0-9]* test|Executed [1-9][0-9]* test',body));skips=bool(re.search(r'^[^A-Za-z0-9]*(Test|Suite) .+ skipped[.:]|with [1-9][0-9]* tests? skipped|skipped [1-9][0-9]* test',body,re.M))
 row={'name':name,'command':cmd,'exit_code':p.returncode,'seconds':time.monotonic()-started,'nonzero_no_skips':not test or (nonzero and not skips)};results.append(row);write('execution.json',results);print(json.dumps(row),flush=True)
 if not test and p.returncode:raise SystemExit(p.returncode)
write('source-verified-before.json',verify())
write('test-environment.json',{k:os.environ[k] for k in sorted(os.environ) if k.startswith(('DARKBLOOM_MTP_','MLX_'))})
run('build',['swift','build','--scratch-path',str(scratch),'--build-tests','--jobs','4','--disable-automatic-resolution'])
proof();write('source-verified-after-build.json',verify())
debug=scratch/'arm64-apple-macosx/debug';bundle=debug/'mlx-swift-lmPackageTests.xctest/Contents/MacOS';assert bundle.is_dir()
lib=Path('/tmp/darkbloom-final-serving-build5/artifact/mlx.metallib');assert sha(lib)=='4ffbbac48a99b495916c3fa0921ce813eb554de1a09aff408d9b5a5a8053e6b0'
for p in [debug/'mlx.metallib',bundle/'mlx.metallib']:shutil.copy2(lib,p)
write('metallib-placement.json',{'source':str(lib),'sha256':sha(lib),'destinations':[str(debug/'mlx.metallib'),str(bundle/'mlx.metallib')],'kernel_sources_unchanged':True})
binary=bundle/'mlx-swift-lmPackageTests';write('test-binary.json',{'path':str(binary),'sha256':sha(binary),'bytes':binary.stat().st_size})
run('identifiers',['swift','test','list','--skip-build','--scratch-path',str(scratch),'--disable-automatic-resolution'])
for name in json.loads((out/'filters.json').read_text()):
 run(name,[str(out/'run-nested-suite.sh'),name,'--scratch-path',str(scratch),'--disable-automatic-resolution'],test=True)
write('source-verified-after.json',verify());assert sha(binary)==json.loads((out/'test-binary.json').read_text())['sha256']
(out/'actual-build-graph-after.yaml.gz').write_bytes(gzip.compress((scratch/'debug.yaml').read_bytes(),mtime=0));shutil.copy2(scratch/'workspace-state.json',out/'actual-package-state-after.json')
failed=[x for x in results if x['exit_code'] or not x['nonzero_no_skips']];write('run-status.json',{'failed_filters':[x['name'] for x in failed],'all_filters_run':len(results)==11});print('NATIVE USEFUL-TAIL FAILED FILTERS='+str(len(failed)),flush=True);raise SystemExit(bool(failed))
