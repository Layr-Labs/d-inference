#!/usr/bin/env python3
"""Validate/compare quality payloads or print commands for the existing runners."""
from pathlib import Path
import argparse
import json
import os
import shlex
import sys

from cohort_common import digest, read_json, require
from quality_compare import compare_serving, compare_teacher
from quality_inputs import load
from quality_runtime import runtime_binding
from teacher_commands import command as existing_teacher_command

ROOT = Path(__file__).resolve().parent


def validate_plan(root, cohort):
    plan = read_json(root/'plan.json')
    require(plan['source_lock_sha256'] == digest(root/'source-lock.json')
            and plan['payload_index_sha256'] == digest(root/'payload-index.json'), 'plan source/input binding differs')
    require(plan['logical_cases'] == 12 and plan['artifacts'] == 6 and plan['model_case_payloads'] == 72,
            'planned coverage differs')
    require(plan['new_numerical_tolerances'] == [] and plan['quality_pass'] is None
            and plan['model_admission_clearance_claimed'] is False, 'unsupported quality/admission claim')
    require(plan['gemma8_m3_prohibited'] is True and plan['stages'] ==
            [{'id':'pilot','model_cases':1},{'id':'short','model_cases':35},{'id':'long','model_cases':36}], 'staging/admission policy differs')
    expected = {(row['model'], row['case_id'], backend) for row in cohort['records'] for backend in ['contiguous', 'paged']}
    for scope in ['serving', 'teacher']:
        cells = plan['cells'][scope]
        require(len(cells) == len({cell['id'] for cell in cells}) == 144
                and {(cell['model'], cell['case_id'], cell['backend']) for cell in cells} == expected,
                'planned cells missing/duplicated')
        for cell in cells:
            record = next(row for row in cohort['records'] if (row['model'], row['case_id']) == (cell['model'], cell['case_id']))
            require(cell['input'] == record[scope], 'cell input binding differs')
            require(cell['id'] == scope+'--'+cell['model']+'--'+cell['case_id']+'--'+cell['backend'], 'cell identity differs')
            stage = 'pilot' if (cell['model'],cell['case_id']) == ('gpt-oss-20b','prose-gutenberg-11-short') else record['length']
            require(cell['stage'] == stage, 'cell stage differs')
    return plan


def command_spec(root, cohort, plan, cell, scope, binding):
    require(cell['id'] in binding['reviewed_cell_ids'], 'cell has no ROOT execution review')
    require(not (binding['host_id'] == 'm3' and cell['model'] == 'gemma-4-26b'), 'Gemma8 remains prohibited on M3')
    model = cohort['models'][cell['model']]
    target = binding['models'][cell['model']]
    source = Path(target['directory'])
    require(source.is_absolute() and source.is_dir(), 'exact model directory is unbound')
    runtime = Path(binding['runtime_directory'])
    output = Path(binding['execution_root'])/cell['id']
    require(not output.exists(), 'result directory already exists; preserve the attempt')
    environment = {'PATH': '/usr/bin:/bin:/usr/sbin:/sbin', 'LANG': 'en_US.UTF-8',
                   'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
                   'DARKBLOOM_PREFIX_CACHE': '0', 'DARKBLOOM_PREFIX_CACHE_MEMORY': '0', **plan['serving_profile']}
    environment.update(DARKBLOOM_MATRIX_BINDING_SHA256=binding['_binding_sha256'],
                       DARKBLOOM_MATRIX_HOST_ID=binding['host_id'])
    if scope == 'serving':
        python = Path(binding['python_executable'])
        require(python.is_absolute() and python.is_file(), 'Python executable is unbound')
        macmon = binding['macmon']
        require(Path(macmon['path']).is_file() and digest(macmon['path']) == macmon['sha256'], 'telemetry binary is unbound')
        argv = [str(python), '-B', str(root/'vendor/run_radix_engine.py'), '--binary', str(runtime/'radix-engine'),
                '--model-directory', str(source), '--input', str(root/cell['input']['path']), '--output', str(output),
                '--cache', 'off', '--mtp', 'on' if model['normal_mtp'] else 'off', '--kv-backend', cell['backend'],
                '--cache-mode', 'ssd', '--key-mode', 'ephemeral', '--production-kv-grant', '--concurrency', '1',
                '--expected-model-sha256', model['aggregate_sha256'], '--prompt-date', cohort['prompt_date'],
                '--startup-timeout', '240', '--macmon', macmon['path']]
        if model['assistant'] is not None:
            assistant = Path(target['assistant_directory'])
            require(assistant.is_absolute() and assistant.is_dir(), 'exact Gemma assistant directory is unbound')
            expected = read_json(root/'fleet/assistant-proof.json')['copied']
            require({path.name for path in assistant.iterdir()} == set(expected), 'Gemma assistant must retain the exact two-file fixture')
            for name, facts in expected.items():
                path = assistant/name
                require(path.is_file() and path.stat().st_size == facts['bytes'] and digest(path) == facts['sha256'],
                        'Gemma assistant file identity differs')
            argv += ['--assistant-directory', str(assistant)]
    else:
        home = Path(target['teacher_fixture_home'])
        snapshot = Path(target['teacher_snapshot'])
        require(home.is_absolute() and home.is_dir() and home.resolve().is_relative_to(Path(binding['execution_root']).resolve()),
                'owned teacher fixture home must be prepared by the existing controller')
        require(snapshot.is_dir() and snapshot.resolve().is_relative_to(home.resolve()), 'teacher snapshot is unbound')
        expected_snapshot = home/'.cache/huggingface/hub'/('models--'+model['model_id'].replace('/','--'))/'snapshots/local'
        require(snapshot.resolve() == expected_snapshot.resolve(), 'teacher snapshot layout differs from existing controller')
        environment.update(CFFIXED_USER_HOME=str(home), HF_HOME=str(home/'.cache/huggingface'),
                           HUGGINGFACE_HUB_CACHE=str(home/'.cache/huggingface/hub'), TMPDIR=str(output/'tmp'))
        require(root.resolve() == ROOT.resolve(), 'teacher argv builder requires this package root')
        argv = existing_teacher_command(runtime, {'model_id': model['model_id'], 'input': cell['input']['path']}, cell, output)
    return {'cell': cell['id'], 'scope': scope, 'argv': argv, 'shell': shlex.join(argv), 'environment': environment,
            'output_directory': str(output), 'input_identity': cell['input'], 'executed': False,
            'teacher_stdout_report': str(output/'report.json') if scope == 'teacher' else None,
            'teacher_config_copy': {'source':str(root/'config'/(cell['model']+'.toml')),
                                    'destination':str(output/'provider.toml'),
                                    'sha256':digest(root/'config'/(cell['model']+'.toml'))} if scope == 'teacher' else None,
            'execution_driver': 'Existing runner/controller only; this tool never launches a model.',
            'required_before_execution': ['ROOT host/thermal/storage/production-grant clearance',
                'exact model and assistant inventories', 'existing bounded process ownership and retirement receipts',
                'teacher fixture/TMPDIR preparation through the existing controller when applicable']}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['validate', 'commands', 'compare-serving', 'compare-teacher'])
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--scope', choices=['serving', 'teacher'])
    parser.add_argument('--cell')
    parser.add_argument('--model')
    parser.add_argument('--case')
    parser.add_argument('--contiguous', type=Path)
    parser.add_argument('--paged', type=Path)
    parser.add_argument('--binding', type=Path)
    parser.add_argument('--binding-sha256')
    args = parser.parse_args()
    cohort = load(args.root); plan = validate_plan(args.root, cohort)
    if args.action == 'validate':
        result = {'input_validation': 'passed', 'models': 6, 'logical_cases': 12, 'model_cases': 72,
                  'serving_payloads': 72, 'teacher_payloads': 72, 'quality_pass': None, 'model_execution': False}
    else:
        require(args.binding is not None and args.binding_sha256, 'reviewed binding and exact binding SHA required')
        binding = runtime_binding(args.binding, args.binding_sha256)
        require(binding['serving_profile'] == plan['serving_profile'], 'reviewed serving profile differs')
        if args.action == 'commands':
            require(args.scope and args.cell, 'select one explicit scope/cell')
            candidates = [cell for cell in plan['cells'][args.scope] if cell['id'] == args.cell]
            require(len(candidates) == 1, 'unknown cell')
            result = command_spec(args.root, cohort, plan, candidates[0], args.scope, binding)
        else:
            require(args.model and args.case and args.contiguous and args.paged, 'select exact model/case and both reports')
            if args.action == 'compare-serving':
                result = compare_serving(cohort, args.model, args.case, read_json(args.contiguous), read_json(args.paged), binding,
                    metadata=[read_json(args.contiguous.parent/'metadata.json'), read_json(args.paged.parent/'metadata.json')])
            else:
                result = compare_teacher(cohort, args.model, args.case, read_json(args.contiguous), read_json(args.paged), binding)
    print(json.dumps(result, indent=2, allow_nan=False))


if __name__ == '__main__':
    main()
