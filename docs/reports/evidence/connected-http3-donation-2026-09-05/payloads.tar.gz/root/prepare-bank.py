import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path

root = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
destination = root / 'docs/reports/evidence/connected-http3-donation-2026-09-05'
assert not destination.exists()
payloads = {}

def add(name, path):
    assert name not in payloads
    data = path.read_bytes()
    assert data[:4] not in [b'\x7fELF', b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf']
    payloads[name] = data

def frozen(label, path):
    manifest = json.loads((path / 'manifest.json').read_text())
    for name, spec in manifest['files'].items():
        data = (path / name).read_bytes()
        assert len(data) == spec['bytes']
        assert hashlib.sha256(data).hexdigest() == spec['sha256']
        add(label + '/' + name, path / name)
    add(label + '/manifest.json', path / 'manifest.json')

frozen('http3', Path('/tmp/darkbloom-connected-http3-q38-donation-failure1'))
frozen('build7', Path('/tmp/darkbloom-final-serving-build7'))
frozen('prior-tool-budget-failure', Path('/tmp/darkbloom-connected-http2-q38-tool-budget-failure1'))
bundle = Path('/tmp/darkbloom-connected-m5-bundle3')
manifest = json.loads((bundle / 'package-manifest.json').read_text())
selected = sorted(set([
    *[p.relative_to(bundle).as_posix() for p in (bundle / 'inputs').glob('*.json')],
    *[p.name for p in bundle.glob('*.py')],
    'README.md', 'bundle-plan.json', 'inputs-diff.json', 'paired-input-validation.json',
    'source-gates.json', 'source-verification.json', 'go-source-manifest.json',
    'tokenizer-plan.json', 'review-handoff.json',
]))
for name in selected:
    data = (bundle / name).read_bytes()
    spec = manifest['files'][name]
    assert hashlib.sha256(data).hexdigest() == spec['sha256']
    assert len(data) == spec['bytes']
    add('bundle3/' + name, bundle / name)
add('bundle3/package-manifest.json', bundle / 'package-manifest.json')
for name in ['darkbloom-build7-root-review.json', 'darkbloom-connected-bundle3-root-review.json',
             'darkbloom-connected-bundle3-helper-root-review.json']:
    add('root/' + name, Path('/tmp') / name)
add('root/prepare-bank.py', Path(__file__))

destination.mkdir(parents=True)
archive = destination / 'payloads.tar.gz'
with archive.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(payloads.items()):
                entry = tarfile.TarInfo(name)
                entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
                tar.addfile(entry, io.BytesIO(data))
entries = {name: {'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data)}
           for name, data in sorted(payloads.items())}
evidence = {
    'schema': 1,
    'scope': 'Q38 HTTP3 cache-off ten-case pass and SSD donation publication failure; release held',
    'source_commit': 'c56e9b11a56dfa9291dbde58e324a7b0c9ec7e3b',
    'files': entries,
    'payload_count': len(entries),
    'payload_bytes': sum(len(data) for data in payloads.values()),
    'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
    'archive_bytes': archive.stat().st_size,
    'excluded': 'Compiled runtime and Go executable bytes; their source and artifact identities remain recorded',
}
(destination / 'manifest.json').write_text(json.dumps(evidence, indent=2) + '\n')
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(entries)
    for member in tar:
        data = tar.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest() == entries[member.name]['sha256']
        assert len(data) == entries[member.name]['bytes']
summary = {key: value for key, value in evidence.items() if key != 'files'}
summary['manifest_sha256'] = hashlib.sha256((destination / 'manifest.json').read_bytes()).hexdigest()
Path('/tmp/darkbloom-http3-bank-root-review.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps(summary, indent=2))
