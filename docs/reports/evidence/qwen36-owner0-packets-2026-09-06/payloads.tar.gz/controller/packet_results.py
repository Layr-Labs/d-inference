"""Strict Q36 selection/export binding around the unchanged native-byte analyzer."""
import hashlib
import json
import stat
from pathlib import Path

from attention_packet.packet import load_packet
from attention_packet.reference import analyze

NAMES = {'queries': 'queries.bin', 'incomingKeys': 'incoming-keys.bin',
         'incomingValues': 'incoming-values.bin', 'storedKeys': 'stored-keys.bin',
         'storedValues': 'stored-values.bin', 'output': 'output.bin'}
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def inspect_packet(local, cell, plan, report):
    """Return strict errors plus retained descriptive analysis; never a numeric gate."""
    errors = []
    analysis = None

    def require(condition, message):
        if not condition: errors.append(message)

    try:
        summary = report['attention_packet']
        require(summary['status'] == 'captured' and summary['evaluation_status'] == 'completed',
                'raw capture incomplete')
        expected_remote = plan['remote_root']+'/runs/'+cell['id']+'/report.attention-packet'
        require(summary['directory'] == expected_remote, 'packet report directory differs from selected cell')
        directory = local/'report.attention-packet'
        require(stat.S_ISDIR(directory.lstat().st_mode) and stat.S_IMODE(directory.stat().st_mode) == 0o700,
                'packet directory must be real and private0700')
        expected_files = set(NAMES.values())|{'packet.json', 'attention-metadata.json'}
        require({p.name for p in directory.iterdir()} == expected_files, 'packet directory inventory differs')
        for name in expected_files:
            require(stat.S_ISREG((directory/name).lstat().st_mode), 'packet file is not regular: '+name)
        if errors: return errors, None
        path = directory/'packet.json'
        require(sha(path) == summary['packet_sha256'], 'report packet SHA does not match bytes')
        packet = load_packet(path)
        doc, record, snapshot = packet.document, packet.record, packet.snapshot
        require(not packet.inconclusive_reasons, 'analyzer refused selected forward: '+repr(packet.inconclusive_reasons))
        identity = doc['identity']
        require(identity['modelID'] == report['model'], 'packet model ID mismatch')
        require(identity['artifactSHA256'] == report['verified_model_hash'] == plan['model_sha256'], 'packet verified model hash mismatch')
        require(identity['inputSHA256'] == report['input_sha256'] == plan['actual_wrapper_input_sha256'], 'packet actual input hash mismatch')
        require(identity['backend'] == report['resolved_backend'] == cell['backend'], 'packet backend mismatch')
        require(summary['tensor_payload_bytes'] == doc['capture']['tensorPayloadBytes'], 'reported native byte total mismatch')
        require(summary['reserved_bytes'] == plan['byte_budget']['conservativeFP32ReservationBytes'], 'packet reservation mismatch')
        require(summary['snapshot'] == snapshot, 'report and exported packet snapshots differ')
        selected = plan['selection']
        for name in ['requestID', 'outputIndex', 'storageLayerIndex', 'modelLayerIndex', 'offsetBefore', 'offsetAfter', 'scaleBits']:
            require(record[name] == selected[name], 'packet selected '+name+' mismatch')
        require(record['phase'] in ['decode', 'chained_decode'], 'packet selected phase unsupported')
        expected_dispatch = 'paged_segmented_decode' if cell['backend'] == 'paged' else 'contiguous_sdpa'
        require(record['dispatch'] == expected_dispatch, 'actual dispatch differs from selected full Q36 geometry')
        tokens = report['rows'][0]['token_ids']; index = selected['outputIndex']
        require(snapshot['seedToken'] == tokens[index-1] == selected['expectedSeedToken']
                and snapshot['targetToken'] == tokens[index], 'packet seed/target differs from actual trajectory')
        expected_shapes = {'queries': selected['QShape'], 'output': selected['QShape'],
            'incomingKeys': selected['incomingKVShape'], 'incomingValues': selected['incomingKVShape'],
            'storedKeys': selected['storedKVShape'], 'storedValues': selected['storedKVShape']}
        for name, shape in expected_shapes.items():
            require(doc['tensors'][name]['shape'] == shape, 'packet actual '+name+' geometry differs')
            require(doc['tensors'][name]['file'] == NAMES[name], 'packet filename differs: '+name)
        owners = report['attention_metadata']['snapshot']
        matching = [r for r in owners['records'] if r['storageLayerIndex'] == selected['storageLayerIndex']]
        require(len(matching) == 1, 'selected full-owner metadata missing or repeated')
        if len(matching) == 1:
            for key in record:
                require(matching[0].get(key) == record[key], 'raw/all-owner observed metadata differs: '+key)
        for key in ['forwardSucceeded', 'sampleOutcome', 'seedToken', 'targetToken', 'selectedForwards']:
            require(owners[key] == snapshot[key], 'raw/all-owner lifecycle differs: '+key)
        logit = report['logit_diagnostic']['snapshot']['records'][0]
        require(logit['phase'] == record['phase'] and logit['seedToken'] == snapshot['seedToken']
                and logit['targetToken'] == snapshot['targetToken'], 'raw/logit selected decision differs')
        if errors: return errors, None
        analysis = analyze(packet)
        require(analysis['status'] == 'analyzed' and not analysis['inconclusiveReasons'],
                'packet reference is inconclusive: '+repr(analysis['inconclusiveReasons']))
        require(all(v['mismatchedNativeElements'] == 0 for v in analysis.get('lastRowConsistency', {}).values()),
                'stored last row differs from incoming native KV')
    except Exception as error:
        errors.append('packet evidence refused: '+type(error).__name__+': '+str(error))
    return errors, analysis
