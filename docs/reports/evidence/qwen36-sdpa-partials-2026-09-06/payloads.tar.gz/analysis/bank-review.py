import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import stat
import struct
import sys
import tarfile

PRIMARY = Path('/Users/gaj/Documents/DarkbloomDev/wt/optimizations-integrated')
BUILD = Path('/tmp/darkbloom-qwen-sdpa-build1')
RESULTS = BUILD / 'operator-results'
RAW = RESULTS / 'raw'
ADAPTER = Path('/tmp/darkbloom-qwen-sdpa-partials-execution-plan1')
CANDIDATE = Path('/tmp/darkbloom-qwen-sdpa-partials1')
BANK = PRIMARY / 'docs/reports/evidence/qwen36-sdpa-partials-2026-09-06'
FINAL_ADAPTER = '12cd0ce5eec6cf252a5d8cdc58c6a30e5756fa17b5c30cde7dbfc93c222367d8'
RAW_PROOF = '900f7cc8a895bd3fcf6372a7f21a89258de9bc14b316bd1f8cad278534e3dfed'


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read(path):
    return json.loads(Path(path).read_bytes())


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def identity(path):
    path = Path(path)
    require(path.is_file() and not path.is_symlink(), 'regular file required')
    return {'sha256': digest(path.read_bytes()), 'bytes': path.stat().st_size,
            'mode': stat.S_IMODE(path.stat().st_mode)}


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def verify_results():
    sys.path.insert(0, str(ADAPTER))
    import adapter
    import common
    require(identity(ADAPTER / 'manifest.json')['sha256'] == FINAL_ADAPTER, 'adapter drift')
    common.verify_plan()
    collection = read(RESULTS / 'collection-receipt.json')
    require(identity(RESULTS / 'results.tar.gz')['sha256'] == collection['archive']['sha256'], 'archive drift')
    actual_files = {str(path.relative_to(RAW)) for path in RAW.rglob('*') if path.is_file()}
    require(actual_files == set(collection['files']), 'collected file set drift')
    for relative, expected in collection['files'].items():
        actual = identity(RAW / relative)
        require(all(actual[key] == value for key, value in expected.items()), 'collected file drift: ' + relative)
    binding = read(RAW / 'reviews/binding.json')
    approval = read(RAW / 'reviews/main-review.json')
    require(binding['manifest_sha256'] == FINAL_ADAPTER, 'wrong approved adapter')
    require(approval['binding_payload_sha256'] == common.binding_payload(binding), 'approval payload drift')
    proof = read(RAW / 'replay-evidence-manifest.json')
    require(identity(RAW / 'replay-evidence-manifest.json') == binding['evidence_manifest']['identity'], 'raw proof binding drift')
    require(digest((RAW / 'replay-evidence-manifest.json').read_bytes()) == RAW_PROOF and len(proof['files']) == 2137, 'wrong raw proof')
    for field in ('handoff', 'main_review'):
        require(identity(RAW / 'reviews' / Path(binding[field]['path']).name) == binding[field]['identity'], 'review descriptor drift')
    handoff = read(RAW / 'reviews/handoff.json')
    _, _, inspector = adapter.helpers()
    outputs = {}
    traces = {}
    arms = {}
    seals = read(RAW / 'runs/arm-manifests.json')
    previous_end = 0
    for arm in common.ARMS:
        step = RAW / 'runs' / arm
        require(common.tree(step) == seals[arm], 'completed arm seal drift')
        traces[arm], outputs[arm] = adapter.interpret(arm, step, 128, inspector)
        command = read(step / 'native-command.json')
        foreground = read(step / 'foreground-terminal.json')
        owner = read(step / 'owner/terminal.json')
        require(command['binding_sha256'] == identity(RAW / 'reviews/binding.json')['sha256'], 'native binding differs')
        require(command['native_timeout_seconds'] == 180 and previous_end < command['exec_unix'], 'deadline/order drift')
        require(handoff['issued_unix'] <= command['exec_unix'] < foreground['ended_unix'] < handoff['expires_unix'], 'execution outside handoff')
        require(foreground['status'] == 'OWNER_FINISHED' and foreground['failure'] is None
                and foreground['independent_native_cleanup_complete'] and foreground['self_renewed_pings'] == 0, 'foreground failure')
        previous_end = foreground['ended_unix']
        postflight = read(step / 'postflight.json')
        require(not postflight['owned_processes'] and not postflight['unexpected_processes'], 'recorded postflight not idle')
        artifact = read(BUILD / 'review' / arm / 'artifact-manifest.json')
        require(identity(BUILD / 'review' / arm / 'artifact-manifest.json') == binding['runtime'][arm]['artifact_manifest']['identity'], 'artifact manifest drift')
        common.validate_source_identity(artifact, read(BUILD / 'review' / arm / 'source-after.json'), arm)
        for name, descriptor in binding['runtime'][arm]['build_evidence'].items():
            relative = Path(descriptor['path']).relative_to(binding['build_root'])
            require(identity(BUILD / 'review' / relative) == descriptor['identity'], 'collected build metadata drift: ' + name)
        inventory = read(BUILD / 'review' / arm / 'function-inventory.json')
        actual_inventory = read(BUILD / 'review/logs' / (arm + '-function-inventory.log'))
        common.validate_inventory(inventory['functions'], arm == 'variant')
        require(inventory['metallib'] == artifact['files']['mlx.metallib'], 'inventory library identity differs')
        require(all(inventory[field] == actual_inventory[field] for field in ('functions', 'architecture', 'device_name')), 'raw inventory differs')
        require(inventory['architecture'] == 'applegpu_g17s', 'wrong architecture')
        runtime_review = RAW / 'reviews' / (arm + '-runtime-review.json')
        require(identity(runtime_review) == binding['runtime'][arm]['runtime_review']['identity'], 'runtime review drift')
        require(read(runtime_review)['evidence_manifest_sha256'] == RAW_PROOF, 'review proof drift')
        arms[arm] = {'pid': owner['pid'], 'exit_code': owner['exit_code'], 'exec_unix': command['exec_unix'],
                     'foreground_end_unix': foreground['ended_unix'], 'native_timeout_seconds': 180,
                     'group_cleanup_complete': owner['group_cleanup_complete'], 'independent_cleanup_complete': True,
                     'trace': traces[arm], 'artifact_files': artifact['files'], 'compiled_function_count': len(inventory['functions'])}
    captures = {name: (CANDIDATE / 'captures' / (name + '.bin')).read_bytes() for name in ('contiguous', 'paged')}
    pair = inspector.compare(traces['baseline'], outputs['baseline'], traces['variant'], outputs['variant'], captures)
    require(pair == read(RAW / 'runs/observation.json') == read(RESULTS / 'analysis.json')['pair'], 'observation mismatch')
    require(read(RAW / 'runs/terminal.json')['status'] == 'OBSERVED', 'pair did not complete')
    executions = read(BUILD / 'review/executions.json')
    require(len(executions) == 15 and len({(row['arm'], row['step']) for row in executions}) == 15, 'build step count differs')
    require(all(row['exit_code'] == 0 and row['failure'] is None and row['group_cleanup_complete'] for row in executions), 'build step failure')
    return binding, collection, arms, pair, outputs, captures


def verify_numbers(outputs, captures):
    import numpy as np
    sys.path.insert(0, str(PRIMARY / 'scripts/benchmarks'))
    from attention_packet.native import decode, rounded
    from attention_packet.reference import attention, statistics
    analysis = read(RESULTS / 'analysis.json')
    require(np.__version__ == analysis['numpy_version'] == '2.4.2', 'reference NumPy version differs')
    require(identity(PRIMARY / 'scripts/benchmarks/attention_packet/reference.py')['sha256'] == analysis['reference_source_sha256'], 'reference code drift')
    source_bank = PRIMARY / 'docs/reports/evidence/qwen36-owner0-packets-2026-09-06'
    source_manifest = read(source_bank / 'manifest.json')
    document = read(CANDIDATE / 'input/input.json')
    members = {}
    for name in ('queries', 'storedKeys', 'storedValues'):
        descriptor = document['tensors'][name]
        matches = [relative for relative, row in source_manifest['files'].items()
                   if row['sha256'] == descriptor['sha256'] and 'contiguous' in relative]
        require(len(matches) == 1, 'sealed input bank ambiguous')
        members[name] = matches[0]
    arrays = {}
    with tarfile.open(source_bank / 'payloads.tar.gz', 'r:gz') as archive:
        for name, relative in members.items():
            raw = archive.extractfile(relative).read()
            descriptor = document['tensors'][name]
            require(digest(raw) == descriptor['sha256'], 'sealed bank input differs')
            arrays[name] = decode(raw, descriptor['dtype'], descriptor['shape'])
    scale = struct.unpack('<f', struct.pack('<I', document['scaleBits']))[0]
    reference, stages = attention(arrays['queries'], arrays['storedKeys'], arrays['storedValues'], scale)
    require(all(not any(stage[kind].values()) for stage in stages for kind in ('logits', 'weights')), 'nonfinite reference')
    rounded_reference = rounded(reference, 'bfloat16')
    values = {name: decode(raw, 'bfloat16', [1, 16, 1, 256]) for name, raw in dict(outputs, paged_capture=captures['paged']).items()}
    comparisons = {name: {'fp32_reference': statistics(value, reference), 'fp32_rounded_bf16': statistics(value, rounded_reference)}
                   for name, value in values.items()}
    require(comparisons == analysis['comparison'], 'independent original-reference analysis differs')
    rounded_mismatches = {name: int(np.count_nonzero(value != rounded_reference)) for name, value in values.items()}
    return {'numpy_version': np.__version__, 'analysis_reproduced_exactly': True, 'comparison': comparisons,
            'rounded_reference_mismatches': rounded_mismatches, 'remaining_variant_vs_paged': analysis['remaining_variant_vs_paged'],
            'reference_source': identity(PRIMARY / 'scripts/benchmarks/attention_packet/reference.py'),
            'decoder_source': identity(PRIMARY / 'scripts/benchmarks/attention_packet/native.py'),
            'input_bank': {'archive': str((source_bank / 'payloads.tar.gz').relative_to(PRIMARY)),
                           'archive_identity': identity(source_bank / 'payloads.tar.gz'),
                           'manifest_identity': identity(source_bank / 'manifest.json'), 'members': members}}


def main():
    require(not BANK.exists(), 'fresh evidence bank required')
    binding, collection, arms, pair, outputs, captures = verify_results()
    numerical = verify_numbers(outputs, captures)
    review = {'schema': 'darkbloom.q36-partials-result-review.v1', 'date': '2026-09-06',
              'status': 'BOUNDED_OPERATOR_RESULT_VERIFIED', 'reviewer': 'Avicenna',
              'adapter_manifest_sha256': FINAL_ADAPTER, 'raw_proof_manifest_sha256': RAW_PROOF,
              'raw_proof_file_count': 2137, 'collected_raw_files_verified': len(collection['files']),
              'arms': arms, 'pair': pair, 'numerical': numerical, 'collection_postflight': collection['observation'],
              'source_verification_provenance': 'Main ran the final adapter full raw-evidence/Git-base verifier on M5 before both operators. This independent review checks the frozen binding, manifests, collected metadata, trace/output and cleanup receipts; it does not rerun the 2137-file remote source audit.',
              'limits': ['One selected owner0 Q36 B1/D256 input; one execution per arm.',
                         'No Q35/Q36 whole-model, token, quality, serving or performance acceptance.',
                         'No primary source or production precision change; no permission for global FP32 partials.',
                         'Recorded cleanup/idle observations are historical receipts, not a fresh remote process probe.']}
    failures = {'schema': 'darkbloom.q36-partials-preserved-events.v1', 'events': [
        {'event': 'initial_resource_packaging_failure', 'evidence': 'controls/build-ssh.stderr',
         'detail': 'Initial baseline Swift/Metal steps succeeded; packaging incorrectly expected swift-crypto_Crypto.bundle/PrivacyInfo.xcprivacy. Original failure and attempt1 receipts retained. Corrected packaging uses only actual SwiftPM resources.'},
        {'event': 'manifest_staging_refusals', 'provenance': 'User/Main reports in the independent-review conversation; rejected-call stdout/stderr was not separately retained in the supplied local collection.',
         'reviewed_hash': '0d48757a3c9a87dce65bac7c7e41f18f15f97435e6ae16e9c57e8c92e9329154',
         'intermediate_hash': 'eee934dfd5a5363aed098c598b82ddb4df698cf8dc256cfde0814f67c1fc32a3',
         'final_reviewed_hash': FINAL_ADAPTER, 'guard_source': identity(BUILD / 'stage_adapter.py'),
         'detail': 'Staging refused stale manifest approval; final handoff plus dependency-proof compatibility delta received exact-hash re-review. No rejected stdout or extra operator run is fabricated.'},
        {'event': 'premature_binding_preparation_failure', 'evidence': 'controls/binding-preparation.stderr',
         'detail': 'ModuleNotFoundError for common before successful final adapter staging; successful retry receipts are retained.'}]}
    payloads = {}
    def add(name, path):
        path = Path(path)
        require(path.is_file() and not path.is_symlink() and name not in payloads, 'unsafe/duplicate payload')
        payloads[name] = path.read_bytes()
    for path in sorted(RAW.rglob('*')):
        if path.is_file():
            add('raw/' + str(path.relative_to(RAW)), path)
    for name in ('analysis.json', 'analyze.py', 'collection-receipt.json'):
        add('analysis/' + name, RESULTS / name)
    add('analysis/bank-review.py', Path(__file__))
    for name in ('preparation.json', 'source-selection.json', 'stage-receipt.json', 'executions.json', 'attempt1-executions.json', 'attempt1-build-status.json', 'build-status.json', 'build-entry.json'):
        add('build/' + name, BUILD / 'review' / name)
    for arm in ('baseline', 'variant'):
        for name in ('artifact-manifest.json', 'source-after.json', 'compiler-source-graph.json', 'dependency-proof.json', 'metal-build-proof.json', 'function-inventory.json', 'release.yaml.gz'):
            add('build/' + arm + '/' + name, BUILD / 'review' / arm / name)
        for name in ('swift-release', 'metal-configure', 'metal-build', 'function-inventory', 'codesign', 'toolchain'):
            filename = arm + '-' + name + '.log'
            add('build/logs/' + filename, BUILD / 'review/logs' / filename)
    add('build/logs/metadata-inventory-compile.log', BUILD / 'review/logs/metadata-inventory-compile.log')
    for path in sorted((BUILD / 'review/steps').glob('*/terminal.json')):
        add('build/steps/' + str(path.relative_to(BUILD / 'review/steps')), path)
    for name in ('common-dispatch-trace.patch', 'variant-from-fab0.patch'):
        add('patches/' + name, BUILD / name)
    add('patches/fp32-partials.patch', CANDIDATE / 'fp32-partials.patch')
    for name in ('adapter-review.json', 'artifact-comparison-review.json', 'evidence-freeze-receipt.json', 'build-ssh.stderr',
                 'local-build-terminal.json', 'local-build2-terminal.json', 'binding-preparation.stderr',
                 'execution-stage.stdout', 'binding-preparation2.stdout'):
        add('controls/' + name, BUILD / name)
    for name in ('terminal.json', 'remote.stdout', 'ssh.stderr'):
        add('controls/replay-transport/' + name, BUILD / 'replay-observation1' / name)
    for name in ('manifest.json', 'binding.schema.json', 'RAW-EVIDENCE-CONTRACT.json', 'P1-REVIEW-HANDOFF.md',
                 'cpu-tests-p1-compat-final.log', 'cpu-tests-p1-compat-optimized.log'):
        add('controls/adapter/' + name, ADAPTER / name)
    add('input/input.json', CANDIDATE / 'input/input.json')
    for name in ('contiguous', 'paged'):
        payloads['input/captures/' + name + '.bin'] = captures[name]
    payloads['analysis/independent-review.json'] = encoded(review)
    payloads['controls/preserved-failures.json'] = encoded(failures)
    payloads['analysis/external-input-bank.json'] = encoded(numerical['input_bank'])
    proof_files = read(RAW / 'replay-evidence-manifest.json')['files']
    linked = 0
    for name, raw in payloads.items():
        require(not re.search(rb'-----BEGIN (?:[A-Z ]*PRIVATE KEY|CERTIFICATE)-----', raw), 'sensitive payload: ' + name)
        require(not raw.startswith((b'\xcf\xfa\xed\xfe', b'\xca\xfe\xba\xbe', b'\x7fELF', b'MTLB')), 'runtime binary: ' + name)
        require(not name.endswith(('.metallib', '.air', '.safetensors', '.pem', '.p12', '.pfx')), 'excluded payload')
        if name.startswith('build/') and name[6:] in proof_files:
            expected = proof_files[name[6:]]
            require(digest(raw) == expected['sha256'] and len(raw) == expected['bytes'], 'raw-proof subset mismatch: ' + name)
            linked += 1
    require(sum(map(len, payloads.values())) < 16 << 20, 'capsule exceeds 16 MiB uncompressed bound')
    BANK.mkdir(parents=True)
    archive_path = BANK / 'payloads.tar.gz'
    with archive_path.open('xb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as archive:
                for name, raw in sorted(payloads.items()):
                    entry = tarfile.TarInfo(name)
                    entry.size, entry.mode, entry.mtime = len(raw), 0o644, 0
                    archive.addfile(entry, io.BytesIO(raw))
    manifest = {'schema': 'darkbloom.q36-partials-bank.v1', 'scope': 'One ephemeral sealed Q36 B1/D256 partial-storage discriminator, not model/production acceptance.',
                'archive': identity(archive_path), 'files': {name: {'bytes': len(raw), 'sha256': digest(raw), 'mode': 420} for name, raw in sorted(payloads.items())},
                'payload_count': len(payloads), 'uncompressed_bytes': sum(map(len, payloads.values())), 'raw_proof_subset_files_verified': linked,
                'adapter_manifest_sha256': FINAL_ADAPTER, 'm5_raw_proof_manifest_sha256': RAW_PROOF,
                'external_input_bank': numerical['input_bank'],
                'excluded': ['runtime executables/metallibs/AIR', 'full source copies', 'private keys/certificates', 'weights',
                             '11 MiB common Q/K/V already banked', 'redundant 77 MiB metallib strings dumps', 'full remote build tree']}
    (BANK / 'manifest.json').write_bytes(encoded(manifest))
    (BANK / 'independent-review.json').write_bytes(encoded(review))
    (BANK / 'preserved-failures.json').write_bytes(encoded(failures))
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        require(len(members) == len(payloads) and {entry.name for entry in members} == set(payloads), 'archive enumeration differs')
        for entry in members:
            require(entry.isfile() and not Path(entry.name).is_absolute() and '..' not in Path(entry.name).parts, 'unsafe archive entry')
            require(digest(archive.extractfile(entry).read()) == manifest['files'][entry.name]['sha256'], 'archive verification failed')
    print(json.dumps({'bank': str(BANK), 'manifest': identity(BANK / 'manifest.json'), 'archive': manifest['archive'],
                      'payload_count': len(payloads), 'uncompressed_bytes': manifest['uncompressed_bytes'],
                      'raw_proof_subset_files_verified': linked, 'rounded_reference_mismatches': numerical['rounded_reference_mismatches'],
                      'result': pair}, indent=2))


if __name__ == '__main__':
    main()
