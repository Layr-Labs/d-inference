from pathlib import Path
import json,hashlib,shlex,subprocess,sys,time
cell=sys.argv[1];source=Path('/tmp/darkbloom-q36-actual-logits-plan3/package');plan=json.loads((source/'plan.json').read_text());assert hashlib.sha256((source/'plan.json').read_bytes()).hexdigest()=='47aa13bc8505fb6226da10330ba5148da70ce0f6d073c1bd22fc472a464139c7';chosen=next(c for c in plan['cells'] if c['id']==cell);command=chosen['argv'];review=Path('/tmp/darkbloom-q36-actual-logits-plan-root-review.json');assert json.loads(review.read_text())['plan_sha256']=='47aa13bc8505fb6226da10330ba5148da70ce0f6d073c1bd22fc472a464139c7';local=Path('/tmp/darkbloom-q36-actual-logits-execution1')/cell;local.mkdir(parents=True,exist_ok=False);remote=command[command.index('--output')+1];ssh=['ssh','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','-o','ConnectTimeout=15','gaj@100.124.35.99']
r=subprocess.run(['python3','-B','/tmp/darkbloom-fleet-smoke-continuation/preflight.py',str(local/'ownership-before.json')],capture_output=True,text=True);(local/'ownership-before.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stdout+r.stderr
check='''from pathlib import Path
import hashlib,json,datetime,shutil
root=Path(ROOT);assert hashlib.sha256((root/'approved-plan-review.json').read_bytes()).hexdigest()==REVIEW_SHA;assert hashlib.sha256((root/'plan.json').read_bytes()).hexdigest()=='47aa13bc8505fb6226da10330ba5148da70ce0f6d073c1bd22fc472a464139c7';assert not Path(OUTPUT).exists();p=json.loads((root/'plan.json').read_text());date=datetime.datetime.now(datetime.timezone.utc).date().isoformat();assert date=='2026-09-05';free=shutil.disk_usage(root).free;assert free>p['execution_guards']['min_free_bytes'];manifest=json.loads((root/'package-manifest.json').read_text());assert hashlib.sha256((root/'package-manifest.json').read_bytes()).hexdigest()=='b1ee3c53492c0f90787e6dbefd9fc5d46c84e386f93c63e495bc2d818393b071'
for name,item in manifest['files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==item['sha256']
runtime_root=Path('/Users/gaj/autoresearch/radix-prefix-cache/090-final-serving-build8/artifact');am=json.loads((root/'runtime-proof/artifact-manifest.json').read_text());verified={}
for name,item in am['files'].items():
 actual=hashlib.sha256((runtime_root/name).read_bytes()).hexdigest();assert actual==item['sha256'];verified[name]=actual
selected=next(c for c in p['cells'] if c['id']==CELL);assert selected['argv']==ARGV
print(json.dumps({'date_utc':date,'free_bytes':free,'runtime_sha256':verified,'cell':CELL,'scope':'Exact reviewed argv/package/runtime, fresh root and minimum storage verified'},indent=2))
'''.replace('ROOT',repr(plan['remote_root'])).replace('REVIEW_SHA',repr(hashlib.sha256(review.read_bytes()).hexdigest())).replace('OUTPUT',repr(remote)).replace('CELL',repr(cell)).replace('ARGV',repr(command));r=subprocess.run(ssh+['python3 -B -'],input=check,text=True,capture_output=True);(local/'runtime-precheck.stdout').write_text(r.stdout);(local/'runtime-precheck.stderr').write_text(r.stderr);assert r.returncode==0,r.stderr
(local/'command.json').write_text(json.dumps(chosen,indent=2)+'\n');start=time.monotonic()
with (local/'ssh-run.log').open('x') as log:r=subprocess.run(ssh+[shlex.join(command)],stdout=log,stderr=subprocess.STDOUT)
rc=r.returncode;(local/'execution.json').write_text(json.dumps({'exit_code':rc,'seconds':time.monotonic()-start,'scope':plan['scope']},indent=2)+'\n')
code='''from pathlib import Path
import hashlib,json
root=Path(ROOT);files={}
if root.exists():
 for p in sorted(root.iterdir()):
  if p.is_file() and not p.is_symlink():files[p.name]={'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
print(json.dumps({'root':str(root),'files':files},indent=2))
'''.replace('ROOT',repr(remote));r=subprocess.run(ssh+['python3 -B -'],input=code,text=True,capture_output=True);assert r.returncode==0,r.stderr;(local/'remote-inventory.json').write_text(r.stdout)
for name,item in json.loads(r.stdout)['files'].items():
 assert all(c.isalnum() or c in '.-_' for c in name);p=local/name;x=subprocess.run(['scp','-i','/Users/gaj/.ssh/darkbloom_testbox','-o','IdentitiesOnly=yes','-o','BatchMode=yes','gaj@100.124.35.99:'+remote+'/'+name,str(p)],capture_output=True,text=True);assert x.returncode==0,x.stderr;assert p.stat().st_size==item['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==item['sha256']
summary={'cell':cell,'exit_code':rc,'trace':chosen['trace'],'scope':'MTP-off diagnostic only; traced timings are not performance evidence; no comparison waiver'}
if (local/'report.json').exists():
 sys.path.insert(0,str(source/'runner'));from radix_engine_evidence import report_errors
 r=json.loads((local/'report.json').read_text());errors=report_errors(r);summary.update(passed_report_integrity=not errors,errors=errors,mtp=r.get('mtp'),rows=[{k:v.get(k) for k in ('id','prompt_tokens','completion_tokens','finish')} for v in r.get('rows',[])],logit_diagnostic=r.get('logit_diagnostic'))
(local/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');files={str(p.relative_to(local)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(local.rglob('*')) if p.is_file()};(local/'manifest.json').write_text(json.dumps({'scope':summary['scope'],'files':files},indent=2)+'\n');display=dict(summary);display.pop('logit_diagnostic',None);display['logit_diagnostic_status']=(summary.get('logit_diagnostic') or {}).get('status');print(json.dumps(display,indent=2));print('manifest_sha256',hashlib.sha256((local/'manifest.json').read_bytes()).hexdigest());sys.exit(rc or (1 if summary.get('errors') else 0))
