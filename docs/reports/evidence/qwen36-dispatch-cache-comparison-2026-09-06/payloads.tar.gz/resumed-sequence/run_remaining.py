from pathlib import Path
import hashlib,json,subprocess,sys,time
ROOT=Path(__file__).resolve().parent
DRIVER=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-execution1/run_cell.py')
PLAN=Path('/tmp/darkbloom-q36-paged-plan-cache-comparison-plan1/plan.json')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
plan=json.loads(PLAN.read_text());records=[]
for cell in plan['cells'][5:]:
 # Check the original guard before the driver creates a fresh local cell root.
 # Only a temperature-only refusal permits bounded cooling; every observation is retained.
 for attempt in range(9):
  path=ROOT/(cell['id']+'-readiness-'+str(attempt)+'.json')
  check=subprocess.run([sys.executable,'-B',str(DRIVER.parent/'preflight.py'),str(path)],text=True,capture_output=True)
  path.with_suffix('.log').write_text(check.stdout+check.stderr)
  if check.returncode==0:break
  state=json.loads(path.read_text())
  if state['processes'] or state['load'][0]>4 or state['free_disk_bytes']<=100*1024**3 or state['gpu_temp_c']<=42 or attempt==8:
   raise SystemExit('original readiness guard failed beyond bounded temperature-only cooling')
  print(json.dumps({'cooling_before':cell['id'],'attempt':attempt,'gpu_temp_c':state['gpu_temp_c']}),flush=True)
  time.sleep(15)
 start=time.time();command=[sys.executable,'-B',str(DRIVER),cell['id']]
 print(json.dumps({'starting':cell['id'],'unix_time':start}),flush=True)
 result=subprocess.run(command)
 record={'cell':cell['id'],'command':command,'started_unix':start,'ended_unix':time.time(),'exit_code':result.returncode,'driver_sha256':sha(DRIVER)}
 records.append(record);(ROOT/'executions.json').write_text(json.dumps(records,indent=2)+'\n')
 if result.returncode:raise SystemExit(result.returncode)
print(json.dumps({'sequence_complete':True,'remaining_cells_completed':len(records)}),flush=True)
