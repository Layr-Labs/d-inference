from pathlib import Path
import gzip,hashlib,json,re,shutil
out=Path('/tmp/darkbloom-final-serving-build6');ws=out/'workspace';unit=Path('/tmp/darkbloom-q35-mtp-useful-tail-validation1');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
execution=json.loads((out/'execution.json').read_text());assert execution['exit_code']==0
known={}
def add(path,digest,group):
 key=str(path.resolve());prior=known.get(key);assert prior is None or prior['sha256']==digest,key;known[key]={'sha256':digest,'group':group}
for name,digest in json.loads((out/'provider-source-manifest.json').read_text())['files'].items():add(ws/name,digest,'provider')
for name,digest in json.loads((out/'native-source-manifest.json').read_text())['files'].items():add(ws/'libs/mlx-swift-lm'/name,digest,'native')
deps=json.loads((out/'dependency-source-manifest.json').read_text())
for key,digest in deps['files'].items():
 alias,name=key.split('/',1);add(Path(deps['repositories'][alias])/name,digest,'dependency')
for name,digest in json.loads((out/'jinja-source-manifest.json').read_text())['files'].items():add(Path('/tmp/darkbloom-final-serving-build1/build/checkouts/swift-jinja')/name,digest,'jinja')
for name,row in json.loads((out/'compile-source-manifest.json').read_text())['files'].items():add(out/name,row['sha256'],'harness')
text=gzip.decompress((out/'actual-build-graph.yaml.gz').read_bytes()).decode();matches={}
for literal in re.findall(r'"(/[^"\n]+\.(?:swift|cpp|c|h|metal))"',text):
 path=Path(literal);key=str(path.resolve())
 if key not in known:continue
 row=known[key];assert sha(path)==row['sha256'],literal;matches[literal]={'resolved_frozen_source':key,**row}
(out/'all-owned-graph-source-proof.json').write_text(json.dumps({'scope':'Every graph input under the frozen source maps resolves to matching bytes. Graph membership is planned compilation, while the release command/log establishes the executed product.','counts':{g:sum(x['group']==g for x in matches.values()) for g in ['provider','native','dependency','jinja','harness']},'files':matches},indent=2)+'\n')
canonical=json.loads((unit/'canonical-owned-manifest.json').read_text())
for row in canonical['files']:
 path=Path(row['path']);target=out/'owned'/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(unit/'owned'/path,target);assert sha(target)==row['after_sha256']
(out/'canonical-owned-manifest.json').write_text(json.dumps(canonical,indent=2)+'\n')
art=json.loads((out/'artifact-manifest.json').read_text())
for name,row in art['files'].items():assert sha(out/'artifact'/name)==row['sha256']
summary={'status':'PASS','scope':'Distinct useful-tail release probe; new native units passed separately. No exact model/HTTP/performance result claimed.','execution':execution,'provider_inputs':677,'native_inputs':481,'dependency_inputs':1356,'jinja_inputs':27,'harness_inputs':12,'harness_unchanged_from_build5':True,'canonical_native_paths':2,'source_patch_sha256':sha(out/'native-useful-tail.patch'),'binary':art['files']['radix-engine'],'inherited_runtime_resources':6,'cli_rebuilt':False,'unit_manifest':str(unit/'manifest.json'),'unit_manifest_sha256':sha(unit/'manifest.json'),'next_gate':'Both normal-MTP Q35 arms use this probe, with maxTokens32 and a longer output budget; prior failures retained.'}
(out/'verdict.json').write_text(json.dumps(summary,indent=2)+'\n')
files={}
for path in sorted(out.rglob('*')):
 if not path.is_file():continue
 rel=path.relative_to(out)
 if rel.parts[0] in ['workspace','artifact','radix-engine'] or rel==Path('manifest.json'):continue
 files[str(rel)]={'sha256':sha(path),'bytes':path.stat().st_size}
(out/'manifest.json').write_text(json.dumps({'schema':1,'status':'PASS: release build; real model validation pending','files':files,'runtime_artifacts':art,'unit_manifest_sha256':summary['unit_manifest_sha256']},indent=2)+'\n')
print(json.dumps({'manifest_sha256':sha(out/'manifest.json'),'payloads':len(files),'verdict':summary},indent=2))
