"""Canonical owned M5 build/tests; no real-model pilot or serving process."""
from pathlib import Path
import gzip,hashlib,json,os,re,shutil,subprocess,time,sys
import owner_helper
ROOT=Path(__file__).resolve().parent
SOURCE=ROOT/'workspace'; ARTIFACT=ROOT/'artifact'; RELEASE=ROOT/'release-build'; TEST_BUILD=ROOT/'native-test-build6'
MANIFEST=json.loads((ROOT/'source-manifest.json').read_text())
REPOS={row['name']:SOURCE/row['relative_path'] for row in MANIFEST['repositories']}
ENV={'HOME':str(Path.home()),'PATH':'/opt/homebrew/bin:/usr/bin:/bin:/usr/sbin:/sbin','TMPDIR':'/private/tmp',
     'DEVELOPER_DIR':'/Applications/Xcode.app/Contents/Developer','RADIX_SOURCE_ROOT':str(SOURCE),'RADIX_CANDIDATE_BUILD':'1',
     'MAKEFLAGS':'-j4','METALLIB_CACHE_DIR':str(ROOT/'metallib-cache')}
EXECUTIONS=[]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def identity(path):
 p=Path(path);return {'sha256':sha(p),'bytes':p.stat().st_size,'mode':p.stat().st_mode&0o777}
def write(path,value):
 p=Path(path);tmp=p.with_name(p.name+'.tmp');tmp.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n');tmp.replace(p)
def state(value):
 write(ROOT/'native6-build-status.json',value)
def verify_sources():
 for name,repo in REPOS.items():
  head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip()
  dirty=subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)
  if head!=MANIFEST['source'][name] or dirty:raise ValueError('canonical source drift: '+name+' '+dirty)
  for relative,expected in MANIFEST['files'][name].items():
   if identity(repo/relative)!=expected:raise ValueError('payload drift: '+name+'/'+relative)
 return {'source':MANIFEST['source'],'all_canonical_sources_clean':True}
def command(name,argv,cwd=SOURCE,timeout=3600):
 step=ROOT/'steps'/name;step.mkdir(mode=0o700)
 started=time.time();state({'state':'starting','step':name,'argv':argv,'cwd':str(cwd)})
 def emit(event):
  value=dict(event,step=name,role='build_or_native_test',log=str(step/'provider.log'))
  if event.get('event')=='started':state(dict(value,state='running',argv=argv,cwd=str(cwd),started_unix=started))
  print(json.dumps(value),flush=True)
 previous=Path.cwd()
 try:
  os.chdir(cwd)
  record=owner_helper.run_owner(argv,ENV,step,sys.stdin.buffer,emit,lease_seconds=30,deadline_seconds=timeout)
 finally:
  os.chdir(previous)
  if (step/'provider.log').exists():shutil.copy2(step/'provider.log',ROOT/'logs'/(name+'.log'))
 result=dict(record,step=name,argv=argv,cwd=str(cwd),seconds=time.time()-started)
 EXECUTIONS.append(result);write(ROOT/'native6-executions.json',EXECUTIONS)
 if record['failure'] is not None or record['exit_code']!=0 or not record['group_cleanup_complete'] or record['stop_requested']:
  raise RuntimeError('owned command failed: '+name)
 return ROOT/'logs'/(name+'.log')

def graph_proof(name,scratch,source_roots):
 candidates=[scratch/'release.yaml',scratch/'debug.yaml'];graph=next((p for p in candidates if p.is_file()),None)
 if graph is None:raise ValueError('SwiftPM build graph missing: '+name)
 text=graph.read_text();(ROOT/(name+'-graph.yaml.gz')).write_bytes(gzip.compress(graph.read_bytes(),mtime=0))
 if '/checkouts/mlx-swift/Source/' in text or (str(SOURCE/'libs/mlx')+'/') in text:raise ValueError('noncanonical MLX source entered graph')
 paths={}
 for value in re.findall(r'"(/[^"\n]+\.(?:swift|cpp|cc|c|h|hpp|metal|mm|modulemap))"',text):
  p=Path(value)
  if p.is_file() and any(p.resolve().is_relative_to(x.resolve()) for x in source_roots):paths[str(p)]=identity(p)
 for suffix in ['quantized.cpp','ForwardShapeV2.swift','ForwardShapeDispatchV2.swift','EngineLoopV2+ForwardShapes.swift']:
  if not any(p.endswith(suffix) for p in paths):raise ValueError('required source absent from graph: '+suffix)
 write(ROOT/(name+'-source-graph.json'),{'source':MANIFEST['source'],'files':paths,'local_mlx_only':True})
 if (scratch/'workspace-state.json').exists():shutil.copy2(scratch/'workspace-state.json',ROOT/(name+'-workspace-state.json'))
 checkouts={}
 for repo in sorted((scratch/'checkouts').glob('*')):
  if (repo/'.git').exists():checkouts[repo.name]={'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'dirty':subprocess.check_output(['git','status','--porcelain'],cwd=repo,text=True)}
 write(ROOT/(name+'-dependency-checkouts.json'),checkouts)

def purge_owned_resources(roots):
 removed=[]
 for base in roots:
  if not base.exists():continue
  for p in sorted(base.rglob('mlx.metallib')):
   if p.is_file():removed.append(str(p));p.unlink()
  for p in sorted(base.glob('*-apple-macosx/*/*.bundle')):
   if p.is_dir():removed.append(str(p));shutil.rmtree(p)
 return removed

def stage_test_metallib():
 destinations=[TEST_BUILD/'arm64-apple-macosx/debug/mlx.metallib']
 debug=TEST_BUILD/'arm64-apple-macosx/debug'
 for bundle in debug.glob('*PackageTests.xctest'):
  macos=bundle/'Contents/MacOS'
  if macos.is_dir():destinations.append(macos/'mlx.metallib')
 if len(destinations)<2:raise ValueError('native xctest bundle not discovered')
 for p in destinations:shutil.copy2(ARTIFACT/'mlx.metallib',p)
 copies={str(p):identity(p) for p in destinations}
 if any(v['sha256']!=sha(ARTIFACT/'mlx.metallib') for v in copies.values()):raise ValueError('test metallib mismatch')
 write(ROOT/'native6-test-metallib-copies.json',copies)

ENV.update({'GIT_CONFIG_COUNT':'3','GIT_CONFIG_KEY_0':'protocol.file.allow','GIT_CONFIG_VALUE_0':'always','GIT_CONFIG_KEY_1':'url.'+str(REPOS['core'])+'.insteadOf','GIT_CONFIG_VALUE_1':'https://github.com/Layr-Labs/mlx.git','GIT_CONFIG_KEY_2':'url.'+str(REPOS['c'])+'.insteadOf','GIT_CONFIG_VALUE_2':'https://github.com/Layr-Labs/mlx-c.git'})
def pins(path,exclude=()):
 return {p['identity']:p for p in json.loads(path.read_text())['pins'] if p['identity'] not in exclude}
def lock_receipt(stage,path):
 write(ROOT/('native6-lock-'+stage+'.json'),{'identity':identity(path),'lock':json.loads(path.read_text())})
def assert_native_pins(path):
 actual=pins(path,exclude=['mlx-swift']);expected=pins(ROOT/'native-seed.resolved',exclude=['mlx-swift'])
 if actual!=expected:raise ValueError('native dependency revisions drifted from reviewed projection')
try:
 write(ROOT/'native-source-before.json',verify_sources())
 test_parent=ROOT/'native-tests6';test_parent.mkdir();test_source=test_parent/'workspace';shutil.copytree(REPOS['native'],test_source,symlinks=True)
 fixture=json.loads((ROOT/'fixture-proof.json').read_text())
 command('native6-fixture-fetch',['git','fetch',str(ROOT/'fixture.bundle'),'HEAD'],test_source,120)
 command('native6-fixture-checkout',['git','checkout','--detach',fixture['test_fixture_commit']],test_source,120)
 write(ROOT/'native6-fixture-source-before.json',fixture)
 (test_parent/'mlx-swift').symlink_to(REPOS['swift'],target_is_directory=True)
 lock=test_source/'Package.resolved';shutil.copy2(ROOT/'native-seed.resolved',lock);lock_receipt('seed',lock)
 command('native6-mirror',['swift','package','--scratch-path',str(TEST_BUILD),'config','set-mirror','--original','https://github.com/Layr-Labs/mlx-swift.git','--mirror',str(REPOS['swift'])],test_source,120)
 write(ROOT/'native6-mirror-proof.json',{'mirror':json.loads((test_source/'.swiftpm/configuration/mirrors.json').read_text()),'git_environment':{k:v for k,v in ENV.items() if k.startswith('GIT_CONFIG')},'purpose':'Resolve reviewed unpushed commit locally before canonical swift package edit; no code or global git config modification.'})
 command('native6-resolve-locked',['swift','package','--scratch-path',str(TEST_BUILD),'--disable-automatic-resolution','resolve'],test_source,1800)
 lock_receipt('resolved',lock);assert_native_pins(lock)
 if pins(lock)['mlx-swift']['state']!={'revision':MANIFEST['source']['swift']}:raise ValueError('wrong resolved mlx revision')
 command('native6-local-mlx-locked',['swift','package','--scratch-path',str(TEST_BUILD),'--disable-automatic-resolution','edit','--path',str(REPOS['swift']),'mlx-swift'],test_source,600)
 lock_receipt('edited',lock);assert_native_pins(lock)
 changed=subprocess.check_output(['git','diff','--name-only'],cwd=test_source,text=True).splitlines()
 if set(changed)-{'Package.resolved'}:raise ValueError('native test code changed during local edit')
 immediate=json.loads((TEST_BUILD/'workspace-state.json').read_text());write(ROOT/'native6-immediate-edit-state.json',immediate)
 edited=[d for d in immediate['object']['dependencies'] if d['packageRef']['identity']=='mlx-swift'];assert len(edited)==1 and edited[0]['state']['name']=='edited',edited
 projected=json.loads(lock.read_text());removed=[p for p in projected['pins'] if p['identity']=='mlx-swift'];assert len(removed)==1
 projected['pins']=[p for p in projected['pins'] if p['identity']!='mlx-swift'];write(lock,projected)
 write(ROOT/'native6-edited-lock-projection.json',{'removed_only':removed,'reason':'SwiftPM locked resolution rechecks pins in edited state; edited local package must be excluded from remote lock entries.','other_pins_unchanged':True,'seed':'native-seed.resolved','projected_lock':identity(lock),'originHash_unchanged':projected.get('originHash')==json.loads((ROOT/'native-seed.resolved').read_text()).get('originHash')})
 assert_native_pins(lock);lock_receipt('projected',lock)
 dependency_log=command('native6-show-dependencies-locked',['swift','package','--scratch-path',str(TEST_BUILD),'--disable-automatic-resolution','show-dependencies','--format','json'],test_source,600)
 current=json.loads((TEST_BUILD/'workspace-state.json').read_text());write(ROOT/'native6-prebuild-workspace-state.json',current)
 edited=[d for d in current['object']['dependencies'] if d['packageRef']['identity']=='mlx-swift'];assert len(edited)==1 and edited[0]['state']['name']=='edited',edited
 assert edited[0]['state']['path']==str(REPOS['swift']),edited
 assert '"path" : "'+str(REPOS['swift'])+'"' in dependency_log.read_text() or '"path": "'+str(REPOS['swift'])+'"' in dependency_log.read_text(),'canonical source missing from dependency graph'
 command('native6-build-tests',['swift','build','--build-tests','--scratch-path',str(TEST_BUILD),'--jobs','4','--disable-automatic-resolution'],test_source,3600)
 lock_receipt('built',lock);assert_native_pins(lock)
 graph_proof('native-tests-fixture-v1',TEST_BUILD,[SOURCE,test_source]);stage_test_metallib()
 for suite in ['CBv2ForwardShapeEngineTests','GPTOSSCompiledExpertsTests','CBv2MTPRoundSmokeTests']:
  log=command('native6-test-'+suite,['bash',str(SOURCE/'scripts/run-nested-suite.sh'),suite,'--no-parallel','--scratch-path',str(TEST_BUILD),'--disable-automatic-resolution'],test_source,1800)
  if suite=='CBv2ForwardShapeEngineTests' and 'firstScopeRefusesDiscardedChainedWorkBeforeItsReadback' not in log.read_text():raise ValueError('activation regression did not execute')
 for relative,expected in MANIFEST['files']['native'].items():
  if relative==fixture['test_only_changed_file']:
   if sha(test_source/relative)!=fixture['new_file_sha256']:raise ValueError('test fixture repair drift')
  elif identity(test_source/relative)!=expected:raise ValueError('native test source drift: '+relative)
 write(ROOT/'source-final.json',verify_sources());assert_native_pins(lock)
 for product in ['darkbloom','radix-engine']:
  command(product+'-codesign',['codesign','--verify','--strict','--verbose=2',str(ARTIFACT/product)],ROOT,120)
  command(product+'-signature',['codesign','-d','--verbose=4',str(ARTIFACT/product)],ROOT,120)
  command(product+'-dylibs',['otool','-L',str(ARTIFACT/product)],ROOT,120)
 command('cli-help',[str(ARTIFACT/'darkbloom'),'--help'],ROOT,60)
 files={str(p.relative_to(ARTIFACT)):identity(p) for p in ARTIFACT.rglob('*') if p.is_file()}
 if len(files)!=8:raise ValueError('canonical artifact must contain eight files')
 write(ROOT/'artifact-manifest.json',{'source':MANIFEST['source'],'files':files,'canonical_swiftpm_build':True,'manual_object_link':False,'M5_built':True,'real_model_pilot':False,'native_test_fixture':fixture,'shader_reuse_proof':'shader-reuse-proof.json','lock_proof':'lock-proof.json'})
 state({'state':'BUILD_AND_NATIVE_TESTS_COMPLETE_ARTIFACT_REVIEW_REQUIRED','source':MANIFEST['source'],'artifact_manifest':str(ROOT/'artifact-manifest.json'),'model_pilot_performed':False})
except BaseException as error:
 state({'state':'FAILED','error':type(error).__name__+': '+str(error),'completed_steps':EXECUTIONS,'model_pilot_performed':False})
 raise
