from pathlib import Path
import collections,gzip,hashlib,json,re,shutil,subprocess
root=Path('/Users/gaj/Documents/DarkbloomDev/wt/cache-stage-measurement')
out=Path('/tmp/darkbloom-cache-stage-measurement')
freeze=out/'freeze1'
assert not freeze.exists(), 'preserve existing freeze'
def sha(b):return hashlib.sha256(b).hexdigest()
def result(name):
 p=out/'evidence'/(name+'.jsonl');counts=collections.Counter();packages=[];skips=[];failed=[]
 for line in p.read_text().splitlines():
  d=json.loads(line)
  if d.get('Action') not in ('pass','fail','skip'):continue
  if d.get('Test'):
   counts[d['Action']+('_subtests' if '/' in d['Test'] else '_functions')]+=1
   if d['Action']=='skip':skips.append(d['Test'])
   if d['Action']=='fail':failed.append(d['Test'])
  else:packages.append({k:d[k] for k in ('Package','Action','Elapsed') if k in d})
 return {'counts':dict(counts),'packages':packages,'skipped_tests':skips,'failed_tests':failed,'raw_sha256':sha(p.read_bytes())}
full=result('full-final');race=result('race-final');baseline=result('baseline-final');gap=result('query-gap-before-fix');focused=result('focused4')
assert len(full['packages'])==3 and all(p['Action']=='pass' for p in full['packages']),full
assert len(race['packages'])==2 and all(p['Action']=='pass' for p in race['packages']),race
assert not full['failed_tests'] and not race['failed_tests']
assert baseline['counts'].get('fail_functions')==7 and baseline['counts'].get('fail_subtests')==4,baseline
assert gap['counts'].get('fail_functions')==1 and gap['counts'].get('fail_subtests')==2,gap
assert focused['counts'].get('pass_functions')==8 and focused['counts'].get('pass_subtests')==13,focused
source=json.loads((out/'final-source-hashes.json').read_text())['files']
paths=subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines()
assert set(paths)==set(source) and len(paths)==7
for p,h in source.items():assert sha((root/p).read_bytes())==h,p
patch=subprocess.check_output(['git','diff','--binary'],cwd=root)
assert patch==(out/'source.patch').read_bytes()
patch_paths=re.findall(r'^diff --git a/(\S+) b/(\S+)$',patch.decode(),re.M)
assert len(patch_paths)==7 and all(a==b for a,b in patch_paths) and {a for a,b in patch_paths}==set(paths)
subprocess.run(['git','diff','--check'],cwd=root,check=True)
subprocess.run(['git','apply','--check','--cached',str(out/'source.patch')],cwd='/tmp/darkbloom-cache-stage-measurement-baseline',check=True)
assert not subprocess.check_output(['gofmt','-l']+[p for p in paths if p.endswith('.go')],cwd=root)
freeze.mkdir()
files=[]
for p in paths:
 b=(root/p).read_bytes();dest=freeze/'files'/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
 files.append({'path':p,'sha256':sha(b),'bytes':len(b)})
(freeze/'source.patch').write_bytes(patch)
shutil.copyfile(out/'REVIEW.md',freeze/'REVIEW.md')
shutil.copyfile(out/'final-source-hashes.json',freeze/'final-source-hashes.json')
shutil.copytree(out/'review1',freeze/'superseded-review1')
(freeze/'evidence').mkdir()
for p in sorted((out/'evidence').iterdir()):
 if p.suffix=='.jsonl':(freeze/'evidence'/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
 elif p.is_file():shutil.copyfile(p,freeze/'evidence'/p.name)
verification={'go_toolchain':'go1.25.0 darwin/arm64','final_full':full,'final_race':race,'new_focused':focused,'baseline_expected_failure':baseline,'superseded_draft_query_gap_expected_failure':gap,'superseded_first_full':result('full-before-query-fix'),'superseded_first_race':result('race-before-query-fix'),'commands':{'full':'GOTOOLCHAIN=go1.25.0 go test ./registry ./api ./protocol -count=1 -json','race':"GOTOOLCHAIN=go1.25.0 go test -race ./registry ./api -run 'Test.*(Cache|Checkpoint|SSD|ProviderInference)' -count=1 -json",'focused_and_baseline':"GOTOOLCHAIN=go1.25.0 go test ./registry -run 'TestSSD(MeasuredStage|ReadyDoesNotExtend|NewLookupReplaces|Measurement|Stage)' -count=1 -json",'query_gap_draft':'GOTOOLCHAIN=go1.25.0 go test ./registry -run TestSSDMeasuredStageQueryFencesCapabilityPublication -count=1 -json','docs':'make docs-check'},'docs':'166 files pass','gofmt':'all 5 owned Go files clean','diff_check':'pass','patch_path_set':'7 source paths exact, new files included','base_index_apply_check':'02f6af71, pass','current_parent_apply_check':'06b02df7, pass','limits':['No provider, protocol, configuration or default changes','No Swift/Metal/GPU/model/network builds or measurements','Baseline and superseded failures are negative controls; superseded full/race do not validate final source','No live rollout action or commit from this lane']}
(freeze/'verification.json').write_text(json.dumps(verification,indent=2)+'\n')
shutil.copyfile(Path(__file__),freeze/'freeze.py')
artifacts={str(p.relative_to(freeze)):{'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size} for p in sorted(freeze.rglob('*')) if p.is_file() and not str(p.relative_to(freeze)).startswith('files/')}
manifest={'schema':1,'base':'02f6af71a5a972a655608f3fa6063d47670c3878','branch':'optimizations/cache-stage-measurement','worktree':str(root),'status':'validated isolated uncommitted patch; root bank pending','files':files,'patch_sha256':sha(patch),'source_paths':paths,'production_go_paths':[p for p in paths if p.endswith('.go') and not p.endswith('_test.go')],'test_paths':[p for p in paths if p.endswith('_test.go')],'docs_paths':[p for p in paths if p.endswith('.md')],'patch_paths_verified':True,'verification':verification,'artifacts':artifacts}
(freeze/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for record in files:assert sha((freeze/'files'/record['path']).read_bytes())==record['sha256']
for p,record in artifacts.items():assert sha((freeze/p).read_bytes())==record['sha256']
assert len(files)+len(artifacts)==len([p for p in freeze.rglob('*') if p.is_file()])-1
print(json.dumps({'manifest':str(freeze/'manifest.json'),'manifest_sha256':sha((freeze/'manifest.json').read_bytes()),'source_paths':len(files),'artifacts':len(artifacts),'full':full['counts'],'race':race['counts']},indent=2))
