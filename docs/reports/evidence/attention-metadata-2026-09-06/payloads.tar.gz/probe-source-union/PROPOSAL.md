Build one isolated optimized radix-engine probe from primary 5b931 plus native 847e320 and the six parent metadata files. The native source is already banked; the parent additions include the separately frozen combined-option tests. Use the same pinned dependency overlays and six runtime resources validated by build8.

Native tests passed and are frozen independently. Benchmark option and idle tests must pass and freeze before this plan can be authorized. Compilation requires root review. The build records exact source correspondence, declared compiler graph, binary identity/mode and resource hashes. The existing CLI8 is not rebuilt by this probe-only plan.

Namespace and cancellation candidates, model execution, remote transfer and production changes are outside this diagnostic build. Root owns the four-cell runtime plan.

Plan2 records the completed 14-test benchmark validation and corrects two test-file byte lengths. All source hashes, source patch, native correspondence and test results remain unchanged. Build preparation consumes the corrected source manifest; plan1 is preserved.
