from pathlib import Path
import math
import struct

from common import checked_file, finite_number, read_json, require
from runtime_identity import validate_snapshot

PROBE_FILES = ('go.stdout', 'go.stderr', 'live.json', 'process.json')
REQUIRED_FILES = {'binding.json', 'readiness.json', 'foundation-home.json', 'command.json', 'provider.toml',
                  'report.json', 'stderr.log', *PROBE_FILES,
                  *('readiness-probe/' + name for name in PROBE_FILES),
                  *('foundation-probe/' + name for name in PROBE_FILES)}


def process_checks(record, expected_argv=None):
    require(type(record.get('pid')) is int and record['pid'] > 0 and record.get('pgid') == record['pid'], 'identified owned process group required')
    require(record.get('exit_code') == 0 and record.get('failure') is None and record.get('group_cleanup_complete') is True, 'process exit or group cleanup failed')
    require(record.get('signal_errors') == [], 'owned group signal errors')
    if expected_argv is not None:
        require(record.get('argv') == expected_argv, 'owned process argv differs')


def process_file_checks(output, expected_argv=None):
    record = read_json(output / 'process.json')
    process_checks(record, expected_argv)
    require(read_json(output / 'live.json') == {key: record[key] for key in ('pid', 'pgid', 'argv')}, 'live/terminal owned process identity differs')
    return record


def readiness_checks(value, binding):
    require(value.get('processes') == [], 'conflicting inference process')
    require(finite_number(value.get('gpu_temp_c'), 0, 42) and finite_number(value['load'][0], 0, 4), 'temperature/load readiness refused')
    require(type(value.get('free_disk_bytes')) is int and value['free_disk_bytes'] > 20 * (1 << 30), 'disk readiness refused')
    username, address = binding['target_host'].split('@')
    require(value.get('username') == username and address in value.get('ipv4_addresses', []), 'execution host/user differs')
    for key in ('hardware_model', 'memory_bytes'):
        require(value.get(key) == binding['host_identity'][key], 'execution hardware identity differs: ' + key)


def report_checks(report, model, cell, binding, input_value, snapshot, plan):
    runtime = binding['runtime']['files']
    require(report['schema'] == 1 and report['scope'] == 'ordinary_teacher_forced_scores', 'teacher report schema/scope differs')
    require(report['status'] == 'observed' and report['inconclusiveReasons'] == [], 'teacher controls did not pass')
    require(report['input'] == input_value and report['inputSHA256'] == model['input_sha256'], 'teacher input differs')
    require(report['verifiedModelAggregateSHA256'] == model['model_sha256'], 'verified model aggregate differs')
    require(report['executableSHA256'] == runtime['darkbloom']['sha256'] and report['metallibSHA256'] == runtime['mlx.metallib']['sha256'], 'reported runtime differs')
    require(Path(report['modelDirectory']).resolve(strict=True) == snapshot.resolve(strict=True), 'reported model directory differs')
    require(report['resolvedBackend'] == cell['backend'] and report['cacheMode'] == 'off' and report['mtpEnabled'] is False and report['concurrency'] == 1, 'ordinary target scoring posture differs')
    require(report['gemmaOptimizations'] == plan['gemma_optimizations'], 'Gemma serving profile differs')
    grant = report['productionGrant']
    require(grant['slotCount'] == 1 and grant['assistantWeightBytes'] == 0 and grant['ramPrefixAllowanceBytes'] == 0, 'production grant posture differs')
    require(type(grant['grantBytes']) is int and grant['grantBytes'] == report['kvCapacityBytes'] > 0, 'production capacity differs')
    diagnostic = report['diagnostic']
    require(diagnostic == report['repeatedDiagnostic'] and report['plainTop1'] == diagnostic['top1'], 'plain/diagnostic/repeat output differs')
    count = model['continuation_tokens']
    require(len(report['plainTop1']) == len(diagnostic['records']) == count, 'incomplete scoring sequence')
    activity = report['activity']
    require(len(activity) == 3 and activity[0] == activity[1] == activity[2], 'three identical control activities required')
    require(type(activity[0]['prefillChunks']) is int and activity[0]['prefillChunks'] > 0 and activity[0]['decodeForwards'] == count - 1, 'extra/missing model forwards')
    for index, record in enumerate(diagnostic['records']):
        require(record['index'] == index and record['contextLength'] == model['prompt_tokens'] + index and record['forcedToken'] == input_value['continuation'][index], 'score record context differs')
        require(record['argMaxID'] == report['plainTop1'][index] and record['nanCount'] == record['infiniteCount'] == 0, 'invalid score IDs or nonfinite counts')
        bits = [record[key] for key in ('argMaxValueBits', 'forcedTokenValueBits', 'logSumExpBits', 'forcedLogProbabilityBits', 'nllBits', 'topTwoMarginBits')] + record['topTwoValueBits']
        require(all(type(value) is int and 0 <= value <= 0xffffffff and math.isfinite(struct.unpack('!f', struct.pack('!I', value))[0]) for value in bits), 'nonfinite score bits')
    require(finite_number(report['meanForcedTokenNLL'], -1e30, 1e30), 'finite mean NLL required')


def check_previous(root, plan, cell, binding, binding_sha, expected_command, expected_environment):
    output = root / 'results' / cell['id']
    summary = read_json(output / 'summary.json')
    require(summary.get('schema') == 2 and summary.get('status') == 'observed' and summary.get('cell') == cell['id'], 'predecessor did not pass')
    require(summary.get('binding_sha256') == binding_sha and summary.get('plan_sha256') == binding['plan_sha256'], 'predecessor identity differs')
    require(set(summary.get('files', {})) == REQUIRED_FILES, 'complete predecessor receipt/report inventory required')
    for relative, expected in summary['files'].items():
        checked_file(output / relative, expected)
    require(read_json(output / 'binding.json') == binding, 'predecessor binding differs')
    command = read_json(output / 'command.json')
    require(command['argv'] == expected_command and command['environment'] == expected_environment, 'predecessor command/environment differs')
    process_file_checks(output, expected_command)
    for name in ('readiness-probe', 'foundation-probe'):
        process_file_checks(output / name)
    readiness_checks(read_json(output / 'readiness.json'), binding)
    home = output / 'fixture-home'
    require(Path(read_json(output / 'foundation-home.json')['foundation_home']).resolve() == home.resolve(), 'predecessor Foundation home differs')
    model = plan['models'][cell['model']]
    snapshot = home / '.cache/huggingface/hub' / ('models--' + model['model_id'].replace('/', '--')) / 'snapshots/local'
    validate_snapshot(model, snapshot)
    checked_file(output / 'provider.toml', plan['files'][model['config']])
    report_checks(read_json(output / 'report.json'), model, cell, binding, read_json(root / model['input']), snapshot, plan)
