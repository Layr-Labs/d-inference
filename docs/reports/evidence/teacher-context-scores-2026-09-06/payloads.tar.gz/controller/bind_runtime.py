"""Bind a reviewed local artifact without launching it or contacting the target host."""
from pathlib import Path
import argparse
import copy
import json

from common import ROOT, checked_file, digest, identity, read_json, require
from controller import plan_inputs
from runtime_identity import runtime_files


def candidate_binding(template, artifact_root, manifest_path, review_path, review_sha256,
                      remote_artifact_root, remote_manifest_path):
    require(template.get('state') == 'awaiting_peer_review' and template.get('runtime') is None,
            'fresh unbound template required; existing execution bindings are immutable')
    for value in (remote_artifact_root, remote_manifest_path):
        require(Path(value).is_absolute() and '..' not in Path(value).parts, 'absolute reviewed remote path required')
    require(str(remote_manifest_path) != str(remote_artifact_root), 'runtime and manifest paths must differ')
    checked_file(review_path, identity(review_path))
    require(digest(review_path) == review_sha256, 'root review receipt hash differs')
    review = read_json(review_path)
    manifest_identity = identity(manifest_path)
    checked_file(manifest_path, manifest_identity)
    manifest = read_json(manifest_path)
    expected_source = template['expected_runtime_source']
    require(manifest.get('source') == expected_source, 'artifact source cut differs')
    require(review.get('source') == expected_source, 'root-reviewed source cut differs')
    require(review.get('artifact_manifest_sha256') == manifest_identity['sha256'], 'root review does not bind this artifact manifest')
    modes = template['expected_runtime_modes']
    require(set(manifest.get('files', {})) == set(modes), 'complete canonical runtime inventory differs')
    require(all(manifest['files'][name]['mode'] == mode for name, mode in modes.items()), 'canonical runtime modes differ')
    local = copy.deepcopy(template)
    local['required_metallib_sha256'] = manifest['files']['mlx.metallib']['sha256']
    local['runtime'] = {'artifact_root': str(artifact_root), 'source_manifest': str(manifest_path),
                        'source_manifest_sha256': manifest_identity['sha256'],
                        'source_manifest_identity': manifest_identity, 'files': manifest['files'], 'source': manifest['source']}
    runtime_files(local)
    require(identity(manifest_path) == manifest_identity and digest(review_path) == review_sha256,
            'review or manifest changed during binding')
    candidate = copy.deepcopy(local)
    candidate['runtime']['artifact_root'] = str(remote_artifact_root)
    candidate['runtime']['source_manifest'] = str(remote_manifest_path)
    candidate['runtime_root_review'] = {'receipt_sha256': review_sha256, 'receipt_identity': identity(review_path)}
    candidate['staging_note'] = 'Local artifact bytes verified; remote paths remain unprobed. Root must review the final binding and M5 owner must hand off before staging or execution.'
    # Keep the existing controller's peer-review refusal active. This helper cannot approve a launch.
    require(candidate['state'] == 'awaiting_peer_review', 'binding preparation may not approve execution')
    return candidate


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--artifact-root', type=Path, required=True)
    parser.add_argument('--artifact-manifest', type=Path, required=True)
    parser.add_argument('--root-review', type=Path, required=True)
    parser.add_argument('--root-review-sha256', required=True)
    parser.add_argument('--remote-artifact-root', required=True)
    parser.add_argument('--remote-manifest', required=True)
    parser.add_argument('--output', type=Path, required=True)
    arguments = parser.parse_args()
    plan = plan_inputs()
    template = read_json(ROOT / 'binding-template.json')
    require(template['plan_sha256'] == digest(ROOT / 'plan.json'), 'template plan differs')
    require(template['expected_runtime_source'] == plan['runtime_source_required'] == read_json(ROOT / 'source-cut.json'), 'prepared source cut differs')
    candidate = candidate_binding(template, arguments.artifact_root, arguments.artifact_manifest,
                                  arguments.root_review, arguments.root_review_sha256,
                                  arguments.remote_artifact_root, arguments.remote_manifest)
    with arguments.output.open('x') as output:
        json.dump(candidate, output, indent=2, allow_nan=False)
        output.write('\n')
    print(json.dumps({'state': candidate['state'], 'binding_candidate_sha256': digest(arguments.output),
                      'runtime_launched': False, 'remote_paths_probed': False}))


if __name__ == '__main__':
    main()
